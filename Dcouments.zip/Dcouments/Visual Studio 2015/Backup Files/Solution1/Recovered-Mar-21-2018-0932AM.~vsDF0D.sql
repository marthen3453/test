select blocking_session_id, wait_time, wait_type, last_wait_type, * from sys.dm_exec_requests

select * from sys.dm_exec_query_memory_grants order by requested_memory_kb desc

sp_Who


select * from sys.dm_exec_requests cross apply sys.dm_exec_sql_text(sql_handle) where session_id = 59

select * from sys.dm_exec_sessions where session_id =58


select * from sys.dm_exec_connections where session_id =58

select WAIT_TIME, * From sys.dm_exec_requests cross apply sys.dm_exec_sql_text(sql_handle) where command <> 'WAITFOR' and session_ID <> @@SPID

select * from sys.dm_exec_requests where last_wait_type = 'RESOURCE_SEMAPHORE' order by wait_time

select * from sys.dm_os_wait_stats where wait_type = 'RESOURCE_SEMAPHORE'

SELECT * FROM sys.dm_exec_query_resource_semaphore