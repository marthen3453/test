select blocking_session_id, wait_time, wait_type, last_wait_type, * from sys.dm_exec_requests 

select * from sys.dm_exec_query_memory_grants order by requested_memory_kb desc
