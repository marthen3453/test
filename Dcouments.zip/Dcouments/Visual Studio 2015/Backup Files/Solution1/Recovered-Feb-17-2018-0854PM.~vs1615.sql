
select top 25 SOC_SECURITY_NUM, * from S_CONTACT where SOC_SECURITY_NUM is not null 