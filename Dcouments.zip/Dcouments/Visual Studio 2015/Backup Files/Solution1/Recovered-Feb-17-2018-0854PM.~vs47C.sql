backup database [AsNetDefinitionModel]
to disk = 'F:\MSSQL\BACKUP\F_MP04\BACKUP\AsNetDefinitionModel.BAK'
with stats = 10, copy_only, compression

backup database [EFREEDOMAS]
to disk = 'F:\MSSQL\BACKUP\F_MP04\BACKUP\EFREEDOMAS.BAK'
with stats = 10, copy_only, compression

