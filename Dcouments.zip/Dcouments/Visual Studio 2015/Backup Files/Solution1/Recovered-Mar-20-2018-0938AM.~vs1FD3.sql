select * from sys.dm_io_pending_io_requests order by io_pending_ms_ticks desc
