select * from sys.dm_exec_query_memory_grants order by requested_memory_kb desc


sp_who