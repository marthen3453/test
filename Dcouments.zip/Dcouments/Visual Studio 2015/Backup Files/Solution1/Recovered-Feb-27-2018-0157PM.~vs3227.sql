select object_name, counter_name, instance_name, cntr_value as counter_value 
from sys.dm_os_performance_counters 
where 
	(
		object_name LIKE '%Memory%' 
		and 
			(
				counter_name LIKE 'Target Server Memory%'
				OR 
				counter_name LIKE 'Total Server Memory%'
			)
	)
	or 
	(	object_name LIKE '%Memory%' 
		and 
			(	counter_name LIKE 'Target Node Memory%'
				OR
				counter_name LIKE 'Total Node Memory%'
			)
	)
	or counter_name = 'Page life expectancy' 
--Give you total target and page life. Target being less than total, good from a RAM persepctive. SQL can use up to a certain total and it hasn't surpassed total.
--PLE ... whta's the standard. No min memory set, target memory/4 multiple by 300 ... so 9GB/4 * 300 = 675 seconds. 15min is OK. If sitting at 300, target and total should be equal. OVER course of day


select * from sys.dm_io_pending_io_requests order by io_pending_ms_ticks desc


select * from sys.dm_exec_query_memory_grants order by requested_memory_kb desc


select * from sys.dm_exec_query_plan(0x050007002F75FB6B30BD69040100000001000000000000000000000000000000000000000000000000000000)


select name, value, value_in_use, ((CONVERT(INT, value_in_use)/1024)/4*300) AS IdealPLE from sys.configurations where name in ('max server memory (MB)', 'min server memory (MB)')

select total_physical_memory_kb, available_physical_memory_kb, system_memory_state_desc  from sys.dm_os_sys_memory


declare @value int
select @value = cntr_value 
from sys.dm_os_performance_counters 
where object_name LIKE '%Buffer Manager%' and counter_name = 'Lazy writes/sec'
waitfor delay '00:00:01'
select cntr_value -@value as lazy_writes_per_second
from sys.dm_os_performance_counters 
where object_name like '%Buffer Manager%' and counter_name = 'Lazy writes/sec'

IF LEFT(CAST(SERVERPROPERTY('ProductVersion') As Varchar),2)<'11'
BEGIN
/*2008_R2 and lower*/
	EXECUTE ('SELECT type, name, memory_node_id 
	, sum(single_pages_kb +multi_pages_kb +
	+ virtual_memory_committed_kb 
	+ awe_allocated_kb 
	+ shared_memory_committed_kb) AS TotalKB
	FROM sys.dm_os_memory_clerks
	GROUP BY type, name, memory_node_id
	ORDER BY TotalKB DESC');
END
ELSE
/*2012 and up*/
BEGIN
	EXECUTE ('SELECT type, name, memory_node_id
	, sum(pages_kb +
	+ virtual_memory_committed_kb 
	+ awe_allocated_kb 
	+ shared_memory_committed_kb) AS TotalKB
	FROM sys.dm_os_memory_clerks
	GROUP BY type, name, memory_node_id
	ORDER BY TotalKB DESC');
END

  


SELECT� 
��� sc.name as schema_name,� 
��� so.name as object_name,� 
��� si.name as index_name 
FROM sys.partitions AS p 
INNER JOIN sys.objects as so on� 
�� p.object_id=so.object_id 
INNER JOIN sys.indexes as si on� 
��� p.index_id=si.index_id and� 
��� p.object_id=si.object_id 
INNER JOIN sys.schemas AS sc on� 
��� so.schema_id=sc.schema_id 
WHERE hobt_id = 72057594054377472; 

GO �


select top 10 total_elapsed_time/execution_count as [average_exec_time], * from sys.dm_exec_query_stats cross apply sys.dm_exec_sql_text(sql_handle) where execution_count > 1 order by total_elapsed_time/execution_count desc 
/*Look execution count. Look at execution time minus creation and shows how long its run between those few hours. Gives us a time window and in that time window
it executed soo many times. Executions per sec for example, 2016-06-28 03:50:17.307 - 2016-06-28 07:54:33.340 = about 4 hrs for total time frame. 4 * 60 sec * 60 = 14,400. Execution count / 14,400 = 0.0177 IS executions PER SECOND
Average exec time is in MICRO SECONDS*/
