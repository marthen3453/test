select object_name, counter_name, instance_name, cntr_value as counter_value 
from sys.dm_os_performance_counters 
where 
	(
		object_name LIKE '%Memory%' 
		and 
			(
				counter_name LIKE 'Target Server Memory%'
				OR 
				counter_name LIKE 'Total Server Memory%'
			)
	)
	or 
	(	object_name LIKE '%Memory%' 
		and 
			(	counter_name LIKE 'Target Node Memory%'
				OR
				counter_name LIKE 'Total Node Memory%'
			)
	)
	or counter_name = 'Page life expectancy' 
--Give you total target and page life. Target being less than total, good from a RAM persepctive. SQL can use up to a certain total and it hasn't surpassed total.
--PLE ... whta's the standard. No min memory set, target memory/4 multiple by 300 ... so 9GB/4 * 300 = 675 seconds. 15min is OK. If sitting at 300, target and total should be equal. OVER course of day
