update STATISTICS dbo.S_SRV_REQ with fullscan 
