EXEC sp_MSforeachdb 'USE ? 
select ''?'' as db, ao.name, s.name
from sys.all_objects ao 
inner join sys.schemas s on ao.schema_id = s.schema_id    
where s.name not in (''dbo'', ''sys'', ''INFORMATION_SCHEMA'',''smart_admin'')'
go


EXEC sp_MSforeachdb 'USE ? 
SELECT ''?'' as db, [name] as SchemaName
      ,[schema_id]
      ,[principal_id]
  FROM [sys].[schemas] where schema_id > 16393'
go

EXEC sp_MSforeachdb 'USE ? 
SELECT a.[name] as endpoint
      ,a.[endpoint_id]
      ,a.[principal_id]
      ,b.[name] as principal
      
  FROM [msdb].[sys].[endpoints] a 
  inner join [msdb].[sys].[sql_logins] b on a.principal_id = b.principal_id
  where b.[name] not in (''sfsa'', ''sa'')'

go

use [master]

SELECT name,
owner_sid,
SUSER_SNAME(owner_sid) as dbowner
FROM sys.databases  where SUSER_SNAME(owner_sid) not in ('sfsa', 'sa')

go

use [msdb]

SELECT name,
owner_sid,
SUSER_SNAME(owner_sid) as jobowner
FROM sysjobs_view  where SUSER_SNAME(owner_sid) not in ('sfsa', 'sa')

go