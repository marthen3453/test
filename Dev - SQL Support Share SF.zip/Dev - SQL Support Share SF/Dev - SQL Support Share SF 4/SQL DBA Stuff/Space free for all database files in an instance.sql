----Space free for all database files in an instance
DECLARE @DB_FileSize TABLE 
(
FileID int
,[FileGroupID] int
,TotalExtents int
,ExtentsUsed int
,name varchar(50)
,[FileName] varchar(200)
)


INSERT INTO @DB_FileSize (FileID, [FileGroupID], TotalExtents, ExtentsUsed, Name, [FileName])
EXECUTE sp_MSforeachdb 'USE [?]; dbcc showfilestats';

select DBF.Name
	  ,[FileName]
	  ,(TotalExtents * 64)/1024 AS SpaceReserved_MB
	  ,(ExtentsUsed * 64)/1024 AS SpaceUsed_MB
	  ,((TotalExtents - ExtentsUsed)*64)/1024 AS SpaceFree_MB
	  ,Ceiling(cast(TotalExtents - ExtentsUsed AS Decimal) / CAST(TotalExtents AS Decimal) * 100) AS Percent_Free
	  ,FG.Name AS [FileGroup]
from @DB_FileSize AS DBF
INNER JOIN sys.filegroups AS FG ON FG.data_space_id = DBF.[FileGroupID]
WHERE DBF.NAME not in ('master', 'modeldev', 'MSDBdata', 'SF_SQL_Admin')
or DBF.name LIKE 'temp%'
order by NAME, Percent_Free



----Space free for all database files in an instance
---- Removed Tempdev
DECLARE @DB_FileSize TABLE 
(
FileID int
,[FileGroupID] int
,TotalExtents int
,ExtentsUsed int
,name varchar(50)
,[FileName] varchar(200)
)


INSERT INTO @DB_FileSize (FileID, [FileGroupID], TotalExtents, ExtentsUsed, Name, [FileName])
EXECUTE sp_MSforeachdb 'USE [?]; dbcc showfilestats';

select DBF.Name
	  ,[FileName]
	  ,(TotalExtents * 64)/1024 AS SpaceReserved_MB
	  ,(ExtentsUsed * 64)/1024 AS SpaceUsed_MB
	  ,((TotalExtents - ExtentsUsed)*64)/1024 AS SpaceFree_MB
	  ,Ceiling(cast(TotalExtents - ExtentsUsed AS Decimal) / CAST(TotalExtents AS Decimal) * 100) AS Percent_Free
	  ,FG.Name AS [FileGroup]
from @DB_FileSize AS DBF
INNER JOIN sys.filegroups AS FG ON FG.data_space_id = DBF.[FileGroupID]
WHERE DBF.NAME not in ('master', 'modeldev', 'MSDBdata', 'SF_SQL_Admin')
and DBF.name NOT LIKE 'tempdev%'
order by NAME, Percent_Free
