select * from 
	(
	SELECT [Database Name] = DB_NAME(database_id),
		   [Size in GB] = CAST( (((SUM(Size)* 8) / 1024.0)/1024) AS DECIMAL(18,2) )
	FROM   sys.master_files
	-- Uncomment if you need to query for a particular database
	WHERE      database_id > 4
	and database_id != DB_ID('SF_SQL_Admin')
	and type_desc = 'rows'
	GROUP BY      (DB_NAME(database_id)), type_Desc
	) AS A
WHERE [Size in GB] > 100 