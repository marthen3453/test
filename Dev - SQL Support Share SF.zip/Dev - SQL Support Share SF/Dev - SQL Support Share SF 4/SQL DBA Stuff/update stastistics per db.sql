--Update Stats -- Connect to each DB
--sp_msforeachtable 'update statistics ? with fullscan'

--legacy
--published
--staging
--systemdb
