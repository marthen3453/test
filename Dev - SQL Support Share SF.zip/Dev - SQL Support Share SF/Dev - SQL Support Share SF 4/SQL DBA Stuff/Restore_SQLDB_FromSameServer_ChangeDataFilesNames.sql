--Restore from Same Server and Changing  File Names
restore database StateFarmT_SystemDB from disk = 'H:\IM4676043\StateFarmD_SystemDB_COPYONLY_COMP.BAK' 
with 
MOVE 'p_StateFarmD_SystemDB' TO         'I:\mssql\system\StateFarmT_SystemDB.mdf', 
MOVE 's_StateFarmD_SystemDB_DATA_01' TO 'I:\MSSQL\DATA\StateFarmT_SystemDB_1.ndf', 
MOVE 's_StateFarmD_SystemDB_DATA_02' TO 'I:\MSSQL\DATA\StateFarmT_SystemDB_2.ndf', 
MOVE 's_StateFarmD_SystemDB_DATA_03' TO 'I:\MSSQL\DATA\StateFarmT_SystemDB_3.ndf', 
MOVE 's_StateFarmD_SystemDB_DATA_04' TO 'I:\MSSQL\DATA\StateFarmT_SystemDB_4.ndf', 
MOVE 'StateFarmD_SystemDB_log_1' TO     'G:\mssql\logs\StateFarmT_SystemDB.ldf', 
stats = 10
