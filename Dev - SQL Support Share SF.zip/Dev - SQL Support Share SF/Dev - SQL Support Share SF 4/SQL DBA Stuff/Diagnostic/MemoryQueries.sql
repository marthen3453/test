
--SQL text , Adhob object type
SELECT TOP(100) * FROM sys.dm_Exec_cached_plans
CROSS APPLY sys.dm_exec_sql_text(plan_handle)
WHERE cacheobjtype = 'Compiled Plan'
AND objtype = 'Adhoc' AND usecounts = 1
AND size_in_bytes < 5242880 ORDER BY size_in_bytes DESC 

--Configure Optimize Ad hoc WOrkloads
sp_configure 'show advanced options', 1
reconfigure
sp_configure 'optimize for ad hoc workloads'


-- TOP 10 Memory Clerks SinglePages + Multi Pages + Virtual Memory Committed
select top 10 * from sys.dm_os_memory_clerks ORDER by single_pages_kb+multi_pages_kb+virtual_memory_committed_kb DESC

--Virtual Memory Reserved and committed
SELECT [type],
 memory_node_id,
 multi_pages_kb,
 virtual_memory_reserved_kb,
 virtual_memory_committed_kb,
 awe_allocated_kb
FROM sys.dm_os_memory_clerks
ORDER BY virtual_memory_reserved_kb DESC;
Read more at http://guides.programming4.us/technology/sql-server-2012---sql-server-memory---clerks,-caches,-and-the-buffer-pool-.aspx#AorkcasO7d02ykOC.99