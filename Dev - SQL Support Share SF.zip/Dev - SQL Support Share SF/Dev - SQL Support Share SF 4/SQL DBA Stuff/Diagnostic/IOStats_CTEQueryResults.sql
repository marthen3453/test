with cte as
(
SELECT DateDiff(ss, Min(collection_time), max(collection_time)) as seconds, max(num_of_bytes_read)  - min(num_of_bytes_read) as bytes_read, max(num_of_bytes_written)  - min(num_of_bytes_written) as bytes_written, [filename]
  FROM [SF_SQL_Admin].[dbo].[IOStats]
  group by [filename] )
  SELECT Bytes_read/seconds AS BytesReadPerSecond, bytes_written/seconds AS ByteWrittenPerSecond, FILEName FROM CTE 
  ORDER BY FileName ASC
  