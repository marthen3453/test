SELECT 
	b.host_name
,	b.program_name
,	MIN(b.login_time) AS OldestSessionLoginTime
,	COUNT(*) AS ProgramConnectionCount
,	SUM(b.memory_usage) * 8 AS ProgramMemoryTotalUsage
FROM 
	sys.dm_db_session_space_usage a
	INNER join
	sys.dm_exec_sessions b
		ON a.session_id = b.session_id
	INNER JOIN
	sys.sysprocesses c
		ON a.session_id = c.spid
	CROSS APPLY
	sys.dm_exec_sql_text(c.[sql_handle]) d
WHERE
	is_user_process = 1
GROUP BY
	b.host_name, b.program_name
ORDER BY
	5 DESC
