/* 
QUERY #1:
Description: This query will display the configured min and max server memory settings.  Understanding these values is important as they create a ceiling and a floor for Buffer Pool memory (SQL 2005+).  In SQL 2012, SQL CLR memory is also managed by the min/max setting.  SQL Server uses dynamic memory allocation and will grow to the max value as needed.  It will also never grow below the min setting once that it reached.  If min=max, you are effectively using fixed memory settings as the server will not drop below/above the min/max setting once reached.
Ideal Value: This setting is dependent on the type of system running and the available RAM.  If LIPM is set, then consider setting Max such that the OS will have 2-4 GB available.  
Units of Measure: MB
*/
select name, value, value_in_use from sys.configurations where name in ('max server memory (MB)', 'min server memory (MB)')

/* 
QUERY #2:
Description: This query will provide information regarding Total Physical Memory and Available Physical Memory in KB.  In addition, the query will provide a status from the OS as to whether physical memory or high or low:

Available physical memory is high
Available physical memory is low

As mentioned above, the Windows OS uses Memory API callbacks to allow applications to check with the OS to determine if it is experiencing memory pressure.  This query provides visibility into the state as perceived by the OS.  Typically, a Low notification will result in the buffer pool and other clerks trimming memory.  The SQL Server system impact due to this notification is increased IO, reduced PLE and generally reduces performance.
Ideal Value: Available physical memory is high
Units of Measure: MB
*/
select total_physical_memory_kb, available_physical_memory_kb, system_memory_state_desc  from sys.dm_os_sys_memory  

/* 
QUERY #3:
Description: This query returns Target/Total Memory (MB) and PLE in Seconds.  PLE is shown as an aggregate as well as per NUMA node.  It is entirely possible for one NUMA node to have a different PLE due to the pages being used within that NUMA node.  Target/Total memory indicate ideal/current memory levels respectively.  Target and Total are used by the engine to determine when to grow or trim buffer pool and other memory clerks. Min and Max memory settings will directly impact these counters.
Ideal Value: PLE Should be >= ((LESSER OF MAX_MEMORY AND PHYSICAL_RAM_IN_GB) / 4 ) * 300.  Target is an automatically determined value and should reflect the minimum of MAX SERVER MEMORY and TOTAL Physical Memory (or close).  Total Server Memory should ideally be as close to Target as possible.  A larger the gap indicates the system just started and has not ramped up or resources are being wasted.  Ideally, you want Total to be as close to Target while Maximizing PLE.
Units of Measure: Memory = KB; PLE = Seconds
*/
select object_name, counter_name, instance_name, cntr_value as counter_value 
from sys.dm_os_performance_counters 
where (object_name = 'SQLServer:Memory Manager' and (counter_name in ('Target Server Memory (KB)', 'Total Server Memory (KB) ')) or (object_name = 'SQLServer:Memory Node' and counter_name in ('Target Node Memory (KB)', 'Total Node Memory (KB)'))) or counter_name = 'Page life expectancy'

/* 
QUERY #4:
Description: This query will return the Lazy Writes Per Second Performance Counter.  This counter is an incremental counter, so you need to query, pause and query again to get the value in Per Seconds.  The Lazy Writer thread wakes up periodically to manage the free page list.  When it determines free pages are low, it will work through the buffer pool and add clean pages to the free page list based on a LRU algorithm.  Dirty pages are also added but are flushed before being added to the free page list.  This process should not be confused with the checkpoint process which is focused on minimizing recovery time.  
Ideal Value: The ideal value for this counter is 0.  Anything > 0 sustained should be looked into as it means SQL Server is trying to flush pages to disk to make room for new pages being read into the buffer pool.
 */
declare @value int
select @value = cntr_value 
from sys.dm_os_performance_counters 
where object_name = 'SQLServer:Buffer Manager' and counter_name = 'Lazy writes/sec'
waitfor delay '00:00:01'
select cntr_value -@value as lazy_writes_per_second
from sys.dm_os_performance_counters 
where object_name = 'SQLServer:Buffer Manager' and counter_name = 'Lazy writes/sec'

/* 
QUERY #5:
Description: This query collects counts of the pages in the buffer pool per database.
Ideal Value: There is no ideal value you here.  The intent is to give you a feel as to the largest consumers of the buffer pool.  If you are hitting memory limitation and cannot increase RAM, you can look into various mechanisms to reduce the number of pages consumed by one database.
*/
select db_name(database_id) as Database_Name, count(database_id) as Buffer_Page_Count from sys.dm_os_buffer_descriptors where database_id <> 32767 group by database_id order by count(database_id) desc

/*
QUERY #6:
Description: This query provides a list of the users of memory by type (or Clerk). 
Ideal Value: Ideally, MEMORYCLERK_SQLBUFFERPOOL and CACHESTORE_OBJCP should be in the top 3.  If these are not and others are, it might indicate a need to dive deeper into the system.  For example, if OBJECTSTORE_LOCK_MANAGER is in the top 3, you might want to dig deeper into the locking mechanism of the application if you are experiencing problems.
*/
SELECT type, name, memory_node_id
, sum(single_pages_kb +multi_pages_kb +
+ virtual_memory_committed_kb 
+ awe_allocated_kb 
+ shared_memory_committed_kb) AS TotalKB
FROM sys.dm_os_memory_clerks
GROUP BY type, name, memory_node_id
ORDER BY TotalKB DESC

/*
QUERY #7:
Description: This query provides a historic list of the Memory Notifications from the OS.
Ideal Value: Ideally, RESOURCE_MEMPHYSICAL_HIGH or RESOURCE_MEM_STEADY should show up in all rows.
*/
SELECT top 10 DATEADD (ss, (-1 * ((cpu_ticks / CONVERT (float, ( cpu_ticks / ms_ticks ))) - [timestamp])/1000), GETDATE()) AS Event_Time, CAST(record as XML).value('(/Record/ResourceMonitor/Notification)[1]', 'varchar(max)') as Type, CAST(record as XML).value('(/Record/ResourceMonitor/IndicatorsProcess)[1]', 'int') as Indicators_Process, CAST(record as XML).value('(/Record/ResourceMonitor/IndicatorsSystem)[1]', 'int') as Indicators_System, CAST(record as XML).value('(/Record/MemoryRecord/AvailablePhysicalMemory)[1]', 'bigint') AS Available_Physical_Memory_KB, CAST(record as XML).value('(/Record/MemoryRecord/TotalPhysicalMemory)[1]', 'bigint') AS Total_Physical_Memory_KB FROM sys.dm_os_ring_buffers CROSS JOIN sys.dm_os_sys_info WHERE ring_buffer_type = 'RING_BUFFER_RESOURCE_MONITOR' AND (CAST(record as XML).value('(/Record/ResourceMonitor/IndicatorsProcess)[1]', 'int')  <> 0 or CAST(record as XML).value('(/Record/ResourceMonitor/IndicatorsSystem)[1]', 'int') <> 0) ORDER BY Event_Time DESC;
