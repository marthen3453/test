-- Mapping Users in a DB to login names. Also shows default Schema

SELECT s.name as [Login Name], d.name as [User Name],
     default_schema_name as [Default Schema]
   FROM sys.database_principals d
      LEFT JOIN sys.server_principals s
   ON s.sid= d.sid
    WHERE d.type_desc = 'SQL_USER';