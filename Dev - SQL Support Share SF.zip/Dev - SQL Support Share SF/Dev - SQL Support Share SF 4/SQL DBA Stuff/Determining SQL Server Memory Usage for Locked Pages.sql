select physical_memory_in_use_kb as 'Total Memory Allocations (KB)',
      locked_page_allocations_kb as 'Locked Page Allocations (KB) ',
      (physical_memory_in_use_kb - locked_page_allocations_kb) * 1024 as 'Working Set (Bytes) '
      from sys.dm_os_process_memory
