--Parameters
DECLARE	
	@MinReservedMemoryPerInstancePreferenceMB INT = 4096
	,@ImplementMaxMemoryChange BIT = 1

--AS

SET NOCOUNT ON
--Local Variables
DECLARE 
	 @Server_Name NVARCHAR(256)
	,@Instance_Name NVARCHAR(256)
	,@Instance_Count TINYINT
    ,@TotalMemory INT
	,@MinMemory INT
	,@MaxMemory INT
	,@PossibleMaxMemoryMB INT
    ,@OSReservedMemoryMB INT
	,@ErrorMessage NVARCHAR(2000)
	,@SQL NVARCHAR(2000)
	,@AdvancedOptions BIT
    ,@LowMemoryMB int

DECLARE @Memory TABLE
(INDEX_Val int NOT NULL
,NAME sysname NOT NULL
,Internal_Value varchar(MAX)
,Character_Value varchar(MAX)
)

DECLARE @GetInstances TABLE
( Value nvarchar(100),
 InstanceNames nvarchar(100),
 Data nvarchar(100))

BEGIN TRY

	Insert into @GetInstances
	EXECUTE xp_regread
	  @rootkey = 'HKEY_LOCAL_MACHINE',
	  @key = 'SOFTWARE\Microsoft\Microsoft SQL Server',
	  @value_name = 'InstalledInstances'

	Select @Instance_Count = COUNT(*) from @GetInstances


	INSERT INTO @Memory
	exec master.dbo.xp_msver 'PhysicalMemory'



	SELECT
		 @Server_Name = CAST(SERVERPROPERTY('MachineName') AS NVARCHAR(256))
		,@Instance_Name  = CAST(SERVERPROPERTY('InstanceName') AS NVARCHAR(256))
		,@TotalMemory =  CAST((SELECT Internal_Value FROM @Memory) AS INT) 
		,@MinMemory = CAST((SELECT cfg.value_in_use FROM sys.configurations AS cfg WHERE name = 'min server memory (MB)') AS INT)
		,@MaxMemory = CAST((SELECT cfg.value_in_use FROM sys.configurations AS cfg WHERE name = 'max server memory (MB)') AS int)


	--Determine OS reserved memory
	--1 GB (by default) + 1 GB for every 4 GB of memory up to 16 GB + 1 GB for every 8 GB of memory over 16GB
	SELECT @OSReservedMemoryMB = 
		1024 + --Minimum 2GB of memory for OS
		(CASE
			WHEN @TotalMemory < 16384 THEN
				@TotalMemory / 4.0
			ELSE
				4096 --4GB
		END) +
		(CASE
			WHEN @TotalMemory > 16384 THEN
				(@TotalMemory - 16384) / 8.0
			ELSE
				0
		END)

	--Check to determine if the server may not have enough memory
	IF (@TotalMemory - @OSReservedMemoryMB - (@Instance_Count * @MinReservedMemoryPerInstancePreferenceMB)) < 0
	BEGIN
		SELECT @LowMemoryMB = ABS((@TotalMemory - @OSReservedMemoryMB - (@Instance_Count * @MinReservedMemoryPerInstancePreferenceMB)))
		RAISERROR('Server %s only has %d MB of memory allocated to it.  The OS requires %d MB.  There are %d instances and you stated you wish to leave at least %d MBs per instace. You need a minimum of %d MB of memory added.', 16, 1, @Server_Name, @TotalMemory, @OSReservedMemoryMB, @Instance_Count, @MinReservedMemoryPerInstancePreferenceMB, @LowMemoryMB)
	END


	-- Determine the highest possible max memory setting for this instance
	-- Total Memory - OS reserved - Min required for other instances = Highest possible Mem setting for this instance
	SELECT @PossibleMaxMemoryMB = @TotalMemory - @OSReservedMemoryMB - ((@Instance_Count - 1) * @MinReservedMemoryPerInstancePreferenceMB)


	SELECT
		 @Server_Name AS Server_Name
		,@Instance_Name AS Instance_Name
		,@Instance_Count AS Instance_Count
		,@TotalMemory AS Total_Memory
		,@OSReservedMemoryMB AS OC_Reserved_Memory_MB
		,(@Instance_Count * @MinReservedMemoryPerInstancePreferenceMB) AS Other_Instance_Min_Memory_Reserve
		,@MaxMemory AS Current_Max_Memory_Setting
		,@PossibleMaxMemoryMB AS Highest_Possible_Max_Memory


	SELECT @ErrorMessage = 
		CASE
			WHEN @MaxMemory > (@PossibleMaxMemoryMB * 1.1) THEN
				'Current Max Memory is above the highest possible setting.  Recommend evaluating a lower Max Memory setting immediately!!'
			ELSE
				NULL
		END

	IF @ErrorMessage IS NOT NULL AND @ImplementMaxMemoryChange = 0
	BEGIN
		RAISERROR(@ErrorMessage, 16, 1)
	END

	IF @ImplementMaxMemoryChange = 1 
	BEGIN
		IF @MaxMemory <> @PossibleMaxMemoryMB
		BEGIN
			--Determine if Advanced options need enabled
			SELECT @AdvancedOptions = CAST(c.value AS BIT) FROM sys.configurations c WHERE c.name = 'show advanced options'

			IF @AdvancedOptions = 0
			BEGIN
				SET @SQL = 'EXEC sys.sp_configure N''show advanced options'', N''1''  RECONFIGURE WITH OVERRIDE'
				PRINT @SQL
				EXEC sys.sp_executesql @SQL
			END

			--Update Max Memory Setting
			SET @SQL = 'EXEC sys.sp_configure N''max server memory (MB)'', N''' + CAST(@PossibleMaxMemoryMB AS VARCHAR(10)) + ''' RECONFIGURE WITH OVERRIDE'
			PRINT @SQL
			EXEC sys.sp_executesql @SQL

			SET @SQL = 'RECONFIGURE WITH OVERRIDE'
			PRINT @SQL
			EXEC sys.sp_executesql @SQL

			-- If Advanced Options was disabled at the beginning, then disable it now
			IF @AdvancedOptions = 0
			BEGIN
				SET @SQL = 'EXEC sys.sp_configure N''show advanced options'', N''0''  RECONFIGURE WITH OVERRIDE'
				PRINT @SQL
				EXEC sys.sp_executesql @SQL
			END
		END
		ELSE
		BEGIN
			PRINT 'Max Memory setting matches highest possible setting.  Why are you messing with it???  You''re all good. Get a soda and watch some YouTube.'
		END

	END
END TRY
BEGIN CATCH
	SET @ErrorMessage = ERROR_MESSAGE()
	RAISERROR(@ErrorMessage, 16, 1)
END CATCH
