--SELECT name, physical_name AS CurrentLocation, state_desc
--FROM sys.master_files
--WHERE database_id = DB_ID('StateFarmD_SystemDB');

--ALTER DATABASE StateFarmD_SystemDB SET OFFLINE WITH ROLLBACK IMMEDIATE;
--ALTER DATABASE StateFarmD_SystemDB  SET ONLINE;





--ALTER DATABASE StateFarmD_SystemDB MODIFY FILE ( NAME =p_StateFarmD_SystemDB, FILENAME = 'i:\mssql\system\StateFarmD_SystemDB.mdf');

--ALTER DATABASE StateFarmD_SystemDB MODIFY FILE ( NAME =StateFarmD_SystemDB_log_1, FILENAME = 'g:\mssql\logs\StateFarmD_SystemDB.ldf');



--ALTER DATABASE StateFarmD_SystemDB MODIFY FILE ( NAME =s_StateFarmD_SystemDB_DATA_01, FILENAME = 'I:\MSSQL\DATA\StateFarmD_SystemDB_1.ndf');
--ALTER DATABASE StateFarmD_SystemDB MODIFY FILE ( NAME =s_StateFarmD_SystemDB_DATA_02, FILENAME = 'I:\MSSQL\DATA\StateFarmD_SystemDB_2.ndf');
--ALTER DATABASE StateFarmD_SystemDB MODIFY FILE ( NAME =s_StateFarmD_SystemDB_DATA_03, FILENAME = 'I:\MSSQL\DATA\StateFarmD_SystemDB_3.ndf');
--ALTER DATABASE StateFarmD_SystemDB MODIFY FILE ( NAME =s_StateFarmD_SystemDB_DATA_04, FILENAME = 'I:\MSSQL\DATA\StateFarmD_SystemDB_4.ndf');
