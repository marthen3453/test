if exists(select * from fn_dblog(NULL, NULL) where Operation = 'LOP_PREP_XACT' and [Master DBID] <> 0)

print 'Based on the active part of the transaction log read, there is evidence that this database has participated in cross-database transactions.'

else

print 'Based on the active part of the transaction log read, there is no evidence of this database having participated in cross-database transactions.'
