SELECT 
	database_name
,	AVG(backup_size) AS AvgFullSize
,	AVG(compressed_backup_size) AS AvgCompSize
,	AVG(compressed_backup_size)/AVG(backup_size) AS AvgCompRatio
INTO 
	#CompRatios
FROM 
	msdb..backupset 
WHERE 
	backup_start_date >= '2015/08/05 17:00:00'
	AND
	database_name NOT IN ('master', 'model', 'msdb', 'tempdb', 'SF_SQL_ADMIN')
	AND
	type = 'D'
GROUP BY
	database_name

SELECT 
	database_name, AvgFullSize/1024/1024/1024 AS AvgFullSizeGB, AvgCompSize/1024/1024/1024 AS AvgCompSizeGB, AvgCompRatio 
FROM 
	#CompRatios

SELECT 
	SUM(AvgCompSize)/1024/1024/1024 AS BackupReqSpaceGB
FROM 
	#CompRatios

DROP TABLE #CompRatios