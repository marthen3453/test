CREATE EVENT SESSION UserTracking on SERVER
    ADD EVENT sqlserver.sql_statement_starting
    (
        ACTION
        (
            sqlserver.nt_username,
            sqlserver.username,
            sqlserver.sql_text,
            sqlserver.database_id,
            sqlserver.client_app_name,
            sqlserver.client_hostname,
            sqlserver.is_system,
            sqlserver.client_pid
        )
        WHERE 
        (
            sqlserver.is_system=0
        )
    ) 
    ADD TARGET
        package0.asynchronous_file_target
        (
            SET filename = 'H:\MSSQL\XEvent\UserTracking.xel',
                max_file_size = 1024,
                max_rollover_files = 10
        )


    WITH
    (
        EVENT_RETENTION_MODE = ALLOW_MULTIPLE_EVENT_LOSS,
        MAX_DISPATCH_LATENCY = INFINITE,
        STARTUP_STATE = OFF
    )
;

--ALTER EVENT SESSION UserTracking ON SERVER STATE = START
--ALTER EVENT SESSION UserTracking ON SERVER STATE = STOP
--DROP EVENT SESSION UserTracking  ON SERVER

