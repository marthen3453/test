SELECT 'Alter Index [' + ind.NAME + '] ON [' + sch.name + '].[' + OBJECT_NAME(ind.OBJECT_ID) + '] Rebuild;'
--ind.name AS IndexName, indexstats.index_type_desc AS IndexType,
--indexstats.avg_fragmentation_in_percent,
--indexstats.page_count
FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) indexstats
INNER JOIN sys.indexes ind ON ind.object_id = indexstats.object_id
INNER JOIN sys.tables tab ON ind.object_id = tab.object_id
INNER JOIN sys.schemas sch ON tab.schema_id = sch.schema_id
	AND ind.index_id = indexstats.index_id
WHERE indexstats.avg_fragmentation_in_percent > 30 AND Page_count > 100--You can specify the percent as you want

