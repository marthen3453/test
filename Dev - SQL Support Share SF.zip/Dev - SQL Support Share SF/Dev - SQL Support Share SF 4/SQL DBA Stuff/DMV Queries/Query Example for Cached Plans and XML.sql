WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/2004/07/showplan' AS sp)
SELECT TOP 100
   QP.query_plan
--   ,n1.RelOp.value('@PhysicalOp', 'nvarchar(256)') AS [Type]
   ,n1.RelOp.value('@EstimateRows', 'nvarchar(256)') AS [EstRows]
FROM
    sys.dm_exec_cached_plans CP
CROSS APPLY sys.dm_exec_sql_text(CP.plan_handle) ST
CROSS APPLY sys.dm_exec_query_plan(CP.plan_handle) QP
CROSS APPLY qp.query_plan.nodes('//sp:RelOp')
    AS n1 ( RelOp )
WHERE
    text LIKE '%HRDATAMART_0002_SFVW%'
AND usecounts > 20
AND n1.RelOp.value('@PhysicalOp', 'nvarchar(256)') = 'Remote Query'
