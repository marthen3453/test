--If the Windows Server Failover Clustering (WSFC) node that hosts an instance of SQL Server with AlwaysOn Availability Groups enabled has WSFC quorum, sys.dm_hadr_cluster returns a row that exposes the cluster name and information about the quorum. If the WSFC node has no quorum, no rows are returned.
--Column names:  cluster_name, quorum_type, quorum_type_desc, quorum_state, quorum_state_desc
select * from sys.dm_hadr_cluster


--AG Members and member type
--If the WSFC node that hosts the local AlwaysOn-enabled instance of SQL Server has WSFC quorum, returns a row for each of the members that constitute the quorum and the state of each of them.
--Column names:  member_name, member_type, member_type_desc, member_state, member_state_desc, number_of_quorum_votes
select * from sys.dm_hadr_cluster_members


--ServerName and SubnetIP

select * from sys.dm_hadr_cluster_networks

--Listner Replica Server Name
select * from sys.dm_hadr_availability_replica_cluster_states

-- Cluster with DB Name, Failover ready and DB joined
select * from sys.dm_hadr_database_replica_cluster_states




--For every instance of SQL Server that hosts an availability replica that is joined to its AlwaysOn availability group, returns the name of the Windows Server Failover Clustering (WSFC) node that hosts the server instance. This dynamic management view has the following uses:
--This dynamic management view is useful for detecting an availability group with multiple availability replicas that are hosted on the same WSFC node, which is an unsupported configuration that could occur after an FCI failover if the availability group is incorrectly configured.
--When multiple SQL Server instances are hosted on the same WSFC node, the Resource DLL uses this dynamic management view to determine the instance of SQL Server to connect to.
--Column names:  ag_resource_id, instance_name, node_name
select * From sys.dm_hadr_instance_node_map

select * from sys.dm_hadr_name_id_map




select * from sys.availability_replicas -- Returns all Availability Group replicas in each Availability Group in your current instance.
select * from sys.availability_read_only_routing_lists -- Returns the read only routing list of each Availability Group replica in an AlwaysOn Availability Group.
select * from sys.dm_hadr_availability_replica_cluster_nodes -- Returns all the Availability Group replicas of the AlwaysOn Availability Groups participating in the cluster.
select * from sys.dm_hadr_availability_replica_cluster_states -- Returns all replicas participating in your Availability Group and its current join state.
select * from sys.dm_hadr_availability_replica_states -- Returns the state and role of each local and remote availability replica participating in the same Availability Group.
select * from sys.fn_hadr_backup_is_preferred_replica -- Returns 1 if the passed parameter database name is the current preferred backup location.
select * from sys.dm_hadr_cluster -- Returns the cluster name and information about the quorum.
select * from sys.dm_hadr_cluster_members -- Returns how many more failures your WSFC cluster can tolerate before losing quorum in a majority node case.

---Always On MSSQLTIPS: 
--https://www.mssqltips.com/sql-server-tip-category/143/alwayson-availability/
