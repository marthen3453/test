Select * From sys.dm_io_virtual_file_stats
Select * From sys.dm_io_pending_io_requests
Select * From sys.dm_io_cluster_shared_drives