--DM_DB Queries



--This DMV returns only 2 columns with information about which indexes are in which group.
select * from sys.dm_db_missing_index_groups


--This DMV returns information about each missing indexes group. It returns info like the estimated average impact or how many seeks, scans and compilations/recompilations would benefit from adding the missing indexes.
select * from sys.dm_db_missing_index_group_stats 


--This DMV returns detailed information about each missing index like table name that is missing an index and CSV�s of columns that the index would be beneficial on.
select * from sys.dm_db_missing_index_details



