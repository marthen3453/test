

select * From sys.dm_exec_requests
--SQL Server Memory Dump File
Select * from sys.dm_server_memory_dumps 

--SQL Services
--SQL Server Service
--Startup, Status what account, Cluster or Not
Select * from sys.dm_server_services 

--Service Registry
--Returns SQL Server Configuration and installtaion information which is stored in the Windows Registry for the current instance of SQL Server
-- Current Version, Path of Master Database, Error Log Files
Select * from sys.dm_server_registry

--Number of Sessions for each User: 
SELECT login_name ,COUNT(session_id) AS session_count 
FROM sys.dm_exec_sessions 
GROUP BY login_name;

--Find Log Running Cursors
USE master;
GO
SELECT creation_time ,cursor_id 
    ,name ,c.session_id ,login_name 
FROM sys.dm_exec_cursors(0) AS c 
JOIN sys.dm_exec_sessions AS s 
   ON c.session_id = s.session_id 
WHERE DATEDIFF(mi, c.creation_time, GETDATE()) > 5;

--Find Idle Sessions that have open transactions
SELECT s.* 
FROM sys.dm_exec_sessions AS s
WHERE EXISTS 
    (
    SELECT * 
    FROM sys.dm_tran_session_transactions AS t
    WHERE t.session_id = s.session_id
    )
    AND NOT EXISTS 
    (
    SELECT * 
    FROM sys.dm_exec_requests AS r
    WHERE r.session_id = s.session_id
    );


