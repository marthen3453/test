select * from sys.dm_exec_connections
select * from sys.dm_exec_sessions
select * from sys.dm_exec_requests
select * from sys.dm_exec_cached_plans
select * from sys.dm_exec_query_plans
select * from sys.dm_exec_sql_text
select * from sys.dm_exec_query_stats
