Select * From sys.dm_os_performance_counters
Select * From sys.dm_os_schedulers
Select * From sys.dm_os_nodes
Select * From sys.dm_os_waiting_tasks
Select * From sys.dm_os_wait_stats