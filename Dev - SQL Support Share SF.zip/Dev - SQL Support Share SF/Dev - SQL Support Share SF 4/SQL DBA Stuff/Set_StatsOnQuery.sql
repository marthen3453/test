SET STATISTICS TIME ON; --Query that you want to set Stats On -- EXEC dbo.Device_LoadDeviceModelFamily @DeviceModelID=4
