/****** Script for SelectTopNRows command from SSMS  ******/
USE msdb
SELECT a.servername,a.domain,a.level100,a.level200,a.skuname,a.version,b.caption00
FROM [msdb].[dbo].[sf_sql_servers_all] a
INNER JOIN [SCCM].[dbo].[Operating_System_DATA] b
ON a.MachineID=b.machineid
WHERE a.SKUNAME LIKE 'Enterprise%'
AND b.caption00 LIKE '%2008%'
AND a.SERVERNAME LIKE 'WPS%'
ORDER BY a.SERVERNAME asc, b.caption00


USE msdb
SELECT DISTINCT a.servername,a.domain,a.level100,a.level200,a.skuname,a.version,b.caption00
FROM [msdb].[dbo].[sf_sql_servers_all] a
INNER JOIN [SCCM].[dbo].[Operating_System_DATA] b
ON a.MachineID=b.machineid
WHERE a.SKUNAME LIKE 'Enterprise%'
AND b.caption00 LIKE '%2008%'
AND a.SERVERNAME LIKE 'WTS%'
