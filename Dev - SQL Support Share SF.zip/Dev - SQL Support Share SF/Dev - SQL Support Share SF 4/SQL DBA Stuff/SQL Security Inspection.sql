DECLARE @Database varchar(256) = 'RSA_CORE_AA'


-- Part 1: SYSADMINS / SERVER ROLES
DECLARE @sa TABLE (ServerRole varchar(512), MemberName varchar(512), MemberSID varchar(128));

INSERT @sa
EXEC sp_helpsrvrolemember;

SELECT ServerRole, MemberName FROM @sa;


-- Part 2: Server level permissions
SELECT name, class_desc, permission_name, state_desc
FROM sys.server_permissions perm
INNER JOIN sys.server_principals prin ON perm.grantee_principal_id = prin.principal_id
ORDER BY name;


-- Part 3: Role Privileges
Declare @UserName VARCHAR(150), @Seq as int, @MaxSeq as int, 
	@sql as varchar(4000), @Privs as varchar (400)

CREATE TABLE [#Permissions] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[Perms2] [varchar] (45),	
	[Type] [varchar] (45),
	[Object] [varchar] (500),
	[Grantee] [varchar] (500),
	[DB] [varchar] (125) )

CREATE TABLE #Users (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[UserName] [varchar] (150),
	[Check] [bit] )

SET @sql =
	'SELECT     TOP 100 PERCENT su.name AS Role
		FROM    ' + @Database + '.dbo.sysusers su INNER JOIN
                ' + @Database + '.dbo.sysmembers sm ON su.uid = sm.groupuid INNER JOIN
        	    ' + @Database + '.dbo.sysusers sysusers_1 ON sm.memberuid = sysusers_1.uid
		GROUP BY su.name
		ORDER BY su.name'

Insert #Users (UserName)
EXECUTE (@sql)

Set @Seq = 1
Set @MaxSeq = (Select max(ID) from #Users)
While @Seq <= @MaxSeq
Begin
	Declare @USeq as int, @MaxUSeq as int

	Set @USeq = 1
	Set @UserName = (Select UserName from #Users where ID = @Seq)

		Set @Sql = 'SELECT     so.name, CASE protecttype WHEN 204 THEN ''GRANT_W_GRANT ''' + Char(13) + 
			'WHEN 205 THEN ''GRANT ''' + Char(13) +
			'ELSE ''BOGUS'''+ Char(13) +
			' END AS Type,' + Char(13) +
			' CASE action WHEN 26 THEN ''REFERENCES'''+ Char(13) +
			' WHEN 178 THEN ''CREATE FUNCTION''' + char(13) +
			' WHEN 193 THEN ''SELECT''' + char(13) +
			' WHEN 195 THEN ''INSERT''' + char(13) +
			' WHEN 196 THEN ''DELETE''' + char(13) +
			' WHEN 197 THEN ''UPDATE''' + char(13) +
			' WHEN 198 THEN ''CREATE TABLE''' + char(13) +
			' WHEN 203 THEN ''CREATE DATABASE''' + char(13) +
			' WHEN 207 THEN ''CREATE VIEW''' + char(13) +
			' WHEN 222 THEN ''CREATE PROCEDURE''' + char(13) +
			' WHEN 224 THEN ''EXECUTE''' + char(13) +
			' WHEN 228 THEN ''BACKUP DATABASE''' + char(13) +
			' WHEN 233 THEN ''CREATE DEFAULT''' + char(13) +
			' WHEN 235 THEN ''BACKUP LOG''' + char(13) +
			' WHEN 236 THEN ''CREATE RULE''' + char(13) +
			' END AS Action, s.name, '''+ @Database +''' as DB' + char(13) +
			' FROM '+ @Database +'.dbo.sysprotects sp INNER JOIN ' + char(13) +
       		        @Database + '.dbo.sysobjects so ON so.id = sp.id INNER JOIN ' + char(13) +
       		        @Database + '.dbo.sysusers s ON sp.uid = s.uid ' + char(13) +
				'WHERE     (s.name = '''+@Username+''')'

	Insert #Permissions (Object, Perms2, Type, Grantee, DB)
		Execute (@Sql)			

	Set @Seq = @Seq+1
Continue
End

SET @sql = 	' SELECT ''GLOBAL DATABASE'', state_desc, permission_name, name, ''' + @Database + '''' + char(13) +
			 ' FROM ' + @Database + '.sys.database_permissions perm' + char(13) +
			 ' INNER JOIN ' + @Database + '.sys.database_principals prin ON prin.principal_id = perm.grantee_principal_id' + char(13) +
			 ' WHERE class_desc = ''DATABASE''' + char(13) +
			 ' AND type_desc = ''DATABASE_ROLE'''
	Insert #Permissions (Object, Perms2, Type, Grantee, DB)
		Execute (@Sql)	

Delete from #Permissions
	where Perms2 = 'Bogus'

Select grantee, type, object From #Permissions

TRUNCATE TABLE #Users
TRUNCATE TABLE #Permissions


--Part 4: Users in Roles
SET @sql = 
	'SELECT TOP 100 PERCENT su.name AS Role, sysusers_1.name AS UserName
	FROM ' + @Database + '.dbo.sysusers su
	INNER JOIN ' + @Database + '.dbo.sysmembers sm ON su.uid = sm.groupuid 
	INNER JOIN ' + @Database + '.dbo.sysusers sysusers_1 ON sm.memberuid = sysusers_1.uid
	ORDER BY su.name'
EXEC (@sql)	


-- Part 5: User Privileges
SET @sql = 
	'SELECT [name] FROM ' + @Database + '.dbo.sysusers
	WHERE [Name] Not In
           (SELECT TOP 100 PERCENT name
			FROM ' + @Database + '.dbo.sysusers
			GROUP BY name, issqlrole
			HAVING (issqlrole = 1))
	Order by [Name]'

Insert #Users (UserName)
EXECUTE (@sql)


Set @Seq = 1
Set @MaxSeq = (Select max(ID) from #Users)
 While @Seq <= @MaxSeq

 Begin
	Set @USeq = 1
	Set @UserName = (Select UserName from #Users where ID = @Seq)

		Set @Sql = 'SELECT     so.name, CASE protecttype WHEN 204 THEN ''GRANT_W_GRANT ''' + Char(13) + 
			'WHEN 205 THEN ''GRANT ''' + Char(13) +
			'ELSE ''BOGUS'''+ Char(13) +
			' END AS Type,' + Char(13) +
			' CASE action WHEN 26 THEN ''REFERENCES'''+ Char(13) +
			' WHEN 178 THEN ''CREATE FUNCTION''' + char(13) +
			' WHEN 193 THEN ''SELECT''' + char(13) +
			' WHEN 195 THEN ''INSERT''' + char(13) +
			' WHEN 196 THEN ''DELETE''' + char(13) +
			' WHEN 197 THEN ''UPDATE''' + char(13) +
			' WHEN 198 THEN ''CREATE TABLE''' + char(13) +
			' WHEN 203 THEN ''CREATE DATABASE''' + char(13) +
			' WHEN 207 THEN ''CREATE VIEW''' + char(13) +
			' WHEN 222 THEN ''CREATE PROCEDURE''' + char(13) +
			' WHEN 224 THEN ''EXECUTE''' + char(13) +
			' WHEN 228 THEN ''BACKUP DATABASE''' + char(13) +
			' WHEN 233 THEN ''CREATE DEFAULT''' + char(13) +
			' WHEN 235 THEN ''BACKUP LOG''' + char(13) +
			' WHEN 236 THEN ''CREATE RULE''' + char(13) +
			' END AS Action, s.name, '''+ @Database +''' as DB'+ char(13) +
			' FROM ' + @Database + '.dbo.sysprotects sp INNER JOIN '+ char(13) +
       		        @Database + '.dbo.sysobjects so ON so.id = sp.id INNER JOIN '+ char(13) +
       		        @Database + '.dbo.sysusers s ON sp.uid = s.uid '+ char(13) +
				'WHERE     (s.name = '''+@Username+''')'

	Insert #Permissions (Object, Perms2, Type, Grantee, DB)
		Execute (@Sql)			

	Set @Seq = @Seq+1
Continue
End

SET @sql = 	' SELECT ''GLOBAL DATABASE'', state_desc, permission_name, name, ''' + @Database + '''' + char(13) +
			 ' FROM ' + @Database + '.sys.database_permissions perm' + char(13) +
			 ' INNER JOIN ' + @Database + '.sys.database_principals prin ON prin.principal_id = perm.grantee_principal_id' + char(13) +
			 ' WHERE class_desc = ''DATABASE''' + char(13) +
			 ' AND type_desc IN (''WINDOWS_GROUP'', ''SQL_USER'')'
	Insert #Permissions (Object, Perms2, Type, Grantee, DB)
		Execute (@Sql)	

Drop table #Users

Delete from #Permissions
	where Perms2 = 'Bogus'

SELECT grantee,	type, perms2, object 
FROM #Permissions
ORDER BY Grantee

Drop table #Permissions

