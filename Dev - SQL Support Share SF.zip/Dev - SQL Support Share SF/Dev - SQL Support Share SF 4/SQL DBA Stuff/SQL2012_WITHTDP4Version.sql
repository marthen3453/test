USE SCCM
select distinct a.name0,
b.level100,
b.level200,
b.level300,
a.Resource_Domain_OR_Workgr0,
c.appname00,
c.build00 
from system_disc a
inner join vmachinetype_data b
on a.itemkey=b.machineid
inner join SF_PackageHistory_64_DATA c
on b.machineid=c.machineid
where a.name0 in (
'WTSDZNVJ',
'WTSDZNVF',
'WTSDZGDY',
'WTSD0D72',
'WTSCVBLQ'
)
and c.Appname00 like 'TSM Client for Server 2012%'
and build00 != 5 -- Not 1.5

---already build 5
--WTSD5VZL
--WTSD5YP6
--WTSDRF41
--WTSDRF42
--WTSDRF43
--WTSDWRGG
--WTSDWRGJ
--WTSDWRGK
--WTSDWRGL
--WTSDZGDY