SELECT * FROM :: fn_trace_getinfo(default) 

