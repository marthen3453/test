select database_name, backup_size/1024/1024/1024 as BackUpSize_GB, compressed_backup_size/1024/1024/1024 as CompressBackUp_GB, compressed_backup_size/backup_size*100 as TotalPercentSize from msdb.dbo.backupset where backup_finish_date > DateAdd (day, -1, GETDATE())
and name ='full'

