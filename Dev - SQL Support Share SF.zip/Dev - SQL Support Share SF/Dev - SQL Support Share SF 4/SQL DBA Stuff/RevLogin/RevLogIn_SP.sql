USE [master]
GO

DECLARE @RC INT
DECLARE @login_name sysname

-- TODO: Set parameter values here.

EXECUTE @RC = [dbo].[sp_help_revlogin] 
   @login_name
GO


