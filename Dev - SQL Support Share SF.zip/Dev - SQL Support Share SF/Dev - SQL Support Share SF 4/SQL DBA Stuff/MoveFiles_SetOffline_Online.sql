----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------- Before Changing, run location of files
------- When you copy, make sure the permissions are accurate
------- Example on one was FULL CONTROL for SQLServerMSSQLUser$WPSDDB6M$MSSQLSERVER (WPSDDB6M\SQLServerMSSQLUser$WPSDDB6M$MSSQLSERVER) was missing
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

------- Set Database Offline
--USE master
--GO
--ALTER DATABASE BBARCHIVE SET OFFLINE WITH ROLLBACK IMMEDIATE
--GO


-------  Change the location of the files 
--USE master
--GO
--ALTER DATABASE BBARCHIVE
--MODIFY FILE 
--( NAME = BBARCHIVE_data02,   ---- Logical Name
--FILENAME = 'K:\MSSQL\Data\BBARCHIVE_data2.ndf'); -- New file path

--USE master
--GO
--ALTER DATABASE BBARCHIVE
--MODIFY FILE 
--( NAME = BBARCHIVE_data03, 
--FILENAME = 'L:\MSSQL\Data\BBARCHIVE_data1.ndf'); -- New file path

--USE master
--GO
--ALTER DATABASE BBARCHIVE
--MODIFY FILE 
--( NAME = BBARCHIVE_data05, 
--FILENAME = 'N:\MSSQL\Data\BBARCHIVE_data1.ndf'); -- New file path

-------------- Set Back ONLINE
--USE master
--GO
--ALTER DATABASE BBARCHIVE SET ONLINE;

