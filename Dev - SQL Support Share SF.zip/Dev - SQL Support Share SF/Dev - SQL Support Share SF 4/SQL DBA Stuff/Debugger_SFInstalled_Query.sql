SELECT DISTINCT c.name0, a.appname00,d.level100,d.level200 FROM
[dbo].[SF_Installed_Packages_64_DATA] a
INNER JOIN [dbo].[SF_Installed_Packages_64_DATA] b
ON a.machineid=b.machineid
INNER JOIN system_disc c
ON a.machineid=c.ItemKey
INNER JOIN vmachinetype_data d
ON a.machineid=d.machineid
WHERE a.name00 LIKE '%XACTIMATE-SQLEXPRESS-BACKEND%'
AND C.name0 LIKE '%W_W%'
ORDER BY c.name0 DESC

SELECT DISTINCT c.name0, a.appname00,d.level100,d.level200 FROM
[dbo].[SF_Installed_Packages_64_DATA] a
INNER JOIN [dbo].[SF_Installed_Packages_64_DATA] b
ON a.machineid=b.machineid
INNER JOIN system_disc c
ON a.machineid=c.ItemKey
INNER JOIN vmachinetype_data d
ON a.machineid=d.machineid
WHERE a.name00 LIKE '%SQL2012-TLS%'
AND C.name0 LIKE '%W_W%'
ORDER BY c.name0 DESC
