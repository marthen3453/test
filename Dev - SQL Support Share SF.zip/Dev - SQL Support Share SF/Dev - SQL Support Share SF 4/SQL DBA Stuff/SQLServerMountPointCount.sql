--SQLpdms01.opr.statefarm.org

----------Count for all SQL MountPoints
USE EMLDB
SELECT COUNT(*) AS ServerMountPointCount FROM tReplSCCMv_sf_WSDBMountPoints WHERE Name0 IN
	(
	SELECT ComName FROM SQL_EML_WSDB.dbDomainInfo.dbo.tblServerInfo 
WHERE
		(
 PrimaryFunction_Id IN (SELECT Function_Id FROM SQL_EML_WSDB.dbDomainInfo.dbo.tblFunctions WHERE vcFun LIKE '%sql%')
 OR
 SecondaryFunction_Id IN (SELECT Function_Id FROM SQL_EML_WSDB.dbDomainInfo.dbo.tblFunctions WHERE vcFun LIKE '%sql%')
 OR 
 TertiaryFunction_Id IN (SELECT Function_Id FROM SQL_EML_WSDB.dbDomainInfo.dbo.tblFunctions WHERE vcFun LIKE '%sql%')
		)
 AND Dom_Id IN 
			(
	SELECT Dom_Id FROM SQL_EML_WSDB.dbDomainInfo.dbo.tblInfoDom WHERE DomName IN 
				(
  'OPR.STATEFARM.ORG' ,
 'Support.statefarm.org'
				) 
			) 
	)




 ---- Mount Points Group By Server
	USE EMLDB
SELECT Name0, COUNT(*) AS ServerMountPointCount FROM tReplSCCMv_sf_WSDBMountPoints WHERE Name0 IN

(
	SELECT ComName FROM SQL_EML_WSDB.dbDomainInfo.dbo.tblServerInfo 
WHERE
 (
 PrimaryFunction_Id IN (SELECT Function_Id FROM SQL_EML_WSDB.dbDomainInfo.dbo.tblFunctions WHERE vcFun LIKE '%sql%')
 OR
 SecondaryFunction_Id IN (SELECT Function_Id FROM SQL_EML_WSDB.dbDomainInfo.dbo.tblFunctions WHERE vcFun LIKE '%sql%')
 OR 
 TertiaryFunction_Id IN (SELECT Function_Id FROM SQL_EML_WSDB.dbDomainInfo.dbo.tblFunctions WHERE vcFun LIKE '%sql%')
 )
 AND Dom_Id IN 
 (
	SELECT Dom_Id FROM SQL_EML_WSDB.dbDomainInfo.dbo.tblInfoDom WHERE DomName IN 
(
  'OPR.STATEFARM.ORG' ,
 'Support.statefarm.org'
 )
 )
 )
GROUP BY
Name0