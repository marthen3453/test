SELECT
    B.login_name,
    A.client_net_address,
    NoOfConnections = COUNT(*)
FROM
    sys.dm_exec_connections A
        INNER JOIN sys.dm_exec_sessions B ON
            A.session_id = B.session_id
GROUP BY
    login_name,
    client_net_address
