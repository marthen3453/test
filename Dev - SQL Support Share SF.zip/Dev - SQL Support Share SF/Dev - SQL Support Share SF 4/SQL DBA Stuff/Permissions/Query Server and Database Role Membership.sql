use master;
SELECT
      rolename = rolep.name,
      membername = memp.name
FROM
      sys.server_role_members rm
      JOIN sys.server_principals rolep ON rm.role_principal_id = rolep.principal_id
      JOIN sys.server_principals memp ON rm.member_principal_id = memp.principal_id
