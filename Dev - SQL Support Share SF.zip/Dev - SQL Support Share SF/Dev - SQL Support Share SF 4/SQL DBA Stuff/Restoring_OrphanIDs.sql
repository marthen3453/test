EXEC�sp_change_users_login�'Report';�

EXEC sp_change_users_login 'Update_One', 'MegaAdm', 'MegaAdm'

EXEC sp_change_users_login 'Update_One', 'MegaUser', 'MegaUser'