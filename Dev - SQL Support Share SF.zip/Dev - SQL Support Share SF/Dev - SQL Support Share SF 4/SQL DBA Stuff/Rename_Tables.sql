USE SFSQL_SMSReport
GO
EXEC sp_rename 'Opis_Eacnd_OLD', 'Opis_Eacnd_OLD_dbc'
EXEC sp_rename 'OPIS_EACND_Temp', 'OPIS_EACND_Temp_dbc'
EXEC sp_rename 'Powermanagement_T858153', 'Powermanagement_T858153_dbc'
EXEC sp_rename 'system_hist_data_backup', 'system_hist_data_backup_dbc'
EXEC sp_rename 'system_hist_data_backup2', 'system_hist_data_backup2_dbc'
