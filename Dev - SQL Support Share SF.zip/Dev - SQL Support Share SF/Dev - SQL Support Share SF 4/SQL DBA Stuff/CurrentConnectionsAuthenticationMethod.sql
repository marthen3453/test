Select con.session_id, net_transport, con.auth_scheme, ses.host_name, ses.login_name
From sys.dm_exec_connections con
Join sys.dm_exec_sessions ses on con.session_id = ses.session_id
