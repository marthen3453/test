select database_name, backup_size/1024/1024/1024 as BackUpSize_GB, compressed_backup_size/1024/1024/1024 as CompBackSize_GB into #TempBackSize  from msdb.dbo.backupset where backup_finish_date > DateAdd (day, -1, GETDATE())
and name ='full'
select * from #TempBackSize
where database_name not in ('master', 'model','msdb','SF_SQL_ADMIN')
select SUM(BackUpSize_GB) as TotalBackSize, SUM(CompBackSize_GB) as TotalCompBackSize from #TempBackSize

Drop Table #TempBackSize