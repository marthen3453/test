-- *******************************************************************************************************
-- * Script:    SFSQL_Connections SP + DB
-- * Project:   R15799 / Misc
-- * Purpose:   Capture logins at certain intervals through a scheduled job
-- * Author:    Chris Thompson
-- * Date:	09/15/2010
-- * Database:	msdb
-- *******************************************************************************************************

USE [msdb]
GO

/****** Object:  Table [dbo].[SFSQL_Connections]    Script Date: 09/14/2010 21:04:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[SFSQL_Connections](
	[HostName] [varchar](max) NOT NULL,
	[LoginName] [varchar](max) NOT NULL,
	[DatabaseName] [varchar](max) NOT NULL,
	[LastUpdateDate] [datetime] NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[SFSQL_Connections] ADD  CONSTRAINT [DF_SFSQL_Connections_LastUpdateDate]  DEFAULT (getdate()) FOR [LastUpdateDate]
GO


/****************************************************************************/

USE [msdb]
GO
/****** Object:  StoredProcedure [dbo].[SFSQL_CaptureConnections]    Script Date: 09/14/2010 21:02:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[SFSQL_CaptureConnections]

AS

DECLARE @hostname VARCHAR(MAX), @loginname VARCHAR(MAX), @databasename VARCHAR(MAX)
CREATE TABLE [dbo].[#tmpSFSQL_Connections](
	[HostName] [varchar](max) NOT NULL,
	[LoginName] [varchar](max) NOT NULL,
	[DatabaseName] [varchar](max) NOT NULL
) ON [PRIMARY]

insert into #tmpSFSQL_Connections
select  hostname , convert(sysname, rtrim(loginame)) as loginname ,db_name(dbid) as database_name
  from master.dbo.sysprocesses with (nolock)  
 where hostname <> ''

DECLARE curConnections CURSOR FOR 
select HostName, LoginName, DatabaseName from #tmpSFSQL_Connections

OPEN curConnections

FETCH NEXT FROM curConnections
INTO @hostname, @loginname, @databasename

WHILE @@FETCH_STATUS = 0
BEGIN

	IF NOT EXISTS(SELECT * FROM SFSQL_Connections
			    	  WHERE HostName = @hostname
	                    AND LoginName = loginname
	                    AND DatabaseName = @databasename)
		BEGIN
			INSERT INTO msdb.dbo.SFSQL_Connections	
			VALUES (@hostname, @loginname, @databasename, GetDate())
		END
	ELSE
		BEGIN
			UPDATE msdb.dbo.SFSQL_Connections	
			  SET LastUpdateDate = GetDate() 
       	    WHERE HostName = @hostname
              AND LoginName = loginname
              AND DatabaseName = @databasename
		END
		
	FETCH NEXT FROM curConnections
	INTO @hostname, @loginname, @databasename
END
CLOSE curConnections
DEALLOCATE curConnections

drop table #tmpSFSQL_Connections
 
 