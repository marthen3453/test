-----Connect to 32V
USE MSDB
/****** Script for SelectTopNRows command from SSMS  ******/
SELECT Count (SERVERNAME) as SQLServerCount
	  ,[FILEVERSION]
	  FROM [msdb].[dbo].[sf_sql_servers]
  where SKUNAME != 'Express Edition (64-bit)'
    and SKUNAME != 'Express Edition with Advanced Services (64-bit)'
  and SKUNAME != 'Express Edition'
  AND SKUNAME != 'Express Edition with Advanced Services'
  Group By FILEVERSION
 -- Order by SERVERNAME,DOMAIN

/****** Script for SelectTopNRows command from SSMS  ******/
SELECT Count (SERVERNAME) as SQLServerCount
	  ,[FILEVERSION]
  FROM [msdb].[dbo].[sf_sql_servers_all]
  where SKUNAME NOT LIKE '%express%'
  Group By FILEVERSION 
  Order by FileVersion ASC


  SELECT
  SERVERNAME,
  DOMAIN,
  level100,
  level200,
  ClusterName00 
  FROM [msdb].[dbo].[sf_sql_servers_all]
  WHERE FILEVERSION = '11.0.5613.0'
  AND SKUNAME NOT LIKE '%express%'
  --AND level100 like 'SCCM2012%'
  ORDER BY SERVERNAME

  2011.110.5556.0
2011.110.5613.0
11.0.5613.0


  SELECT * FROM [msdb].[dbo].[sf_sql_servers_all]
  WHERE SERVERNAME IN  (
  'WTSDSNPY',
'WTSDYM3X',
'WTSDYK9F',
'WTSD3NT1'
)
