--Set Tranaction isolation level read uncommitted
Select 
	o.name as table_name,
	i.name as index_name,
	s.user_seeks, 
	s.user_scans,
	s.user_lookups,
	s.user_updates
from
	sys.dm_db_index_usage_stats s
inner join sys.indexes i
	on i.index_id = s.index_id
	and s.object_id=i.object_id
inner join sys.objects o
	on s.object_id=o.object_id
inner join sys.schemas c
	on o.schema_id= c.schema_id 
where
	o.name ='Users'
	
