SELECT encrypt_option 
FROM sys.dm_exec_connections 
WHERE session_id = @@SPID
