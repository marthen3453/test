USE [SF_SQL_Admin]
GO
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET NOCOUNT ON
GO
PRINT 'CREATING TABLE SQLPIG_CONFIGURATION_SF.....'
/****************************************/
/* CREATE TABLE SQLPIG_CONFIGURATION_SF */
/****************************************/
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Configuration_SF]') AND type in (N'U'))
	CREATE TABLE [dbo].[SQLPIG_Configuration_SF](
		[Server_Name] [sysname] NOT NULL,
		[Instance_Name] [sysname] NOT NULL,
		[Configuration_Name] [varchar](200) NOT NULL,
		[Configuration_Value] [varchar](200) NOT NULL,
	 CONSTRAINT [PK_SQLPIG_Configuration_SF] PRIMARY KEY CLUSTERED 
	(
		[Server_Name] ASC,
		[Instance_Name] ASC,
		[Configuration_Name] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'TABLE',N'SQLPIG_Configuration_SF', NULL,NULL))
	EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'SQLPIG_Configuration_SF'
GO

PRINT 'INSERTING DEFAULT DATA INTO SQLPIG_CONFIGURATION_SF'
/*************************************************************/
/* Populate table SQLPIG_CONFIGURATION_SF with default values*/
/*************************************************************/
IF NOT EXISTS (SELECT 1 FROM dbo.SQLPIG_Configuration_SF C WHERE C.Server_Name = @@SERVERNAME AND C.Instance_Name = @@servicename AND C.Configuration_Name = 'CPU Usage Retention Days')
BEGIN
	INSERT INTO dbo.SQLPIG_Configuration_SF
			( Server_Name ,
			  Instance_Name ,
			  Configuration_Name ,
			  Configuration_Value
			)
	SELECT 
		@@SERVERNAME AS Server_Name
		,@@servicename AS Instance_Name
		,'CPU Usage Retention Days' AS Configuration_Name
		,'400' AS Configuration_Value
END

IF NOT EXISTS (SELECT 1 FROM dbo.SQLPIG_Configuration_SF C WHERE C.Server_Name = @@SERVERNAME AND C.Instance_Name = @@servicename AND C.Configuration_Name = 'Memory Usage Retention Days')
BEGIN
	INSERT INTO dbo.SQLPIG_Configuration_SF
			( Server_Name ,
			  Instance_Name ,
			  Configuration_Name ,
			  Configuration_Value
			)
	VALUES  (@@SERVERNAME, -- Server_Name
			@@servicename, -- Instance_Name
			  'Memory Usage Retention Days' , 
			  '400'
			)
END
GO



PRINT 'CREATING UDF SQLPIG_Processor_Meta_SEL_End_Time_SF.....'
/****************************************/
/* CREATE UDF SQLPIG_Processor_Meta_SEL_End_Time_SF */
/****************************************/
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Processor_Meta_SEL_End_Time_SF]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[SQLPIG_Processor_Meta_SEL_End_Time_SF] (@Server_Name sysname, @Instance_Name sysname, @Start_Time SMALLDATETIME)
RETURNS SMALLDATETIME
AS
BEGIN
	DECLARE @End_Time SMALLDATETIME
  
	RETURN (
		SELECT
			DATEADD(minute, -1, MIN(PM.Start_Time)) EndTime
		FROM
			dbo.SQLPIG_Processor_Meta_SF PM
		WHERE
			PM.Server_Name = @Server_Name
		AND PM.Instance_Name = @Instance_Name
		AND PM.Start_Time > @Start_Time  
	)
	
END
' 
END
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'FUNCTION',N'SQLPIG_Processor_Meta_SEL_End_Time_SF', NULL,NULL))
	EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'FUNCTION',@level1name=N'SQLPIG_Processor_Meta_SEL_End_Time_SF'
GO



PRINT 'CREATING TABLE SQLPIG_Processor_meta_SF.....'
/*****************************************/
/* CREATE TABLE SQLPIG_Processor_meta_SF */
/*****************************************/
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Processor_Meta_SF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SQLPIG_Processor_Meta_SF](
	[Server_Name] [sysname] NOT NULL,
	[Instance_Name] [sysname] NOT NULL,
	[Start_Time] [smalldatetime] NOT NULL,
	[End_Time]  AS ([dbo].[SQLPIG_Processor_Meta_SEL_End_Time_SF]([Server_Name],[Instance_Name],[Start_Time])),
	[Num_Processors] [tinyint] NOT NULL,
 CONSTRAINT [PK_SQLPIG_Processor_Meta_SF] PRIMARY KEY CLUSTERED 
(
	[Server_Name] ASC,
	[Instance_Name] ASC,
	[Start_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'TABLE',N'SQLPIG_Processor_Meta_SF', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'SQLPIG_Processor_Meta_SF'
GO



PRINT 'CREATING TABLE SQLPIG_Processor_usage_SF.....'
/*****************************************/
/* CREATE TABLE SQLPIG_Processor_usage_SF */
/*****************************************/
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Processor_Usage_SF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SQLPIG_Processor_Usage_SF](
	[Server_Name] [sysname] NOT NULL,
	[Instance_Name] [sysname] NOT NULL,
	[Report_Time] [smalldatetime] NOT NULL,
	[SQL_Process_Utilization] [tinyint] NOT NULL,
	[System_Idle] [tinyint] NOT NULL,
	[Other_Process_Utilization] [tinyint] NOT NULL,
 CONSTRAINT [PK_SQLPIG_Processor_Usage_SF] PRIMARY KEY CLUSTERED 
(
	[Server_Name] ASC,
	[Instance_Name] ASC,
	[Report_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'TABLE',N'SQLPIG_Processor_Usage_SF', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'SQLPIG_Processor_Usage_SF'
GO






PRINT 'CREATING UDF SQLPIG_Memory_Meta_SEL_End_Time_SF.....'
/*************************************************/
/* CREATE UDF SQLPIG_Memory_Meta_SEL_End_Time_SF */
/*************************************************/
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Memory_Meta_SEL_End_Time_SF]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[SQLPIG_Memory_Meta_SEL_End_Time_SF] (@Server_Name sysname, @Instance_Name sysname, @Start_Time SMALLDATETIME)
RETURNS SMALLDATETIME
AS
BEGIN
	DECLARE @End_Time SMALLDATETIME
  
	RETURN (
		SELECT
			DATEADD(minute, -1, MIN(MM.Start_Time)) EndTime
		FROM
			dbo.SQLPIG_Memory_Meta_SF MM
		WHERE
			MM.Server_Name = @Server_Name
		AND MM.Instance_Name = @Instance_Name
		AND MM.Start_Time > @Start_Time  
	)
	
END
' 
END
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'FUNCTION',N'SQLPIG_Memory_Meta_SEL_End_Time_SF', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'FUNCTION',@level1name=N'SQLPIG_Memory_Meta_SEL_End_Time_SF'
GO



PRINT 'CREATING TABLE SQLPIG_Memory_Meta_SF.....'
/*************************************************/
/* CREATE TABLE SQLPIG_Memory_meta_SF */
/*************************************************/
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Memory_Meta_SF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SQLPIG_Memory_Meta_SF](
	[Server_Name] [sysname] NOT NULL,
	[Instance_Name] [sysname] NOT NULL,
	[Start_Time] [smalldatetime] NOT NULL,
	[End_Time]  AS ([dbo].[SQLPIG_Memory_Meta_SEL_End_Time_SF]([Server_Name],[Instance_Name],[Start_Time])),
	[Total_Memory] [int] NOT NULL,
	[Min_Memory] [int] NOT NULL,
	[Max_Memory] [int] NOT NULL,
 CONSTRAINT [PK_SQLPIG_Memory_meta_SF] PRIMARY KEY CLUSTERED 
(
	[Server_Name] ASC,
	[Instance_Name] ASC,
	[Start_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'TABLE',N'SQLPIG_Memory_Meta_SF', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'SQLPIG_Memory_Meta_SF'
GO



PRINT 'CREATING TABLE SQLPIG_Memory_Usage_SF.....'
/***************************************/
/* CREATE TABLE SQLPIG_Memory_Usage_SF */
/***************************************/
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Memory_Usage_SF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SQLPIG_Memory_Usage_SF](
	[Server_Name] [sysname] NOT NULL,
	[Instance_Name] [sysname] NOT NULL,
	[Report_Time] [smalldatetime] NOT NULL,
	[PLE] [int] NOT NULL,
	[Free_Pages] [int] NOT NULL,
	[Lazy_Writes_Per_Sec] [int] NOT NULL,
 CONSTRAINT [PK_SQLPIG_Memory_Usage_SF] PRIMARY KEY CLUSTERED 
(
	[Server_Name] ASC,
	[Instance_Name] ASC,
	[Report_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'TABLE',N'SQLPIG_Memory_Usage_SF', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'SQLPIG_Memory_Usage_SF'
GO




PRINT 'CREATING PROCEDURE SQLPIG_Processor_Meta_Capture_SF.....'
/*****************************************************/
/* CREATE PROCEDURE SQLPIG_Processor_Meta_Capture_SF */
/*****************************************************/
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Processor_Meta_Capture_SF]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = 
N'/****************************************************************************************************************************************************************
** Author: Jason Ingram
** Creation Date: 11/01/2013
** Purpose:  This procedure part of the SQLPIG utility.  It will capture processor metadata for the SQL instance and store it in SQLPIG_Processor_Meta_SF table.
** Modification History:
**
****************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[SQLPIG_Processor_Meta_Capture_SF]
AS
SET NOCOUNT ON
DECLARE 
	 @Server_Name sysname
	,@Instance_Name sysname
	,@Start_Time smalldatetime
	,@Cur_Num_Processors TINYINT
	,@New_Num_Processors TINYINT  

CREATE TABLE #tblStats 
(
[Index] INT,
[Name] VARCHAR(200),
Internal_Value VARCHAR(50),
Character_Value VARCHAR(200)
)

INSERT INTO #tblStats
EXEC master.dbo.xp_msver ''ProcessorCount''
	
SELECT
	 @Server_Name = @@SERVERNAME
	,@Instance_Name  = @@servicename
	,@New_Num_Processors = Internal_Value FROM #tblStats WHERE [Index] = 16

SELECT
	@Start_Time = PM.Start_Time
	,@Cur_Num_Processors = PM.Num_Processors
FROM	
	dbo.SQLPIG_Processor_Meta_SF PM
WHERE
	PM.Server_Name = @Server_Name
AND PM.Instance_Name = @Instance_Name
AND PM.End_Time IS NULL


---- No record found for this instance or a value changed
IF @Start_Time IS NULL
	OR @New_Num_Processors != @Cur_Num_Processors

BEGIN
	INSERT INTO dbo.SQLPIG_Processor_Meta_SF
	        ( Server_Name ,
	          Instance_Name ,
	          Start_Time ,
	          Num_Processors
	        )
	SELECT
		@Server_Name Server_Name
		,@Instance_Name Instance_Name
		,GETDATE()
		,@New_Num_Processors
END' 
END
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'PROCEDURE',N'SQLPIG_Processor_Meta_Capture_SF', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'PROCEDURE',@level1name=N'SQLPIG_Processor_Meta_Capture_SF'
GO





PRINT 'CREATING PROCEDURE SQLPIG_Processor_Usage_Capture_SF.....'
/*****************************************************/
/* CREATE PROCEDURE SQLPIG_Processor_Usage_Capture_SF */
/*****************************************************/
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Processor_Usage_Capture_SF]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = 
N'/****************************************************************************************************************************************************************
** Author: Jason Ingram
** Creation Date: 11/01/2013
** Purpose:  This procedure part of the SQLPIG utility.  It will continually run capturing processor usage for the SQL instance and storing it in 
**		SQLPIG_Processor_Usage_SF table.
** Modification History:
**
****************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[SQLPIG_Processor_Usage_Capture_SF]

AS
SET NOCOUNT ON
DECLARE @EndTime smalldatetime 
DECLARE @ts_now BIGINT


WHILE 1=1
BEGIN
	EXEC dbo.SQLPIG_Processor_Meta_Capture_SF

	SET @EndTime = DATEADD(minute, -1, GETDATE())

	-- Find the timestamp for current server time
	SELECT @ts_now = cpu_ticks / (cpu_ticks / ms_ticks)
	FROM sys.dm_os_sys_info;

	INSERT INTO dbo.SQLPIG_Processor_Usage_SF
	(
		Server_Name
		,Instance_Name
		,Report_Time
		,SQL_Process_Utilization
		,System_Idle
		,Other_Process_Utilization
	)
	SELECT
		DT.Server_Name
		,DT.Instance_Name
		,DT.Report_Time
		,DT.SQL_Process_Utilization
		,DT.System_Idle
		,DT.Other_Process_Utilization
	FROM
	( 
		SELECT
			@@SERVERNAME  Server_Name
			,@@servicename Instance_Name      
			,CAST(DATEADD(ms, -1 * (@ts_now - [timestamp]), GETDATE()) AS smalldatetime) AS Report_Time
		   ,AVG(SQL_Process_Utilization) SQL_Process_Utilization
		   ,AVG(System_Idle) System_Idle
		   ,AVG(100 - System_Idle - SQL_Process_Utilization) AS Other_Process_Utilization
		FROM
			(
			 SELECT
				record.value(''(./Record/@id)[1]'', ''int'') AS record_id
			   ,record.value(''(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]'',
							 ''int'') AS System_Idle
			   ,record.value(''(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]'',
							 ''int'') AS SQL_Process_Utilization
			   ,[timestamp]
			 FROM
				(
				 SELECT
					[timestamp]
				   ,CONVERT(XML, record) AS record
				 FROM
					sys.dm_os_ring_buffers
				 WHERE
					ring_buffer_type = N''RING_BUFFER_SCHEDULER_MONITOR''
					AND record LIKE ''% %''
					AND DATEADD(ms, -1 * (@ts_now - [timestamp]), GETDATE()) < @EndTime
				) AS x
			) AS y
		GROUP BY
			CAST(DATEADD(ms, -1 * (@ts_now - [timestamp]), GETDATE()) AS smalldatetime)
	) DT
	LEFT OUTER JOIN dbo.SQLPIG_Processor_Usage_SF PU
		ON DT.Server_Name = PU.Server_Name
		AND DT.Instance_Name = PU.Instance_Name
		AND DT.Report_Time = PU.Report_Time
	WHERE
		PU.Report_Time is NULL

	WAITFOR DELAY ''00:01:00''
END

' 
END
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'PROCEDURE',N'SQLPIG_Processor_Usage_Capture_SF', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'PROCEDURE',@level1name=N'SQLPIG_Processor_Usage_Capture_SF'
GO





PRINT 'CREATING PROCEDURE SQLPIG_Memory_Meta_Capture_SF.....'
/*****************************************************/
/* CREATE PROCEDURE SQLPIG_Memory_Meta_Capture_SF    */
/*****************************************************/
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Memory_Meta_Capture_SF]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = 
N'/****************************************************************************************************************************************************************
** Author: Jason Ingram
** Creation Date: 11/01/2013
** Purpose:  This procedure part of the SQLPIG utility.  It will capture memory metadata for the SQL instance and store it in SQLPIG_Memory_Meta_SF table.
** Modification History:
**
****************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[SQLPIG_Memory_Meta_Capture_SF]
AS
SET NOCOUNT ON

DECLARE @t TABLE
(INDEX_Val int NOT NULL
,NAME sysname NOT NULL
,Internal_Value varchar(MAX)
,Character_Value varchar(MAX)
)
INSERT INTO @t
exec master.dbo.xp_msver ''PhysicalMemory''

DECLARE 
	 @Server_Name sysname
	,@Instance_Name sysname
	,@Start_Time smalldatetime
	,@CurTotalMemory INT
	,@CurMinMemory INT
	,@CurMaxMemory INT
    ,@NewTotalMemory INT
	,@NewMinMemory INT
	,@NewMaxMemory INT
SELECT
	 @Server_Name = @@SERVERNAME
	,@Instance_Name  = @@servicename
	,@NewTotalMemory =  CAST((SELECT Internal_Value FROM @t) AS INT)
	,@NewMinMemory = CAST((SELECT cfg.value_in_use FROM sys.configurations AS cfg WHERE name = ''min server memory (MB)'') AS INT)
	,@NewMaxMemory = CAST((SELECT cfg.value_in_use FROM sys.configurations AS cfg WHERE name = ''max server memory (MB)'') AS int)

SELECT
	@Start_Time = MM.Start_Time
	,@CurTotalMemory = MM.Total_Memory
	,@CurMinMemory = MM.Min_Memory
	,@CurMaxMemory = MM.Max_Memory
FROM	
	dbo.SQLPIG_Memory_Meta_SF MM
WHERE
	MM.Server_Name = @Server_Name
AND MM.Instance_Name = @Instance_Name
AND MM.End_Time IS NULL

---- No record found for this instance or a value changed
IF @Start_Time IS NULL
	OR @CurMinMemory != @NewMinMemory
	OR @CurMaxMemory != @NewMaxMemory
	OR @CurTotalMemory != @NewTotalMemory
BEGIN
	INSERT INTO dbo.SQLPIG_Memory_Meta_SF
	        ( Server_Name ,
	          Instance_Name ,
	          Start_Time ,
	          Total_Memory ,
	          Min_Memory ,
	          Max_Memory
	        )
	SELECT
		@Server_Name Server_Name
		,@Instance_Name Instance_Name
		,GETDATE()
		,@NewTotalMemory NewTotalMemory
		,@NewMinMemory NewMinMemory
		,@NewMaxMemory NewMaxMemory
END
' 
END
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'PROCEDURE',N'SQLPIG_Memory_Meta_Capture_SF', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'PROCEDURE',@level1name=N'SQLPIG_Memory_Meta_Capture_SF'
GO





PRINT 'CREATING PROCEDURE SQLPIG_Memory_Usage_Capture_SF.....'
/*****************************************************/
/* CREATE PROCEDURE SQLPIG_Memory_Usage_Capture_SF    */
/*****************************************************/
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Memory_Usage_Capture_SF]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = 
N'/****************************************************************************************************************************************************************
** Author: Jason Ingram
** Creation Date: 11/01/2013
** Purpose:  This procedure part of the SQLPIG utility.  It will continually run capturing memory usage for the SQL instance and storing it in 
**		SQLPIG_Processor_Usage_SF table.
** Modification History:
**
****************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[SQLPIG_Memory_Usage_Capture_SF]
AS
SET NOCOUNT ON
DECLARE 
	@Lazy_Writes_Per_Sec INT
	,@Report_Time smalldatetime

WHILE 1=1
BEGIN
	-- Capture changes in memory settings
	EXEC dbo.SQLPIG_Memory_Meta_Capture_SF


	SET @Report_Time = GETDATE()
	/*Capture Lazy write value at point #1 */
	select  
		@Lazy_Writes_Per_Sec = cntr_value
	from 
		sys.dm_os_performance_counters
	where 
		object_name like ''%Manager%'' 
	and  counter_name = ''Lazy writes/sec''

	WAITFOR DELAY ''00:00:01''


	INSERT INTO dbo.SQLPIG_Memory_Usage_SF
	(
		Server_Name,
		Instance_Name,
		Report_Time,
		PLE,
		Free_Pages,
		Lazy_Writes_Per_Sec
	)
	SELECT
  		DT.Server_Name
		,DT.Instance_Name  
		,@Report_Time
		,DT.PLE
		,DT.Free_Pages
		,DT.Lazy_Writes_Per_Sec - @Lazy_Writes_Per_Sec AS Lazy_Writes_Per_Sec 
	FROM
	(
		select  
		  	@@SERVERNAME  Server_Name
			,@@servicename Instance_Name  
			,@Report_Time Report_Time
			,SUM(CASE counter_Name
				WHEN ''Page life expectancy'' THEN
					cntr_value
				ELSE
					0
			END) PLE
			,SUM(CASE counter_Name
				WHEN ''Lazy writes/sec'' THEN
					cntr_value
				ELSE
					0
			END) [Lazy_Writes_Per_Sec]
			,SUM(CASE counter_Name
				WHEN ''Free pages'' THEN
					cntr_value
				ELSE
					0
			END) Free_Pages

		from 
			sys.dm_os_performance_counters
		where 
			object_name like ''%Manager%'' 
		and  counter_name IN (''Page life expectancy'', ''Lazy writes/sec'', ''Free pages'')
	) DT
	LEFT OUTER JOIN dbo.SQLPIG_Memory_Usage_SF Mem
		ON DT.Server_Name = Mem.Server_Name
		AND DT.Instance_Name = Mem.Instance_Name
		AND DT.Report_Time = Mem.Report_Time
	WHERE
		Mem.Report_Time is NULL

	WAITFOR DELAY ''00:01:00''
END
' 
END
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'PROCEDURE',N'SQLPIG_Memory_Usage_Capture_SF', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'PROCEDURE',@level1name=N'SQLPIG_Memory_Usage_Capture_SF'
GO





PRINT 'CREATING PROCEDURE SQLPIG_Archive_Processor_Usage_SF.....'
/******************************************************/
/* CREATE PROCEDURE SQLPIG_Archive_Processor_Usage_SF */
/******************************************************/
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Archive_Processor_Usage_SF]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = 
N'/****************************************************************************************************************************************************************
** Author: Jason Ingram
** Creation Date: 11/01/2013
** Purpose:  This procedure part of the SQLPIG utility.  It will delete old rows out of dbo.SQLPIG_Processor_Usage based on the value specified in the
**		dbo.SQLPIG_Configuration_SF table.
** Modification History:
**
****************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[SQLPIG_Archive_Processor_Usage_SF]
AS
SET NOCOUNT ON
DECLARE @NumRetentionDays INT

SELECT 
	@NumRetentionDays = Config.Configuration_Value
FROM
	dbo.SQLPIG_Configuration_SF Config
WHERE
	Config.Configuration_Name = ''CPU Usage Retention Days''

DELETE PU 
FROM
	dbo.SQLPIG_Processor_Usage_SF PU
WHERE	
	PU.Report_Time < DATEADD(DAY, (-1 * @NumRetentionDays), GETDATE())
' 
END
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'PROCEDURE',N'SQLPIG_Archive_Processor_Usage_SF', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'PROCEDURE',@level1name=N'SQLPIG_Archive_Processor_Usage_SF'
GO





PRINT 'CREATING PROCEDURE SQLPIG_Archive_Memory_Usage_SF.....'
/******************************************************/
/* CREATE PROCEDURE SQLPIG_Archive_Memory_Usage_SF */
/******************************************************/
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQLPIG_Archive_Memory_Usage_SF]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = 
N'/****************************************************************************************************************************************************************
** Author: Jason Ingram
** Creation Date: 11/01/2013
** Purpose:  This procedure part of the SQLPIG utility.  It will delete old rows out of dbo.SQLPIG_Memory_Usage based on the value specified in the
**		dbo.SQLPIG_Configuration_SF table.
** Modification History:
**
****************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[SQLPIG_Archive_Memory_Usage_SF]
AS
SET NOCOUNT ON
DECLARE @NumRetentionDays INT

SELECT 
	@NumRetentionDays = Config.Configuration_Value
FROM
	dbo.SQLPIG_Configuration_SF Config
WHERE
	Config.Configuration_Name = ''Memory Usage Retention Days''

DELETE PU 
FROM
	dbo.SQLPIG_Memory_Usage_SF PU
WHERE	
	PU.Report_Time < DATEADD(DAY, (-1 * @NumRetentionDays), GETDATE())
' 
END
GO
IF NOT EXISTS (SELECT * FROM ::fn_listextendedproperty(N'Version' , N'SCHEMA',N'dbo', N'PROCEDURE',N'SQLPIG_Archive_Memory_Usage_SF', NULL,NULL))
EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1.0' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'PROCEDURE',@level1name=N'SQLPIG_Archive_Memory_Usage_SF'
GO




USE MSDB

PRINT 'CREATING AGENT JOB SQLPIG - Capture Processor Stats.....'
/****** Object:  Job [SQLPIG - Capture Processor Stats]    Script Date: 11/15/2013 11:00:34 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 11/15/2013 11:00:34 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
select @jobId = job_id from msdb.dbo.sysjobs where (name = N'SQLPIG - Capture Processor Stats')
if (@jobId is NULL)
BEGIN
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SQLPIG - Capture Processor Stats', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job will collect processor usage stats FOR the server instance.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sfsa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END
/****** Object:  Step [Processor Usage Capture]    Script Date: 11/15/2013 11:00:34 AM ******/
IF NOT EXISTS (SELECT * FROM msdb.dbo.sysjobsteps WHERE job_id = @jobId and step_id = 1)
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Processor Usage Capture', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.SQLPIG_Processor_Usage_Capture_SF', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'SQLPIG - Processor Capture - Daily', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20130930, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'SQLPIG - Processor Capture - On Startup', 
		@enabled=1, 
		@freq_type=64, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20131009, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
IF NOT EXISTS (SELECT 1 FROM dbo.sysjobs J INNER JOIN dbo.sysjobservers JS ON J.job_id = JS.job_id WHERE J.name = 'SQLPIG - Capture Processor Stats')
	EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_name = 'SQLPIG - Capture Processor Stats', @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO
PRINT 'Starting AGENT JOB SQLPIG - Capture Processor Stats.....'
IF NOT EXISTS (SELECT 1 FROM dbo.sysjobs J INNER JOIN dbo.sysjobactivity JA ON J.job_id = JA.job_id WHERE JA.last_executed_step_date IS NULL AND J.name = 'SQLPIG - Capture Processor Stats')
BEGIN
	EXEC sp_start_job @job_name=N'SQLPIG - Capture Processor Stats'
END
GO




PRINT 'CREATING AGENT JOB SQLPIG - Capture Memory Stats.....'
/****** Object:  Job [SQLPIG - Capture Memory Stats]    Script Date: 11/15/2013 11:00:05 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 11/15/2013 11:00:05 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
select @jobId = job_id from msdb.dbo.sysjobs where (name = N'SQLPIG - Capture Memory Stats')
if (@jobId is NULL)
BEGIN
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SQLPIG - Capture Memory Stats', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job will collect memory usage stats for the server instance.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sfsa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END
/****** Object:  Step [Memory Usage Capture]    Script Date: 11/15/2013 11:00:05 AM ******/
IF NOT EXISTS (SELECT * FROM msdb.dbo.sysjobsteps WHERE job_id = @jobId and step_id = 1)
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Memory Usage Capture', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.SQLPIG_Memory_Usage_Capture_SF', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'SQLPIG - Memory Capture - Daily', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20130930, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'SQLPIG - Memory Capture - On Startup', 
		@enabled=1, 
		@freq_type=64, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20131009, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
IF NOT EXISTS (SELECT 1 FROM dbo.sysjobs J INNER JOIN dbo.sysjobservers JS ON J.job_id = JS.job_id WHERE J.name = 'SQLPIG - Capture Memory Stats')
	EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_name = 'SQLPIG - Capture Memory Stats', @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO
PRINT 'STARTING AGENT JOB SQLPIG - Capture Memory Stats.....'
IF NOT EXISTS (SELECT 1 FROM dbo.sysjobs J INNER JOIN dbo.sysjobactivity JA ON J.job_id = JA.job_id WHERE JA.last_executed_step_date IS NULL AND J.name = 'SQLPIG - Capture Memory Stats')
BEGIN
	EXEC sp_start_job @job_name=N'SQLPIG - Capture Memory Stats'
END
GO




PRINT 'CREATING AGENT JOB SQLPIG - Archive Old Data.....'
/****** Object:  Job [SQLPIG - Archive Old Data]    Script Date: 11/15/2013 10:58:44 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 11/15/2013 10:58:44 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
select @jobId = job_id from msdb.dbo.sysjobs where (name = N'SQLPIG - Archive Old Data')
if (@jobId is NULL)
BEGIN
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SQLPIG - Archive Old Data', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sfsa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END
/****** Object:  Step [Delete Processor Usage Data]    Script Date: 11/15/2013 10:58:45 AM ******/
IF NOT EXISTS (SELECT * FROM msdb.dbo.sysjobsteps WHERE job_id = @jobId and step_id = 1)
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Delete Processor Usage Data', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.SQLPIG_Archive_Processor_Usage_SF', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Delete Memory Usage Data]    Script Date: 11/15/2013 10:58:45 AM ******/
IF NOT EXISTS (SELECT * FROM msdb.dbo.sysjobsteps WHERE job_id = @jobId and step_id = 2)
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Delete Memory Usage Data', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.SQLPIG_Archive_Memory_Usage_SF', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'SQLPIG Archive Data Daily run', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20131113, 
		@active_end_date=99991231, 
		@active_start_time=53000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
IF NOT EXISTS (SELECT 1 FROM dbo.sysjobs J INNER JOIN dbo.sysjobservers JS ON J.job_id = JS.job_id WHERE J.name = 'SQLPIG - Archive Old Data')
	EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_name = 'SQLPIG - Archive Old Data', @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

SELECT 'SUCCESS' AS Result
