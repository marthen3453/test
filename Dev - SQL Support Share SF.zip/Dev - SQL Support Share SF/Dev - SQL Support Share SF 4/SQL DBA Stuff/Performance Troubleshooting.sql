SELECT SUM(unallocated_extent_page_count) AS [free pages], 
(SUM(unallocated_extent_page_count)*1.0/128) AS [free space in MB]
FROM sys.dm_db_file_space_usage;

SELECT * FROM sys.dm_db_file_space_usage

SELECT SUM(version_store_reserved_page_count) AS [version store pages used],  (SUM(version_store_reserved_page_count)*1.0/128) AS [version store space in MB]  FROM tempdb.sys.dm_db_file_space_usage; 

SELECT * FROM sys.dm_tran_active_snapshot_database_transactions


SELECT @@SERVERNAME, COUNT(*) FROM sys.databases WHERE name LIKE 'C_TEAM%'

/**  SHAREPOINT ROW WRAPPING QUERY  **/
select tp_listID, COUNT(DISTINCT tp_RowOrdinal)--, tp_siteid, tp_RowOrdinal
from AllUserData (nolock)
where tp_RowOrdinal <> '0'
group by tp_ListId--, tp_SiteId, tp_RowOrdinal
ORDER by 2 DESC
/**  SHAREPOINT ROW WRAPPING QUERY  **/

/**  SHAREPOINT LIST COUNT QUERY  **/
SELECT tp_listID, tp_RowOrdinal, COUNT(*) 
FROM dbo.AllUserData 
GROUP BY tp_listID, tp_RowOrdinal 
ORDER BY 3 DESC
/**  SHAREPOINT LIST COUNT QUERY  **/

SELECT * FROM sys.databases WHERE database_id = 14

SELECT * FROM sys.objects WHERE OBJECT_ID = 274100017

SELECT * FROM sys.dm_tran_locks WHERE request_session_id = 532

SELECT 
	host_name
,	COUNT(*) AS HostConnections 
FROM sys.dm_exec_sessions
GROUP BY
	host_name
ORDER BY 2 DESC

SELECT * 
FROM sys.dm_exec_connections

SELECT * 
FROM 
	sys.dm_exec_requests 
	CROSS APPLY
	sys.dm_exec_sql_text(sql_handle)

SELECT
	a.session_id AS [SESSION ID],
	DB_NAME(c.dbid) AS [DATABASE Name],
	b.HOST_NAME AS [System Name],
	b.program_name AS [Program Name],
	d.[text] AS QueryText,
	last_request_start_time,
	last_request_end_time,
	login_name AS [USER Name],
	b.status,
	cpu_time AS [CPU TIME (in milisec)],
	total_scheduled_time AS [Total Scheduled TIME (in milisec)],
	total_elapsed_time AS    [Elapsed TIME (in milisec)],
	(memory_usage * 8)      AS [Memory USAGE (in KB)],
	(user_objects_alloc_page_count * 8) AS [SPACE Allocated FOR USER Objects (in KB)],
	(user_objects_dealloc_page_count * 8) AS [SPACE Deallocated FOR USER Objects (in KB)],
	(internal_objects_alloc_page_count * 8) AS [SPACE Allocated FOR Internal Objects (in KB)],
	(internal_objects_dealloc_page_count * 8) AS [SPACE Deallocated FOR Internal Objects (in KB)],
	CASE is_user_process
		WHEN 1      THEN 'user session'
		WHEN 0      THEN 'system session'
	END         AS [SESSION Type], row_count AS [ROW COUNT]
	, c.waittype
	, c.waittime
FROM 
	sys.dm_db_session_space_usage a
	INNER join
	sys.dm_exec_sessions b
		ON a.session_id = b.session_id
	INNER JOIN
	sys.sysprocesses c
		ON a.session_id = c.spid
	CROSS APPLY
	sys.dm_exec_sql_text(c.[sql_handle]) d
WHERE
	is_user_process = 1
	--AND
	--DB_NAME(c.dbid) = 'DEV_SPC_Collab_03'
	AND
	login_name NOT IN ('UNTOPR\SVC_SQL_DEV_SP2013', 'SUPPORT\SIA_KZR9')
	--AND
	--total_elapsed_time > 2000
	--AND
	--@@SERVERNAME IN ('WVSDGP7G', 'WVSDGP7J', 'WVSDGP7D', 'WVSDGP7L')
ORDER BY
	total_elapsed_time DESC


SELECT
	max_elapsed_time/100000 AS max_exec_time_seconds
,	execution_count
,	total_elapsed_time/execution_count/100000 AS avg_exec_time_seconds
,	LEFT(st.text, 50) AS query_text
--,	qs.*
FROM
	sys.dm_exec_query_stats AS qs
	CROSS APPLY 
	sys.dm_exec_sql_text (qs.sql_handle) st
WHERE
	max_elapsed_time > 1000000
ORDER BY
	max_elapsed_time DESC




DECLARE @sqltext VARBINARY(128)

SELECT @sqltext = [sql_handle] FROM sys.sysprocesses WHERE spid = 88

SELECT * FROM sys.dm_exec_sql_text (@sqltext)

SELECT * FROM sys.dm_exec_sessions WHERE session_id = 140

SELECT TOP 25 obj.name, max_logical_reads, max_elapsed_time
FROM sys.dm_exec_query_stats a
CROSS APPLY sys.dm_exec_sql_text(sql_handle) hnd
INNER JOIN sys.sysobjects obj on hnd.objectid = obj.id
ORDER BY max_logical_reads DESC


SELECT * FROM sys.dm_exec_query_stats ORDER BY total_worker_time DESC
SELECT * FROM sys.dm_exec_sql_text (0x0300050096D4167F12E6580194A2000001000000000000000000000000000000000000000000000000000000)

select top 10
t1.session_id, 
t1.request_id, 
t1.task_alloc,
     t1.task_dealloc,  
    (SELECT SUBSTRING(text, t2.statement_start_offset/2 + 1,
         (CASE WHEN statement_end_offset = -1 
              THEN LEN(CONVERT(nvarchar(max),text)) * 2 
                   ELSE statement_end_offset 
              END - t2.statement_start_offset)/2)
     FROM sys.dm_exec_sql_text(sql_handle)) AS query_text,
 (SELECT query_plan from sys.dm_exec_query_plan(t2.plan_handle)) as query_plan
from      (Select session_id, request_id,
sum(internal_objects_alloc_page_count +   user_objects_alloc_page_count) as task_alloc,
sum (internal_objects_dealloc_page_count + user_objects_dealloc_page_count) as task_dealloc
       from sys.dm_db_task_space_usage 
       group by session_id, request_id) as t1, 
       sys.dm_exec_requests as t2
where t1.session_id = t2.session_id and 
(t1.request_id = t2.request_id) and 
      t1.session_id > 50
order by t1.task_alloc DESC


/****  BLOCKING Queries  ****/

select session_id, blocking_session_id, wait_type, last_wait_type, * from sys.dm_exec_requests as der cross apply sys.dm_exec_sql_text(sql_handle)  

where (blocking_session_id <> 0 ) 
order by der.wait_type, der.session_id



with cte as 
(select request_session_id, count(request_session_id) as count_session from sys.dm_tran_locks where resource_database_id = 33 group by request_session_id )  

select des.login_name, 
des.host_name, 
des.login_time, cte.request_session_id, cte.count_session from cte inner join sys.dm_exec_sessions as des on des.session_id = cte.request_session_id order by cte.count_session desc



