select * FROM system_disc a
LEFT JOIN softwareinventory b ON a.itemkey = b.clientid
INNER JOIN softwarefile c ON b.fileid = c.fileid
INNER JOIN softwarefilepath d ON b.filepathid = d.filepathid
WHERE fileversion = '2011.0110.3000.00' and a.name0 like 'W_W%'


USE SCCM
select count(itemkey) AS SSMSCount
	,fileversion AS SSMSVersion
	,filepath AS SSMSFileLocation
	,e.level100
FROM system_disc a
LEFT JOIN softwareinventory b ON a.itemkey = b.clientid
INNER JOIN softwarefile c ON b.fileid = c.fileid
INNER JOIN softwarefilepath d ON b.filepathid = d.filepathid
Inner Join vMachineType_Data e ON a.itemkey = e.MachineID
WHERE filename = 'ssms.exe' and a.name0 like 'W_W%'
and filepath like 'C:\Program Files (x86)\Microsoft SQL Server\1%'
Group By FileVersion, filepath, e.level100
With Rollup