SELECT
	a.name
,	c.step_name
,	CASE c.run_status
		WHEN 1 THEN 'success'
		ELSE 'FAILED!!'
	END AS run_status
,	SUBSTRING(RIGHT('0000000' + CONVERT(VARCHAR(6), c.run_duration), 6), 1, 2) + ':' + 
	SUBSTRING(RIGHT('0000000' + CONVERT(VARCHAR(6), c.run_duration), 6), 3, 2) + ':' +
	SUBSTRING(RIGHT('0000000' + CONVERT(VARCHAR(6), c.run_duration), 6), 5, 2) 
	AS run_duration_HHMMSS
,	c.message
FROM
	msdb.dbo.sysjobs a
	INNER JOIN msdb.dbo.syscategories b ON b.category_id = a.category_id
	INNER JOIN msdb.dbo.sysjobhistory c ON c.job_id = a.job_id
WHERE
	b.name = 'Database Maintenance'
	AND
	c.step_id = 0
	AND
	CONVERT(DATETIME, CONVERT(VARCHAR(8), c.run_date)) >= DATEADD(DAY, -3, GETDATE())
ORDER BY
	a.name ASC
