
--DBCC SHRINKFILE (SCCM_LOG_02, EMPTYFILE);
--GO

--ALTER DATABASE SCCM
--REMOVE FILE SCCM_LOG_02;
--Go

--DBCC SHRINKFILE (SCCM_LOG_01.ldf, 204800,);


----Check the availablesize for Data Files and Logs
SELECT name ,size/128.0 - CAST(FILEPROPERTY(name, 'SpaceUsed') AS int)/128.0 AS AvailableSpaceInMB
FROM sys.database_files;
