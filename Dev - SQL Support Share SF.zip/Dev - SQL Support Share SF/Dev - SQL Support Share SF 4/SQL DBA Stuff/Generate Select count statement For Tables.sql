
-- * Generate statements
select 'Select count(*) ', substring(name,1,30), ';' from  sys.tables order by 2 ;

