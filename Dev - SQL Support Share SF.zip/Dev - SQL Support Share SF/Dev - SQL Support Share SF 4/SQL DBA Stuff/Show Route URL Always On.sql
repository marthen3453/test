select 
	ar.replica_server_name "When This Server is Primary",
	r1.routing_priority,
	ar2.replica_server_name "Route to this Server",
	ar.secondary_role_allow_connections_desc,
	ar2.read_only_routing_url
from
	sys.availability_read_only_routing_lists r1
Inner Join
	sys.availability_replicas ar
ON
	r1.replica_id = ar.replica_id
Inner Join
	sys.availability_replicas ar2
On 
	r1.read_only_replica_id=ar2.replica_id
ORDER BY 
	ar.replica_server_name,r1.routing_priority
