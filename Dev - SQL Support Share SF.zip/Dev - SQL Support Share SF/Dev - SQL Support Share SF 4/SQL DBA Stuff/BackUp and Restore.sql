--Backup on Production

Backup database [AirWatch-4HS]
to disk = 'H:\JASON\AirWatch_JASON_WVSDZT00_COPYONLY_COMP.BAK'
with stats = 10, copy_only, compression


--	Restore on Forest A

ALTER DATABASE [AirWatch-4HS] SET OFFLINE WITH ROLLBACK IMMEDIATE
RESTORE DATABASE [AirWatch-4HS]
from disk = 'H:\JASON\AirWatch_JASON_WVSDZT00_COPYONLY_COMP.BAK'
with 
move 'AirWatch' to 'I:\MSSQL\DATA\AirWatch-4HS_data.mdf',
move 'AirWatch_log' to 'G:\MSSQL\LOGS\AirWatch-4HS_log.ldf',
stats = 10, replace

USE master
GO
ALTER DATABASE [AirWatch-4HS]
MODIFY FILE
(NAME = 'AirWatch', NEWNAME= 'AirWatch-4HS_data')
GO

ALTER DATABASE [AirWatch-4HS]
MODIFY FILE
(NAME = 'AirWatch_log', NEWNAME= 'AirWatch-4HS_log')
GO


--Permission 
SUPPORT\SA_MDMAdmin_G - READ
UNTOPR\UTL_MDMAdmin - DBO
