--To Find what Databases have SIMPLE RECOVERY 
select name from sys.databases where recovery_model_desc ='simple'