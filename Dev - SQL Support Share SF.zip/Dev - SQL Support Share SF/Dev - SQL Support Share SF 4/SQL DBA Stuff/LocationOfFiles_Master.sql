------  Location of Files with Logical and Physical Name
------ This is handy if Database is offline
USE master
GO
SELECT name AS LogicalFileName, physical_name AS FileLocation
, state_desc AS Status 
FROM sys.master_files 
WHERE database_id = DB_ID('BBarchive'); --- Change Database name


----- Run this from the DB that you need location of files
SELECT 
	f.name AS [File Name],
	f.physical_name AS [Physical Name],
	CAST((f.size/128.0) AS DECIMAL(15,2)) AS [Total Size in MB],
	CAST(f.size/128.0 - CAST(FILEPROPERTY(f.name, 'SpaceUsed') AS int)/128.0 AS DECIMAL(15,2))  AS [Available Space In MB],
	[file_id], fg.name AS [Filegroup Name] 
FROM sys.database_files AS f WITH (NOLOCK)  
LEFT OUTER JOIN sys.data_spaces AS fg WITH (NOLOCK)  ON f.data_space_id = fg.data_space_id 
OPTION (RECOMPILE);  
