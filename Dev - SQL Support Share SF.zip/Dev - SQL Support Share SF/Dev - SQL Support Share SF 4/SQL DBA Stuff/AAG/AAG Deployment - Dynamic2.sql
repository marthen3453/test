SET NOCOUNT ON 
CREATE TABLE #AAGNames
(
	AAGNumber				TINYINT
,	AAGName					VARCHAR(16)
)

CREATE TABLE #AAGIPAdds
(
	AAGNumber			TINYINT
,	AAGIPNumber			TINYINT
,	AAGListenerIP		VARCHAR(16)
,	AAGListenerSubnet	VARCHAR(16)
)

CREATE TABLE #AAGServers
(
	AAGNumber			TINYINT
,	AAGServerNumber		TINYINT
,	ServerName			VARCHAR(16)
,	InstanceName		VARCHAR(128)
,	FailoverMode		VARCHAR(64)
,	AvailMode			VARCHAR(64)
,	BackupPriority		VARCHAR(2)
,	PrimaryRole			VARCHAR(64)
)

/****  Enter a distinct number, starting at 1, for each Listener in the CLUSTER (not per instance)  ****/
INSERT INTO #AAGNames VALUES 
(		1, 'WSLD5YZM01'		)
--, (		2, 'WSLDWRGJ02'		)
--, (		3, 'WSLDWRGJ03'		)
--, (		4, 'WSLDWRGJ04'		)

/****  For each Listener, enter one row of values per IP address designated in WSDB, numbering each IP address in order, starting at the Primary IP as 1  ****/
INSERT INTO #AAGIPAdds VALUES
/****	AAG#	IP#		ListenerIP			ListenerSubnet		****/
(		1,		1,		'10.97.48.170',	'255.255.254.0'		)
, (		1,		2,		'10.129.48.126',	'255.255.254.0'		)

--INSERT INTO #AAGIPAdds VALUES
--(		2,		1,		'10.250.144.81',	'255.255.252.0'		)
--, (		2,		2,		'10.250.156.113',	'255.255.252.0'		)

--INSERT INTO #AAGIPAdds VALUES
--(		3,		1,		'10.250.144.82',	'255.255.252.0'		)
--, (		3,		2,		'10.250.156.114',	'255.255.252.0'		)

--INSERT INTO #AAGIPAdds VALUES
--(		4,		1,		'10.250.144.83',	'255.255.252.0'		)
--, (		4,		2,		'10.250.156.115',	'255.255.252.0'		)

/****  For each Listener, enter one row for each SERVER/INSTANCE replica in the AAG, numbering each server in order, starting with the Primary Server as 1. ****/
INSERT INTO #AAGServers VALUES
/****	AAG#	Server#		ServerName	InstanceName	FailoverMode	Commit Type				BackupPriority		Allow Readable Secondary	****/
(		1,		1,			'WPSD5YZM', 'WMSD5YZM01',	'AUTOMATIC',	'SYNCHRONOUS_COMMIT',	'50',				'(ALLOW_CONNECTIONS = ALL)'		)
, (		1,		2,			'WPSD5YZN',	'WMSD5YZM02',	'AUTOMATIC',	'SYNCHRONOUS_COMMIT',	'50',				'(ALLOW_CONNECTIONS = ALL)'		)
, (		1,		3,			'WPSD5YZP', 'WMSD5YZM03',	'MANUAL',		'ASYNCHRONOUS_COMMIT',	'1',				'(ALLOW_CONNECTIONS = ALL)'		)

--INSERT INTO #AAGServers VALUES
--(		2,		1,			'WTSDWRGJ', 'WMSDWRGJ02',	'AUTOMATIC',	'SYNCHRONOUS_COMMIT',	'50',				'(ALLOW_CONNECTIONS = ALL)'		)
--, (		2,		2,			'WTSDWRGK', 'WMSDWRGJ04',	'AUTOMATIC',	'SYNCHRONOUS_COMMIT',	'50',				'(ALLOW_CONNECTIONS = ALL)'		)
--, (		2,		3,			'WTSDWRGL', 'WMSDWRGJ06',	'MANUAL',		'ASYNCHRONOUS_COMMIT',	'1',				'(ALLOW_CONNECTIONS = ALL)'		)

--INSERT INTO #AAGServers VALUES
--(		3,		1,			'WTSDWRGJ', 'WMSDWRGJ01',	'AUTOMATIC',	'SYNCHRONOUS_COMMIT',	'50',				'(ALLOW_CONNECTIONS = ALL)'		)
--, (		3,		2,			'WTSDWRGK', 'WMSDWRGJ03',	'AUTOMATIC',	'SYNCHRONOUS_COMMIT',	'50',				'(ALLOW_CONNECTIONS = ALL)'		)
--, (		3,		3,			'WTSDWRGL', 'WMSDWRGJ05',	'MANUAL',		'ASYNCHRONOUS_COMMIT',	'1',				'(ALLOW_CONNECTIONS = ALL)'		)

--INSERT INTO #AAGServers VALUES
--(		4,		1,			'WTSDWRGJ', 'WMSDWRGJ02',	'AUTOMATIC',	'SYNCHRONOUS_COMMIT',	'50',				'(ALLOW_CONNECTIONS = ALL)'		)
--, (		4,		2,			'WTSDWRGK', 'WMSDWRGJ04',	'AUTOMATIC',	'SYNCHRONOUS_COMMIT',	'50',				'(ALLOW_CONNECTIONS = ALL)'		)
--, (		4,		3,			'WTSDWRGL', 'WMSDWRGJ06',	'MANUAL',		'ASYNCHRONOUS_COMMIT',	'1',				'(ALLOW_CONNECTIONS = ALL)'		)


--SELECT * FROM #AAGNames
--SELECT * FROM #AAGIPAdds
--SELECT * FROM #AAGServers





/********************************************************************************************************************************/
/********************************************************************************************************************************/
/********************************************************************************************************************************/
/********************************************************************************************************************************/
/********************************************************************************************************************************/

DECLARE	@ListenerPortStartNum	INT
,		@EndpointPortStartNum	INT
,		@FullDomainName			VARCHAR(256)
,		@SQLServiceAccountName	VARCHAR(256)
,		@cmd					VARCHAR(2048)

SET @ListenerPortStartNum = 57750
SET @EndpointPortStartNum = 57780

SELECT @FullDomainName = 
	CASE DEFAULT_DOMAIN()
		WHEN 'OPR' THEN 'opr.statefarm.org'
		WHEN 'OPRSYS' THEN 'opr.system.test.statefarm.org'
		WHEN 'UNTOPR' THEN 'unitopr.unitint.test.statefarm.org'
		WHEN 'SUPPORT' THEN 'support.statefarm.org'
		ELSE ''
	END

EXEC [master].dbo.xp_instance_regread
              @rootkey      = N'HKEY_LOCAL_MACHINE',
              @key          = N'SYSTEM\CurrentControlSet\Services\MSSQLServer',
              @value_name   = N'ObjectName',
              @value        = @SQLServiceAccountName OUTPUT

IF EXISTS 
	(	SELECT DISTINCT
			c.AAGName
		,	a.ServerName + '\' + a.InstanceName
		FROM #AAGServers a
			INNER JOIN #AAGIPAdds b
				ON a.AAGNumber = b.AAGNumber
			INNER JOIN #AAGNames c
				ON a.AAGNumber = c.AAGNumber
		WHERE 
			a.ServerName + '\' + a.InstanceName = @@SERVERNAME
			AND
			a.AAGServerNumber = 1
			AND
			c.AAGName IS NOT NULL
			AND
			b.AAGListenerIP IS NOT NULL
	)
BEGIN
	PRINT '/****  PRIMARY SERVER  ****/'

	/****  PRIMARY SERVER  ****/
	SET @EndpointPortStartNum = @EndpointPortStartNum + 
		(	SELECT DISTINCT
				MIN(c.AAGNumber)
			FROM #AAGServers a
				INNER JOIN #AAGIPAdds b
					ON a.AAGNumber = b.AAGNumber
				INNER JOIN #AAGNames c
					ON a.AAGNumber = c.AAGNumber
			WHERE 
				a.ServerName + '\' + a.InstanceName = @@SERVERNAME
				AND
				c.AAGName IS NOT NULL
				AND
				b.AAGListenerIP IS NOT NULL
		)

	SET @cmd = 'USE [master]
	
	IF NOT EXISTS (SELECT 1 FROM [master].sys.server_principals WHERE name = ''' + @SQLServiceAccountName + ''')
		CREATE LOGIN [' + @SQLServiceAccountName + '] FROM WINDOWS
	
	IF NOT EXISTS (SELECT 1 FROM sys.endpoints WHERE name = N''Hadr_endpoint'')
		CREATE ENDPOINT [Hadr_endpoint] AUTHORIZATION [sfsa]
			AS TCP (LISTENER_PORT = ' + CONVERT(VARCHAR(5), @EndpointPortStartNum) + ')
			FOR DATA_MIRRORING (ROLE = ALL, ENCRYPTION = REQUIRED ALGORITHM AES)
	
	IF (SELECT state FROM sys.endpoints WHERE name = N''Hadr_endpoint'') <> 0
	BEGIN
		ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED;
	END
	
	GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [' + @SQLServiceAccountName + '] AS [sfsa];
		
	IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name=''AlwaysOn_health'')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=ON);
	END
	IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name=''AlwaysOn_health'')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
	END
	'
	
	--PRINT @cmd
	PRINT '/****  CONFIGURING ENDPOINTS  ****/ '
	EXEC (@cmd)

	WAITFOR DELAY '00:00:05'

	IF EXISTS 
	(	SELECT DISTINCT
			1
		FROM #AAGServers a
			INNER JOIN #AAGIPAdds b
				ON a.AAGNumber = b.AAGNumber
			INNER JOIN #AAGNames c
				ON a.AAGNumber = c.AAGNumber
			LEFT OUTER JOIN master.sys.availability_groups d
				ON 	c.AAGName = d.name
		WHERE 
			a.ServerName + '\' + a.InstanceName = @@SERVERNAME
			AND
			a.AAGServerNumber = 1
			AND
			c.AAGName IS NOT NULL
			AND
			b.AAGListenerIP IS NOT NULL
			AND
			d.name IS NULL
	)
	BEGIN
		DECLARE 	@AAGNumber		TINYINT
		,			@NewAAGName		VARCHAR(16)
		,			@AAGcmd			VARCHAR(5000)

		DECLARE AAGCursor CURSOR STATIC FOR
		SELECT DISTINCT
			c.AAGNumber
		,	c.AAGName
		FROM #AAGServers a
			INNER JOIN #AAGIPAdds b
				ON a.AAGNumber = b.AAGNumber
			INNER JOIN #AAGNames c
				ON a.AAGNumber = c.AAGNumber
			LEFT OUTER JOIN master.sys.availability_groups d
				ON 	c.AAGName = d.name
		WHERE 
			a.ServerName + '\' + a.InstanceName = @@SERVERNAME
			AND
			a.AAGServerNumber = 1
			AND
			c.AAGName IS NOT NULL
			AND
			b.AAGListenerIP IS NOT NULL
			AND
			d.name IS NULL
		ORDER BY
			c.AAGNumber ASC

		OPEN AAGCursor

		FETCH FIRST FROM AAGCursor INTO @AAGNumber,	@NewAAGName

		WHILE @@FETCH_STATUS = 0
		BEGIN
			
			DECLARE		@IPCount				TINYINT
			,			@NewAAGListenerIP		VARCHAR(16)
			,			@NewAAGListenerSubnet	VARCHAR(16)
			,			@NewAAGListenerPort		VARCHAR(5)
			,			@ServerCount			TINYINT
			,			@NewServer				VARCHAR(16)
			,			@NewInstanceName		VARCHAR(128)
			,			@NewFailoverMode		VARCHAR(64)
			,			@NewAvailMode			VARCHAR(64)
			,			@NewBackupPriority		VARCHAR(2)
			,			@NewRole				VARCHAR(64)

			SET @IPCount = 1
			SET @ServerCount = 1

			SET @AAGcmd = '
			CREATE AVAILABILITY GROUP [' + @NewAAGName + ']
			WITH (AUTOMATED_BACKUP_PREFERENCE = SECONDARY)
			FOR 
			REPLICA ON 
					'

			WHILE @ServerCount <= 
			(	SELECT 
					MAX(a.AAGServerNumber)
				FROM #AAGServers a
					INNER JOIN #AAGIPAdds b
						ON a.AAGNumber = b.AAGNumber
					INNER JOIN #AAGNames c
						ON a.AAGNumber = c.AAGNumber
				WHERE 
					c.AAGName = @NewAAGName
			)
			BEGIN
				SELECT 
					@NewServer = ServerName
				,	@NewInstanceName = InstanceName
				,	@NewFailoverMode = FailoverMode
				,	@NewAvailMode = AvailMode
				,	@NewBackupPriority = BackupPriority
				,	@NewRole = PrimaryRole
				FROM #AAGServers a
					INNER JOIN #AAGNames c
						ON a.AAGNumber = c.AAGNumber
				WHERE 
					c.AAGName = @NewAAGName
					AND
					a.AAGServerNumber = @ServerCount

				SET @AAGcmd = @AAGcmd + 'N''' + @NewServer + '\' + @NewInstanceName + ''' WITH (ENDPOINT_URL = N''TCP://' + @NewServer + '.' + @FullDomainName + ':' + CONVERT(VARCHAR(5), @EndpointPortStartNum) + ''', FAILOVER_MODE = ' + @NewFailoverMode + ', AVAILABILITY_MODE = ' + @NewAvailMode + ', BACKUP_PRIORITY = ' + @NewBackupPriority + ', SECONDARY_ROLE' + @NewRole + ')'
				
				IF @ServerCount < 
					(	SELECT 
							MAX(a.AAGServerNumber)
						FROM #AAGServers a
							INNER JOIN #AAGIPAdds b
								ON a.AAGNumber = b.AAGNumber
							INNER JOIN #AAGNames c
								ON a.AAGNumber = c.AAGNumber
						WHERE 
							c.AAGName = @NewAAGName
					)
				BEGIN
					SET @AAGcmd = @AAGcmd + ',
					' 
				END
				ELSE
				BEGIN
					SET @AAGcmd = @AAGcmd + ';
					' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)
				END

				SET @ServerCount = @ServerCount + 1
			END

			SELECT @NewAAGListenerPort = CONVERT(VARCHAR(5), (@ListenerPortStartNum + @AAGNumber))

			SET @AAGcmd = @AAGcmd + 'ALTER AVAILABILITY GROUP [' + @NewAAGName + ']
			ADD LISTENER N''' + @NewAAGName + ''' (
			WITH IP
			(
				'

			WHILE @IPCount <= 
			(	SELECT 
					MAX(b.AAGIPNumber)
				FROM #AAGServers a
					INNER JOIN #AAGIPAdds b
						ON a.AAGNumber = b.AAGNumber
					INNER JOIN #AAGNames c
						ON a.AAGNumber = c.AAGNumber
				WHERE 
					c.AAGName = @NewAAGName
			)
			BEGIN
				SELECT 
					@NewAAGListenerIP = AAGListenerIP
				,	@NewAAGListenerSubnet = AAGListenerSubnet
				FROM #AAGIPAdds a
					INNER JOIN #AAGNames c
						ON a.AAGNumber = c.AAGNumber
				WHERE 
					c.AAGName = @NewAAGName
					AND
					a.AAGIPNumber = @IPCount

				SET @AAGcmd = @AAGcmd + '(N''' + @NewAAGListenerIP + ''', N''' + @NewAAGListenerSubnet + ''')'
						
				IF @IPCount < 
					(	SELECT 
							MAX(b.AAGIPNumber)
						FROM #AAGServers a
							INNER JOIN #AAGIPAdds b
								ON a.AAGNumber = b.AAGNumber
							INNER JOIN #AAGNames c
								ON a.AAGNumber = c.AAGNumber
						WHERE 
							c.AAGName = @NewAAGName
					)
				BEGIN
					SET @AAGcmd = @AAGcmd + ',
				' 
				END
				ELSE
				BEGIN
					SET @AAGcmd = @AAGcmd + '
			),	PORT=' + @NewAAGListenerPort + ');			
			'
				END

				SET @IPCount = @IPCount + 1
			END

			--PRINT @AAGcmd
			PRINT '/****  CONFIGURING PRIMARY AAG  ****/ '
			EXEC (@AAGcmd)

			FETCH NEXT FROM AAGCursor INTO @AAGNumber,	@NewAAGName
		END --End Cursor Loop

		CLOSE AAGCursor
		DEALLOCATE AAGCursor

	END --End Create AAGs

END --End Primary Server
ELSE IF EXISTS 
		(	SELECT DISTINCT
			c.AAGName
		,	a.ServerName + '\' + a.InstanceName
		FROM #AAGServers a
			INNER JOIN #AAGIPAdds b
				ON a.AAGNumber = b.AAGNumber
			INNER JOIN #AAGNames c
				ON a.AAGNumber = c.AAGNumber
		WHERE 
			a.ServerName + '\' + a.InstanceName = @@SERVERNAME
			AND
			a.AAGServerNumber > 1
			AND
			c.AAGName IS NOT NULL
			AND
			b.AAGListenerIP IS NOT NULL
	)
BEGIN
	PRINT '/****  SECONDARY SERVER  ****/'

	SET @EndpointPortStartNum = @EndpointPortStartNum + 
		(	SELECT DISTINCT
				MIN(c.AAGNumber)
			FROM #AAGServers a
				INNER JOIN #AAGIPAdds b
					ON a.AAGNumber = b.AAGNumber
				INNER JOIN #AAGNames c
					ON a.AAGNumber = c.AAGNumber
			WHERE 
				a.ServerName + '\' + a.InstanceName = @@SERVERNAME
				AND
				c.AAGName IS NOT NULL
				AND
				b.AAGListenerIP IS NOT NULL
		)

	SET @cmd = 'USE [master]
	
	IF NOT EXISTS (SELECT 1 FROM [master].sys.server_principals WHERE name = ''' + @SQLServiceAccountName + ''')
		CREATE LOGIN [' + @SQLServiceAccountName + '] FROM WINDOWS
	
	IF NOT EXISTS (SELECT 1 FROM sys.endpoints WHERE name = N''Hadr_endpoint'')
		CREATE ENDPOINT [Hadr_endpoint] AUTHORIZATION [sfsa]
			AS TCP (LISTENER_PORT = ' + CONVERT(VARCHAR(5), @EndpointPortStartNum) + ')
			FOR DATA_MIRRORING (ROLE = ALL, ENCRYPTION = REQUIRED ALGORITHM AES)
	
	IF (SELECT state FROM sys.endpoints WHERE name = N''Hadr_endpoint'') <> 0
	BEGIN
		ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED;
	END
	
	GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [' + @SQLServiceAccountName + '] AS [sfsa];
		
	IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name=''AlwaysOn_health'')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=ON);
	END
	IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name=''AlwaysOn_health'')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
	END
	'
	
	--PRINT @cmd
	PRINT '/****  CONFIGURING ENDPOINTS  ****/ '
	EXEC (@cmd)
	
	--While Deployed AAGs < Deployable AAGs, wait for 5 seconds
	WHILE 
	(	SELECT 
			COUNT(*) AS DeployedAAGs
		FROM #AAGServers a
			INNER JOIN #AAGNames c
				ON a.AAGNumber = c.AAGNumber 
			LEFT OUTER JOIN master.sys.availability_groups_cluster d 
				ON c.AAGName = d.name 
		WHERE
			(a.ServerName + '\' + a.InstanceName = @@SERVERNAME)
			AND
			d.name IS NOT NULL
	)
	<
	(	SELECT 
			COUNT(*) AS DeployableAAGs
		FROM #AAGServers a
			INNER JOIN #AAGNames c
				ON a.AAGNumber = c.AAGNumber  
		WHERE
			(a.ServerName + '\' + a.InstanceName = @@SERVERNAME)
	)
	BEGIN
		WAITFOR DELAY '00:00:05'
	END

	IF (	SELECT 
			COUNT(*) AS DeployedAAGs
		FROM #AAGServers a
			INNER JOIN #AAGNames c
				ON a.AAGNumber = c.AAGNumber 
			LEFT OUTER JOIN master.sys.availability_groups_cluster d 
				ON c.AAGName = d.name 
		WHERE
			(a.ServerName + '\' + a.InstanceName = @@SERVERNAME)
			AND
			d.name IS NOT NULL
	)
	=
	(	SELECT 
			COUNT(*) AS DeployableAAGs
		FROM #AAGServers a
			INNER JOIN #AAGNames c
				ON a.AAGNumber = c.AAGNumber  
		WHERE
			(a.ServerName + '\' + a.InstanceName = @@SERVERNAME)
	)
	BEGIN
		WAITFOR DELAY '00:00:05'
		
		DECLARE 	@NewAAGNumber						TINYINT
		,			@NewAAGNameSec					VARCHAR(16)
		,			@AAGcmdSec						VARCHAR(5120)

		DECLARE AAGCursor CURSOR STATIC FOR
		SELECT DISTINCT
			c.AAGNumber
		,	c.AAGName
		FROM #AAGServers a
			INNER JOIN #AAGIPAdds b
				ON a.AAGNumber = b.AAGNumber
			INNER JOIN #AAGNames c
				ON a.AAGNumber = c.AAGNumber
			LEFT OUTER JOIN master.sys.availability_groups d
				ON 	c.AAGName = d.name
		WHERE 
			a.ServerName + '\' + a.InstanceName = @@SERVERNAME
			AND
			a.AAGServerNumber > 1
			AND
			c.AAGName IS NOT NULL
			AND
			b.AAGListenerIP IS NOT NULL
			AND
			d.name IS NULL
		ORDER BY
			c.AAGNumber ASC

		OPEN AAGCursor

		FETCH FIRST FROM AAGCursor INTO @NewAAGNumber, @NewAAGNameSec

		WHILE @@FETCH_STATUS = 0
		BEGIN
			
			SET @AAGcmdSec = '
			ALTER AVAILABILITY GROUP ' + @NewAAGNameSec + ' JOIN;
			'

			--PRINT @AAGcmdSec
			PRINT '/****  CONFIGURING SECONDARY AAG  ****/ '
			EXEC (@AAGcmdSec)

			FETCH NEXT FROM AAGCursor INTO @NewAAGNumber, @NewAAGNameSec
		END --End Cursor Loop

		CLOSE AAGCursor
		DEALLOCATE AAGCursor
	END

END --End Secondary Servers
ELSE 
BEGIN
	PRINT '/* NO CONFIGURATION VALUE */'
END


DROP TABLE #AAGNames
DROP TABLE #AAGIPAdds
DROP TABLE #AAGServers