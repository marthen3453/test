SET NOCOUNT ON

DECLARE @BackupDir			VARCHAR(256)
,		@DBName				VARCHAR(256)
,		@BackupFullCMD		VARCHAR(1024)
,		@BackupLogCMD		VARCHAR(1024)
,		@RestoreFullCMD		VARCHAR(1024)
,		@RestoreLogCMD		VARCHAR(1024)
,		@AAGName			VARCHAR(16)
,		@AAGPrimaryCMD		VARCHAR(512)
,		@AAGSecondaryCMD	VARCHAR(512)


EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'BackupDirectory', @BackupDir OUTPUT

IF (SELECT COUNT(*) FROM master.sys.availability_groups) = 1
BEGIN
	SELECT @AAGName = name FROM master.sys.availability_groups
END
ELSE 
BEGIN
	PRINT '**** MORE THAN ONE AVAILABILITY GROUP!!!! ****'
	PRINT '**** CHOOSE AAG NAME AND DATABASES SEPARATELY!!!! ****'
	SELECT '**** MORE THAN ONE AVAILABILITY GROUP!!!! ****'
	SELECT '**** CHOOSE AAG NAME AND DATABASES SEPARATELY!!!! ****'
	SELECT name FROM master.sys.availability_groups
	
	/****  CHOOSE AAG NAME HERE ****/
	SELECT @AAGName = 'WSLDWRGJ01'
	/****  CHOOSE AAG NAME HERE ****/

END

--SELECT @BackupDir
--SELECT @AAGName

DECLARE DBNames CURSOR STATIC FOR
SELECT name FROM sys.databases 

/**** SELECT ALL DATABASES HERE ****/
WHERE name NOT IN ('master', 'model', 'msdb', 'tempdb', 'reportserver', 'reportservertempdb', 'SF_SQL_ADMIN') 
/**** SELECT ALL DATABASES HERE ****/

/**** SELECT SPECIFIC DATABASES HERE ****/
--WHERE name IN ('SP2013Migration')
/**** SELECT SPECIFIC DATABASES HERE ****/

ORDER BY name ASC

OPEN DBNames

FETCH FIRST FROM DBNames INTO @DBName

WHILE @@FETCH_STATUS = 0
BEGIN

	--PRINT @DBName

	SELECT @BackupFullCMD = 'BACKUP DATABASE ' + @DBName + '
	TO DISK = N''' + @BackupDir + '\' + @DBName + '_FullDB.BAK''
	WITH  
		--COPY_ONLY, 
	NOFORMAT, INIT, SKIP, NOREWIND, NOUNLOAD, COMPRESSION;'

	SELECT @BackupLogCMD = 'BACKUP LOG ' + @DBName + '
	TO DISK = N''' + @BackupDir + '\' + @DBName + '_TrnLog.BAK''
	WITH  NOFORMAT, INIT, SKIP, NOREWIND, NOUNLOAD, COMPRESSION;'

	--PRINT @BackupFullCMD
	--PRINT ''
	--PRINT @BackupLogCMD
	--PRINT ''

	SELECT @RestoreFullCMD = 'RESTORE DATABASE ' + @DBName + '
	FROM DISK = N''' + @BackupDir + '\' + @DBName + '_FullDB.BAK''
		WITH REPLACE, NORECOVERY'

	SELECT @RestoreLogCMD = 'RESTORE DATABASE ' + @DBName + '
	FROM DISK = N''' + @BackupDir + '\' + @DBName + '_TrnLog.BAK''
		WITH NORECOVERY'

	SELECT @AAGSecondaryCMD = 'ALTER DATABASE [' + @DBName + '] SET HADR AVAILABILITY GROUP = [' + @AAGName + '];'

	PRINT ''
	PRINT ''
	PRINT @RestoreFullCMD
	PRINT ''
	PRINT @RestoreLogCMD
	PRINT ''
	PRINT @AAGSecondaryCMD
	PRINT ''

	IF NOT EXISTS (
					SELECT 
						1 
					FROM 
						master.sys.databases a
						INNER JOIN
						master.sys.availability_replicas b
							ON a.replica_id = b.replica_id
								AND b.replica_server_name = @@SERVERNAME
								AND a.name = @DBName
					)
	BEGIN
		SELECT @AAGPrimaryCMD = 'ALTER AVAILABILITY GROUP ' + @AAGName + ' ADD DATABASE [' + @DBName + '];'
	END
	ELSE 
		SELECT @AAGPrimaryCMD = NULL
	
	--EXEC (@BackupFullCMD)
	--EXEC (@BackupLogCMD)
	--EXEC (@AAGPrimaryCMD)

	FETCH NEXT FROM DBNames INTO @DBName
END

CLOSE DBNames
DEALLOCATE DBNames





