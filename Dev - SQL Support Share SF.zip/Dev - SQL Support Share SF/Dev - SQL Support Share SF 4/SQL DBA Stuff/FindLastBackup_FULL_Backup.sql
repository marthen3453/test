select Backup_Size,Backup_Start_Date from dbo.backupset where database_name = 'VHT_PIC4_RPT' 
AND Type ='L'
order by backup_start_date DESC