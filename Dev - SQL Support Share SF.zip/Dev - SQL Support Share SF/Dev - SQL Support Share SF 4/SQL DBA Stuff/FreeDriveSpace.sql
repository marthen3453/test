select	
	b.name0, 
	a.Size0, 
	a.FreeSpace0, 
	DeviceID0 
from 
	v_gs_logical_disk a 
inner join 
	v_gs_system b 
		on a.resourceID = b.resourceID
where 
	b.Name0
		IN ('WPSDL32v','wpsdl321','wpsdl323','wpsdl32x','wpsdl32z','wpsdppyb')
		

