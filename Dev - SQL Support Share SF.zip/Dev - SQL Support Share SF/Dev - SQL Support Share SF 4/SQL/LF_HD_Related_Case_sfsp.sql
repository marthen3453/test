USE [LegalFiles]
GO

/****** Object:  StoredProcedure [dbo].[LF_HD_Related_Case_sfsp]    Script Date: 8/27/2015 3:52:29 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



--DROP PROCEDURE [dbo].[LF_HD_Related_Case_sfsp] 
CREATE PROCEDURE  [dbo].[LF_HD_Related_Case_sfsp]
 (     
 @Return_Message VARCHAR(1024) = ''  OUT

 ) AS      
 SET NOCOUNT ON;  
 /****************************** 
 *  Variable Declarations 
 *******************************/     
 DECLARE     @ErrorCode  int       
 DECLARE     @ErrorStep  varchar(200)  
 
 /****************************** 
 *  Initialize Variables 
 *******************************/      
 SELECT @ErrorCode = @@ERROR 
 
 INSERT INTO LF_HD.DBO.LOG_Data ( sType, sMessage )
 SELECT 'LF_HD_Related_Case_sfsp', 'Data Transfer Started';
 
 BEGIN TRY      
 BEGIN TRAN         
   EXEC LF_HD.dbo.proc_Truncate_Table_SFSP @Table = 'LF_HD.dbo.LF_Related_Case';
			  With
			  FileFacts (FileFacts, EntityID) as
			  (Select NoteText, EntityID from Notes
			  where Notes.NoteTopic = 'File Facts'),
			  DateFileReceived (DateFileReceived, FileID) as
			  (Select DateStatus, FileID from FileHst, Xtable
			  where FileStatusId = XTableId
			  and Description = 'File Received'),
			  DateNotified (DateNotified, FileID) as
			  (Select DateStatus, FileID from FileHst, Xtable
			  where FileStatusId = XTableId
			  and Description = 'Notified'),
			  Caption1 (CaptionsEntityID, Attorney_for_NoteId, Defendants_for_Caption_NoteId, Plaintiffs_for_Caption_NoteId, Trial_Date, CMC_Date, CMC_Time) as
			  (Select EntityId,Attorney_for_NoteId, Defendants_for_Caption_NoteId, Plaintiffs_for_Caption_NoteId, Trial_Date, CMC_Date, CMC_Time from Captions
			  where Caption_Type_Desc = '1st named caption'),
			  Caption2 (CaptionsEntityID, Attorney_for_NoteId, Defendants_for_Caption_NoteId, Plaintiffs_for_Caption_NoteId, Trial_Date, CMC_Date, CMC_Time) as
			  (Select EntityId,Attorney_for_NoteId, Defendants_for_Caption_NoteId, Plaintiffs_for_Caption_NoteId, Trial_Date, CMC_Date, CMC_Time from Captions
			  where Caption_Type_Desc = '2nd named caption'),
			  Caption3 (CaptionsEntityID, Attorney_for_NoteId, Defendants_for_Caption_NoteId, Plaintiffs_for_Caption_NoteId, Trial_Date, CMC_Date, CMC_Time) as
			  (Select EntityId,Attorney_for_NoteId, Defendants_for_Caption_NoteId, Plaintiffs_for_Caption_NoteId, Trial_Date, CMC_Date, CMC_Time from Captions
			  where Caption_Type_Desc = '3rd named caption')

--Insert Into DBO.LF_Related_Case
Insert Into LF_HD.DBO.LF_Related_Case

(
			  MainFileId,
			  FileId,
			  SiteID,
			  SuitType,
  			  IncidentType,
			  DateClose,
			  DateOpen,
			  Issue,
			  NameFile,
			  Long_File_Name,
			  OpenFileNo,
			  ReasonClosed,
			  ClaimType,
			  LossType,
			  FileType,
			  DateFileReceived,
			  DateNotified,
			  FileFacts,
	  		  AttorneyForCaption1,
			  DefendantsForCaption1,
			  PlaintiffsForCaption1,
			  Trial_Date_for_Caption1,
			  CMC_Date_for_Caption1,
			  CMC_Time_for_Caption1,
			  AttorneyForCaption2,
			  DefendantsForCaption2,
			  PlaintiffsForCaption2,
			  Trial_Date_for_Caption2,
  			  CMC_Date_for_Caption2,
			  CMC_Time_for_Caption2,
			  AttorneyForCaption3,
			  DefendantsForCaption3,
			  PlaintiffsForCaption3,
			  Trial_Date_for_Caption3,
			  CMC_Date_for_Caption3,
			  CMC_Time_for_Caption3,
			  Claim_Number,
  			  DateOfLoss,
			  Company,
			  Coverage,
			  Effective_Date,
			  Other_Company_Name,
			  Other_Effective_Date,
   			  PLUP,
   			  PLUP_Policy_Limits,
   			  PLUP_Policy_Number,
   			  Policy_Limits,
   			  Policy_Number,
   			  Policyholder,
   			  SF_Policyholder_Name,
   			  SF_Coverage,
   			  SF_Policy_Limits,
   			  SF_Policy_Number
)

			  SELECT
			  FileHdr.FileID as MainFileId,
			  RelatedFileHdr.FileId as FileId,
			  RelatedFileHdr.SiteID,
			  SuitType = CASE SuitTypeXTABLE.Description WHEN ' ' THEN '' ELSE SuitTypeXTABLE.Description END,
  			  IncidentType = CASE IncidentTypeXTABLE.Description WHEN ' ' THEN '' ELSE IncidentTypeXTABLE.Description END,
			  convert(varchar,RelatedFileHdr.DateClose,101) as DateClose,
			  convert(varchar,RelatedFileHdr.DateOpen,101) as DateOpen,
			  Issue = CASE RelatedFileHdr.Keyword WHEN ' ' THEN '' ELSE RelatedFileHdr.Keyword END,
			  RelatedFileHdr.NameFile,
			  LongFileNameNote.NoteText as Long_File_Name,
			  RelatedFileHdr.OpenFileNo,
			  ReasonClosed = CASE ReasonClosedXTABLE.Description WHEN ' ' THEN '' ELSE ReasonClosedXTABLE.Description END,
			  ClaimType = CASE ClaimTypeXTABLE.Description WHEN ' ' THEN '' ELSE ClaimTypeXTABLE.Description END,
			  LossTypeXTABLE.Description as LossType,
			  FileTypeXTABLE.Description as FileType,
			  convert(varchar,DateFileReceived.DateFileReceived,101) as DateFileReceived,
			  convert(varchar,DateNotified.DateNotified,101) as DateNotified,
			  FileFacts.FileFacts,
	  		  AttorneyForNotesCaption1.NoteText as AttorneyForCaption1,
			  DefendantsForCaptionNotesCaption1.NoteText as DefendantsForCaption1,
			  PlaintiffForCaptionNotesCaption1.NoteText as PlaintiffsForCaption1,
			  Caption1.Trial_Date as Trial_Date_for_Caption1,
			  Caption1.CMC_Date as CMC_Date_for_Caption1,
			  CMC_Time_for_Caption1 = CASE Caption1.CMC_Time WHEN ' ' THEN '' ELSE Caption1.CMC_Time END,
			  AttorneyForNotesCaption2.NoteText as AttorneyForCaption2,
			  DefendantsForCaptionNotesCaption2.NoteText as DefendantsForCaption2,
			  PlaintiffForCaptionNotesCaption2.NoteText as PlaintiffsForCaption2,
			  Caption2.Trial_Date as Trial_Date_for_Caption2,
  			  Caption2.CMC_Date as CMC_Date_for_Caption2,
			  CMC_Time_for_Caption2 = CASE Caption2.CMC_Time WHEN ' ' THEN '' ELSE Caption2.CMC_Time END,
			  AttorneyForNotesCaption3.NoteText as AttorneyForCaption3,
			  DefendantsForCaptionNotesCaption3.NoteText as DefendantsForCaption3,
			  PlaintiffForCaptionNotesCaption3.NoteText as PlaintiffsForCaption3,
			  Caption3.Trial_Date as Trial_Date_for_Caption3,
			  Caption3.CMC_Date as CMC_Date_for_Caption3,
			  CMC_Time_for_Caption3 = CASE Caption3.CMC_Time WHEN ' ' THEN '' ELSE Caption3.CMC_Time END,
			  Claim_Number = CASE RelatedFileHdr.ExtClientMatterNo WHEN ' ' THEN '' ELSE RelatedFileHdr.ExtClientMatterNo END,
  			  convert(varchar,Coverage.Date_of_Loss,101) as DateOfLoss,
			  Coverage.Company,
			  Coverage = CASE Coverage.Coverage WHEN ' ' THEN '' ELSE Coverage.Coverage END,
			  Coverage.Effective_Date,
			  Other_Company_Name = CASE Coverage.Other_Company_Name WHEN ' ' THEN '' ELSE Coverage.Other_Company_Name END,
			  Coverage.Other_Effective_Date,
   			  convert(bit,Coverage.PLUP) as PLUP,
   			  PLUP_Policy_Limits = CASE Coverage.PLUP_Policy_Limits WHEN ' ' THEN '' ELSE Coverage.PLUP_Policy_Limits END,
   			  PLUP_Policy_Number = CASE Coverage.PLUP_Policy_Number WHEN ' ' THEN '' ELSE Coverage.PLUP_Policy_Number END,
   			  Policy_Limits = CASE Coverage.Policy_Limits WHEN ' ' THEN '' ELSE Coverage.Policy_Limits END,
   			  Policy_Number = CASE Coverage.Policy_Number WHEN ' ' THEN '' ELSE Coverage.Policy_Number END,
   			  Policyholder = CASE Coverage.Policyholder WHEN ' ' THEN '' ELSE Coverage.Policyholder END,
   			  SF_Policyholder_Name = CASE Coverage.SF_Policyholder_Name WHEN ' ' THEN '' ELSE Coverage.SF_Policyholder_Name END,
   			  SF_Coverage = CASE Coverage.SF_Coverage WHEN ' ' THEN '' ELSE Coverage.SF_Coverage END,
   			  SF_Policy_Limits = CASE Coverage.SF_Policy_Limits WHEN ' ' THEN '' ELSE Coverage.SF_Policy_Limits END,
   			  SF_Policy_Number = CASE Coverage.SF_Policy_Number WHEN ' ' THEN '' ELSE Coverage.SF_Policy_Number END
			  FROM dbo.FileHdr With (NOLOCK)
			  JOIN dbo.XLink With (NOLOCK)
			  on FileHdr.FileID = XLink.EntityID1
			  JOIN dbo.FileHdr RelatedFileHdr With (NOLOCK)
			  on XLink.EntityID2 = RelatedFileHdr.FileID
			  JOIN dbo.XTABLE With (NOLOCK)
			  on XLink.RelationshipID2 = XTABLE.XTableId
			  and XTABLE.Description = 'Related File'
			  LEFT JOIN dbo.Long_File_Name With (NOLOCK)
			  on RelatedFileHdr.FileID = Long_File_Name.EntityId
			  LEFT JOIN dbo.Notes LongFileNameNote With (NOLOCK)
			  on Long_File_Name.Long_File_Name_NoteId = LongFileNameNote.NoteID
			  LEFT JOIN DateFileReceived
			  on RelatedFileHdr.FileID = DateFileReceived.FileID
			  LEFT JOIN DateNotified
			  on RelatedFileHdr.FileID = DateNotified.FileID
			  LEFT JOIN dbo.Xtable SuitTypeXTABLE With (NOLOCK)
			  on RelatedFileHdr.AdmValCatId = SuitTypeXTABLE.XtableId
			  LEFT JOIN dbo.Xtable IncidentTypeXTABLE With (NOLOCK)
			  on RelatedFileHdr.CostCenterId = IncidentTypeXTABLE.XtableId
			  LEFT JOIN dbo.Xtable ReasonClosedXTABLE With (NOLOCK)
			  on RelatedFileHdr.ReasonClosedId = ReasonClosedXTABLE.XtableId
			  LEFT JOIN dbo.Xtable ClaimTypeXTABLE With (NOLOCK)
			  on RelatedFileHdr.TypeCat2Id = ClaimTypeXTABLE.XtableId
			  LEFT JOIN dbo.Xtable LossTypeXTABLE With (NOLOCK)
			  on RelatedFileHdr.TypeCat3Id = LossTypeXTABLE.XtableId
			  LEFT JOIN dbo.Xtable FileTypeXTABLE With (NOLOCK)
			  on RelatedFileHdr.TypeCatId = FileTypeXTABLE.XtableId
			  LEFT JOIN FileFacts
			  on RelatedFileHdr.FileID = FileFacts.EntityID
			  LEFT JOIN Caption1
			  on RelatedFileHdr.FileID = Caption1.CaptionsEntityID
			  LEFT JOIN dbo.Notes AttorneyForNotesCaption1 With (NOLOCK)
			  on Caption1.Attorney_for_NoteId = AttorneyForNotesCaption1.NoteID
			  LEFT JOIN dbo.Notes DefendantsForCaptionNotesCaption1 With (NOLOCK)
			  on Caption1.Defendants_for_Caption_NoteId = DefendantsForCaptionNotesCaption1.NoteId
			  LEFT JOIN dbo.Notes PlaintiffForCaptionNotesCaption1 With (NOLOCK)
			  on Caption1.Plaintiffs_for_Caption_NoteId = PlaintiffForCaptionNotesCaption1.NoteId
			  LEFT JOIN Caption2
			  on RelatedFileHdr.FileID = Caption2.CaptionsEntityID
			  LEFT JOIN dbo.Notes AttorneyForNotesCaption2 With (NOLOCK)
			  on Caption2.Attorney_for_NoteId = AttorneyForNotesCaption2.NoteID
			  LEFT JOIN dbo.Notes DefendantsForCaptionNotesCaption2 With (NOLOCK)
			  on Caption2.Defendants_for_Caption_NoteId = DefendantsForCaptionNotesCaption2.NoteId
			  LEFT JOIN dbo.Notes PlaintiffForCaptionNotesCaption2 With (NOLOCK)
			  on Caption2.Plaintiffs_for_Caption_NoteId = PlaintiffForCaptionNotesCaption2.NoteId
			  LEFT JOIN Caption3
			  on RelatedFileHdr.FileID = Caption3.CaptionsEntityID
			  LEFT JOIN dbo.Notes AttorneyForNotesCaption3 With (NOLOCK)
			  on Caption3.Attorney_for_NoteId = AttorneyForNotesCaption3.NoteID
			  LEFT JOIN dbo.Notes DefendantsForCaptionNotesCaption3 With (NOLOCK)
			  on Caption3.Defendants_for_Caption_NoteId = DefendantsForCaptionNotesCaption3.NoteId
			  LEFT JOIN dbo.Notes PlaintiffForCaptionNotesCaption3 With (NOLOCK)
			  on Caption3.Plaintiffs_for_Caption_NoteId = PlaintiffForCaptionNotesCaption3.NoteId
			  LEFT JOIN dbo.Coverage With (NOLOCK)
			  on RelatedFileHdr.FileID = Coverage.EntityId
			  WHERE FileHdr.DateClose is null
	    	  or FileHdr.DateClose > DATEADD(DAY,-30,current_timestamp)
UNION ALL
			  SELECT
			  FileHdr.FileID as MainFileId,
			  RelatedFileHdr.FileId as FileId,
			  RelatedFileHdr.SiteID,
			  SuitType = CASE SuitTypeXTABLE.Description WHEN ' ' THEN '' ELSE SuitTypeXTABLE.Description END,
  			  IncidentType = CASE IncidentTypeXTABLE.Description WHEN ' ' THEN '' ELSE IncidentTypeXTABLE.Description END,
			  convert(varchar,RelatedFileHdr.DateClose,101) as DateClose,
			  convert(varchar,RelatedFileHdr.DateOpen,101) as DateOpen,
			  Issue = CASE RelatedFileHdr.Keyword WHEN ' ' THEN '' ELSE RelatedFileHdr.Keyword END,
			  RelatedFileHdr.NameFile,
			  LongFileNameNote.NoteText as Long_File_Name,
			  RelatedFileHdr.OpenFileNo,
			  ReasonClosed = CASE ReasonClosedXTABLE.Description WHEN ' ' THEN '' ELSE ReasonClosedXTABLE.Description END,
			  ClaimType = CASE ClaimTypeXTABLE.Description WHEN ' ' THEN '' ELSE ClaimTypeXTABLE.Description END,
			  LossTypeXTABLE.Description as LossType,
			  FileTypeXTABLE.Description as FileType,
			  convert(varchar,DateFileReceived.DateFileReceived,101) as DateFileReceived,
			  convert(varchar,DateNotified.DateNotified,101) as DateNotified,
			  FileFacts.FileFacts,
	  		  AttorneyForNotesCaption1.NoteText as AttorneyForCaption1,
			  DefendantsForCaptionNotesCaption1.NoteText as DefendantsForCaption1,
			  PlaintiffForCaptionNotesCaption1.NoteText as PlaintiffsForCaption1,
			  Caption1.Trial_Date as Trial_Date_for_Caption1,
			  Caption1.CMC_Date as CMC_Date_for_Caption1,
			  CMC_Time_for_Caption1 = CASE Caption1.CMC_Time WHEN ' ' THEN '' ELSE Caption1.CMC_Time END,
			  AttorneyForNotesCaption2.NoteText as AttorneyForCaption2,
			  DefendantsForCaptionNotesCaption2.NoteText as DefendantsForCaption2,
			  PlaintiffForCaptionNotesCaption2.NoteText as PlaintiffsForCaption2,
			  Caption2.Trial_Date as Trial_Date_for_Caption2,
  			  Caption2.CMC_Date as CMC_Date_for_Caption2,
			  CMC_Time_for_Caption2 = CASE Caption2.CMC_Time WHEN ' ' THEN '' ELSE Caption2.CMC_Time END,
			  AttorneyForNotesCaption3.NoteText as AttorneyForCaption3,
			  DefendantsForCaptionNotesCaption3.NoteText as DefendantsForCaption3,
			  PlaintiffForCaptionNotesCaption3.NoteText as PlaintiffsForCaption3,
			  Caption3.Trial_Date as Trial_Date_for_Caption3,
			  Caption3.CMC_Date as CMC_Date_for_Caption3,
			  CMC_Time_for_Caption3 = CASE Caption3.CMC_Time WHEN ' ' THEN '' ELSE Caption3.CMC_Time END,
			  Claim_Number = CASE RelatedFileHdr.ExtClientMatterNo WHEN ' ' THEN '' ELSE RelatedFileHdr.ExtClientMatterNo END,
  			  convert(varchar,Coverage.Date_of_Loss,101) as DateOfLoss,
			  Coverage.Company,
			  Coverage = CASE Coverage.Coverage WHEN ' ' THEN '' ELSE Coverage.Coverage END,
			  Coverage.Effective_Date,
			  Other_Company_Name = CASE Coverage.Other_Company_Name WHEN ' ' THEN '' ELSE Coverage.Other_Company_Name END,
			  Coverage.Other_Effective_Date,
   			  convert(bit,Coverage.PLUP) as PLUP,
   			  PLUP_Policy_Limits = CASE Coverage.PLUP_Policy_Limits WHEN ' ' THEN '' ELSE Coverage.PLUP_Policy_Limits END,
   			  PLUP_Policy_Number = CASE Coverage.PLUP_Policy_Number WHEN ' ' THEN '' ELSE Coverage.PLUP_Policy_Number END,
   			  Policy_Limits = CASE Coverage.Policy_Limits WHEN ' ' THEN '' ELSE Coverage.Policy_Limits END,
   			  Policy_Number = CASE Coverage.Policy_Number WHEN ' ' THEN '' ELSE Coverage.Policy_Number END,
   			  Policyholder = CASE Coverage.Policyholder WHEN ' ' THEN '' ELSE Coverage.Policyholder END,
   			  SF_Policyholder_Name = CASE Coverage.SF_Policyholder_Name WHEN ' ' THEN '' ELSE Coverage.SF_Policyholder_Name END,
   			  SF_Coverage = CASE Coverage.SF_Coverage WHEN ' ' THEN '' ELSE Coverage.SF_Coverage END,
   			  SF_Policy_Limits = CASE Coverage.SF_Policy_Limits WHEN ' ' THEN '' ELSE Coverage.SF_Policy_Limits END,
   			  SF_Policy_Number = CASE Coverage.SF_Policy_Number WHEN ' ' THEN '' ELSE Coverage.SF_Policy_Number END
			  FROM dbo.FileHdr With (NOLOCK)
			  JOIN dbo.XLink With (NOLOCK)
			  on FileHdr.FileID = XLink.EntityID2
			  JOIN dbo.FileHdr RelatedFileHdr With (NOLOCK)
			  on XLink.EntityID1 = RelatedFileHdr.FileID
			  JOIN dbo.XTABLE With (NOLOCK)
			  on XLink.RelationshipID2 = XTABLE.XTableId
			  and XTABLE.Description = 'Related File'
			  LEFT JOIN dbo.Long_File_Name With (NOLOCK)
			  on RelatedFileHdr.FileID = Long_File_Name.EntityId
			  LEFT JOIN dbo.Notes LongFileNameNote With (NOLOCK)
			  on Long_File_Name.Long_File_Name_NoteId = LongFileNameNote.NoteID
			  LEFT JOIN DateFileReceived
			  on RelatedFileHdr.FileID = DateFileReceived.FileID
			  LEFT JOIN DateNotified
			  on RelatedFileHdr.FileID = DateNotified.FileID
			  LEFT JOIN dbo.Xtable SuitTypeXTABLE With (NOLOCK)
			  on RelatedFileHdr.AdmValCatId = SuitTypeXTABLE.XtableId
			  LEFT JOIN dbo.Xtable IncidentTypeXTABLE With (NOLOCK)
			  on RelatedFileHdr.CostCenterId = IncidentTypeXTABLE.XtableId
			  LEFT JOIN dbo.Xtable ReasonClosedXTABLE With (NOLOCK)
			  on RelatedFileHdr.ReasonClosedId = ReasonClosedXTABLE.XtableId
			  LEFT JOIN dbo.Xtable ClaimTypeXTABLE With (NOLOCK)
			  on RelatedFileHdr.TypeCat2Id = ClaimTypeXTABLE.XtableId
			  LEFT JOIN dbo.Xtable LossTypeXTABLE With (NOLOCK)
			  on RelatedFileHdr.TypeCat3Id = LossTypeXTABLE.XtableId
			  LEFT JOIN dbo.Xtable FileTypeXTABLE With (NOLOCK)
			  on RelatedFileHdr.TypeCatId = FileTypeXTABLE.XtableId
			  LEFT JOIN FileFacts
			  on RelatedFileHdr.FileID = FileFacts.EntityID
			  LEFT JOIN Caption1
			  on RelatedFileHdr.FileID = Caption1.CaptionsEntityID
			  LEFT JOIN dbo.Notes AttorneyForNotesCaption1 With (NOLOCK)
			  on Caption1.Attorney_for_NoteId = AttorneyForNotesCaption1.NoteID
			  LEFT JOIN dbo.Notes DefendantsForCaptionNotesCaption1 With (NOLOCK)
			  on Caption1.Defendants_for_Caption_NoteId = DefendantsForCaptionNotesCaption1.NoteId
			  LEFT JOIN dbo.Notes PlaintiffForCaptionNotesCaption1 With (NOLOCK)
			  on Caption1.Plaintiffs_for_Caption_NoteId = PlaintiffForCaptionNotesCaption1.NoteId
			  LEFT JOIN Caption2
			  on RelatedFileHdr.FileID = Caption2.CaptionsEntityID
			  LEFT JOIN dbo.Notes AttorneyForNotesCaption2 With (NOLOCK)
			  on Caption2.Attorney_for_NoteId = AttorneyForNotesCaption2.NoteID
			  LEFT JOIN dbo.Notes DefendantsForCaptionNotesCaption2 With (NOLOCK)
			  on Caption2.Defendants_for_Caption_NoteId = DefendantsForCaptionNotesCaption2.NoteId
			  LEFT JOIN dbo.Notes PlaintiffForCaptionNotesCaption2 With (NOLOCK)
			  on Caption2.Plaintiffs_for_Caption_NoteId = PlaintiffForCaptionNotesCaption2.NoteId
			  LEFT JOIN Caption3
			  on RelatedFileHdr.FileID = Caption3.CaptionsEntityID
			  LEFT JOIN dbo.Notes AttorneyForNotesCaption3 With (NOLOCK)
			  on Caption3.Attorney_for_NoteId = AttorneyForNotesCaption3.NoteID
			  LEFT JOIN dbo.Notes DefendantsForCaptionNotesCaption3 With (NOLOCK)
			  on Caption3.Defendants_for_Caption_NoteId = DefendantsForCaptionNotesCaption3.NoteId
			  LEFT JOIN dbo.Notes PlaintiffForCaptionNotesCaption3 With (NOLOCK)
			  on Caption3.Plaintiffs_for_Caption_NoteId = PlaintiffForCaptionNotesCaption3.NoteId
			  LEFT JOIN dbo.Coverage With (NOLOCK)
			  on RelatedFileHdr.FileID = Coverage.EntityId
			  WHERE FileHdr.DateClose is null
	    	  or FileHdr.DateClose > DATEADD(DAY,-30,current_timestamp)

   COMMIT TRAN      

   INSERT INTO LF_HD.DBO.LOG_Data ( sType, sMessage )
   SELECT 'LF_HD_Related_Case_sfsp', 'Data Transfer Complete';
     
   END TRY  
   
   BEGIN CATCH 

    select @Return_Message = @@ERROR	
    IF @@TRANCOUNT > 0 ROLLBACK      
     
    INSERT INTO LF_HD.DBO.LOG_Data ( sType, sMessage )
    SELECT 'LF_HD_Related_Case_sfsp', @Return_Message;
     
  --  EXEC xp_logevent 60000, 'LF_HD_Related_Case_sfsp', error 
   END CATCH


GO


