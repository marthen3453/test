CREATE PROCEDURE [dbo].[CreateJob_SF_SQL_Admin_DatabaseBackup_ALL_Database_Full] AS
BEGIN

DECLARE @Version numeric(18,10)
DECLARE @OutputFileDirectory nvarchar(max)

SET @Version = CAST(LEFT(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)),CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max))) - 1) + '.' + REPLACE(RIGHT(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)), LEN(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max))) - CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)))),'.','') AS numeric(18,10))

IF @Version >= 11
BEGIN
	SELECT @OutputFileDirectory = [path]
	FROM sys.dm_os_server_diagnostics_log_configurations
END
ELSE
BEGIN
	SELECT @OutputFileDirectory = LEFT(CAST(SERVERPROPERTY('ErrorLogFileName') AS nvarchar(max)),LEN(CAST(SERVERPROPERTY('ErrorLogFileName') AS nvarchar(max))) - CHARINDEX('\',REVERSE(CAST(SERVERPROPERTY('ErrorLogFileName') AS nvarchar(max)))))
END

IF RIGHT(@OutputFileDirectory,1) = '\'
BEGIN
	SET @OutputFileDirectory = LEFT(@OutputFileDirectory, LEN(@OutputFileDirectory) - 1)
END

DECLARE @InstanceName VARCHAR(100)
SET @InstanceName = LTRIM(RTRIM((SELECT CONVERT(VARCHAR(100), ISNULL(SERVERPROPERTY ('InstanceName'), @@SERVERNAME)))))
DECLARE @JobStepOutputFile VARCHAR(255)
SET @JobStepOutputFile = @OutputFileDirectory + '\SF_SQL_Admin_DatabaseBackup_ALLDB_Full_' + @InstanceName + '_$(ESCAPE_SQUOTE(STRTDT))_$(ESCAPE_SQUOTE(STRTTM)).txt'

DECLARE @BackupStartTime INT
SET @BackupStartTime = (
SELECT TOP 1
	CASE [BackupScheduleFile]
		WHEN 'SQLTDP-0000-full.cmd' THEN 0
		WHEN 'SQLTDP-0100-full.cmd' THEN 10000
		WHEN 'SQLTDP-0200-full.cmd' THEN 20000
		WHEN 'SQLTDP-2000-full.cmd' THEN 200000
		WHEN 'SQLTDP-2100-full.cmd' THEN 210000
		WHEN 'SQLTDP-2200-full.cmd' THEN 220000
		WHEN 'SQLTDP-2300-full.cmd' THEN 230000
		ELSE 200000
	END AS BackupStartTime
FROM
	[SF_SQL_Admin].[dbo].[BackupSchedule])

IF ISNULL(@BackupStartTime, -1) < 0
BEGIN
	SET @BackupStartTime = 200000
END

/****** Object:  Job [SF_SQL_Admin Master Database Local Backup]    Script Date: 6/10/2014 1:40:15 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 6/10/2014 1:40:15 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @ExistingJobId UNIQUEIDENTIFIER

SELECT @ExistingJobId = job_id FROM msdb.dbo.sysjobs WHERE (name = N'SF_SQL_Admin All Database Full Local Backup')

IF (@ExistingJobId IS NOT NULL)
BEGIN
    EXEC msdb.dbo.sp_delete_job @job_id=@ExistingJobId, @delete_unused_schedule=0
END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SF_SQL_Admin All Database Full Database Local Backup', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Local All Database Full SQL Server native backup', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sfsa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DatabaseBackup - master]    Script Date: 6/10/2014 1:40:15 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DatabaseBackup - All Database Full', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d SF_SQL_Admin -Q "EXECUTE [dbo].[DatabaseBackup] @Databases = ''ALL_DATABASES'', @BackupType = ''FULL'', @CreateDirectory = ''Y'', @Verify = ''Y'', @CleanupTime = 72, @Compress = ''Y'', @LogToTable = ''Y''" -b', 
		@output_file_name=@JobStepOutputFile, 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
DECLARE @ExstingScheduleId INT

SELECT @ExstingScheduleId = schedule_id FROM msdb.dbo.sysschedules WHERE (name = N'SF_SQL_Admin DatabaseBackup All Database Full Daily')

IF (@ExstingScheduleId IS NOT NULL)
BEGIN
    EXEC msdb.dbo.sp_attach_schedule @job_name = N'SF_SQL_Admin All Database Full Database Local Backup', @schedule_name = N'SF_SQL_Admin DatabaseBackup All Database Full Daily' ;
END
ELSE
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'SF_SQL_Admin DatabaseBackup All Database Full Daily', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140610, 
		@active_end_date=99991231, 
		@active_start_time=@BackupStartTime, 
		@active_end_time=235959
END
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

END
GO