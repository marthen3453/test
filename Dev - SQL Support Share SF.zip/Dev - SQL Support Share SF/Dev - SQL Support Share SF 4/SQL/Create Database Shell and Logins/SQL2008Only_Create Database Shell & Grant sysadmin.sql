DECLARE @dbname varchar(20)
SET @dbname = 'RightFax_XXXXXXXX' --update database name
PRINT @dbname
EXEC msdb.dbo.sp_sf_createdb @dbname = @dbname
GO


DECLARE @MyCommand varchar(1000)
DECLARE @dbname varchar(20)
SET @dbname = 'RightFax_XXXXXXXX' --update database name
PRINT @dbname
SET @MyCommand = 'ALTER DATABASE [' + @DBNAME + '] MODIFY FILE ( NAME = N''p_'+@dbname+''', MAXSIZE = UNLIMITED)'
SET @MyCommand = @MyCommand + CHAR(13)
SET @MyCommand = @MyCommand + CHAR(10)
SET @MyCommand = @MyCommand + 'ALTER DATABASE [' + @DBNAME + '] MODIFY FILE ( NAME = N''s_'+@dbname+''', MAXSIZE = UNLIMITED)'
SET @MyCommand = @MyCommand + CHAR(13)
SET @MyCommand = @MyCommand + CHAR(10)
SET @MyCommand = @MyCommand + 'ALTER DATABASE [' + @DBNAME + '] MODIFY FILE ( NAME =  N'''+@dbname+'_log_1'''+', FILEGROWTH = 10240KB )'
SET @MyCommand = @MyCommand + CHAR(13)
SET @MyCommand = @MyCommand + CHAR(10)
PRINT @MyCommand
EXECUTE(@MyCommand)

SET @MyCommand = 'USE [' + @DBNAME + '];CREATE USER [RightFax] FOR LOGIN [RightFax]'
SET @MyCommand = @MyCommand + CHAR(13)
SET @MyCommand = @MyCommand + CHAR(10)
SET @MyCommand = @MyCommand + 'USE [' + @DBNAME + '];EXEC sp_addrolemember N''db_owner'', N''RightFax'''
PRINT @MyCommand
EXECUTE(@MyCommand)
GO
EXEC master..sp_addsrvrolemember @loginame = N'Rightfax_Install', @rolename = N'sysadmin'
GO