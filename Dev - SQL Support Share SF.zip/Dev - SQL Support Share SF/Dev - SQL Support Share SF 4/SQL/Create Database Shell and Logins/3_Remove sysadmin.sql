--Remove sysadmin access from Rightfax_Install login once the install completes

EXEC master..sp_dropsrvrolemember @loginame = N'Rightfax_Install', @rolename = N'sysadmin'
GO
