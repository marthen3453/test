-- password must be manually set to the agreed value after running this script

USE [master]
GO
CREATE LOGIN [IAnstl] WITH PASSWORD=N'2bReset!', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=ON
GO
ALTER SERVER ROLE [sysadmin] ADD MEMBER [junk]
GO