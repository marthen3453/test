-- password must be manually set to the agreed value after running this script

USE [master]
GO
CREATE LOGIN [IAuser] WITH PASSWORD=N'2bReset!', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=ON
GO

USE [IADB]
GO
CREATE USER [IAuser] FOR LOGIN [IAuser]
GO
ALTER ROLE [db_datareader] ADD MEMBER [IAuser]
ALTER ROLE [db_datawriter] ADD MEMBER [IAuser]
GRANT EXECUTE TO [IAuser]
GO