USE [IADB]
GO
EXEC dbo.sp_changedbowner @loginame = N'sfsa', @map = false
GO
CREATE USER [IAnstl] FOR LOGIN [IAnstl]
GO
ALTER ROLE [db_datareader] ADD MEMBER [IAnstl]
ALTER ROLE [db_datawriter] ADD MEMBER [IAnstl]
ALTER ROLE [db_owner] DROP MEMBER [IAnstl]
GRANT EXECUTE TO [IAnstl]
GO
