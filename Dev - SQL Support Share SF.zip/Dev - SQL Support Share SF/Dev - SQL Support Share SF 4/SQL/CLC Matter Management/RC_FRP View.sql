USE [LegalFiles]
GO

/****** Object:  View [dbo].[RC_FRP]    Script Date: 9/16/2015 11:16:27 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO










 Create View [dbo].[RC_FRP] as
 				    WITH
					FirstCellPhone (NameCardID, OrderId, StatusPhones) as
					(SELECT NameCardID,min(OrderId), StatusPhones FROM Phones
					WHERE TypeID = 'E7WBI82L610'
					and StatusPhones = 'A'
					GROUP BY NameCardID,StatusPhones),
					FirstHomePhone (NameCardID, OrderId, StatusPhones) as
					(SELECT NameCardID,min(OrderId), StatusPhones FROM Phones
					WHERE TypeID = '0000000018X000'
					and StatusPhones = 'A'
					GROUP BY NameCardID,StatusPhones),
					FirstWorkPhone (NameCardID, OrderId, StatusPhones) as
					(SELECT NameCardID,min(OrderId),StatusPhones FROM Phones
					WHERE TypeID = '0000000209X000'
					and StatusPhones = 'A'
					GROUP BY NameCardID,StatusPhones),
					FirstFaxPhone (NameCardID, OrderId, StatusPhones) as
					(SELECT NameCardID,min(OrderId), StatusPhones FROM Phones
					WHERE TypeID = '0000000137X000'
					and StatusPhones = 'A'
					GROUP BY NameCardID,StatusPhones),
					FirstEmailAddress (NameCardID, OrderId) as
					(SELECT NameCardID,min(OrderId) FROM INetAddr
			        WHERE Status = 'A' 
			        GROUP BY NameCardID)
   
					SELECT
					FileHdr.FileID,
					RoleXTABLE.Description as Role,
					Prefix = CASE PrefixXTABLE.Description WHEN ' ' THEN '' ELSE PrefixXTABLE.Description END,
					NameFirst = CASE NameCard.NameFirst WHEN ' ' THEN '' ELSE NameCard.NameFirst END,
					NameMI = CASE NameCard.NameMI WHEN ' ' THEN '' ELSE NameCard.NameMI + '.' END,
					NameLast = CASE NameCard.NameLast WHEN ' ' THEN '' ELSE NameCard.NameLast END,
					Suffix = CASE SuffixXTABLE.Description WHEN ' ' THEN '' ELSE SuffixXTABLE.Description END,
					NameFull = CASE NameCard.NameFull WHEN ' ' THEN '' ELSE NameCard.NameFull END,
					Alias = CASE NameCard.NameAlias WHEN ' ' THEN '' ELSE NameCard.NameAlias END,
					Nickname = CASE NameCard.NameNick WHEN ' ' THEN '' ELSE NameCard.NameNick END,
					Gender = CASE NameCard.CardType WHEN 'C' THEN 'Other'
					ELSE CASE GenderXTABLE.Description WHEN ' ' THEN '' ELSE GenderXTABLE.Description END END,
					convert(varchar,NameCard.DOB,101) as DOB,
					convert(varchar,NameCard.DateOfDeath,101) as DOD,
					LicenseNo = CASE NameCard.LicenseNo WHEN ' ' THEN '' ELSE NameCard.LicenseNo END,
					BarNumber = CASE NameCard.LicenseNo WHEN ' ' THEN '' ELSE NameCard.LicenseNo END,
					Dept = CASE NameCard.Dept WHEN ' ' THEN '' ELSE NameCard.Dept END,
					SSN = CASE NameCard.SSN WHEN ' ' THEN ''
					ELSE +SUBSTRING(RIGHT('000000000' + NameCard.SSN, 9),1,3)+'-' +SUBSTRING(RIGHT('000000000' + NameCard.SSN, 9),4,2) +'-' +SUBSTRING(RIGHT('000000000' + NameCard.SSN, 9),6,LEN(RIGHT('000000000' + NameCard.SSN, 9))) END,
					TID = CASE NameCard.TID WHEN ' ' THEN ''
					ELSE +SUBSTRING(NameCard.TID,1,2)+'-' +SUBSTRING(NameCard.TID,3,LEN(NameCard.TID)) END,
					Firm_Contact_Name = CASE NameCard.NameContactSpouse WHEN ' ' THEN '' ELSE NameCard.NameContactSpouse END,
					Line1 = CASE PrimaryAddress.Line1 WHEN ' ' THEN '' ELSE PrimaryAddress.Line1 END,
					Line2 = CASE PrimaryAddress.Line2 WHEN ' ' THEN '' ELSE PrimaryAddress.Line2 END,
					NameCity = CASE PrimaryAddress.NameCity WHEN ' ' THEN '' ELSE PrimaryAddress.NameCity END,
					StateID = CASE PrimaryAddress.StateID WHEN ' ' THEN '' ELSE PrimaryAddress.StateID END,
					ZipCode = CASE PrimaryAddress.ZipCode WHEN ' ' THEN '' ELSE PrimaryAddress.ZipCode END,
					ZipPlus4 = CASE PrimaryAddress.ZipPlus4 WHEN ' ' THEN '' ELSE PrimaryAddress.ZipPlus4 END,
					County = CASE PrimaryAddress.County WHEN ' ' THEN '' ELSE PrimaryAddress.County END,
					Country = CASE PrimaryAddress.Country WHEN ' ' THEN '' ELSE PrimaryAddress.Country END,
					CountryCode = CASE PrimaryAddress.CountryCode WHEN ' ' THEN '' ELSE PrimaryAddress.CountryCode END,
					Email_Address = CASE InetAddr.INetID WHEN ' ' THEN '' ELSE InetAddr.INetID END,
					'('+SUBSTRING(CellPhone.PhoneNo,1,3)+') ' +SUBSTRING(CellPhone.PhoneNo,4,3) +'-' +SUBSTRING(CellPhone.PhoneNo,7,LEN(CellPhone.PhoneNo)) as CellNo,
					'('+SUBSTRING(HomePhone.PhoneNo,1,3)+') ' +SUBSTRING(HomePhone.PhoneNo,4,3) +'-' +SUBSTRING(HomePhone.PhoneNo,7,LEN(HomePhone.PhoneNo)) as HomeNo,
					'('+SUBSTRING(WorkPhone.PhoneNo,1,3)+') ' +SUBSTRING(WorkPhone.PhoneNo,4,3) +'-' +SUBSTRING(WorkPhone.PhoneNo,7,LEN(WorkPhone.PhoneNo)) as WorkNo,
					WorkNoExt = CASE WorkPhone.PhoneExt WHEN ' ' THEN '' ELSE WorkPhone.PhoneExt END,
					'('+SUBSTRING(FaxPhone.PhoneNo,1,3)+') ' +SUBSTRING(FaxPhone.PhoneNo,4,3) +'-' +SUBSTRING(FaxPhone.PhoneNo,7,LEN(FaxPhone.PhoneNo)) as FaxNo,
					Job_Title = CASE JobTitleXTABLE.Description WHEN ' ' THEN '' ELSE JobTitleXTABLE.Description END,
					DocInitials = CASE Users.DocInitials WHEN ' ' THEN '' ELSE Users.DocInitials END,
					LoginID = CASE Users.LoginID WHEN ' ' THEN '' ELSE Users.LoginID END,
					Company_Name = CASE CompanyNameCard.NameFull WHEN ' ' THEN '' ELSE CompanyNameCard.NameFull END,
					Company_TID = CASE CompanyNameCard.TID WHEN ' ' THEN ''
					ELSE +SUBSTRING(CompanyNameCard.TID,1,2)+'-' +SUBSTRING(CompanyNameCard.TID,3,LEN(CompanyNameCard.TID)) END,
					CO_Line1 = CASE CompanyPrimaryAddress.Line1 WHEN ' ' THEN '' ELSE CompanyPrimaryAddress.Line1 END,
					CO_Line2 = CASE CompanyPrimaryAddress.Line2 WHEN ' ' THEN '' ELSE CompanyPrimaryAddress.Line2 END,
					CO_NameCity = CASE CompanyPrimaryAddress.NameCity WHEN ' ' THEN '' ELSE CompanyPrimaryAddress.NameCity END,
					CO_StateID = CASE CompanyPrimaryAddress.StateID WHEN ' ' THEN '' ELSE CompanyPrimaryAddress.StateID END,
					CO_ZipCode = CASE CompanyPrimaryAddress.ZipCode WHEN ' ' THEN '' ELSE CompanyPrimaryAddress.ZipCode END,
					CO_ZipPlus4 = CASE CompanyPrimaryAddress.ZipPlus4 WHEN ' ' THEN '' ELSE CompanyPrimaryAddress.ZipPlus4 END,
					'('+SUBSTRING(CompanyPhone.PhoneNo,1,3)+') ' +SUBSTRING(CompanyPhone.PhoneNo,4,3) +'-' +SUBSTRING(CompanyPhone.PhoneNo,7,LEN(CompanyPhone.PhoneNo)) as CO_PhoneNo,
					CompanyPhone.PhoneExt as CO_PhoneExt,
					'('+SUBSTRING(CompanyFaxPhone.PhoneNo,1,3)+') ' +SUBSTRING(CompanyFaxPhone.PhoneNo,4,3) +'-' +SUBSTRING(CompanyFaxPhone.PhoneNo,7,LEN(CompanyFaxPhone.PhoneNo)) as CO_FaxNo,
					Counsel_Prefix = CASE CounselPrefixXTABLE.Description WHEN ' ' THEN '' ELSE CounselPrefixXTABLE.Description END,
					Counsel_NameFirst = CASE CounselNameCard.NameFirst WHEN ' ' THEN '' ELSE CounselNameCard.NameFirst END,
					Counsel_NameMI = CASE CounselNameCard.NameMI WHEN ' ' THEN '' ELSE CounselNameCard.NameMI + '.' END,
					Counsel_NameLast = CASE CounselNameCard.NameLast WHEN ' ' THEN '' ELSE CounselNameCard.NameLast END,
					Counsel_Suffix = CASE CounselSuffixXTABLE.Description WHEN ' ' THEN '' ELSE CounselSuffixXTABLE.Description END,
					Counsel_LicenseNo = CASE CounselNameCard.LicenseNo WHEN ' ' THEN '' ELSE CounselNameCard.LicenseNo END,
					Counsel_Email_Address = CASE CounselINetAddr.INetID WHEN ' ' THEN '' ELSE CounselINetAddr.INetID END,
					Counsel_Line1 = CASE CounselPrimaryAddress.Line1 WHEN ' ' THEN '' ELSE CounselPrimaryAddress.Line1 END,
					Counsel_Line2 = CASE CounselPrimaryAddress.Line2 WHEN ' ' THEN '' ELSE CounselPrimaryAddress.Line2 END,
					Counsel_NameCity = CASE CounselPrimaryAddress.NameCity WHEN ' ' THEN '' ELSE CounselPrimaryAddress.NameCity END,
					Counsel_StateID = CASE CounselPrimaryAddress.StateID WHEN ' ' THEN '' ELSE CounselPrimaryAddress.StateID END,
					Counsel_ZipCode = CASE CounselPrimaryAddress.ZipCode WHEN ' ' THEN '' ELSE CounselPrimaryAddress.ZipCode END,
					Counsel_ZipPlus4 = CASE CounselPrimaryAddress.ZipPlus4 WHEN ' ' THEN '' ELSE CounselPrimaryAddress.ZipPlus4 END,
					'('+SUBSTRING(CounselWorkPhone.PhoneNo,1,3)+') ' +SUBSTRING(CounselWorkPhone.PhoneNo,4,3) +'-' +SUBSTRING(CounselWorkPhone.PhoneNo,7,LEN(CounselWorkPhone.PhoneNo)) as Counsel_WorkNo,
					Counsel_WorkNoExt = CASE CounselWorkPhone.PhoneExt WHEN ' ' THEN '' ELSE CounselWorkPhone.PhoneExt END,
					'('+SUBSTRING(CounselCellPhone.PhoneNo,1,3)+') ' +SUBSTRING(CounselCellPhone.PhoneNo,4,3) +'-' +SUBSTRING(CounselCellPhone.PhoneNo,7,LEN(CounselCellPhone.PhoneNo)) as Counsel_CellNo,
					'('+SUBSTRING(CounselFaxPhone.PhoneNo,1,3)+') ' +SUBSTRING(CounselFaxPhone.PhoneNo,4,3) +'-' +SUBSTRING(CounselFaxPhone.PhoneNo,7,LEN(CounselFaxPhone.PhoneNo)) as Counsel_FaxNo,
					Counsel_Company_Name =
					CASE CounselNameCard.NameLast
						WHEN ' ' THEN CASE CounselNameCard.NameFull WHEN ' ' THEN '' ELSE CounselNameCard.NameFull END
						ELSE CASE CounselCompanyNameCard.NameFull WHEN ' ' THEN '' ELSE CounselCompanyNameCard.NameFull END
					END
					FROM dbo.FileHdr  With (NOLOCK)
					JOIN dbo.FileRel With (NOLOCK)
					on FileHdr.FileID = FileRel.FileID
					and FileRel.StatusFileRel = 'A'
					JOIN dbo.XTABLE RoleXTABLE With (NOLOCK)
					on FileRel.RoleID = RoleXTABLE.XTableId
					and RoleXTABLE.Description NOT IN ('Opposing Counsel','Court')
					JOIN dbo.NameCard With (NOLOCK)
					on FileRel.NameCardID = NameCard.NameCardID
					LEFT JOIN CounselFRNamecard With (NOLOCK)
					on FileRel.FileRelID = CounselFRNamecard.EntityId
					LEFT JOIN dbo.NameCard CounselNameCard With (NOLOCK)
					on CounselFRNamecard.Additional_Counsel_NCId = CounselNameCard.NameCardID
					LEFT JOIN FileRel CounselFileRel With (NOLOCK)
					on CounselFRNamecard.FileRelParent = CounselFileRel.FileID
					and CounselFRNamecard.Additional_Counsel_NCId = CounselFileRel.NameCardID
					LEFT JOIN dbo.XTABLE CounselPrefixXTABLE With (NOLOCK)
					on CounselNameCard.SaluteID = CounselPrefixXTABLE.XTableId
					LEFT JOIN dbo.XTABLE CounselSuffixXTABLE With (NOLOCK)
					on CounselNameCard.GenerationID = CounselSuffixXTABLE.XtableId
					LEFT JOIN dbo.NameCard CounselCompanyNameCard With (NOLOCK)
					on CounselNameCard.ComNameCardID = CounselCompanyNameCard.NameCardID
					LEFT JOIN FirstCellPhone FCPA With (NOLOCK)
					on CounselFRNamecard.Additional_Counsel_NCId = FCPA.NameCardId
					LEFT JOIN Phones CounselCellPhone With (NOLOCK)
					on FCPA.NameCardId = CounselCellPhone.NameCardID
					and FCPA.OrderId = CounselCellPhone.OrderId
					and FCPA.StatusPhones = CounselCellPhone.StatusPhones
					LEFT JOIN FirstFaxPhone FFPA With (NOLOCK)
					on CounselFRNamecard.Additional_Counsel_NCId = FFPA.NameCardId
					LEFT JOIN Phones CounselFaxPhone With (NOLOCK)
					on FFPA.NameCardId = CounselFaxPhone.NameCardID
					and FFPA.OrderId = CounselFaxPhone.OrderId
					and FFPA.StatusPhones = CounselFaxPhone.StatusPhones
					LEFT JOIN FirstWorkPhone FWPA With (NOLOCK)
					on CounselFRNamecard.Additional_Counsel_NCId = FWPA.NameCardId
					LEFT JOIN Phones CounselWorkPhone With (NOLOCK)
					on FWPA.NameCardId = CounselWorkPhone.NameCardID
					and FWPA.OrderId = CounselWorkPhone.OrderId
					and FWPA.StatusPhones = CounselWorkPhone.StatusPhones
					LEFT JOIN dbo.PrimaryAddress With (NOLOCK)
					on NameCard.NameCardID = PrimaryAddress.NameCardID
					LEFT JOIN dbo.PrimaryAddress CounselPrimaryAddress With (NOLOCK)
					on CounselNameCard.NameCardID = CounselPrimaryAddress.NameCardID
					Left JOIN dbo.XTABLE GenderXTABLE With (NOLOCK)
					on NameCard.GenderID = GenderXTABLE.XTableId
					LEFT JOIN dbo.XTABLE PrefixXTABLE With (NOLOCK)
					on NameCard.SaluteID = PrefixXTABLE.XTableId
					LEFT JOIN dbo.XTABLE SuffixXTABLE With (NOLOCK)
					on NameCard.GenerationID = SuffixXTABLE.XtableId
					LEFT JOIN dbo.XTABLE JobTitleXTABLE With (NOLOCK)
					on NameCard.TitleID = JobTitleXTABLE.XtableId
					LEFT JOIN FirstCellPhone FCPB With (NOLOCK)
					on NameCard.NameCardID = FCPB.NameCardId
					LEFT JOIN Phones CellPhone With (NOLOCK)
					on FCPB.NameCardId = CellPhone.NameCardID
					and FCPB.OrderId = CellPhone.OrderId
					and FCPB.StatusPhones = CellPhone.StatusPhones
					LEFT JOIN FirstHomePhone FHPA With (NOLOCK)
					on NameCard.NameCardID = FHPA.NameCardID
					LEFT JOIN Phones HomePhone With (NOLOCK)
					on FHPA.NameCardId = HomePhone.NameCardID
					and FHPA.OrderId = HomePhone.OrderId
					and FHPA.StatusPhones = HomePhone.StatusPhones
					LEFT JOIN FirstWorkPhone FWPB With (NOLOCK)
					on NameCard.NameCardID = FWPB.NameCardID
					LEFT JOIN Phones WorkPhone With (NOLOCK)
					on FWPB.NameCardId = WorkPhone.NameCardID
					and FWPB.OrderId = WorkPhone.OrderId
					and FWPB.StatusPhones = WorkPhone.StatusPhones
					LEFT JOIN FirstFaxPhone FFPB With (NOLOCK)
					on NameCard.NameCardID = FFPB.NameCardID
					LEFT JOIN Phones FaxPhone With (NOLOCK)
					on FFPB.NameCardId = FaxPhone.NameCardID
					and FFPB.OrderId = FaxPhone.OrderId
					and FFPB.StatusPhones = FaxPhone.StatusPhones
					LEFT JOIN FirstEmailAddress FEAA With (NOLOCK)
					on NameCard.NameCardID = FEAA.NameCardID
					LEFT JOIN dbo.INetAddr With (NOLOCK)
					on INetAddr.NameCardID = FEAA.NameCardID
					and INetAddr.OrderID = FEAA.OrderId
					LEFT JOIN FirstEmailAddress FEAB With (NOLOCK)
					on CounselNameCard.NameCardID = FEAB.NameCardID
					LEFT JOIN dbo.INetAddr CounselINetAddr With (NOLOCK)
					on CounselINetAddr.NameCardID = FEAB.NameCardID
					and CounselINetAddr.OrderID = FEAB.OrderId
					LEFT JOIN dbo.Users With (NOLOCK)
					on NameCard.NameCardID = Users.NameCardID
					LEFT JOIN dbo.NameCard CompanyNameCard With (NOLOCK)
					on NameCard.ComNameCardID = CompanyNameCard.NameCardID
					LEFT JOIN dbo.PrimaryAddress CompanyPrimaryAddress With (NOLOCK)
					on CompanyNameCard.NameCardID = CompanyPrimaryAddress.NameCardID
					LEFT JOIN FirstFaxPhone FFPC With (NOLOCK)
					on CompanyNameCard.NameCardID = FFPC.NameCardID
					LEFT JOIN Phones CompanyFaxPhone With (NOLOCK)
					on FFPC.NameCardId = CompanyFaxPhone.NameCardID
					and FFPC.OrderId = CompanyFaxPhone.OrderId
					and FFPC.StatusPhones = CompanyFaxPhone.StatusPhones
					LEFT JOIN FirstWorkPhone FWPC With (NOLOCK)
					on CompanyNameCard.NameCardID = FWPC.NameCardID
					LEFT JOIN Phones CompanyPhone With (NOLOCK)
					on FWPC.NameCardId = CompanyPhone.NameCardID
					and FWPC.OrderId = CompanyPhone.OrderId
					and FWPC.StatusPhones = CompanyPhone.StatusPhones
					WHERE (FileHdr.DateClose is null
	    	        or FileHdr.DateClose > DATEADD(DAY,-30,current_timestamp))
	    	        and FileHdr.SiteID in ('NEWY','WASH')









GO


