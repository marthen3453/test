USE [LegalFiles]
GO

/****** Object:  View [dbo].[RC_Info]    Script Date: 9/16/2015 11:17:15 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO










 Create View [dbo].[RC_Info] as
 			    With
				Caption1 (CaptionsEntityID, Attorney_for_NoteId, Defendants_for_Caption_NoteId, Plaintiffs_for_Caption_NoteId, Trial_Date, CMC_Date, CMC_Time) as
				(Select EntityId,Attorney_for_NoteId, Defendants_for_Caption_NoteId, Plaintiffs_for_Caption_NoteId, Trial_Date, CMC_Date, CMC_Time from Captions
				where Caption_Type_Desc = '1st named caption'),
				Caption2 (CaptionsEntityID, Attorney_for_NoteId, Defendants_for_Caption_NoteId, Plaintiffs_for_Caption_NoteId, Trial_Date, CMC_Date, CMC_Time) as
				(Select EntityId,Attorney_for_NoteId, Defendants_for_Caption_NoteId, Plaintiffs_for_Caption_NoteId, Trial_Date, CMC_Date, CMC_Time from Captions
				where Caption_Type_Desc = '2nd named caption'),
				Caption3 (CaptionsEntityID, Attorney_for_NoteId, Defendants_for_Caption_NoteId, Plaintiffs_for_Caption_NoteId, Trial_Date, CMC_Date, CMC_Time) as
				(Select EntityId,Attorney_for_NoteId, Defendants_for_Caption_NoteId, Plaintiffs_for_Caption_NoteId, Trial_Date, CMC_Date, CMC_Time from Captions
				where Caption_Type_Desc = '3rd named caption')

   
				SELECT
				FileHdr.FileID as MainFileId,
				RelatedFileHdr.FileId as FileId,
				RelatedFileHdr.SiteID,
				RelatedFileHdr.NameFile,
				RelatedFileHdr.OpenFileNo,
				DefendantsForCaptionNotesCaption1.NoteText as DefendantsForCaption1,
				PlaintiffForCaptionNotesCaption1.NoteText as PlaintiffsForCaption1,
				DefendantsForCaptionNotesCaption2.NoteText as DefendantsForCaption2,
				PlaintiffForCaptionNotesCaption2.NoteText as PlaintiffsForCaption2,
				DefendantsForCaptionNotesCaption3.NoteText as DefendantsForCaption3,
				PlaintiffForCaptionNotesCaption3.NoteText as PlaintiffsForCaption3
				FROM dbo.FileHdr With (NOLOCK)
				JOIN dbo.XLink With (NOLOCK)
				on FileHdr.FileID = XLink.EntityID1
				JOIN dbo.FileHdr RelatedFileHdr With (NOLOCK)
				on XLink.EntityID2 = RelatedFileHdr.FileID
				JOIN dbo.XTABLE With (NOLOCK)
				on XLink.RelationshipID2 = XTABLE.XTableId
				and XTABLE.Description = 'Related File'
				LEFT JOIN Caption1 With (NOLOCK)
				on RelatedFileHdr.FileID = Caption1.CaptionsEntityID
				LEFT JOIN dbo.Notes DefendantsForCaptionNotesCaption1 With (NOLOCK)
				on Caption1.Defendants_for_Caption_NoteId = DefendantsForCaptionNotesCaption1.NoteId
				LEFT JOIN dbo.Notes PlaintiffForCaptionNotesCaption1 With (NOLOCK)
				on Caption1.Plaintiffs_for_Caption_NoteId = PlaintiffForCaptionNotesCaption1.NoteId
				LEFT JOIN Caption2 With (NOLOCK)
				on RelatedFileHdr.FileID = Caption2.CaptionsEntityID
				LEFT JOIN dbo.Notes DefendantsForCaptionNotesCaption2 With (NOLOCK)
				on Caption2.Defendants_for_Caption_NoteId = DefendantsForCaptionNotesCaption2.NoteId
				LEFT JOIN dbo.Notes PlaintiffForCaptionNotesCaption2 With (NOLOCK)
				on Caption2.Plaintiffs_for_Caption_NoteId = PlaintiffForCaptionNotesCaption2.NoteId
				LEFT JOIN Caption3 With (NOLOCK)
				on RelatedFileHdr.FileID = Caption3.CaptionsEntityID
				LEFT JOIN dbo.Notes DefendantsForCaptionNotesCaption3 With (NOLOCK)
				on Caption3.Defendants_for_Caption_NoteId = DefendantsForCaptionNotesCaption3.NoteId
				LEFT JOIN dbo.Notes PlaintiffForCaptionNotesCaption3 With (NOLOCK)
				on Caption3.Plaintiffs_for_Caption_NoteId = PlaintiffForCaptionNotesCaption3.NoteId
				WHERE (FileHdr.DateClose is null
	    	    or FileHdr.DateClose > DATEADD(DAY,-30,current_timestamp))
	    	    and FileHdr.SiteID in ('NEWY','WASH')
		UNION ALL
				SELECT
				FileHdr.FileID as MainFileId,
				RelatedFileHdr.FileId as FileId,
				RelatedFileHdr.SiteID,
				RelatedFileHdr.NameFile,
				RelatedFileHdr.OpenFileNo,
				DefendantsForCaptionNotesCaption1.NoteText as DefendantsForCaption1,
				PlaintiffForCaptionNotesCaption1.NoteText as PlaintiffsForCaption1,
				DefendantsForCaptionNotesCaption2.NoteText as DefendantsForCaption2,
				PlaintiffForCaptionNotesCaption2.NoteText as PlaintiffsForCaption2,
				DefendantsForCaptionNotesCaption3.NoteText as DefendantsForCaption3,
				PlaintiffForCaptionNotesCaption3.NoteText as PlaintiffsForCaption3
				FROM dbo.FileHdr With (NOLOCK)
				JOIN dbo.XLink With (NOLOCK)
				on FileHdr.FileID = XLink.EntityID2
				JOIN dbo.FileHdr RelatedFileHdr With (NOLOCK)
				on XLink.EntityID1 = RelatedFileHdr.FileID
				JOIN dbo.XTABLE With (NOLOCK)
				on XLink.RelationshipID2 = XTABLE.XTableId
				and XTABLE.Description = 'Related File'
				LEFT JOIN Caption1 With (NOLOCK)
				on RelatedFileHdr.FileID = Caption1.CaptionsEntityID
				LEFT JOIN dbo.Notes DefendantsForCaptionNotesCaption1 With (NOLOCK)
				on Caption1.Defendants_for_Caption_NoteId = DefendantsForCaptionNotesCaption1.NoteId
				LEFT JOIN dbo.Notes PlaintiffForCaptionNotesCaption1 With (NOLOCK)
				on Caption1.Plaintiffs_for_Caption_NoteId = PlaintiffForCaptionNotesCaption1.NoteId
				LEFT JOIN Caption2 With (NOLOCK)
				on RelatedFileHdr.FileID = Caption2.CaptionsEntityID
				LEFT JOIN dbo.Notes DefendantsForCaptionNotesCaption2 With (NOLOCK)
				on Caption2.Defendants_for_Caption_NoteId = DefendantsForCaptionNotesCaption2.NoteId
				LEFT JOIN dbo.Notes PlaintiffForCaptionNotesCaption2 With (NOLOCK)
				on Caption2.Plaintiffs_for_Caption_NoteId = PlaintiffForCaptionNotesCaption2.NoteId
				LEFT JOIN Caption3 With (NOLOCK)
				on RelatedFileHdr.FileID = Caption3.CaptionsEntityID
				LEFT JOIN dbo.Notes DefendantsForCaptionNotesCaption3 With (NOLOCK)
				on Caption3.Defendants_for_Caption_NoteId = DefendantsForCaptionNotesCaption3.NoteId
				LEFT JOIN dbo.Notes PlaintiffForCaptionNotesCaption3 With (NOLOCK)
				on Caption3.Plaintiffs_for_Caption_NoteId = PlaintiffForCaptionNotesCaption3.NoteId
				WHERE (FileHdr.DateClose is null
	    	    or FileHdr.DateClose > DATEADD(DAY,-30,current_timestamp))
	    	    and FileHdr.SiteID in ('NEWY','WASH')









GO


