use Master
go

restore database LegalFiles
from disk = 'F:\MSSQL\BACKUP\F_MP04\BACKUP\WTSD3NTF$WTSD3NTF01\Migration\LegalFiles_Migration_SERVERNAME_COPYONLY_COMP.BAK'
WITH 
move 'LegalFiles_data' to 'F:\MSSQL\DATA\F_MP01\DATA\LegalFiles.mdf',
move 'LegalFiles_log' to 'F:\MSSQL\LOGS\F_MP02\LOGS\LegalFiles_log.ldf', 
REPLACE, RECOVERY
go

use LegalFiles
go
EXEC sp_changedbowner 'sfsa'