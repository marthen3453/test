use Master
go

restore database LF_HD
from disk = 'F:\MSSQL\BACKUP\F_MP04\BACKUP\WTSD3NTF$WTSD3NTF01\Migration\LF_HD_Migration_SERVERNAME_COPYONLY_COMP.BAK'
WITH 
move 'LF_HD' to 'F:\MSSQL\DATA\F_MP01\DATA\LF_HD.mdf',
move 'LF_HD_log' to 'F:\MSSQL\LOGS\F_MP02\LOGS\LF_HD_log.ldf', 
REPLACE, RECOVERY
go

use LF_HD
go
EXEC sp_changedbowner 'sfsa'