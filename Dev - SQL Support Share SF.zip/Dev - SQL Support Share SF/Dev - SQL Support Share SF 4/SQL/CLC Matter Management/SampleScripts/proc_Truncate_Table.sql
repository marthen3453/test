USE [SFSQL_ENT_WLM]
GO

/****** Object:  StoredProcedure [dbo].[proc_Truncate_Table_SFSP]    Script Date: 8/24/2015 9:28:23 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Stephen Manahan (ST43)
-- Create date: 01/22/2008
-- Description:	Allows the ability to truncate 
--	a table based on parameter with added protection 
--  to help prevent truncating a non-user created
--	table (e.g. system table, etc...)
-- =============================================
CREATE PROCEDURE [dbo].[proc_Truncate_Table_SFSP] 

	-- Add the parameters for the stored procedure here
	@Table varchar(75)

WITH EXECUTE AS SELF

AS

BEGIN

	SET NOCOUNT ON;

	DECLARE @Check_SQL1 varchar(200)
	DECLARE @Dynamic_SQL1 varchar(1500)

	SET @Check_SQL1 = 'SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'+ ''''+ @Table+ '''' +') AND type in (N'''+'U'''+') AND is_ms_shipped = 0'

	SET @Dynamic_SQL1 = 
		'IF  EXISTS ('+@Check_SQL1+')
			BEGIN
				TRUNCATE TABLE ' + @Table + '
			END
		ELSE
			BEGIN
				PRINT ''Table ' + @Table + ' Does Not EXIST In Database.''
			END
		'

	EXEC(@Dynamic_SQL1)
END

GO


