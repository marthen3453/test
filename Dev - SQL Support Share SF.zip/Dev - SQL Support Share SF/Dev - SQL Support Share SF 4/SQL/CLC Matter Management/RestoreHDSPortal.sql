use Master
go

restore database HDSPortal
from disk = 'F:\MSSQL\BACKUP\F_MP04\BACKUP\WTSD3NTF$WTSD3NTF01\Migration\HDSPortal_Migration_SERVERNAME_COPYONLY_COMP.BAK'
WITH 
move 'HDSPortal' to 'F:\MSSQL\DATA\F_MP01\DATA\HDSPortal.mdf',
move 'HDSPortal_log' to 'F:\MSSQL\LOGS\F_MP02\LOGS\HDSPortal_log.ldf', 
REPLACE, RECOVERY
go

use HDSPortal
go
EXEC sp_changedbowner 'sfsa'