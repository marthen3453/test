USE [Legalfiles]
GO

/****** Object:  View [dbo].[Captions]    Script Date: 09/21/2015 11:23:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


 Create View [dbo].[Captions] as  Select Distinct    
 CDM.CustomTplMID,
 CDM.CustomDataMID,    
 CDM.NameCustomDataM,    
 CDM.EntityId,    
 CDM.EntityTypeID, 
 CDM.SiteId, FH.NameFile, 
 ISNULL((Select ValuePickLong From CustomDataD CD1 Where CD1.CustomTplDID = 'CXV128JM3R0'   and CD1.CustomDataMID = CDM.CustomDataMID), '0') as Caption_Type_XId, 
 IsNull((Select X.Description From XTable X, CustomDataD CD1 Where X.XTableID = CD1.ValuePickLong and CD1.CustomTplDID = 'CXV128JM3R0'and CD1.CustomDataMID = CDM.CustomDataMID), ' ') as Caption_Type_Desc, 
 ISNULL((Select NoteIDCustomDataD From CustomDataD CD2 Where CD2.CustomTplDID = 'CXV128LC3T0'   and CD2.CustomDataMID = CDM.CustomDataMID), Cast('' as text)) as Plaintiffs_for_Caption_NoteId, 
 ISNULL((Select NoteIDCustomDataD From CustomDataD CD3 Where CD3.CustomTplDID = 'CXV128MN3V0'   and CD3.CustomDataMID = CDM.CustomDataMID), Cast('' as text)) as Defendants_for_Caption_NoteId, 
 ISNULL((Select NoteIDCustomDataD From CustomDataD CD4 Where CD4.CustomTplDID = 'CXV128NY3X0'   and CD4.CustomDataMID = CDM.CustomDataMID), Cast('' as text)) as Attorney_for_NoteId, 
 ISNULL((Select ValueDate From CustomDataD CD5 Where CD5.CustomTplDID = 'BF124C4E4Q0'   and CD5.CustomDataMID = CDM.CustomDataMID), NULL) as Trial_Date, 
 ISNULL((Select ValueDate From CustomDataD CD6 Where CD6.CustomTplDID = 'BF124D8B770'   and CD6.CustomDataMID = CDM.CustomDataMID), NULL) as CMC_Date, 
 ISNULL((Select ValueEntry From CustomDataD CD7 Where CD7.CustomTplDID = 'BF124DD7DA0'   and CD7.CustomDataMID = CDM.CustomDataMID), '') as CMC_Time, 
 ISNULL((Select ValueDate From CustomDataD CD8 Where CD8.CustomTplDID = 'BDP4762E3D0'   and CD8.CustomDataMID = CDM.CustomDataMID), 0) as Updated_Date, 
 ISNULL((Select ValuePickLong From CustomDataD CD9 Where CD9.CustomTplDID = 'BDP476718T0'   and CD9.CustomDataMID = CDM.CustomDataMID), '0') as Updated_By_UId , 
 ISNULL((Select N.NameFull From NameCard N, Users U, CustomDataD CD9 Where N.NameCardID = U.NameCardID and U.UserID = CD9.ValuePickLong and CD9.CustomTplDID = 'BDP476718T0' and CD9.CustomDataMID = CDM.CustomDataMID), ' ') as Updated_By_Name 
 From CustomDataM CDM , FileHdr FH Where CustomTplMID = 'CXV128IB3P0' and FH.FileId = CDM.EntityID

GO


