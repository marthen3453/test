USE [SF_SQL_Admin]
GO

DECLARE
	@cmd nvarchar(max)
	,@Site_code varchar(5)
	,@Domain varchar(10)
	,@DomainPrefix varchar(20)
	,@AppAdmin sysname
	,@AppAcct sysname
	,@DataAdmin sysname
	,@ReportUser sysname
	,@TempAdmin sysname
	,@i INT
	,@ErrMsg VARCHAR(MAX)
	,@DBname varchar(25)
	,@Security_Group_Base_Name varchar(10)  

SELECT @Domain = DEFAULT_DOMAIN()
SELECT
	@DomainPrefix = @Domain + '\'
	select @DBname = 'msdb'
	select @Security_Group_Base_Name = 'CLCM'

PRINT '--------------------------------------------------------------------------------'
PRINT '--DOMAIN:  ' + @Domain
PRINT '--DATABASE:  ' + @DBName	
PRINT '--SECURITY GROUP BASE NAME:  ' + @Security_Group_Base_Name
PRINT '--------------------------------------------------------------------------------'
PRINT ''
BEGIN TRY 



	SELECT
		@AppAdmin = @DomainPrefix + 'SQL_'+@Security_Group_Base_Name+'_APPADMIN_DLG'
		,@AppAcct = @DomainPrefix + 'SQL_'+@Security_Group_Base_Name+'_APPACCT_DLG'
		,@DataAdmin = @DomainPrefix + 'SQL_'+@Security_Group_Base_Name+'_DATAADMIN_ALL_DLG'
		,@ReportUser = @DomainPrefix + 'SQL_'+@Security_Group_Base_Name+'_RPT_ALL_DLG'
		,@TempAdmin = @DomainPrefix + 'SQL_'+@Security_Group_Base_Name+'_TEMPADMIN_DLG'

	


	CREATE_DB_USERS:
	/**************************
	** Create Database Users **
	**************************/
	-- Validate if database exists if attempting to create
	IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = @DBName)
	BEGIN
		RAISERROR ('DATABASE %s does not exist!!', 15, 1, @DBName)
	END
	PRINT '-------------------------'
	PRINT '--CREATE DATABASE USERS--'
	PRINT '-------------------------'
	
	--App Admin
	select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
				'IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = ''' + @AppAdmin + ''')' + CHAR(13) + CHAR(10) +
				CHAR(9) + 'CREATE USER [' + @AppAdmin + '] FOR LOGIN  [' + @AppAdmin + ']'
	Print @cmd
	EXEC sp_executesql @cmd

	
	PRINT ''


	


	GRANT_DB_PERMISSIONS:
	
	PRINT '---------------------------------'		
	PRINT '--GRANTING DATABASE PERMISSIONS--'
	PRINT '---------------------------------'		
	-- App Admin

	select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
				CHAR(9) + 'ALTER ROLE [SQLAgentUserRole] ADD MEMBER [' + @AppAdmin + ']'
		Print @cmd
		EXEC sp_executesql @cmd

	

	PRINT ''


END TRY
BEGIN CATCH
	Set @ErrMsg = '!!!ERROR:  ' + ISNULL(ERROR_MESSAGE(), 'UNKNOWN') + '!!!'
	--PRINT @ErrMsg
	RAISERROR (@ErrMsg, 15, 1)
END CATCH

PROC_EXIT:
	PRINT ''

GO


