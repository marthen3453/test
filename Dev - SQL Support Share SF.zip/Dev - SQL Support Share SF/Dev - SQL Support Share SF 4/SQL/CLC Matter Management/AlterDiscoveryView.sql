USE [LegalFiles]
GO

/****** Object:  View [dbo].[Discovery]    Script Date: 7/1/2015 9:13:59 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



 ALTER View [dbo].[Discovery] as  Select Distinct    CDM.CustomTplMID,    CDM.CustomDataMID,    CDM.NameCustomDataM,    CDM.EntityId,    CDM.EntityTypeID, CDM.SiteId, FH.NameFile, ISNULL((Select ValueDate From CustomDataD CD1 Where CD1.CustomTplDID = 'CXV70KRW4S0'   and CD1.CustomDataMID = CDM.CustomDataMID), NULL) as Date_Due, ISNULL((Select ValuePickLong From CustomDataD CD2 Where CD2.CustomTplDID = 'CXV70KSS4T0'   and CD2.CustomDataMID = CDM.CustomDataMID), '0') as Document_Type_XId, IsNull((Select X.Description From XTable X, CustomDataD CD2 Where X.XTableID = CD2.ValuePickLong and CD2.CustomTplDID = 'CXV70KSS4T0'and CD2.CustomDataMID = CDM.CustomDataMID), ' ') as Document_Type_Desc, ISNULL((Select ValuePickLong From CustomDataD CD3 Where CD3.CustomTplDID = 'CXV70KTN4U0'   and CD3.CustomDataMID = CDM.CustomDataMID), '0') as Staff_Responsible_UId, IsNull((Select N.NameFull From NameCard N, Users U, CustomDataD CD3 Where N.NameCardID = U.NameCardID and U.UserID = CD3.ValuePickLong and CD3.CustomTplDID = 'CXV70KTN4U0'and CD3.CustomDataMID = CDM.CustomDataMID), ' ') as Staff_Responsible_Name, ISNULL((Select ValuePickLong From CustomDataD CD4 Where CD4.CustomTplDID = 'CXV70KUI4V0'   and CD4.CustomDataMID = CDM.CustomDataMID), '0') as Party_Name_FRNCId, IsNull((Select N.NameFull From NameCard N, CustomDataD CD4 Where N.NameCardID = CD4.ValuePickLong and CD4.CustomTplDID = 'CXV70KUI4V0'and CD4.CustomDataMID = CDM.CustomDataMID), ' ')as Party_Name_Name, ISNULL((Select ValueDefaultPickLong From CustomTplD ECW Where ECW.CustomTplDID = 'CXVCYW694X0'), '0') as Status_TplId, ISNULL((Select NoteIDCustomDataD From CustomDataD CD6 Where CD6.CustomTplDID = 'CXVCYW7Z4Z0'   and CD6.CustomDataMID = CDM.CustomDataMID), ' ' ) as Description_NoteId, ISNULL((Select ValueDate From CustomDataD CD7 Where CD7.CustomTplDID = 'BDP47A4C510'   and CD7.CustomDataMID = CDM.CustomDataMID), 0) as Updated_Date, ISNULL((Select ValuePickLong From CustomDataD CD8 Where CD8.CustomTplDID = 'BDP47A981E0'   and CD8.CustomDataMID = CDM.CustomDataMID), '0') as Updated_By_UId , ISNULL((Select N.NameFull From NameCard N, Users U, CustomDataD CD8 Where N.NameCardID = U.NameCardID and U.UserID = CD8.ValuePickLong and CD8.CustomTplDID = 'BDP47A981E0' and CD8.CustomDataMID = CDM.CustomDataMID), ' ') as Updated_By_Name From CustomDataM CDM , FileHdr FH Where CustomTplMID = 'CXV70KQ64Q0' and FH.FileId = CDM.EntityID


GO


