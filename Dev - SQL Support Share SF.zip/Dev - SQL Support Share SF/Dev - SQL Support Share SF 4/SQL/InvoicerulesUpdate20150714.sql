/* UseDB.sql */
print 'updating database'
print '*****************'
print ''
go

use casetrack
go

/* SystemConfigDT.sql */
print 'updating system configuration'
go

set nocount on
go

execute setsystemconfig 'invrulecategory', 'mattersubtype'
go

set nocount off
go

/* InvRuleCategoryV.sql */
print 'invrulecategory view'
go

if exists (select * from sysobjects where name= 'invrulecategory' and type = 'V')
  drop view invrulecategory
go

declare
  @source varchar(30),
  @viewstmnt varchar(300)

select @source = value
  from systemconfig
  where itemname = 'invrulecategory'

if @source is null
  select @source = value
    from systemconfig
    where itemname = 'invrulecategory2'

if @source is null
  select @viewstmnt = 'create view dbo.invrulecategory with encryption as select 0 as invrulecategoryid, convert( varchar(30), null) as descr, 0 as inactive where 1 = 0'

if @source = 'mattersubtype'
  select @viewstmnt = 'create view dbo.invrulecategory with encryption as select mattersubtype.mattersubtypeid as invrulecategoryid, mattertype.descr + '' | '' + mattersubtype.descr as descr, mattersubtype.inactive from mattersubtype inner join mattertype on mattersubtype.mattertypeid = mattertype.mattertypeid'

if @source = 'orglevel2'
  select @viewstmnt = 'create view dbo.invrulecategory with encryption as select orglevel2.orglevel2id as invrulecategoryid, orglevel1.descr + '' | '' + orglevel2.descr as descr, orglevel2.inactive from orglevel2 inner join orglevel1 on orglevel2.orglevel1id = orglevel1.orglevel1id'

if isnumeric( @source) <> 0
  select @viewstmnt = 'create view dbo.invrulecategory with encryption as select customvalueid as invrulecategoryid, descr, inactive from customvalue where customfieldid = ' + @source

if @viewstmnt is null
  if not exists (select * from syscolumns inner join sysobjects on syscolumns.id = sysobjects.id where syscolumns.name = 'inactive' and sysobjects.name = @source)
    select @viewstmnt = 'create view dbo.invrulecategory with encryption as select ' + @source + 'id as invrulecategoryid, descr, 0 as inactive from ' + @source
  else
    select @viewstmnt = 'create view dbo.invrulecategory with encryption as select ' + @source + 'id as invrulecategoryid, descr, inactive from ' + @source

execute (@viewstmnt)
go

grant select on invrulecategory to dbadmin
go

/* InvRuleMatterV.sql */
print 'invrulematter view'
go

if exists (select * from sysobjects where name= 'invrulematter' and type = 'V')
  drop view invrulematter
go

declare
  @source varchar(30),
  @viewstmnt varchar(255)

select @source = value
  from systemconfig
  where itemname = 'invrulecategory'

if @source is null
    select @viewstmnt = 'create view dbo.invrulematter with encryption as select 0 as matterid, 0 as invrulecategoryid where 1 = 0'
else
  if isnumeric( @source) <> 0
    select @viewstmnt = 'create view dbo.invrulematter with encryption as select parentid as matterid, customvalueid as invrulecategoryid from customdata_t where customformid = 1 and customfieldid = ' + @source
  else
    select @viewstmnt = 'create view dbo.invrulematter with encryption as select matterid, ' + @source + 'id as invrulecategoryid from matter_t where ' + @source + 'id is not null'

execute (@viewstmnt)
go

/* Done.sql */
print ''
print '***************'
print 'update complete'
go

