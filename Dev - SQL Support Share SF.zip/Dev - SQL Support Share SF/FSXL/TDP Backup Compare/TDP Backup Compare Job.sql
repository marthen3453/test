USE [msdb]
GO

DECLARE @cmd nvarchar(max), @path nvarchar(max);

IF EXISTS (SELECT name FROM sys.system_objects WHERE name like 'dm_os_windows_info')
BEGIN
SELECT @path = CASE WHEN windows_release < '6.2'
	THEN 'D:\DATA\SQL\Scripts\' 
	ELSE 'C:\Progra~1\Storage\TSM\SCRIPTS\SQL\' END
FROM sys.dm_os_windows_info;
END
ELSE
BEGIN
	SET @path = 'D:\DATA\SQL\Scripts\';
END

IF EXISTS (SELECT name FROM msdb..sysjobs WHERE name = 'SF_SQL_Admin TDP Backup Compare')
	EXEC sp_delete_job @job_name = 'SF_SQL_Admin TDP Backup Compare';

SET @cmd = '
	EXEC  msdb.dbo.sp_add_job @job_name=N''SF_SQL_Admin TDP Backup Compare'', 
			@enabled=1, 
			@notify_level_eventlog=0, 
			@notify_level_email=0, 
			@notify_level_netsend=0, 
			@notify_level_page=0, 
			@delete_level=0, 
			@description=N''No description available.'', 
			@category_name=N''[Uncategorized (Local)]'', 
			@owner_login_name=N''sfsa'';

	EXEC msdb.dbo.sp_add_jobstep @job_name=N''SF_SQL_Admin TDP Backup Compare'', @step_name=N''PS Collect TDP Info'', 
			@step_id=1, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2, 
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, @subsystem=N''CmdExec'', 
			@command=N''powershell ' + @path + 'TDPBackupCollectAll.ps1 $(ESCAPE_SQUOTE(INST))'', 
			@flags=0;

	EXEC msdb.dbo.sp_update_job @job_name=N''SF_SQL_Admin TDP Backup Compare'', @start_step_id = 1;
	EXEC msdb.dbo.sp_add_jobserver @job_name=N''SF_SQL_Admin TDP Backup Compare'', @server_name = N''(local)'';';

EXEC sp_executesql @cmd;



