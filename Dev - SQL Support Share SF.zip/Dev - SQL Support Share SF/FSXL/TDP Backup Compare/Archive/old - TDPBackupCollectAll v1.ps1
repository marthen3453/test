﻿### DECLARE VARIABLES.
[System.String] $appdir = $env:APPSDIR -replace "PROGRAM FILES", "PROGRA~1"
[System.Int32] $tdpposition = 12
[System.String] $sqlinstance = $args[0].ToString().Split("\")[1]
[System.String] $sqlcmd = ""
[System.String] $tdpcmd = ""
[System.String] $connectionString = ""
[System.Collections.ArrayList] $databases = New-Object System.Collections.ArrayList
[System.Collections.ArrayList] $tdpoutput = New-Object System.Collections.ArrayList
[System.Collections.ArrayList] $tdpparams = New-Object System.Collections.ArrayList
[System.Data.DataTable] $dt = $null
[System.Data.DataColumn] $dc = $null
[System.Data.DataRow] $dr = $null
[System.Data.SqlClient.SqlConnection] $connection = $null
[System.Data.SqlClient.SqlBulkCopy] $bc = $null

### CREATE TDP BACKUP STORAGE TABLE, IF IT DOES NOT ALREADY EXIST.
$sqlcmd = "IF NOT EXISTS (SELECT name FROM SF_SQL_Admin.sys.objects WHERE name = 'TDPBackupInfo')
                CREATE TABLE SF_SQL_Admin.dbo.TDPBackupInfo (TDPNodeName varchar(512), DatabaseName varchar(512), BackupType varchar(128), BackupDT datetime, 
                Size float, SizeType varchar(4), SQLCompressed bit, TDPCompressed bit);                
                CREATE CLUSTERED INDEX CIX_TDPBackup ON TDPBackupInfo (backupDT) WITH (DATA_COMPRESSION=PAGE);"
Invoke-Sqlcmd -ServerInstance .\$sqlinstance -Query $sqlcmd -Database "SF_SQL_Admin" 

### CREATE STAGING TDP BACKUP STORAGE TABLE, IF IT DOES NOT ALREADY EXIST.
$sqlcmd = "IF NOT EXISTS (SELECT name FROM SF_SQL_Admin.sys.objects WHERE name = 'Stage_TDPBackupInfo')
                CREATE TABLE SF_SQL_Admin.dbo.Stage_TDPBackupInfo (TDPNodeName varchar(512), DatabaseName varchar(512), BackupType varchar(128), BackupDT datetime, 
                Size float, SizeType varchar(4), SQLCompressed bit, TDPCompressed bit);"
Invoke-Sqlcmd -ServerInstance .\$sqlinstance -Query $sqlcmd -Database "SF_SQL_Admin" 

### DROP AND CREATE STORED PROC TO MERGE FROM STAGING AND COMPARE MISSING/MISMATCHED BACKUPS.
$sqlcmd = "IF EXISTS (SELECT name FROM SF_SQL_Admin.sys.objects WHERE name = 'usp_MergeTDPCollection')
                DROP PROC usp_MergeTDPCollection
            GO

            CREATE PROC usp_MergeTDPCollection
            AS
            BEGIN
	            INSERT TDPBackupInfo
	            SELECT * FROM Stage_TDPBackupInfo
	            EXCEPT
	            SELECT * FROM TDPBackupInfo;

	            TRUNCATE TABLE Stage_TDPBackupInfo;

                DELETE TDPBackupInfo WHERE BackupDT < DATEADD(dd, -60, GETDATE());
				ALTER TABLE TDPBackupInfo REBUILD;
            END;"
Invoke-Sqlcmd -ServerInstance .\$sqlinstance -Query $sqlcmd -Database "SF_SQL_Admin" 

### CREATE DATATABLE FOR TDP RESULTS.
$dt = New-Object Data.DataTable
$dc = New-Object Data.DataColumn("TDPNodeName", [string])
$dt.Columns.Add($dc)
$dc = New-Object Data.DataColumn("DatabaseName", [string])
$dt.Columns.Add($dc)
$dc = New-Object Data.DataColumn("BackupType", [string])
$dt.Columns.Add($dc)
$dc = New-Object Data.DataColumn("BackupDT", [DateTime])
$dt.Columns.Add($dc)
$dc = New-Object Data.DataColumn("Size", [float])
$dt.Columns.Add($dc)
$dc = New-Object Data.DataColumn("SizeType", [string])
$dt.Columns.Add($dc)
$dc = New-Object Data.DataColumn("SQLCompressed", [int16])
$dt.Columns.Add($dc)
$dc = New-Object Data.DataColumn("TDPCompressed", [int16])
$dt.Columns.Add($dc)

### BUILD AND EXECUTE TDP QUERY FOR THE BACKUPS OF EACH DATABASE.
$databases = Invoke-Sqlcmd -ServerInstance .\$sqlinstance -Query "SELECT name FROM sys.databases"

$databases | foreach {
    $tdpcmd = $env:APPSDIR + "\Storage\TSM\TDPSql\tdpsqlc"
    $tdpparams = 'query', 'tsm', $_.name, '/ALL', 
        ('/tsmoptfile="' + $appdir + '\Storage\TSM\CONFIG\SQL_' + $sqlinstance + '.OPT"'), 
        ('/CONFIG="' + $appdir + '\Storage\TSM\CONFIG\SQL_' + $sqlinstance + '.cfg"') 
    $tdpoutput = & $tdpcmd $tdpparams 

    ### ADD TDP QUERY RESULTS TO DATATABLE.
    $tdpposition = 12
    while ($tdpoutput[$tdpposition] -ne $null)
    {
        $dr = $dt.NewRow()

        $dr.Item('TDPNodeName') = ""
        $dr.Item('DatabaseName') = ($tdpoutput[$tdpposition] -split " ")[4] 
        $dr.Item('BackupType') = ($tdpoutput[$tdpposition + 3] -split " ")[4] 
        $dr.Item('BackupDT') = ($tdpoutput[$tdpposition + 6] -split " ")[6] + " " + ($tdpoutput[$tdpposition + 6] -split " ")[7]
        $dr.Item('Size') = ($tdpoutput[$tdpposition + 7] -split " ")[3]
        $dr.Item('SizeType') = ($tdpoutput[$tdpposition + 7] -split " ")[4]
        if (($tdpoutput[$tdpposition + 8] -split " ")[3] -eq "Yes") { $dr.Item('SQLCompressed') = 1 } else { $dr.Item('SQLCompressed') = 0 }
        if (($tdpoutput[$tdpposition + 9] -split " ")[3] -eq "Yes") { $dr.Item('TDPCompressed') = 1 } else { $dr.Item('TDPCompressed') = 0 }

        $dt.Rows.Add($dr)

        $tdpposition += 22
    }
}
<#
### CHECK FOR AVAILABILITY GROUPS AND LOAD BACKUP INFORMATION.
$hadr = Invoke-Sqlcmd -ServerInstance .\$sqlinstance -Query "SELECT SERVERPROPERTY ('IsHadrEnabled');"
if ($hadr.Column1 -eq 1) {
    $fcmPath = (get-itemproperty -path 'HKLM:\SOFTWARE\IBM\flashcopymanager\currentversion\mmc').path
    dir $fcmPath fmmodule*.dll | select -expand fullname | import-module

    $tdpoutput = Get-DpSqlBackup  -Name * -AllTypes -COMPATibilityinfo -FROMSQLserver * -QUERYNode AlwaysOn -ConfigFile "C:\PROGRAM FILES\Storage\TSM\Config\SQL_WSLDWRGJ03.CFG" -TsmOptFile "C:\PROGRAM FILES\Storage\TSM\Config\SQL_WMSDWRGJ01.OPT" 
    
    foreach ($b in $a) {
        $b.SQLDatabaseName 
        $b.BackupCreationDateTime
    }
}
#>
### BULK INSERT DATATABLE INTO SF_SQL_ADMIN STAGING TABLE.
if ($dt.Rows.Count -gt 0) {
    $connectionString = "Data Source=.\$sqlinstance;Integrated Security=SSPI;Database=SF_SQL_Admin"
    $connection = New-Object System.Data.SqlClient.SQLConnection($connectionString)
    $connection.Open()

    $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $connection
    $bc.DestinationTableName = "Stage_TDPBackupInfo"
    $bc.WriteToServer($dt)

    $connection.Close()
}

### EXECUTE STORED PROC TO MERGE AND CHECK FOR DISCREPANCIES.
$sqlcmd = "EXEC usp_MergeTDPCollection;"
Invoke-Sqlcmd -ServerInstance .\$sqlinstance -Query $sqlcmd -Database "SF_SQL_Admin"