USE [SF_SQL_Admin];
GO

IF EXISTS (SELECT name FROM sys.objects WHERE name = 'SF_Admin_Execute_Command')
	DROP TABLE SF_Admin_Execute_Command;
GO

CREATE TABLE SF_Admin_Execute_Command (
	InsertedDate datetime
	, JobStartDate datetime
	, JobEndDate datetime
	, CalledBy varchar(128)
	, Command varchar(128)
	, Params nvarchar(MAX)
	, ParamValues nvarchar(MAX));
GO

IF EXISTS (SELECT name FROM sys.objects WHERE name = 'sfsp_DBCC_CHECKDB')
	DROP PROC sfsp_DBCC_CHECKDB;
GO

CREATE PROC sfsp_DBCC_CHECKDB (@dbid int)
WITH EXECUTE AS OWNER
AS
BEGIN
	SET NOCOUNT ON;

	IF EXISTS (SELECT * FROM SF_Admin_Execute_Command 
				WHERE JobStartDate IS NOT NULL
				AND JobEndDate IS NULL)
	BEGIN
		PRINT 'SF_SQL_Admin Execute Command job is currently executing, please try again after job has completed.';
		return;
	END;

	-- Clear unused commands
	UPDATE SF_Admin_Execute_Command SET JobEndDate = '1/1/1900', JobStartDate = '1/1/1900' WHERE JobEndDate IS NULL AND JobStartDate IS NULL;	
	
	-- Declare variables.
	DECLARE @params varchar(MAX), @paramvalues varchar(MAX);

	--  Build command, parameters, and parameter values
	SET @params = '';
	SET @paramvalues = CAST(@dbid AS varchar);

	-- Insert into command table.
	INSERT SF_Admin_Execute_Command VALUES (GETDATE(), null, null, ORIGINAL_LOGIN(), 'DBCC CHECKDB', @params, @paramvalues);

	-- Print the command necessary to run the correct job step. (Context does not allow the proc to call this automatically.)
	PRINT 'Execute the following to start the appropriate job step and complete the command:'
	PRINT 'EXEC msdb.dbo.sp_start_job  @job_name = ''SF_SQL_Admin Execute Command'', @step_name = ''DBCC CHECKDB'';'
END
GO

IF EXISTS (SELECT name FROM sys.objects WHERE name = 'sfsp_DBCC_SHRINKFILE')
	DROP PROC sfsp_DBCC_SHRINKFILE;
GO

CREATE PROC sfsp_DBCC_SHRINKFILE (@dbid int, @logicalfile varchar(512), @sizemb int)
WITH EXECUTE AS OWNER
AS
BEGIN
	SET NOCOUNT ON;

	IF EXISTS (SELECT * FROM SF_Admin_Execute_Command 
			WHERE JobStartDate IS NOT NULL
			AND JobEndDate IS NULL)
	BEGIN
		PRINT 'SF_SQL_Admin Execute Command job is currently executing, please try again after job has completed.';
		return;
	END;

	-- Clear unused commands
	UPDATE SF_Admin_Execute_Command SET JobEndDate = '1/1/1900', JobStartDate = '1/1/1900' WHERE JobEndDate IS NULL AND JobStartDate IS NULL;	
	
	-- Declare variables.
	DECLARE @cmd varchar(MAX), @params varchar(MAX), @paramvalues varchar(MAX);

	--  Build command, parameters, and parameter values
	SET @params = N'@file varchar(512), @size int' ;
	SET @paramvalues = CAST(@dbid AS varchar) + ',' + @logicalfile + ',' + CAST(@sizemb AS varchar);

	-- Insert into command table.
	INSERT SF_Admin_Execute_Command VALUES (GETDATE(), null, null, ORIGINAL_LOGIN(), 'DBCC SHRINKFILE', @params, @paramvalues);
	
	-- Print the command necessary to run the correct job step. (Context does not allow the proc to call this automatically.)
	PRINT 'Execute the following to start the appropriate job step and complete the command:'
	PRINT 'EXEC msdb..sp_start_job  @job_name = ''SF_SQL_Admin Execute Command'', @step_name = ''DBCC SHRINKFILE'';';
END
GO

IF EXISTS (SELECT name FROM sys.objects WHERE name = 'sfsp_ADD_FILE')
	DROP PROC sfsp_ADD_FILE;
GO

CREATE PROC sfsp_ADD_FILE (@dbid int, @type varchar(4), @name varchar(512), @path varchar(512), @sizemb int, @growthmb int)
WITH EXECUTE AS OWNER
AS
BEGIN
	SET NOCOUNT ON;

	IF EXISTS (SELECT * FROM SF_Admin_Execute_Command 
				WHERE JobStartDate IS NOT NULL
				AND JobEndDate IS NULL)
	BEGIN
		PRINT 'SF_SQL_Admin Execute Command job is currently executing, please try again after job has completed.';
		return;
	END;

	-- Clear unused commands
	UPDATE SF_Admin_Execute_Command SET JobEndDate = '1/1/1900', JobStartDate = '1/1/1900' WHERE JobEndDate IS NULL AND JobStartDate IS NULL;	
	
	--  Build command, parameters, and parameter values
	DECLARE @params varchar(MAX), @paramvalues varchar(MAX);

	IF (@type = 'DATA')
	BEGIN
		IF SUBSTRING(@path, LEN(@path), 1) = '\'
			SET @path = @path + @name + '.ndf';
		ELSE
			SET @path = @path + '\' + @name + '.ndf';

		SET @params = '';
		SET @paramvalues = CAST(@dbid AS varchar) + ',' + @name + ',' + @path + ',' + CAST(@sizemb AS varchar) + ',' + 
			CAST(@growthmb AS varchar);
	END;

	ELSE IF (@type = 'LOG')
	BEGIN
		IF SUBSTRING(@path, LEN(@path), 1) = '\'
			SET @path = @path + @name + '.ldf';
		ELSE
			SET @path = @path + '\' + @name + '.ldf';
			
		SET @params = '';
		SET @paramvalues = CAST(@dbid AS varchar) + ',' + @name + ',' + @path + ',' + CAST(@sizemb AS varchar) + ',' + 
			CAST(@growthmb AS varchar);
	END;

	INSERT SF_Admin_Execute_Command VALUES (GETDATE(), null, null, ORIGINAL_LOGIN(), 'ADD FILE', @params, @paramvalues);

	-- Print the command necessary to run the correct job step. (Context does not allow the proc to call this automatically.)
	PRINT 'Execute the following to start the appropriate job step and complete the command:'
	PRINT 'EXEC msdb..sp_start_job  @job_name = ''SF_SQL_Admin Execute Command'', @step_name = ''ADD FILE'';';
END;
GO

IF EXISTS (SELECT name FROM sys.objects WHERE name = 'sfudf_SplitString')
	DROP FUNCTION sfudf_SplitString;
GO

CREATE FUNCTION sfudf_SplitString (@string varchar(max), @element int, @delim char(1))
RETURNS varchar(MAX)
AS
BEGIN
	DECLARE @id int = 0, @elementcount int = -1, @returnstring varchar(MAX) = '';
	WHILE (@id <= LEN(@string))
	BEGIN
		IF (SUBSTRING(@string, @id, 1) = @delim)
		BEGIN
			SET @elementcount = @elementcount + 1;
			
			IF @elementcount = @element
			BEGIN
				break;
			END;

			SET @returnstring = '';
			SET @id = @id + 1;
		END
				
		SET @returnstring = @returnstring + SUBSTRING(@string, @id, 1);
		SET @id = @id + 1;
	END;

	RETURN @returnstring;
END;
GO

IF EXISTS (SELECT name FROM sys.objects WHERE name = 'sfudf_CountElements')
	DROP FUNCTION sfudf_CountElements;
GO

CREATE FUNCTION sfudf_CountElements (@string varchar(max), @delim char(1))
RETURNS INT
AS
BEGIN
	DECLARE @id int = 0, @elements int = 0;
	WHILE (@id <= LEN(@string))
	BEGIN
		IF (SUBSTRING(@string, @id, 1) = @delim)
		BEGIN
			SET @elements = @elements + 1;
		END
		
		SET @id = @id + 1;
	END;

	RETURN @elements;
END;
GO

DECLARE @account varchar(512), @cmd nvarchar(512);

SELECT @account = name FROM sys.syslogins
WHERE name LIKE '%SQLSuppE2_DLG';

SET @cmd = 'DENY INSERT,UPDATE,DELETE,ALTER,CONTROL,TAKE OWNERSHIP, VIEW DEFINITION ON SF_Admin_Execute_Command TO [' + @account + ']';
EXEC sp_executesql @cmd
GO



USE [msdb]
GO

IF EXISTS (SELECT name FROM sysjobs WHERE name = 'SF_SQL_Admin Execute Command')
	EXEC msdb.dbo.sp_delete_job @job_name=N'SF_SQL_Admin Execute Command'

EXEC msdb.dbo.sp_add_job @job_name=N'SF_SQL_Admin Execute Command', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sfsa'

		
EXEC  msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Execute Command', @step_name=N'DBCC SHRINKFILE', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=4, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'UPDATE SF_Admin_Execute_Command
SET JobStartDate = GETDATE()
WHERE JobStartDate IS NULL;
GO

DECLARE @cmd nvarchar(MAX), @params nvarchar(MAX), @logicalfile nvarchar(512), @sizemb nvarchar(12);
SELECT TOP 1 @cmd = N''USE ['' + name + '']; DBCC SHRINKFILE (@file, @size);'', 
	@params = params, @logicalfile = dbo.sfudf_SplitString (ParamValues, 1, '',''),
	@sizemb = dbo.sfudf_SplitString (ParamValues, 2, '','')
FROM SF_Admin_Execute_Command sf
INNER JOIN sys.databases sd ON sd.database_id = dbo.sfudf_SplitString (ParamValues, 0, '','')
WHERE JobEndDate IS NULL;

EXEC sp_executesql @cmd, @params, @logicalfile, @sizemb;
', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

		
EXEC  msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Execute Command', @step_name=N'DBCC CHECKDB', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=4, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'UPDATE SF_Admin_Execute_Command
SET JobStartDate = GETDATE()
WHERE JobStartDate IS NULL;
GO

DECLARE @cmd nvarchar(MAX);
SELECT TOP 1 @cmd = ''DBCC CHECKDB ('' + name + '') WITH NO_INFOMSGS;''
FROM SF_Admin_Execute_Command sf
INNER JOIN sys.databases sd ON sf.ParamValues = sd.database_id
WHERE JobEndDate IS NULL;

EXEC sp_executesql @cmd;', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

		
EXEC  msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Execute Command', @step_name=N'ADD FILE', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=4, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'UPDATE SF_Admin_Execute_Command
SET JobStartDate = GETDATE()
WHERE JobStartDate IS NULL;
GO

DECLARE @cmd nvarchar(MAX), @params nvarchar(MAX), @elements int;

SELECT @elements = dbo.sfudf_CountElements(ParamValues, '','')
FROM SF_Admin_Execute_Command
WHERE JobEndDate IS NULL;

IF (@elements > 6)
BEGIN
	PRINT ''Error found in parameters, please try again.'';
	-- Update execution date to preserve record
	UPDATE SF_Admin_Execute_Command SET JobEndDate = GETDATE() WHERE JobEndDate IS NULL;
	-- Write event to log for SCOM monitoring
	
	RETURN;
END

SELECT @cmd = ''ALTER DATABASE ['' + name + ''] ADD FILE ( NAME = '''''' + dbo.sfudf_SplitString(ParamValues, 1, '','') + 
	'''''', FILENAME = '''''' + dbo.sfudf_SplitString(ParamValues, 2, '','') + 
	'''''', SIZE = '' + dbo.sfudf_SplitString(ParamValues, 3, '','') + ''MB, 
	FILEGROWTH = '' + dbo.sfudf_SplitString(ParamValues, 4, '','') + ''MB)''
FROM SF_Admin_Execute_Command sf
INNER JOIN sys.databases sd ON sd.database_id = dbo.sfudf_SplitString(ParamValues, 0, '','')
WHERE JobEndDate IS NULL;

EXEC sp_executesql @cmd;
', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

		
EXEC  msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Execute Command', @step_name=N'ENTER JOB END', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'UPDATE SF_Admin_Execute_Command
SET JobEndDate = GETDATE()
WHERE JobEndDate IS NULL;', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

		
EXEC  msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Execute Command', @step_name=N'CLEAN UP', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DELETE SF_Admin_Execute_Command
WHERE InsertedDate < GETDATE() - 60', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

		
EXEC  msdb.dbo.sp_update_job @job_name=N'SF_SQL_Admin Execute Command', @start_step_id = 5


EXEC  msdb.dbo.sp_add_jobschedule @job_name=N'SF_SQL_Admin Execute Command', @name=N'Monthly', 
		@enabled=1, 
		@freq_type=16, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160816, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'b3106a17-b197-421c-83f3-31d7c9353a4b'

		
EXEC  msdb.dbo.sp_add_jobserver @job_name=N'SF_SQL_Admin Execute Command', @server_name = N'(local)'

GO