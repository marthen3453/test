USE [SF_SQL_Admin];
GO

CREATE TABLE SF_Admin_Execute_Command (
	InsertedDate datetime
	, JobStartDate datetime
	, JobEndDate datetime
	, CalledBy varchar(128)
	, Command varchar(128)
	, Params nvarchar(MAX)
	, ParamValues nvarchar(MAX));
GO

CREATE PROC sfsp_DBCC_CHECKDB (@dbid int)
WITH EXECUTE AS OWNER
AS
BEGIN
	SET NOCOUNT ON;

	IF EXISTS (SELECT * FROM SF_Admin_Execute_Command 
				WHERE JobStartDate IS NOT NULL
				AND JobEndDate IS NULL)
	BEGIN
		PRINT 'SF_SQL_Admin Execute Command job is currently executing, please try again after job has completed.';
		return;
	END;

	-- Clear unused commands
	UPDATE SF_Admin_Execute_Command SET JobEndDate = '1/1/1900', JobStartDate = '1/1/1900' WHERE JobEndDate IS NULL AND JobStartDate IS NULL;	
	
	-- Declare variables.
	DECLARE @params varchar(MAX), @paramvalues varchar(MAX);

	--  Build command, parameters, and parameter values
	SET @params = '';
	SET @paramvalues = CAST(@dbid AS varchar);

	-- Insert into command table.
	INSERT SF_Admin_Execute_Command VALUES (GETDATE(), null, null, ORIGINAL_LOGIN(), 'DBCC CHECKDB', @params, @paramvalues);

	-- Print the command necessary to run the correct job step. (Context does not allow the proc to call this automatically.)
	PRINT 'Execute the following to start the appropriate job step and complete the command:'
	PRINT 'EXEC msdb.dbo.sp_start_job  @job_name = ''SF_SQL_Admin Execute Command'', @step_name = ''DBCC CHECKDB'';'
END
GO

CREATE PROC sfsp_DBCC_SHRINKFILE (@dbid int, @logicalfile varchar(512), @sizemb int)
WITH EXECUTE AS OWNER
AS
BEGIN
	SET NOCOUNT ON;

	IF EXISTS (SELECT * FROM SF_Admin_Execute_Command 
			WHERE JobStartDate IS NOT NULL
			AND JobEndDate IS NULL)
	BEGIN
		PRINT 'SF_SQL_Admin Execute Command job is currently executing, please try again after job has completed.';
		return;
	END;

	-- Clear unused commands
	UPDATE SF_Admin_Execute_Command SET JobEndDate = '1/1/1900', JobStartDate = '1/1/1900' WHERE JobEndDate IS NULL AND JobStartDate IS NULL;	
	
	-- Declare variables.
	DECLARE @cmd varchar(MAX), @params varchar(MAX), @paramvalues varchar(MAX);

	--  Build command, parameters, and parameter values
	SET @params = N'@file varchar(512), @size int' ;
	SET @paramvalues = CAST(@dbid AS varchar) + ',' + @logicalfile + ',' + CAST(@sizemb AS varchar);

	-- Insert into command table.
	INSERT SF_Admin_Execute_Command VALUES (GETDATE(), null, null, ORIGINAL_LOGIN(), 'DBCC SHRINKFILE', @params, @paramvalues);
	
	-- Print the command necessary to run the correct job step. (Context does not allow the proc to call this automatically.)
	PRINT 'Execute the following to start the appropriate job step and complete the command:'
	PRINT 'EXEC msdb..sp_start_job  @job_name = ''SF_SQL_Admin Execute Command'', @step_name = ''DBCC SHRINKFILE'';';
END
GO

CREATE PROC sfsp_ADD_FILE (@dbid int, @type varchar(4), @name varchar(512), @path varchar(512), @sizemb int, @growthmb int)
WITH EXECUTE AS OWNER
AS
BEGIN
	SET NOCOUNT ON;

	IF EXISTS (SELECT * FROM SF_Admin_Execute_Command 
				WHERE JobStartDate IS NOT NULL
				AND JobEndDate IS NULL)
	BEGIN
		PRINT 'SF_SQL_Admin Execute Command job is currently executing, please try again after job has completed.';
		return;
	END;

	-- Clear unused commands
	UPDATE SF_Admin_Execute_Command SET JobEndDate = '1/1/1900', JobStartDate = '1/1/1900' WHERE JobEndDate IS NULL AND JobStartDate IS NULL;	
	
	--  Build command, parameters, and parameter values
	DECLARE @params varchar(MAX), @paramvalues varchar(MAX);

	IF (@type = 'DATA')
	BEGIN
		IF SUBSTRING(@path, LEN(@path), 1) = '\'
			SET @path = @path + @name + '.ndf';
		ELSE
			SET @path = @path + '\' + @name + '.ndf';

		SET @params = '';
		SET @paramvalues = CAST(@dbid AS varchar) + ',' + @name + ',' + @path + ',' + CAST(@sizemb AS varchar) + ',' + 
			CAST(@growthmb AS varchar);
	END;

	ELSE IF (@type = 'LOG')
	BEGIN
		IF SUBSTRING(@path, LEN(@path), 1) = '\'
			SET @path = @path + @name + '.ldf';
		ELSE
			SET @path = @path + '\' + @name + '.ldf';
			
		SET @params = '';
		SET @paramvalues = CAST(@dbid AS varchar) + ',' + @name + ',' + @path + ',' + CAST(@sizemb AS varchar) + ',' + 
			CAST(@growthmb AS varchar);
	END;

	INSERT SF_Admin_Execute_Command VALUES (GETDATE(), null, null, ORIGINAL_LOGIN(), 'ADD FILE', @params, @paramvalues);

	-- Print the command necessary to run the correct job step. (Context does not allow the proc to call this automatically.)
	PRINT 'Execute the following to start the appropriate job step and complete the command:'
	PRINT 'EXEC msdb..sp_start_job  @job_name = ''SF_SQL_Admin Execute Command'', @step_name = ''ADD FILE'';';
END;
GO

CREATE FUNCTION sfudf_SplitString (@string varchar(max), @element int, @delim char(1))
RETURNS varchar(MAX)
AS
BEGIN
	DECLARE @id int = 0, @elementcount int = -1, @returnstring varchar(MAX) = '';
	WHILE (@id <= LEN(@string))
	BEGIN
		IF (SUBSTRING(@string, @id, 1) = @delim)
		BEGIN
			SET @elementcount = @elementcount + 1;
			
			IF @elementcount = @element
			BEGIN
				break;
			END;

			SET @returnstring = '';
			SET @id = @id + 1;
		END
				
		SET @returnstring = @returnstring + SUBSTRING(@string, @id, 1);
		SET @id = @id + 1;
	END;

	RETURN @returnstring;
END;
GO

CREATE FUNCTION sfudf_CountElements (@string varchar(max), @delim char(1))
RETURNS INT
AS
BEGIN
	DECLARE @id int = 0, @elements int = 0;
	WHILE (@id <= LEN(@string))
	BEGIN
		IF (SUBSTRING(@string, @id, 1) = @delim)
		BEGIN
			SET @elements = @elements + 1;
		END
		
		SET @id = @id + 1;
	END;

	RETURN @elements;
END;
GO

DENY INSERT,UPDATE,DELETE,ALTER,CONTROL,TAKE OWNERSHIP, VIEW DEFINITION ON SF_Admin_Execute_Command TO [UNTOPR\SQLSuppE2_DLG];
GO




