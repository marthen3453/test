USE [msdb]
GO

IF EXISTS (SELECT name FROM sysjobs WHERE name = 'SF_SQL_Admin Execute Command')
	EXEC msdb.dbo.sp_delete_job @job_name=N'SF_SQL_Admin Execute Command'

EXEC msdb.dbo.sp_add_job @job_name=N'SF_SQL_Admin Execute Command', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sfsa'

		
EXEC  msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Execute Command', @step_name=N'DBCC SHRINKFILE', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=4, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'UPDATE SF_Admin_Execute_Command
SET JobStartDate = GETDATE()
WHERE JobStartDate IS NULL;
GO

DECLARE @cmd nvarchar(MAX), @params nvarchar(MAX), @logicalfile nvarchar(512), @sizemb nvarchar(12);
SELECT TOP 1 @cmd = N''USE ['' + name + '']; DBCC SHRINKFILE (@file, @size);'', 
	@params = params, @logicalfile = dbo.sfudf_SplitString (ParamValues, 1, '',''),
	@sizemb = dbo.sfudf_SplitString (ParamValues, 2, '','')
FROM SF_Admin_Execute_Command sf
INNER JOIN sys.databases sd ON sd.database_id = dbo.sfudf_SplitString (ParamValues, 0, '','')
WHERE JobEndDate IS NULL;

EXEC sp_executesql @cmd, @params, @logicalfile, @sizemb;
', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

		
EXEC  msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Execute Command', @step_name=N'DBCC CHECKDB', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=4, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'UPDATE SF_Admin_Execute_Command
SET JobStartDate = GETDATE()
WHERE JobStartDate IS NULL;
GO

DECLARE @cmd nvarchar(MAX);
SELECT TOP 1 @cmd = ''DBCC CHECKDB ('' + name + '') WITH NO_INFOMSGS;''
FROM SF_Admin_Execute_Command sf
INNER JOIN sys.databases sd ON sf.ParamValues = sd.database_id
WHERE JobEndDate IS NULL;

EXEC sp_executesql @cmd;', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

		
EXEC  msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Execute Command', @step_name=N'ADD FILE', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=4, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'UPDATE SF_Admin_Execute_Command
SET JobStartDate = GETDATE()
WHERE JobStartDate IS NULL;
GO

DECLARE @cmd nvarchar(MAX), @params nvarchar(MAX), @elements int;

SELECT @elements = dbo.sfudf_CountElements(ParamValues, '','')
FROM SF_Admin_Execute_Command
WHERE JobEndDate IS NULL;

IF (@elements > 6)
BEGIN
	PRINT ''Error found in parameters, please try again.'';
	-- Update execution date to preserve record
	UPDATE SF_Admin_Execute_Command SET JobEndDate = GETDATE() WHERE JobEndDate IS NULL;
	-- Write event to log for SCOM monitoring
	
	RETURN;
END

SELECT @cmd = ''ALTER DATABASE ['' + name + ''] ADD FILE ( NAME = '''''' + dbo.sfudf_SplitString(ParamValues, 1, '','') + 
	'''''', FILENAME = '''''' + dbo.sfudf_SplitString(ParamValues, 2, '','') + 
	'''''', SIZE = '' + dbo.sfudf_SplitString(ParamValues, 3, '','') + ''MB, 
	FILEGROWTH = '' + dbo.sfudf_SplitString(ParamValues, 4, '','') + ''MB)''
FROM SF_Admin_Execute_Command sf
INNER JOIN sys.databases sd ON sd.database_id = dbo.sfudf_SplitString(ParamValues, 0, '','')
WHERE JobEndDate IS NULL;

EXEC sp_executesql @cmd;
', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

		
EXEC  msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Execute Command', @step_name=N'ENTER JOB END', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'UPDATE SF_Admin_Execute_Command
SET JobEndDate = GETDATE()
WHERE JobEndDate IS NULL;', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

		
EXEC  msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Execute Command', @step_name=N'CLEAN UP', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DELETE SF_Admin_Execute_Command
WHERE InsertedDate < GETDATE() - 60', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

		
EXEC  msdb.dbo.sp_update_job @job_name=N'SF_SQL_Admin Execute Command', @start_step_id = 5


EXEC  msdb.dbo.sp_add_jobschedule @job_name=N'SF_SQL_Admin Execute Command', @name=N'Monthly', 
		@enabled=1, 
		@freq_type=16, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160816, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'b3106a17-b197-421c-83f3-31d7c9353a4b'

		
EXEC  msdb.dbo.sp_add_jobserver @job_name=N'SF_SQL_Admin Execute Command', @server_name = N'(local)'

GO


