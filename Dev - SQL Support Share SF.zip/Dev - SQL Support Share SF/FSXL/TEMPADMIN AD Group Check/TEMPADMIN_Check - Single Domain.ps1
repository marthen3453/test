$file = "C:\DATA\SQL\SF_SQL_Admin\ADOutput.txt"

$admin = Get-ADGroup -Filter 'Name -like "SQL*TEMPADMIN_G*"'

"Domain: " + (Get-ADDomain -Current LocalComputer).DNSRoot | Out-File $file
"" + $admin.Count + " temp admin groups found." | Out-File $file -Append

foreach ($a in $admin) {
    $member = Get-ADGroupMember $a.Name

    "`r`n*********************************************" | Out-File $file -Append
    "Group name: " + $a.Name | Out-File $file -Append
    "Members (" + @($member).Count + "):" | Out-File $file -Append
    "=============================================" | Out-File $file -Append
     
    foreach ($m in $member) {
        "`t" + $m.Name | Out-File $file -Append
    }
}