$file = "C:\DATA\SQL\SF_SQL_Admin\TEMPADMIN\TEMPADMIN_SearchResults_" + ((Get-Date).ToShortDateString() -replace "/", "-") + ".csv"

$domains = @()
$domains += "OPR.STATEFARM.ORG"
$domains += "OPR.SYSTEM.TEST.STATEFARM.ORG"
$domains += "UNITOPR.UNITINT.TEST.STATEFARM.ORG"
$domains += "SUPPORT.OPR.STATEFARM.ORG"

$results = @()

foreach ($d in $domains) {
    $admin = Get-ADGroup -Filter 'Name -like "SQL*TEMPADMIN_G*"' -Server $d
     
    foreach ($a in $admin) {
        $member = Get-ADGroupMember $a.Name -Server $d

        if (@($member).Count -le 0) { continue; }

        foreach ($m in $member) {
            $details = @{
                Domain = $d
                Group =  $a.Name
                Alias =  $m.Name
            }
            
            $results += New-Object PSObject -Property $details
        }
    }
}

$results | Select Domain,Group,Alias | Export-Csv -Path $file -NoTypeInformation

Get-ChildItem -Path "C:\DATA\SQL\SF_SQL_Admin\TEMPADMIN" -Force | Where-Object { !$_.PSIsContainer -and $_.CreationTime -lt (Get-Date).AddDays(-7) -and $_.Name -ne "PSTempAdminCheck.ps1"} | Remove-Item -Force
