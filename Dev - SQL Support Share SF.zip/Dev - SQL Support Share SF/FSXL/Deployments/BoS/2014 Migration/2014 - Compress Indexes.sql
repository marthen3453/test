SELECT DISTINCT i.type_desc, 
CASE 
	WHEN i.type_desc = 'HEAP' THEN 'ALTER TABLE [' + s.name + '].[' + o.name + '] REBUILD WITH (DATA_COMPRESSION=PAGE)'
	WHEN i.type_desc = 'CLUSTERED' THEN 'ALTER INDEX [' + i.name + '] ON [' + s.name + '].[' + o.name + '] REBUILD WITH (DATA_COMPRESSION=PAGE)' 
	WHEN i.type_desc = 'NONCLUSTERED' THEN 'ALTER INDEX [' + i.name + '] ON [' + s.name + '].[' + o.name + '] REBUILD WITH (DATA_COMPRESSION=PAGE)' END
FROM sys.indexes i
INNER JOIN sys.objects o ON o.object_id = i.object_id
INNER JOIN sys.schemas s ON s.schema_id = o.schema_id
INNER JOIN sys.partitions p ON p.object_id = o.object_id
WHERE is_ms_shipped = 0
AND data_compression = 0
ORDER BY i.type_desc