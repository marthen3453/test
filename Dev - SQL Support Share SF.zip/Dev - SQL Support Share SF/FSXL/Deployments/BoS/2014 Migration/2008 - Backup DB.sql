BACKUP DATABASE [SFSQL_ENT_WLM] TO  
DISK = N'\\Wpsd5v0d\wpsd5v0d_f\MSSQL\BACKUP\F_MP08\BACKUP\2014_Pre-Migration_Backup_1.bak',  
DISK = N'\\Wpsd5v0d\wpsd5v0d_f\MSSQL\BACKUP\F_MP08\BACKUP\2014_Pre-Migration_Backup_2.bak',  
DISK = N'\\Wpsd5v0d\wpsd5v0d_f\MSSQL\BACKUP\F_MP08\BACKUP\2014_Pre-Migration_Backup_3.bak',  
DISK = N'\\Wpsd5v0d\wpsd5v0d_f\MSSQL\BACKUP\F_MP08\BACKUP\2014_Pre-Migration_Backup_4.bak',  
DISK = N'\\Wpsd5v0d\wpsd5v0d_f\MSSQL\BACKUP\F_MP08\BACKUP\2014_Pre-Migration_Backup_5.bak',  
DISK = N'\\Wpsd5v0d\wpsd5v0d_f\MSSQL\BACKUP\F_MP08\BACKUP\2014_Pre-Migration_Backup_6.bak' 
WITH  COPY_ONLY, NOFORMAT, NOINIT,  NAME = N'SFSQL_ENT_WLM-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10, COMPRESSION
GO