CREATE TABLE BOSSTG.TASK_SUM(
    TASK_SUM_ID            int               NOT NULL,
    PROJ_ID                int               NULL,
    WBS_ID                 int               NULL,
    ACTUL_WORK_QTY_CNT     decimal(22, 6)    DEFAULT 0 NULL,
    TOTAL_DUR_HR_CNT       decimal(17, 6)    NULL,
    ETC_WORK_QTY_CNT       decimal(22, 6)    DEFAULT 0 NULL,
    RMN_WORK_QTY_CNT       decimal(22, 6)    DEFAULT 0 NULL,
    ACTUL_WORK_COST_AMT    decimal(25, 6)    DEFAULT 0 NULL,
    ETC_WORK_COST_AMT      decimal(25, 6)    DEFAULT 0 NULL,
    RMN_WORK_COST_AMT      decimal(25, 6)    DEFAULT 0 NULL,
    UPDT_DT                smalldatetime     NULL,
    CREAT_DT               smalldatetime     DEFAULT getdate() NULL,
    DLTE_DT                smalldatetime     DEFAULT getdate() NULL,
    BOS_INSRT_TSTMP        smalldatetime     DEFAULT getdate() NOT NULL,
    HASH_VALUE_TXT         varchar(32)       NULL,
    CONSTRAINT TASK_SUM_ID_PK PRIMARY KEY CLUSTERED (TASK_SUM_ID)
)
go


GRANT SELECT ON BOSSTG.TASK_SUM TO NONCON_RO
GRANT SELECT, INSERT, UPDATE, DELETE on BOSSTG.TASK_SUM to NONCON_RW

go

sp_rename 'BOSSTG.UDF_VALUE.PROJ_ID', 'FK_ID'

go



/****** Object:  View [dbo].[CURNT_ACTVY_SFVW]    Script Date: 7/26/2016 9:45:02 AM ******/
DROP VIEW [dbo].[CURNT_ACTVY_SFVW]
GO

/****** Object:  View [dbo].[CURNT_ACTVY_SFVW]    Script Date: 7/26/2016 9:45:02 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







/*****
**Date Created: 10/13/2010
**Author: Dan Pascavis
**Change: 
	Requested by SFOnline Program to see activity data for BC's via a view for forecasting using assignments.
******/

/*****
** R20124 Phase to Release
**Date changed	: 12/5/2013
**Author		: Dan Pascavis (JP6L)
**Added			: RD.ADJST_REL_NUM
******/

/*****
** R20124 Phase to Release
**Date changed	: 01/14/2014
**Author		: Vamsikrishna Parvataneni (RJG7)
**Added			: RD.REL_DIM_ID
******/

/*****
** SR81852 ICP Delivery Dashboard Updates
**Date changed	: 07/28/2014
**Author		: Vamsikrishna Parvataneni (RJG7)
**Added			: Added 25 New fields
******/


/*****
**Date changed	: 07/18/2016
**Author		: Vamsikrishna Parvataneni (RJG7)
**Change: 
	Request by Patrick Resendiz to only display the active records and not to show records that no longer exists in Primavera Source
******/


CREATE VIEW [dbo].[CURNT_ACTVY_SFVW]
AS
SELECT 
AD.TASK_ID,
AD.ACTVY_NM,
AD.ACTVY_NUM,
AD.ACTUL_STRT_DT,
AD.ACTUL_END_DT,
AD.SCHED_STRT_DT,
AD.SCHED_END_DT,
AD.RSTRT_DT,
AD.REEND_DT,
AD.WBS_ELMT_NM_TXT,
CD.MAJOR_CLAS_NM AS MAJOR_CLAS_NM,
CD.SUB_CLAS_NM AS SUB_CLAS_NM,
ASD.STTS_NM AS ACTIVITY_STTS_NM,
BSD.STTS_NM AS BUSN_CASE_STTS_NM,
WSD.STTS_NM AS WORK_STTS_NM,
HTD.HR_TYPE_NM,
WD.WORK_NUM,
BCD.BUSN_CASE_NUM,
WTD.WORK_TYPE_NM,
MPD.METHD_PHAS_NM,
SDTD.SR_DEV_TYPE_NM,
PD.PRFL_ID AS PFOLO_PRFL_ID,
PD.LEVL_2_PFOLO_ID,
PD.LEVL_2_PFOLO_NM,
PD.LEVL_4_PFOLO_ID,
PD.LEVL_4_PFOLO_NM,
PD.LEVL_4_PFOLO_SHORT_NM,
RD.ADJST_REL_NUM,
RD.REL_DIM_ID,
AF.CNSMD_HR_CNT,
AF.RMN_HR_CNT,
AF.CNSMD_HR_PCT,
AF.PLAN_DUR_CNT,
AF.RMN_DUR_CNT,
AF.CNSMD_DUR_PCT
FROM
dbo.ACTVY_FACT				AF		WITH (NOLOCK)
INNER JOIN ACTVY_DIM		AD		WITH (NOLOCK) ON AF.ACTVY_DIM_ID=AD.ACTVY_DIM_ID
INNER JOIN TM_DIM			STRT_TD WITH (NOLOCK) ON AF.STRT_TM_DIM_ID=STRT_TD.TM_DIM_ID
INNER JOIN TM_DIM			END_TD	WITH (NOLOCK) ON AF.END_TM_DIM_ID=END_TD.TM_DIM_ID
INNER JOIN CLAS_DIM			CD		WITH (NOLOCK) ON AF.CLAS_DIM_ID=CD.CLAS_DIM_ID
INNER JOIN STTS_DIM			ASD		WITH (NOLOCK) ON AF.ACTVY_STTS_DIM_ID=ASD.STTS_DIM_ID
INNER JOIN STTS_DIM			BSD		WITH (NOLOCK) ON AF.BUSN_CASE_STTS_DIM_ID=BSD.STTS_DIM_ID
INNER JOIN STTS_DIM			WSD		WITH (NOLOCK) ON AF.WORK_STTS_DIM_ID=WSD.STTS_DIM_ID
INNER JOIN HR_TYPE_DIM		HTD		WITH (NOLOCK) ON AF.HR_TYPE_DIM_ID=HTD.HR_TYPE_DIM_ID
INNER JOIN WORK_DIM			WD		WITH (NOLOCK) ON AF.WORK_DIM_ID=WD.WORK_DIM_ID
INNER JOIN BUSN_CASE_DIM	BCD		WITH (NOLOCK) ON AF.BUSN_CASE_DIM_ID=BCD.BUSN_CASE_DIM_ID
INNER JOIN WORK_TYPE_DIM	WTD		WITH (NOLOCK) ON AF.WORK_TYPE_DIM_ID=WTD.WORK_TYPE_DIM_ID
INNER JOIN METHD_PHAS_DIM	MPD		WITH (NOLOCK) ON AF.METHD_PHAS_DIM_ID=MPD.METHD_PHAS_DIM_ID
INNER JOIN SR_DEV_TYPE_DIM	SDTD	WITH (NOLOCK) ON AF.SR_DEV_TYPE_DIM_ID=SDTD.SR_DEV_TYPE_DIM_ID
INNER JOIN PFOLO_DIM		PD		WITH (NOLOCK) ON AF.PFOLO_DIM_ID=PD.PFOLO_DIM_ID
INNER JOIN REL_DIM			RD		WITH (NOLOCK) ON AF.REL_DIM_ID=RD.REL_DIM_ID

WHERE 
AF.ACTV_ROW_IND='Y'
AND 
END_TD.FUL_DT=CONVERT(SMALLDATETIME, LEFT(GETDATE(),11), 101)



GO




/****** Object:  View [dbo].[CURNT_WBS_SFVW]    Script Date: 7/26/2016 9:45:51 AM ******/
DROP VIEW [dbo].[CURNT_WBS_SFVW]
GO

/****** Object:  View [dbo].[CURNT_WBS_SFVW]    Script Date: 7/26/2016 9:45:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





/*****
**Date Created	: 05/01/2015
**Author		: Vamsikrishna Parvataneni (RJG7)
**Change		: As part of BoSERC#1048 created Current WBS (Work Breakdown Structure) View.
******/

/*****
**Date changed	: 07/18/2016
**Author		: Vamsikrishna Parvataneni (RJG7)
**Change: 
	Request by Patrick Resendiz to only display the active records and not to show records that no longer exists in Primavera Source
******/


CREATE VIEW [dbo].[CURNT_WBS_SFVW]
AS
SELECT 
WBS_ID,
WORK_NUM,
WBS_STTS_NM,
WBS_PTH_TXT,
WBS_CD,
WBS_NM,
NODE_TYPE_CD,
WBS_RESPB_MGR_TXT,
INSRT_TSTMP
FROM
BOSINT.WBS_DIM WBS


GO


GRANT SELECT ON [dbo].[CURNT_WBS_SFVW] TO NONCON_RO;
GRANT SELECT ON [dbo].[CURNT_WBS_SFVW]TO NONCON_RW;
GRANT SELECT ON [dbo].[CURNT_WBS_SFVW]TO NONCON_VIEWS_RO;
GRANT SELECT ON [dbo].[CURNT_WBS_SFVW]TO SDM_NONCON_VIEWS_RO;


GRANT SELECT ON [dbo].[CURNT_ACTVY_SFVW]TO NONCON_RO;
GRANT SELECT ON [dbo].[CURNT_ACTVY_SFVW]TO NONCON_RW;
GRANT SELECT ON [dbo].[CURNT_ACTVY_SFVW]TO NONCON_VIEWS_RO;
GRANT SELECT ON [dbo].[CURNT_ACTVY_SFVW]TO SDM_NONCON_VIEWS_RO;
