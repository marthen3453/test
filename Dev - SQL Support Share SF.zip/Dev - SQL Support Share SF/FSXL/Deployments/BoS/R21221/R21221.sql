USE [SFSQL_ENT_BOS];
GO
/* 
 * TABLE: COLLAB_STG 
 */

CREATE TABLE STG.COLLAB_STG(
    SRC_TYPE_NM                 varchar(255)     NULL,
    X_ENVL_ID                   bigint           NULL,
    MULTI_PG_CD                 smallint         NULL,
    PG_NUM                      smallint         NULL,
    PG_SIZE_NUM                 int              NULL,
    RCRD_CNT                    int              NULL,
    STTS_CD                     int              NULL,
    STTS_MSG_TXT                varchar(255)     NULL,
    FALT_CD                     varchar(255)     NULL,
    FALT_TXT                    varchar(255)     NULL,
    FALT_FCTR_TXT               varchar(255)     NULL,
    MSG_TXT                     varchar(1000)    NULL,
    X_FIELD                     bigint           NULL,
    FK_TNS_WEB_FORM_INSTC_ID    bigint           NULL,
    CUSTM_FLD_NM                varchar(255)     NULL,
    CUSTM_FLD_TXT               varchar(255)     NULL,
    BOS_INSRT_TSTMP             smalldatetime    DEFAULT GETDATE() NOT NULL
);
GO

-- Table: RISK_IMPCT_TYPE
ALTER TABLE STG.RISK_IMPCT_TYPE ADD DATA_CNTXT_CD char(10) NOT NULL DEFAULT '(N/A)';
GO
ALTER TABLE STG.RISK_IMPCT_TYPE ADD BOS_INSRT_TSTMP smalldatetime NOT NULL DEFAULT GETDATE();
GO

-- Table: ISS_IMPCT_TYPE
ALTER TABLE STG.ISS_IMPCT_TYPE ADD DATA_CNTXT_CD char(10) NOT NULL DEFAULT '(N/A)';
GO
ALTER TABLE STG.ISS_IMPCT_TYPE ADD BOS_INSRT_TSTMP smalldatetime NOT NULL DEFAULT GETDATE();
GO

-- Table: DELIVERABLE_DOCUMENT_STG_TABLE
ALTER TABLE STG.DELIVERABLE_DOCUMENT_STG_TABLE ADD DATA_CNTXT_CD char(10) NOT NULL DEFAULT '(N/A)';
GO

-- Table: CHNG_RQST_IMP_TYPE
ALTER TABLE STG.CHNG_RQST_IMP_TYPE ADD BOS_INSRT_TSTMP smalldatetime NOT NULL DEFAULT GETDATE();
GO
ALTER TABLE STG.CHNG_RQST_IMP_TYPE ADD DATA_CNTXT_CD char(10) NOT NULL DEFAULT '(N/A)';
GO

-- Table: DELIVERABLE_TEMPLATE_STG_TABLE
ALTER TABLE STG.DELIVERABLE_TEMPLATE_STG_TABLE ADD DATA_CNTXT_CD char(10) NOT NULL DEFAULT '(N/A)';
GO

-- Table: LV1_LKUP_APPR_PKG_TMPLT
ALTER TABLE LV1_LKUP_APPR_PKG_TMPLT ADD DATA_CNTXT_CD char(10) NOT NULL DEFAULT '(N/A)';
GO

-- Table: LV1_APPR_PKG_INFO
ALTER TABLE LV1_APPR_PKG_INFO ADD DATA_CNTXT_CD char(10) NOT NULL DEFAULT '(N/A)';
GO

-- Permissions
GRANT SELECT ON STG.COLLAB_STG TO NONCON_RO;
GRANT SELECT,INSERT,DELETE,UPDATE ON STG.COLLAB_STG TO NONCON_RW;
