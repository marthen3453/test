SELECT i.*, 'ALTER INDEX [' + i.name + '] ON [' + s.name + '].[' + o.name + '] REBUILD WITH (DATA_COMPRESSION=PAGE,ONLINE=ON,SORT_IN_TEMPDB=ON)'
FROM sys.indexes i
INNER JOIN sys.objects o ON i.object_id = o.object_id
INNER JOIN sys.schemas s ON o.schema_id = s.schema_id
WHERE i.type_desc IN ('CLUSTERED', 'NONCLUSTERED')
AND o.type_desc = 'USER_TABLE'
ORDER BY i.type_desc

