SELECT s.name, o.name, i.name, rows, total_pages, used_pages, data_pages
FROM sys.partitions p
INNER JOIN sys.allocation_units au ON p.partition_id = au.container_id
INNER JOIN sys.objects o ON o.object_id = p.object_id
INNER JOIN sys.schemas s ON s.schema_id = o.schema_id
INNER JOIN sys.indexes i ON i.index_id = p.index_id
	AND i.object_id = p.object_id
WHERE o.type = 'U'	
AND o.name IN ('WKGRP_MAP_STG',
'WKGRP_MAP',
'LGCY_SYS_CD_LINE_STG',
'DEPT_AREA_CD_LINE_STG',
'DEPT_AREA_CD_LINE_MO_FACT',
'DEPT_AREA_CD_LINE_WK_FACT',
'LGCY_SYS_CD_LINE_MO_FACT',
'LGCY_SYS_CD_LINE_WK_FACT',
'DSTRB_DATA_MTRC_STG_TABLE',
'DSTRB_DATA_WK_FACT',
'DSTRB_DATA_MO_FACT',
'DATA_LOC_DIM')
ORDER BY o.name, i.name


