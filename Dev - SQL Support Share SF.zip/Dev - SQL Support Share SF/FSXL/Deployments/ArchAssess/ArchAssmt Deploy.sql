/*
 * ER/Studio Data Architect 9.5 SQL Code Generation
 * Company :      State Farm Insurance
 * Project :      Enterprise Architecture - Assessment Survey
 * Author :       David Iverson
 *
 * Date Created : Monday, December 19, 2016 12:09:49
 * Target DBMS : Microsoft SQL Server 2012
 */

/* 
 * TABLE: ADDL_RESP 
 */

CREATE TABLE ADDL_RESP(
    RESP_CD                char(16)        NOT NULL,
    DESC_TXT               varchar(512)    NULL,
    DSPLY_QSTN_NUM         char(4)         NULL,
    SELCT_CAPB_SEQ_NUM     char(10)        NULL,
    [Question Identifier]  char(10)        NULL,
    CONSTRAINT PK_ADDL_RESP PRIMARY KEY NONCLUSTERED (RESP_CD)
)
go



/* 
 * TABLE: [Architecture Content -Question Set] 
 */

CREATE TABLE [Architecture Content -Question Set](
    [Architectural Content Type Code]  smallint     NOT NULL,
    QSTN_SET_ID                        smallint     NOT NULL,
    [Start Date]                       date         NOT NULL,
    [End Date]                         date         NOT NULL,
    [Create Signon Identifier]         char(6)      NULL,
    [Create Timestamp]                 timestamp    NULL,
    [Last Update Signon Identifier]    char(6)      NULL,
    [Last Update Timestamp]            timestamp    NULL,
    CONSTRAINT [PK_Architecture Content -Question Set] PRIMARY KEY NONCLUSTERED ([Architectural Content Type Code], QSTN_SET_ID)
)
go



/* 
 * TABLE: [Architecture Content Type] 
 */

CREATE TABLE [Architecture Content Type](
    [Architectural Content Type Code]  smallint       IDENTITY(1,1),
    [Architectural Content Type Name]  varchar(60)    NULL,
    [Start Date]                       date           NOT NULL,
    [End Date]                         date           NOT NULL,
    [Create Signon Identifier]         char(6)        NULL,
    [Create Timestamp]                 timestamp      NULL,
    [Last Update Signon Identifier]    char(6)        NULL,
    [Last Update Timestamp]            timestamp      NULL,
    CONSTRAINT [PK_Architecture Content Type] PRIMARY KEY NONCLUSTERED ([Architectural Content Type Code])
)
go



/* 
 * TABLE: ASMT_DETL 
 */

CREATE TABLE ASMT_DETL(
    [Question Identifier]  char(10)     NOT NULL,
    DSPLY_QSTN_NUM         char(4)      NOT NULL,
    SELCT_CAPB_SEQ_NUM     char(10)     NOT NULL,
    FLAGD_IND              char(1)      NULL,
    USURE_IND              char(1)      DEFAULT "N" NOT NULL,
    LAST_UPDT_TSTMP        timestamp    NOT NULL,
    LAST_UPDT_SGNON_ID     char(6)      NOT NULL,
    CREAT_TSTMP            timestamp    NOT NULL,
    CREAT_SGNON_ID         char(6)      NOT NULL,
    CONSTRAINT PK_ASMT_DETL PRIMARY KEY NONCLUSTERED ([Question Identifier], DSPLY_QSTN_NUM, SELCT_CAPB_SEQ_NUM)
)
go



/* 
 * TABLE: ASMT_HEADR 
 */

CREATE TABLE ASMT_HEADR(
    ASMT_ID               int              NOT NULL,
    STRT_DT               datetime         NULL,
    END_DT                datetime         NULL,
    NOTE_CMNT_TXT         varchar(1000)    NULL,
    LAST_UPDT_SGNON_ID    char(6)          NULL,
    LAST_UPDT_TSTMP       timestamp        NOT NULL,
    CREAT_TSTMP           timestamp        NOT NULL,
    CREAT_SGNON_ID        char(6)          NOT NULL,
    WIT_ID                char(16)         NULL,
    IDEA_IND              char(1)          NULL,
    PPT_ID                char(16)         NULL,
    CONSTRAINT PK_ASMT_HEADR PRIMARY KEY NONCLUSTERED (ASMT_ID)
)
go



/* 
 * TABLE: ASMT_PRTPT 
 */

CREATE TABLE ASMT_PRTPT(
    ASMT_ID     int         NOT NULL,
    ASSOC_ID    char(11)    NOT NULL,
    ROLE_ID     char(16)    NOT NULL,
    CONSTRAINT PK_ASMT_PRTPT PRIMARY KEY NONCLUSTERED (ASMT_ID, ASSOC_ID, ROLE_ID)
)
go




/* 
 * TABLE: ASMT_SCOR 
 */

CREATE TABLE ASMT_SCOR(
    ASMT_ID     int         NOT NULL,
    CTGRY_ID    smallint    IDENTITY(1,1),
    SCOR_NUM    smallint    IDENTITY(1,1),
    CONSTRAINT PK_ASMT_SCOR PRIMARY KEY NONCLUSTERED (ASMT_ID)
)
go



/* 
 * TABLE: ASMT_STTS 
 */

CREATE TABLE ASMT_STTS(
    ASMT_ID         int            NOT NULL,
    STTS_CD         varchar(10)    NULL,
    STTS_DT         date           NULL,
    STTS_RESN_CD    varchar(30)    NULL,
    CONSTRAINT PK_ASMT_STTS PRIMARY KEY NONCLUSTERED (ASMT_ID)
)
go



/* 
 * TABLE: ASSOC 
 */

CREATE TABLE ASSOC(
    ASSOC_ID        char(11)        NOT NULL,
    SGNON_ID        char(6)         NOT NULL,
    TLPHN_NUM       varchar(20)     NULL,
    EML_ADDR_TXT    varchar(256)    NULL,
    PRSN_ROLE_NM    varchar(50)     NULL,
    LAST_NM         varchar(30)     NULL,
    FIRST_NM        varchar(30)     NULL,
    CONSTRAINT PK_ASSOC PRIMARY KEY NONCLUSTERED (ASSOC_ID)
)
go



/* 
 * TABLE: ASSOC_QSTN_INVL 
 */

CREATE TABLE ASSOC_QSTN_INVL(
    ASSOC_ID               char(11)    NOT NULL,
    DSPLY_QSTN_NUM         char(4)     NOT NULL,
    SELCT_CAPB_SEQ_NUM     char(10)    NOT NULL,
    [Question Identifier]  char(10)    NOT NULL,
    CONSTRAINT PK_ASSOC_QSTN_INVL PRIMARY KEY NONCLUSTERED (ASSOC_ID, DSPLY_QSTN_NUM, SELCT_CAPB_SEQ_NUM, [Question Identifier])
)
go



/* 
 * TABLE: [BCM_2-3] 
 */

CREATE TABLE [BCM_2-3](
    [BCM_LEVL_2-3_SEQ_NUM]  int            NOT NULL,
    ASMT_ID                 int            NULL,
    BCM_LEVL_2_ID           varchar(25)    NOT NULL,
    BCM_LEVL_3_ID           varchar(25)    NOT NULL,
    CONSTRAINT [PK_BCM_2-3] PRIMARY KEY NONCLUSTERED ([BCM_LEVL_2-3_SEQ_NUM])
)
go



/* 
 * TABLE: BCM_LEVL_1 
 */

CREATE TABLE BCM_LEVL_1(
    BCM_LEVL_1_ID    varchar(25)     NOT NULL,
    ASMT_ID          int             NULL,
    BCM_NM           varchar(256)    NULL,
    CONSTRAINT PK_BCM_LEVL_1 PRIMARY KEY NONCLUSTERED (BCM_LEVL_1_ID)
)
go



/* 
 * TABLE: [BCM_LEVL_1-2] 
 */

CREATE TABLE [BCM_LEVL_1-2](
    [BCM_LEVL_1-2_SEQ_NUM]  char(10)       NOT NULL,
    ASMT_ID                 int            NULL,
    BCM_LEVL_1_ID           varchar(25)    NOT NULL,
    BCM_LEVL_2_ID           varchar(25)    NOT NULL,
    CONSTRAINT [PK_BCM_LEVL_1-2] PRIMARY KEY NONCLUSTERED ([BCM_LEVL_1-2_SEQ_NUM])
)
go



/* 
 * TABLE: BCM_LEVL_2 
 */

CREATE TABLE BCM_LEVL_2(
    BCM_LEVL_2_ID    varchar(25)     NOT NULL,
    ASMT_ID          int             NULL,
    BCM_NM           varchar(256)    NULL,
    CONSTRAINT PK_BCM_LEVL_2 PRIMARY KEY NONCLUSTERED (BCM_LEVL_2_ID)
)
go



/* 
 * TABLE: BCM_LEVL_3 
 */

CREATE TABLE BCM_LEVL_3(
    BCM_LEVL_3_ID    varchar(25)     NOT NULL,
    ASMT_ID          int             NULL,
    BCM_NM           varchar(256)    NULL,
    CONSTRAINT PK_BCM_LEVL_3 PRIMARY KEY NONCLUSTERED (BCM_LEVL_3_ID)
)
go



/* 
 * TABLE: CMNT 
 */

CREATE TABLE CMNT(
    QSTN_ID         smallint         NOT NULL,
    QSTN_VER_NUM    smallint         NOT NULL,
    INSRT_TSTMP     timestamp        NOT NULL,
    CMNT_TXT        varchar(1028)    NOT NULL,
    ALIAS_CD        char(6)          NOT NULL,
    CONSTRAINT PK_CMNT PRIMARY KEY NONCLUSTERED (QSTN_ID, QSTN_VER_NUM, INSRT_TSTMP)
)
go



/* 
 * TABLE: CTGRY 
 */

CREATE TABLE CTGRY(
    CTGRY_ID          char(16)         NOT NULL,
    PARNT_CTGRY_ID    char(16)         NOT NULL,
    DESC_TXT          varchar(512)     NOT NULL,
    WGT_FCTR_NUM      decimal(3, 2)    NOT NULL,
    STRT_DT           Date             NOT NULL,
    END_DT            Date             NOT NULL,
    CONSTRAINT PK_CTGRY PRIMARY KEY NONCLUSTERED (CTGRY_ID)
)
go



/* 
 * TABLE: DSA_LEVL_1 
 */

CREATE TABLE DSA_LEVL_1(
    DSA_LEVL_1_ID    varchar(25)     NOT NULL,
    ASMT_ID          int             NULL,
    DSA_NM           varchar(256)    NULL,
    CONSTRAINT PK_DSA_LEVL_1 PRIMARY KEY NONCLUSTERED (DSA_LEVL_1_ID)
)
go



/* 
 * TABLE: [DSA_LEVL_1-2] 
 */

CREATE TABLE [DSA_LEVL_1-2](
    [DSA_1-2_SE_NUM]  int            NOT NULL,
    ASMT_ID           int            NULL,
    DSA_LEVL_2_ID     varchar(25)    NOT NULL,
    DSA_LEVL_1_ID     varchar(25)    NOT NULL,
    CONSTRAINT [PK_DSA_LEVL_1-2] PRIMARY KEY NONCLUSTERED ([DSA_1-2_SE_NUM])
)
go



/* 
 * TABLE: DSA_LEVL_2 
 */

CREATE TABLE DSA_LEVL_2(
    DSA_LEVL_2_ID    varchar(25)     NOT NULL,
    ASMT_ID          int             NULL,
    DSA_NM           varchar(256)    NULL,
    BCM_LEVL_3_ID    varchar(25)     NOT NULL,
    CONSTRAINT PK_DSA_LEVL_2 PRIMARY KEY NONCLUSTERED (DSA_LEVL_2_ID)
)
go



/* 
 * TABLE: [GRP_-_ANSW_SCOR] 
 */

CREATE TABLE [GRP_-_ANSW_SCOR](
    QSTN_ID             smallint        NOT NULL,
    QSTN_VER_NUM        smallint        NOT NULL,
    CTGRY_ID            char(16)        NOT NULL,
    SCOR_GRP_ID         char(1)         NOT NULL,
    ANSW_ID             char(10)        NOT NULL,
    SCOR_NUM            smallint        NULL,
    SCORING_CMNT_TXT    varchar(255)    NULL,
    CONSTRAINT [PK_GRP_-_ANSW_SCOR] PRIMARY KEY NONCLUSTERED (QSTN_ID, QSTN_VER_NUM, CTGRY_ID, SCOR_GRP_ID, ANSW_ID)
)
go



/* 
 * TABLE: GRP_INFO 
 */

CREATE TABLE GRP_INFO(
    GRP_ID               char(16)        NOT NULL,
    GRP_NM               varchar(35)     NOT NULL,
    MAIL_GRP_ALIAS_CD    char(6)         NOT NULL,
    GRP_MAIL_ADDR_TXT    varchar(256)    NOT NULL,
    ACTV_IND             char(1)         NOT NULL,
    LDAP_GRP_NM          varchar(256)    NOT NULL,
    CTGRY_TXT            varchar(256)    NULL,
    LAST_UPDT_TSTMP      timestamp       NULL,
    CREAT_TSTMP          timestamp       NULL,
    CREAT_SGNON_ID       char(6)         NULL,
    UPDT_SGNON_ID        char(6)         NULL,
    GRP_LONG_NM          varchar(256)    NOT NULL,
    CONSTRAINT PK_GRP_INFO PRIMARY KEY NONCLUSTERED (GRP_ID)
)
go


/* 
 * TABLE: GRP_INFO_PRSN 
 */

CREATE TABLE GRP_INFO_PRSN(
    GRP_ID                 char(16)    NOT NULL,
    ASSOC_ID               char(11)    NOT NULL,
    ASSOC_ROLE_CD          int         NOT NULL,
    DSPLY_QSTN_NUM         char(4)     NOT NULL,
    SELCT_CAPB_SEQ_NUM     char(10)    NOT NULL,
    [Question Identifier]  char(10)    NOT NULL,
    CONSTRAINT PK_GRP_INFO_PRSN PRIMARY KEY NONCLUSTERED (GRP_ID, ASSOC_ID, ASSOC_ROLE_CD, DSPLY_QSTN_NUM, SELCT_CAPB_SEQ_NUM, [Question Identifier])
)
go


/* 
 * TABLE: HELP 
 */

CREATE TABLE HELP(
    QSTN_ID         smallint        NOT NULL,
    QSTN_VER_NUM    smallint        NOT NULL,
    INSRT_TSTMP     timestamp       NOT NULL,
    HELP_TXT        varchar(512)    NULL,
    ALIAS_CD        char(6)         NULL,
    CONSTRAINT PK_HELP PRIMARY KEY NONCLUSTERED (QSTN_ID, QSTN_VER_NUM, INSRT_TSTMP)
)
go



/* 
 * TABLE: HOVR_TXT 
 */

CREATE TABLE HOVR_TXT(
    QSTN_ID         smallint         NOT NULL,
    QSTN_VER_NUM    smallint         NOT NULL,
    INSRT_TSTMP     timestamp        NOT NULL,
    HOVR_TXT        varchar(1028)    NULL,
    ALIAS_CD        char(6)          NULL,
    CONSTRAINT PK_HOVR_TXT PRIMARY KEY NONCLUSTERED (QSTN_ID, QSTN_VER_NUM, INSRT_TSTMP)
)
go



/* 
 * TABLE: IDEA 
 */

CREATE TABLE IDEA(
    ASMT_ID                   int             NOT NULL,
    IDEA_NM                   varchar(256)    NOT NULL,
    IDEA_DESC_TXT             varchar(max)    NOT NULL,
    STRGY_PFOLO_TYPE          char(10)        NOT NULL,
    [Confidential Indicator]  char(1)         DEFAULT "N" NOT NULL,
    [Idea End Date]           date            NULL,
    [WIT Identifier]          char(10)        NULL,
    CONSTRAINT PK_IDEA PRIMARY KEY NONCLUSTERED (ASMT_ID)
)
go



/* 
 * TABLE: IT_SYS 
 */

CREATE TABLE IT_SYS(
    IT_SYS_SEQ_NUM    int             NOT NULL,
    ASMT_ID           int             NULL,
    IT_SYS_ID         varchar(256)    NOT NULL,
    IT_SYS_NM         varchar(256)    NULL,
    CONSTRAINT PK_IT_SYS PRIMARY KEY NONCLUSTERED (IT_SYS_SEQ_NUM)
)
go


/* 
 * TABLE: [IT_SYS_-_DATA_SUBJ_AREA_LEVL_2] 
 */

CREATE TABLE [IT_SYS_-_DATA_SUBJ_AREA_LEVL_2](
    DSA_LEVL_2_ID     varchar(25)    NOT NULL,
    IT_SYS_SEQ_NUM    int            NOT NULL,
    ASMT_IDENTFIER    int            NULL,
    CONSTRAINT [PK_IT_SYS_-_DATA_SUBJ_AREA_LEVL_2] PRIMARY KEY NONCLUSTERED (DSA_LEVL_2_ID, IT_SYS_SEQ_NUM)
)
go



/* 
 * TABLE: PPT 
 */

CREATE TABLE PPT(
    PPT_ID                           char(16)    NOT NULL,
    WORK_TITLE_NM                    char(10)    NULL,
    [NEW-CARRYOVER_IND]              char(10)    NULL,
    BUSN_CASE_NUM                    char(10)    NULL,
    REL_NUM                          char(10)    NULL,
    [Confidential Indicator]         char(1)     NULL,
    PLAN_YR_TTL_LBR_COSTS_AMT        char(10)    NULL,
    PLAN_YR_TTL_COST_EST_AMT         char(10)    NULL,
    PRTZN_SCOR_NUM                   char(10)    NULL,
    SUBMT_TIME_TXT                   char(10)    NULL,
    PRGRS_IND_STTS_CD                char(10)    NULL,
    RANK_ORD_NUM                     char(10)    NULL,
    BUSN_PLAN_ALGN_ID                char(10)    NULL,
    ALGN_TO_BUSN_STRATEGIES          char(10)    NULL,
    [AGLIGNMENT_RUN-GROW-TRANSFORM]  char(10)    NULL,
    PFOLO_WORK_CTGRY                 char(10)    NULL,
    AGIL_WORK_IND                    char(1)     NULL,
    STRT_DT                          date        NOT NULL,
    DESC_TXT                         date        NOT NULL,
    CONSTRAINT PK_PPT PRIMARY KEY NONCLUSTERED (PPT_ID)
)
go



/* 
 * TABLE: PPT_DIRTN_STMT 
 */

CREATE TABLE PPT_DIRTN_STMT(
    STMT_SEQ_NUM      smallint        NOT NULL,
    PPT_ID            char(16)        NOT NULL,
    DIRTN_STMT_TXT    varchar(512)    NULL,
    CONSTRAINT PK_PPT_DIRTN_STMT PRIMARY KEY NONCLUSTERED (STMT_SEQ_NUM, PPT_ID)
)
go



/* 
 * TABLE: PSSBL_ANSW 
 */

CREATE TABLE PSSBL_ANSW(
    ANSW_ID                         char(10)         NOT NULL,
    QSTN_ID                         smallint         NOT NULL,
    QSTN_VER_NUM                    smallint         NOT NULL,
    ANSW_RESP_CD                    char(2)          NULL,
    ANSW_RESP_TXT                   varchar(50)      NOT NULL,
    ADDL_RESP_REQD_IND              char(1)          DEFAULT "N" NOT NULL,
    DEFLT_ANSW_IND                  char(1)          NULL,
    DEFLT_ANSW_TXT                  varchar(50)      NULL,
    ACTN_BUTN_UNIV_RSRC_LCTR_TXT    varchar(1028)    NULL,
    REFLEX_QSTN_APLY_IND            char(1)          DEFAULT "N" NOT NULL,
    BASE_SCOR_NUM                   smallint         IDENTITY(1,1),
    CONSTRAINT PK_PSSBL_ANSW PRIMARY KEY NONCLUSTERED (ANSW_ID, QSTN_ID, QSTN_VER_NUM)
)
go


/* 
 * TABLE: QSTN 
 */

CREATE TABLE QSTN(
    QSTN_ID               smallint         IDENTITY(1,1),
    QSTN_VER_NUM          smallint         IDENTITY(1,1),
    QSTN_TXT              varchar(2048)    NOT NULL,
    ADDL_INFO_TXT         varchar(1028)    NULL,
    QSTN_REFR_NUM         char(8)          NULL,
    EFF_DT                Date             NULL,
    EXP_DT                Date             NULL,
    HIGH_LEVL_QSTN_IND    char(1)          NOT NULL,
    SNGL_RESP_IND         char(1)          DEFAULT "Y" NULL,
    RESP_MIN_CNT          smallint         NULL,
    RESP_MAX_CNT          smallint         NULL,
    RESP_EDT_TXT          varchar(50)      DEFAULT WITH DEFAULT NOT NULL,
    LAST_UPDT_SGNON_ID    char(6)          NULL,
    LAST_UPDT_TSTMP       timestamp        NOT NULL,
    CREAT_TSTMP           timestamp        NOT NULL,
    CREAT_SGNON_ID        char(6)          NOT NULL,
    CTGRY_ID              char(16)         NOT NULL,
    CONSTRAINT PK_QSTN PRIMARY KEY NONCLUSTERED (QSTN_ID, QSTN_VER_NUM)
)
go



/* 
 * TABLE: QSTN_GRP 
 */

CREATE TABLE QSTN_GRP(
    QSTN_SET_ID     smallint       NOT NULL,
    QSTN_ID         smallint       NOT NULL,
    QSTN_VER_NUM    smallint       NOT NULL,
    GRP_CD          char(2)        DEFAULT "ZZ" NOT NULL,
    GRP_NM          varchar(60)    NULL,
    CONSTRAINT PK_QSTN_GRP PRIMARY KEY NONCLUSTERED (QSTN_SET_ID, QSTN_ID, QSTN_VER_NUM, GRP_CD)
)
go



/* 
 * TABLE: QSTN_RULE 
 */

CREATE TABLE QSTN_RULE(
    QSTN_RULE_ID                 char(16)        NOT NULL,
    QSTN_RULE_CONTINUATION_ID    char(16)        NOT NULL,
    QSTN_ID                      smallint        NULL,
    QSTN_VER_NUM                 smallint        NULL,
    ANSW_ID                      char(10)        NULL,
    QSTN_RULE_EFF_DT             date            DEFAULT WITH DEFAULT NOT NULL,
    QSTN_RULE_END_DT             date            DEFAULT '9999-12-31' NOT NULL,
    INIT_DSPLY_CD                smallint        DEFAULT 0 NOT NULL,
    REQD_RESP_SW                 char(1)         DEFAULT 0 NOT NULL,
    BND_IND                      smallint        DEFAULT 0 NOT NULL,
    CRIT_QSTN_TYPE_CD            smallint        DEFAULT 0 NOT NULL,
    PAGING_CD                    smallint        DEFAULT 0 NOT NULL,
    COMPR_OPRTN_CD               varchar(10)     DEFAULT WITH DEFAULT NOT NULL,
    COMPR_VALUE_TXT              varchar(100)    DEFAULT WITH DEFAULT NOT NULL,
    CONT_EXPSN_SW                char(1)         NULL,
    REFLEX_NEXT_QSTN_ID          int             NULL,
    REFLEX_NEXT_QSTN_SET_ID      int             DEFAULT WITH DEFAULT NULL,
    REFLEX_ALT_QSTN_SET_ID       int             DEFAULT WITH DEFAULT NULL,
    REFLEX_ALT_QSTN_ID           int             NULL,
    RTRN_OPRTN_CD                varchar(10)     DEFAULT WITH DEFAULT NOT NULL,
    RTRN_VALUE_TXT               varchar(15)     DEFAULT WITH DEFAULT NOT NULL,
    RTRN_TXT                     varchar(100)    DEFAULT WITH DEFAULT NOT NULL,
    QSTN_LEADIN_TXT              varchar(500)    DEFAULT WITH DEFAULT NOT NULL,
    CONSTRAINT PK_QSTN_RULE PRIMARY KEY NONCLUSTERED (QSTN_RULE_ID)
)
go



/* 
 * TABLE: QSTN_SET 
 */

CREATE TABLE QSTN_SET(
    QSTN_SET_ID      smallint       NOT NULL,
    QSTN_SUBST_ID    smallint       NOT NULL,
    QSTN_SET_NM      varchar(60)    NULL,
    CONSTRAINT PK_QSTN_SET PRIMARY KEY NONCLUSTERED (QSTN_SET_ID)
)
go



/* 
 * TABLE: ROLE 
 */

CREATE TABLE ROLE(
    ROLE_ID    char(16)        NOT NULL,
    ROLE_NM    varchar(128)    NOT NULL,
    ROLE_CD    varchar(30)     NULL,
    CONSTRAINT PK_ROLE PRIMARY KEY NONCLUSTERED (ROLE_ID)
)
go



/* 
 * TABLE: SCOR_GRP 
 */

CREATE TABLE SCOR_GRP(
    CTGRY_ID        char(16)         NOT NULL,
    SCOR_GRP_ID     char(1)          NOT NULL,
    WGT_FCTR_NUM    decimal(3, 0)    DEFAULT 1 NOT NULL,
    CONSTRAINT PK_SCOR_GRP PRIMARY KEY NONCLUSTERED (CTGRY_ID, SCOR_GRP_ID)
)
go



/* 
 * TABLE: SELCT_CAPB 
 */

CREATE TABLE SELCT_CAPB(
    SELCT_CAPB_SEQ_NUM    char(10)       NOT NULL,
    ASMT_ID               int            NOT NULL,
    QSTN_SET_ID           smallint       NOT NULL,
    BCM_LEVL_3_ID         varchar(25)    NOT NULL,
    IT_SYS_SEQ_NUM        int            NULL,
    DSA_LEVL_2_ID         varchar(25)    NULL,
    CONSTRAINT PK_SELCT_CAPB PRIMARY KEY NONCLUSTERED (SELCT_CAPB_SEQ_NUM)
)
go



/* 
 * TABLE: WIT 
 */

CREATE TABLE WIT(
    WIT_ID                            char(16)    NOT NULL,
    INVST_CATEOGRY_CD                 char(10)    NULL,
    BUSN_AREA_NM                      char(10)    NULL,
    IT_INVST_PRPS_TXT                 char(10)    NULL,
    BUSN_CASE_NUM                     char(10)    NULL,
    BUSN_CASE_NM                      char(10)    NULL,
    BUSEINSS_CASE_DESCIPRTION_TXT     char(10)    NULL,
    BUSN_CASE_VER_NUM                 char(10)    NULL,
    CFDTL_IND                         char(1)     DEFAULT 'N' NULL,
    EST_QTR_STRT_NUM                  char(10)    NULL,
    EST_QTR_END_NUM                   char(10)    NULL,
    [NEW-CARRYOVER_IND]               char(10)    NULL,
    STTS_CD                           char(10)    NULL,
    VAULE_SCOR_NUM                    char(10)    NULL,
    YR_HRLY_LBR_EST_AMT               char(10)    NULL,
    [YR_NON-HOURLY_LBR_ESITMATE_AMT]  char(10)    NULL,
    CONSTRAINT PK_WIT PRIMARY KEY NONCLUSTERED (WIT_ID)
)
go



/* 
 * TABLE: WIT_DIRTN_STMT 
 */

CREATE TABLE WIT_DIRTN_STMT(
    WIT_ID            char(16)        NOT NULL,
    STMT_SEQ_NUM      smallint        NOT NULL,
    DIRTN_STMT_TXT    varchar(512)    NULL,
    CONSTRAINT PK_WIT_DIRTN_STMT PRIMARY KEY NONCLUSTERED (WIT_ID, STMT_SEQ_NUM)
)
go


