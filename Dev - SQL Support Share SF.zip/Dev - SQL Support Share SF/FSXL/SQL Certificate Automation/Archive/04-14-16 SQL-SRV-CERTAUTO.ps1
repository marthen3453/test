﻿$ErrorActionPreference = "SilentlyContinue"

#### Update these two variables as the issuance is updated
[System.String] $IssuanceVersion = "1.0"
[System.String] $IssuanceName = "SQL-SRV-CERT-GEN-1.0-1.0"


#### Load assemblies
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null 
[Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo") | Out-Null
[Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum") | Out-Null


#### Required functions
Function WriteToLog ([string] $logFile1, [string] $logFile2, [string] $string, [string] $type)
{
    try
    {
        # This trims any CRLF and replaces with 4 spaces and a : to better format the text in the output.
        [System.String] $tmpString = $string.replace("`r`n", "`r`n    : ")
        
        switch ($type)
        {
            # Warning
            "W"
            {
                Out-File -Append -FilePath $logFile1  -InputObject ("WARN: " + $tmpString) 
                Out-File -Append -FilePath $logFile2  -InputObject ("WARN: " + $tmpString) 
            }

            # Information
            "I"
            {
                Out-File -Append -FilePath $logFile1  -InputObject ("INFO: " + $tmpString) 
                Out-File -Append -FilePath $logFile2  -InputObject ("INFO: " + $tmpString) 
            }

            # Error
            "E"
            {
                Out-File -Append -FilePath $logFile1  -InputObject ("ERRO: " + $tmpString)
                Out-File -Append -FilePath $logFile2  -InputObject ("ERRO: " + $tmpString)
            }

            # Unknown
            Default
            {
                Out-File -Append -FilePath $logFile1 -InputObject ("UNKN: " + $tmpString) 
                Out-File -Append -FilePath $logFile2 -InputObject ("UNKN: " + $tmpString) 
            }
        }
    }
    catch
    {
        throw $_.Exception
    }
}

Function WriteToFile ([string] $OutputFile, [string] $string)
{
    try
    {
        Out-File -Append -FilePath $OutputFile  -InputObject ($string) -Encoding ASCII
    }
    catch
    {
        throw $_.Exception
    }
}

Function RunSQLCDRSInitialDataCall($ServerName, $DatabaseName, $UserName, $certpassword, $SqlText)
{
    $Connection = New-Object System.Data.SqlClient.SQLConnection("Data Source=$ServerName;Initial Catalog=$DatabaseName;User ID=$UserName;Password=$certpassword;");
    $Cmd = New-Object System.Data.SqlClient.SqlCommand($SqlText, $Connection);

    $Connection.Open();
    $Reader = $Cmd.ExecuteReader()

    $Results = @()
    while ($Reader.Read())
    {
        $Row = @{}
        for ($i = 0; $i -lt $Reader.FieldCount; $i++)
        {
            $Row[$Reader.GetName($i)] = $Reader.GetValue($i)
        }
        $Results += New-Object psobject -Property $Row
    }
    $Connection.Close();

    $Results
}

Function New-ComplexPassword ([int]$Length=8, $digits=$null, $alphaUpper=$null, $alphaLower=$null, $special=$null)
{
<#  
	.SYNOPSIS  
		 
	.DESCRIPTION  
		  
	.NOTES  
		File Name  : %DATADIR%\SQL\Library\SharedFunctionSQLSecurity.ps1
		Author     : SQL Server Support team (WG1436)
		Requires   : Windows Server 2008R2 or Higher, SQL Server 2012 and PowerShell 3.0/Windows Framework 3.0
		Requires   : Import-Module -name $Env:DATADIR'\SQL\Library\SharedFunctionSMO' -DisableNameChecking -NoClobber
		Requires   : Import-Module -name $Env:DATADIR'\SQL\Library\SharedFunctionSQLServer' -DisableNameChecking -NoClobber
		Requires   : Import-Module -name $Env:DATADIR'\SQL\Library\SharedFunctionWindows' -DisableNameChecking -NoClobber
						 
	.LINK  
	.EXAMPLE  
	.INPUTTYPE  
		N/A
	.RETURNVALUE  
		Return new generated password.
	.PARAMETER 
		$Length (int)
	.PARAMETER 
		$digits (int)
	.PARAMETER 
		$alphaUpper (int)
	.PARAMETER 
		$alphaLower (int)
	.PARAMETER 
		$special (int) 
#>
	#  ASCII data taken from http://msdn2.microsoft.com/en-us/library/60ecse8t(VS.80).aspx

	# Make sure the password is long enough to meet complexity requirements
	if($digits+$alphaUpper+$alphaLower+$special -gt $Length) { throw "Password too short for specified complexity" }

	# Define character groups and the number of each required by passwords

	# In case this is used in a DCPromo answer files, theres a few chars to 
	# avoid: Ampersand, Less than, double quote and back slash
	# (34,38,60,92)
	
	$groups = @()
	$group = New-Object System.Object
	Add-Member -In $group -Type NoteProperty -Name "Group" -Value "0123456789" # 48..57

	Add-Member -In $group -Type NoteProperty -Name "Count" -Value $Digits
	$groups += $group

	$group = New-Object System.Object
	Add-Member -In $group -Type NoteProperty -Name "Group" -Value "ABCDEFGHIJKLMNOPQRSTUVWXYZ" # 65..90
	Add-Member -In $group -Type NoteProperty -Name "Count" -Value $alphaUpper
	$groups += $group

	$group = New-Object System.Object
	Add-Member -In $group -Type NoteProperty -Name "Group" -Value "abcdefghijklmnopqrstuvwxyk" # 97..122
	Add-Member -In $group -Type NoteProperty -Name "Count" -Value $alphaLower
	$groups += $group

	$group = New-Object System.Object
	Add-Member -In $group -Type NoteProperty -Name "Group" -Value '~`!@#$%^&*()-_={}[]\|;:<>?,./ ' #  32..47, 58..64, 91..96, 123..126
	Add-Member -In $group -Type NoteProperty -Name "Count" -Value $special
	$groups += $group 

	# initilize random number generator
	$ran = New-Object Random

	# make sure password meets complexity requirements
	foreach ($req in $groups)
	{
		if ($req.count)
		{
			$charsAllowed += $req.group

			for ($i=0; $i -lt $req.count; $i++)
			{
				$r = $ran.Next(0,$req.group.length)
				$certpassword += $req.group[$r]	
			}
		} elseif ($req.count -eq 0) {
			$charsAllowed += $req.group
		}
	}

	# make sure password meets length requirement
	if(!$charsAllowed)
	{
		$groups |% { $charsAllowed += $_.group }
	}

	for($i=$certpassword.length; $i -lt $length; $i++)
	{
		$r = $ran.Next(0,$charsAllowed.length)
		$certpassword += $charsAllowed[$r]
	}

	# randomize the password
	return [string]::join('',($certpassword.ToCharArray()|sort {$ran.next()}))
}

function script:GetPasswordFromDPL([System.String] $domain, [System.String] $user)
{
    try
    {
    
        [System.String] $password = ""
        
        # Call DPL to retrieve password
        [Reflection.Assembly]::LoadWithPartialName("W0095751_Proxy_PS") | Out-Null
        $ps = New-Object W0095751_Proxy.GetPassWord 
        $ps.GetAccountPassWord($domain, $user, [ref] $password) | Out-Null

        # If password is blank, consider the call failed.
        if($password -eq "") 
        {
            throw "Unable to retrieve password from DPL"
        }
        else
        {
            return $password
        }
    }
    catch
    {
        WriteToLog $logFile "Error in `'function script:GetPasswordfromDPL()`'." "E"
        WriteToLog $logFileScripter "Error in `'function script:GetPasswordfromDPL()`'." "E"
        throw $_.Exception
    }
} 


#### Config paths and common variables
[System.Boolean] $found = $false
[System.String] $sqlTemplate = ""
[System.String] $fqdn = $env:computername + "." + $env:MCHRESDM
[System.String] $certpassword = New-ComplexPassword
[System.String] $workgroup = "WG3565"
[System.String] $configurationitem = "SQL SERVER"
[System.String] $username = [Environment]::UserDomainName + "\" + [Environment]::UserName
[System.String] $email = "SQLServer@statefarm.org"
[System.String] $keysize = 2048
[System.String] $domain = $env:NBDOMNAME 
[System.String] $LogFilePath = $ENV:DATADIR + "\SQL\Logs\"
[System.String] $LogFile = $LogFilePath + $IssuanceName + "_" + $CurDateTime.ToString("yyyy-MM-dd_hh-mm-ss") + ".log"
[System.String] $LogFileScripter = $LogFilePath + $IssuanceName + ".log"
[System.String] $KeyFilePath = $logfilepath + "sqlencryptionkey.p12"
[System.String] $IssuanceFail = "Issuance Failed"
[System.String] $IssuanceSuccess = "Issuance Success"
[System.String] $runAsAccountPassword = ""
[System.String] $runAsAccountDomain = "SUPPORT"
[System.String] $runAsAccount = "SVC_SetSQLCert"
[System.DateTime] $CurDateTime = ([System.DateTime]::Now)
[System.Collections.ArrayList] $SANlist = New-Object System.Collections.ArrayList


#### Begin main TRY/CATCH block
try
{
    ### Write Log header
    if (Test-Path $LogFileScripter)
    {
            Remove-Item $LogFileScripter -Force
    }

    WritetoLog $LogFile $LogFileScripter ($IssuanceName + " (" + $IssuanceVersion + ")") "I"
    WritetoLog $LogFile $LogFileScripter ("Script start time: " + $CurDateTime.ToString("yyyy-MM-dd hh:mm:ss")) "I"
    WritetoLog $LogFile $LogFileScripter ("User Context = " + ($env:USERNAME)) "I"
    WritetoLog $LogFile $LogFileScripter ("Detail log available at " + $LogFile) "I"
    WriteToLog $LogFile $LogFileScripter ("Starting Script...") "I"

    WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("Runtime Variables: FQDN=" + $fqdn + "; UserName=" + $username + "; KeyFilePath=" + $KeyFilePath) "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"

    ###############################################################################################################################
    # BEGIN - Configure C# code to import certificate.
    ###############################################################################################################################
    
    #### C# Code to add certificate and key
    WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("Begin - Create C# object to import certificate to server.") "I"

    $CSsource = "
    using System.Security.Cryptography;
    using System.Security.Cryptography.X509Certificates;

    public class AddCertificateToServer
    {
        public void Add(string pathToPfx, string pfxPassword)
        {
            X509Store store = null;   
            X509Certificate2Collection collection = new X509Certificate2Collection();
            collection.Import(pathToPfx, pfxPassword, X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.Exportable);
            store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
            store.Open(OpenFlags.ReadWrite);
            foreach (X509Certificate2 cert in collection)
            {
                store.Add(cert);
            }
        }
    }"

    #### Create the C# class definition
    Add-Type -TypeDefinition $CSsource

    #### Create the class object
    $CSImportCert = New-Object AddCertificateToServer

    WriteToLog $LogFile $LogFileScripter ("Finish - Create C# object to import certificate to server.") "I"

    ###############################################################################################################################
    # END - Configure C# code to import certificate.
    ###############################################################################################################################


	###############################################################################################################################
    # BEGIN - Choose the web service based on current domain & get SQL template.
    ###############################################################################################################################
	WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"    
    WriteToLog $LogFile $LogFileScripter ("Begin - Set web service and domain from current domain environment variable. (" + $domain + ")") "I"
    
    if ($domain -eq "OPR") {
        $URI = "https://sfcertrequestPROD.support.statefarm.org/CertRequestService/CertRequestService.svc"
        $domain = "PROD"
    }  

    elseif ($domain -eq "SUPPORT") {
        $URI = "https://sfcertrequestPROD.support.statefarm.org/CertRequestService/CertRequestService.svc"
        $domain = "PROD"
    }

    elseif ($domain -eq "OPRSYS") {
        $URI = "https://sfcertrequesttest.support.statefarm.org/CertRequestService/CertRequestService.svc"
        $domain = "TEST"
    }

    elseif ($domain -eq "UNTOPR") {
        $URI = "https://sfcertrequesttest.support.statefarm.org/CertRequestService/CertRequestService.svc"
        $domain = "TEST"
    }

    WriteToLog $LogFile $LogFileScripter ("Finish - Set web service and domain from current domain environment variable. URI=" + $URI + "; Domain=" + $domain) "I"
    
    ### Create credential and retrieve DPL password for web service proxy
	WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("Begin - Retrieve password for $runAsAccountDomain\$runAsAccount from DPL.") "I"
    $runAsAccountPassword = GetPasswordFromDPL $runAsAccountDomain $runAsAccount
    WritetoLog $logFile $LogFileScripter ("Finish - DPL Password retrieval successful.") "I"
    
    ### Create a Proxy to the web  service
	WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("Begin - Create proxy to web service.") "I"
    $securepw = ConvertTo-SecureString –String $runAsAccountPassword –AsPlainText -Force
    $credential = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList "$runAsAccountDomain\$runAsAccount", $securepw
    $proxy = New-WebServiceProxy -Uri $URI -Class CertRequestServiceClient -Namespace CertRequestService -Credential $credential
    WriteToLog $LogFile $LogFileScripter ("Finish - Create proxy to web service. URL=" + $proxy.Url) "I"

    ### The AvailableTemplate function returns a list based on whether they are TEST (Forest A/B) or PROD (OPR/SUPPORT)
	WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"    
    WriteToLog $LogFile $LogFileScripter ("Begin - Get SQL template from web service.") "I"
    $templates = $proxy.AvailableTemplates($domain);

    ### Find a SQL Template
    foreach ($template in $templates)
    {
        if ($template -like "SQL_Server_Internal_SSL*")
        {
            $sqlTemplate = $template
            $found = $true
            break
        }
    }

    ### Output the template name if found
    if ($found  -eq $true)
    {
        WriteToLog $LogFile $LogFileScripter ("Finish - Get SQL template from web service. (SUCCESS)") "I"
    }
    else
    {
        WriteToLog $LogFile $LogFileScripter ("Finish - Get SQL template from web service. (NOT FOUND)") "I"
        throw "No SQL template found for " + $domain + " using web service '" + $URI + "'."
    }
    ###############################################################################################################################
    # END - Choose the web service based on current domain & get SQL template.
    ###############################################################################################################################


    ###############################################################################################################################
    # BEGIN - Request and load the certificate/key.
    ###############################################################################################################################

    ### If found, then generate a Cert
    if ($found -eq $true)
    {
        ## Add the subject alternate names into an array from SQL_CDRS
	    WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
        WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter ("Begin - Get Subject alternate names from SQL_CDRS.") "I"
        $CDRS_User = "sql_ro"
        $CDRS_Pass = "Sqlalsk123!!!!"
        $CDRS_Server = "SQLPSQLI1.SUPPORT.STATEFARM.ORG"
        $CDRS_Database = "SFSQL_CDRS"
        $CDRS_Cmd = "usp_GetSubjectAlternateNames '" + $fqdn + "'"

        $sqlresult = RunSQLCDRSInitialDataCall $CDRS_Server $CDRS_Database $CDRS_User $CDRS_Pass $CDRS_Cmd
        $sqlresult | foreach {
            $sanlist.Add($_.SAN) | Out-Null
            WriteToLog $LogFile $LogFileScripter ("    Added " + $_.SAN) "I"
        }
        WriteToLog $LogFile $LogFileScripter ("Finish - Get Subject alternate names from SQL_CDRS.") "I"

        ## Request certificate from web service
	    WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
        WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter ("Begin - Request the certificate.") "I"
        $result = $proxy.RequestCert($domain, $username, $sqlTemplate, $configurationitem, $workgroup, $email, $fqdn, $fqdn, $sanlist, $keysize, $true, $certpassword)
        WriteToLog $LogFile $LogFileScripter ("Finish - Request the certificate.") "I"

        ## Write the key to file - requires conversion.
	    WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
        WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter ("Begin - Write the encryption key to file. " + $KeyFilePath) "I"
        $output = [Convert]::FromBase64String($result.PKCS12)  
        $writer = [System.IO.File]::OpenWrite($KeyFilePath)
        $writer.Write($output, 0, $output.Length)    
        $writer.Dispose() 
        WriteToLog $LogFile $LogFileScripter ("Finish - Write the encryption key to file.") "I"

        ## Call the C# function to import certificate
	    WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
        WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter ("Begin - Use C# code to import certificate.") "I"
        $CSImportCert.Add($KeyFilePath, $certpassword)
        WriteToLog $LogFile $LogFileScripter ("Finish - Use C# code to import certificate.") "I"

        ## Delete the certificate and key files 
	    WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
        WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter ("Begin - Remove physical file.") "I"
        Remove-Item $KeyFilePath | Out-Null
        WriteToLog $LogFile $LogFileScripter ("Finish - Remove physical file.") "I"
    }
    
    ###############################################################################################################################
    # END - Request and load the certificate/key.
    ###############################################################################################################################

    ### If we made it this far,  we are successful
	WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"
	WritetoLog $LogFile $LogFileScripter ("Script end time: " + ([System.DateTime]::Now).ToString("yyyy-MM-dd hh:mm:ss")) "I"
	WriteToLog $LogFile $LogFileScripter ($IssuanceSuccess) "I"
}

catch
{
    WriteToLog $LogFile $LogFileScripter ($_.Exception) "E"
    WriteToLog $LogFile $LogFileScripter ($IssuanceFail) "E"
    throw $_.Exception
}