﻿# Config paths and common variables
[System.Boolean] $found = $false
[System.String] $sqlTemplate = ""
[System.String] $fqdn = "WPSDXXXX.OPR.SYSTEM.TEST.STATEFARM.ORG"
[System.String] $password = "somepassword" #dynamic generate password - use securestring
[System.String] $workgroup = "WG3565"
[System.String] $configurationitem = "SQL SERVER"
[System.String] $username = [Environment]::UserDomainName + "\" + [Environment]::UserName
[System.String] $email = "SQLServer@statefarm.org"
[System.String] $keysize = 2048
[System.String] $domain = $env:USERDOMAIN
$ErrorActionPreference = "SilentlyContinue"


try
{
    <#
    if ($domain -eq "OPR") {
        $URI = "https://sfcertrequestPROD.support.statefarm.org/CertRequestService/CertRequestService.svc"
        $domain = "PROD"
    }  
    elseif ($domain -eq "UNTOPR") {
        $URI = "https://sfcertrequesttest.support.statefarm.org/CertRequestService/CertRequestService.svc"
        $domain = "TEST"
    }
    #>

    $URI = "https://sfcertrequesttest.support.statefarm.org/CertRequestService/CertRequestService.svc"
    $domain = "TEST"


    ### Create a Proxy to the web  service
    $proxy = New-WebServiceProxy -Uri $URI -Class CertRequestServiceClient -Namespace CertRequestService -UseDefaultCredential

    ### Make sure we find a SQL Template - Filter by TEST templates first.  The AvailableTemplate function returns a list based on whether they are TEST (Forest A/B) or PROD (OPR/SUPPORT)
    $templates = $proxy.AvailableTemplates($domain);

    ### Find a SQL Template
    foreach ($template in $templates)
    {
        if ($template -like "SQL_Server_Internal_SSL*")
        {
            $sqlTemplate = $template
            $found = $true
            break
        }
    }

    ### Output the template name if found
    if ($found  -eq $true)
    {
        Write-Output ("Found a template: " + $sqlTemplate)
        # switch to write to log
    }
    else
    {
        Write-Output ("Could not find a SQL template")
        # switch to write to log
    }

    ### If found, then generate a Cert
    if ($found -eq $true)
    {
        ## Read/add the subject alternate names into an array
        $sanlist = New-Object System.Collections.ArrayList
        $sanlist.Add("Test1.OPR.SYSTEM.TEST.STATEFARM.ORG") | Out-Null
        $sanlist.Add("Test2.OPR.SYSTEM.TEST.STATEFARM.ORG") | Out-Null

        ## Request Cert with some dummy parameters for now.  We need to solidify what these need to be
        $result = $proxy.RequestCert($domain, $username, $sqlTemplate, $configurationitem, $workgroup, $email, $fqdn, $fqdn, $sanlist, $keysize, $true, $password)

        ## Write the key to file - requires conversion.
        $output = [Convert]::FromBase64String($result.PKCS12)
        $TargetFilePath = "C:\Users\FSXL\documents\testkey.p12"
  
        $writer = [System.IO.File]::OpenWrite($TargetFilePath)
        $writer.Write($output, 0, $output.Length);
    
        $writer.Dispose() 

        ## Write the certificate to file - plain text is ok.
        $result.OutputCertificate | Out-File .\TestCert.cer

        <#
            Code to add certificate and key

            using System.Security.Cryptography;
            using System.Security.Cryptography.X509Certificates;
            X509Store store = null;
            try
            {
            X509Certificate2Collection collection = new X509Certificate2Collection();
                  collection.Import(pathToPfx, pfxPassword, X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.MachineKeySet);
                  store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
            store.Open(OpenFlags.ReadWrite);
            foreach (X509Certificate2 cert in collection)
            {
                store.Add(cert);
            }
    } 


        #>

        ### Delete the certificate and key files ###

    }
}

catch
{
    throw $_.Exception
}
