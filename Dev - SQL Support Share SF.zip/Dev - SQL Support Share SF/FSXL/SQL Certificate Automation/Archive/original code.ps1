cls
$found = $false
$sqlTemplate = ""

### Create a Proxy to the WS
$URI = "https://sfcertrequesttest.support.statefarm.org/CertRequestService/CertRequestService.svc"
$proxy = New-WebServiceProxy -Uri $URI -Class CertRequestServiceClient -Namespace CertRequestService -UseDefaultCredential

### Make sure we find a SQL Template - Filter by TEST templates first.  The AvailableTemplate function returns a list based on whether they are TEST (Forest A/B) or PROD (OPR/SUPPORT)
$templates = $proxy.AvailableTemplates("TEST");

## Find a SQL Template
foreach ($template in $templates)
{
    if ($template -like "SQL_Server_Internal_SSL*")
    {
        $sqlTemplate = $template
        $found = $true
        break
    }
}

## Output the template name if found
if ($found  -eq $true)
{
    Write-Output ("Found a template: " + $sqlTemplate)
}
else
{
    Write-Output ("Could not find a SQL template")
}

## If found, then generate a Cert
if ($found -eq $true)
{

    ## Request Cert with some dummy parameters for now.  We need to solidify what these need to be
    $result = $proxy.RequestCert("TEST", "OPR\RMEG", $sqlTemplate, "SQL SERVER", "WG3565", "SQLServer@statefarm.org", `
                                    "WPSDXXXX.OPR.SYSTEM.TEST.STATEFARM.ORG", "WPSDXXXX.OPR.SYSTEM.TEST.STATEFARM.ORG", `
                                    $null, 2048, $true, "somepassword")

    $result.PKCS12
    $result.OutputCertificate

}
