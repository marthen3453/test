﻿$ErrorActionPreference = "SilentlyContinue"

# Update these two variables as the issuance is updated
[System.String] $IssuanceVersion = "1.1"
[System.String] $IssuanceName = "SQL-SRV-CERT_Automation 1.0-1.1"

# Config paths and common variables
[System.String] $SQLServerVersion = "ALL"
[System.DateTime] $CurDateTime = ([System.DateTime]::Now)
[System.String] $LogFilePath = $ENV:DATADIR + "\SQL\Logs\"
[System.String] $ConfigFilePath = $ENV:DATADIR + "\SQL\Config\"
[System.String] $LibraryFilePath = $ENV:DATADIR + "\SQL\Library\"
[System.String] $LibraryFile = $LibraryFilePath + "SQL-PowerShell-Library.psm1"
[System.String] $ScriptsFilePath = $ENV:DATADIR + "\SQL\Scripts\"
[System.String] $SFSQLAdminFilePath = $ENV:DATADIR + "\SQL\SF_SQL_Admin\"
[System.String] $LogFile = $LogFilePath + $IssuanceName + "_" + $CurDateTime.ToString("yyyy-MM-dd_hh-mm-ss") + ".log"
[System.String] $LogFileScripter = $LogFilePath + $IssuanceName + ".log"
[System.String] $IssuanceFail = "Issuance Failed"
[System.String] $IssuanceSuccess = "Issuance Success"
[System.String] $ApplicationDirectory = $env:APPSDIR
[System.String] $ComputerName = $env:COMPUTERNAME
[System.String] $Domain = $env:MCHRESDM
[System.String] $RunPath = $PSScriptRoot

# Import the $LibraryFile (SQL-PowerShell-Library.psm1)
Import-Module -Name $LibraryFile -DisableNameChecking -NoClobber

try
    {
        # Write Log header
        if (Test-Path $LogFileScripter)
        {
            Remove-Item $LogFileScripter -Force
        }
        WritetoLog $LogFile $LogFileScripter ($IssuanceName + " (" + $IssuanceVersion + ")") "I"
        WritetoLog $LogFile $LogFileScripter ("Script start time: " + $CurDateTime.ToString("yyyy-MM-dd hh:mm:ss")) "I"
        WritetoLog $LogFile $LogFileScripter ("User Context = " + ($env:USERNAME)) "I"
        WritetoLog $LogFile $LogFileScripter ("Detail log available at " + $LogFile) "I"
        WriteToLog $LogFile $LogFileScripter ("Starting Script...") "I"
		
		WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
        WriteToLog $LogFile $LogFileScripter (" ") "I"
		
		###############################################################################################################################
        # Begin Issuance Code
        ###############################################################################################################################
       
        cls
        $found = $false
        $sqlTemplate = ""

        ### Create a Proxy to the WS
        $URI = "https://sfcertrequesttest.support.statefarm.org/CertRequestService/CertRequestService.svc"
        $proxy = New-WebServiceProxy -Uri $URI -Class CertRequestServiceClient -Namespace CertRequestService -UseDefaultCredential

        ### Make sure we find a SQL Template - Filter by TEST templates first.  The AvailableTemplate function returns a list based on whether they are TEST (Forest A/B) or PROD (OPR/SUPPORT)
        $templates = $proxy.AvailableTemplates("TEST");

        ## Find a SQL Template
        foreach ($template in $templates)
        {
            if ($template -like "SQL_Server_Internal_SSL*")
            {
                $sqlTemplate = $template
                $found = $true
                break
            }
        }

        ## Output the template name if found
        if ($found  -eq $true)
        {
            Write-Output ("Found a template: " + $sqlTemplate)
        }
        else
        {
            Write-Output ("Could not find a SQL template")
        }

        ## If found, then generate a Cert
        if ($found -eq $true)
        {

            ## Request Cert with some dummy parameters for now.  We need to solidify what these need to be
            $result = $proxy.RequestCert("TEST", "OPR\RMEG", $sqlTemplate, "SQL SERVER", "WG3565", "SQLServer@statefarm.org", `
                                            "WPSDXXXX.OPR.SYSTEM.TEST.STATEFARM.ORG", "WPSDXXXX.OPR.SYSTEM.TEST.STATEFARM.ORG", `
                                            $null, 2048, $true, "somepassword")

            $result.PKCS12
            $result.OutputCertificate

        }


		
		###############################################################################################################################
        # End Issuance Code
        ###############################################################################################################################
		
		WriteToLog $LogFile $LogFileScripter (" ") "I"
	    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
	    WriteToLog $LogFile $LogFileScripter (" ") "I"

	    # If we made it this far,  we are successful
	    WritetoLog $LogFile $LogFileScripter ("Script end time: " + ([System.DateTime]::Now).ToString("yyyy-MM-dd hh:mm:ss")) "I"
	    WriteToLog $LogFile $LogFileScripter ($IssuanceSuccess) "I"
    }
catch
    {
        WriteToLog $LogFile $LogFileScripter ($_.Exception) "E"
        WriteToLog $LogFile $LogFileScripter ($IssuanceFail) "E"
        throw $_.Exception
    }