CREATE TABLE Perf_QueryText (QueryHash binary(8), QueryText nvarchar(max), DatabaseName nvarchar(512), ObjectID bigint);
GO

CREATE TABLE Perf_QueryPlan (QueryPlanHash binary(8), QueryPlan xml, DatabaseName nvarchar(512), ObjectID bigint);
GO

CREATE TABLE Perf_QueryStats (CreationTime datetime, CacheObjectType nvarchar(512), ObjectType nvarchar(512), RefCounts bigint,
	UseCounts bigint, SizeInBytes bigint, QueryPlanHash binary(8), QueryHash binary(8), StatementStartOffset int,
	StatementEndOffset int, LastExecutionTime datetime, ExecutionCount bigint, TotalWorkerTime bigint, LastWorkerTime bigint, 
	MinWorkerTime bigint, MaxWorkerTime bigint, TotalPhysicalReads bigint, LastPhysicalReads bigint, MinPhysicalReads bigint, 
	MaxPhysicalReads bigint, TotalLogicalWrites bigint, LastLogicalWrites bigint, MinLogicalWrites bigint, MaxLogicalWrites bigint, 
	TotalLogicalReads bigint, LastLogicalReads bigint, MinLogicalReads bigint, MaxLogicalReads bigint, TotalClrTime bigint, 
	LastClrTime bigint, MinClrTime bigint, MaxClrTime bigint, TotalElapsedTime bigint, LastElapsedTime bigint, 
	MinElapsedTime bigint, MaxElapsedTime bigint, TotalRows bigint, LastRows bigint, MinRows bigint, MaxRows bigint, 
	TotalDop bigint, LastDop bigint, MinDop bigint, MaxDop bigint, TotalGrantKb bigint, LastGrantKb bigint, MinGrantKb bigint, 
	MaxGrantKb bigint, TotalUsedGrantKb bigint, LastUsedGrantKb bigint, MinUsedGrantKb bigint, MaxUsedGrantKb bigint, 
	TotalIdealGrantKb bigint, LastIdealGrantKb bigint, MinIdealGrantKb bigint, MaxIdealGrantKb bigint, TotalReservedThreads bigint, 
	LastReservedThreads bigint, MinReservedThreads bigint, MaxReservedThreads bigint, TotalUsedThreads bigint, LastUsedThreads bigint, 
	MinUsedThreads bigint, MaxUsedThreads bigint);
GO

/* MERGE QUERY STATS */
MERGE Perf_QueryStats t
USING (
		SELECT
		creation_time, cacheobjtype, objtype, refcounts, usecounts, size_in_bytes, 
		query_plan_hash, query_hash, statement_start_offset, statement_end_offset,
		last_execution_time, execution_count, total_worker_time, last_worker_time, min_worker_time, 
		max_worker_time,total_physical_reads, last_physical_reads, 
		min_physical_reads, max_physical_reads, total_logical_writes, 
		last_logical_writes, min_logical_writes, max_logical_writes, 
		total_logical_reads, last_logical_reads, min_logical_reads, 
		max_logical_reads, total_clr_time, last_clr_time, min_clr_time, 
		max_clr_time, total_elapsed_time, last_elapsed_time, min_elapsed_time, 
		max_elapsed_time, total_rows, last_rows, min_rows, max_rows, total_dop, 
		last_dop, min_dop, max_dop, total_grant_kb, last_grant_kb, min_grant_kb, 
		max_grant_kb, total_used_grant_kb, last_used_grant_kb, min_used_grant_kb, 
		max_used_grant_kb, total_ideal_grant_kb, last_ideal_grant_kb, min_ideal_grant_kb, 
		max_ideal_grant_kb, total_reserved_threads, last_reserved_threads, min_reserved_threads, 
		max_reserved_threads, total_used_threads, last_used_threads, min_used_threads, max_used_threads
		FROM sys.dm_exec_query_stats s
		INNER JOIN sys.dm_exec_cached_plans p ON s.plan_handle = p.plan_handle) s
ON statement_start_offset = StatementStartOffset
	AND statement_end_offset = StatementEndOffset
	AND query_hash = QueryHash
	AND creation_time = CreationTime
	AND query_plan_hash = QueryPlanHash
WHEN NOT MATCHED THEN
	INSERT (CreationTime, CacheObjectType, ObjectType, RefCounts, UseCounts, SizeInBytes, QueryPlanHash, QueryHash, StatementStartOffset,
		StatementEndOffset, LastExecutionTime, ExecutionCount, TotalWorkerTime, LastWorkerTime, MinWorkerTime, MaxWorkerTime, 
		TotalPhysicalReads, LastPhysicalReads, MinPhysicalReads, MaxPhysicalReads, TotalLogicalWrites, LastLogicalWrites, MinLogicalWrites, 
		MaxLogicalWrites, TotalLogicalReads, LastLogicalReads, MinLogicalReads, MaxLogicalReads, TotalClrTime, LastClrTime, MinClrTime, 
		MaxClrTime, TotalElapsedTime, LastElapsedTime, MinElapsedTime, MaxElapsedTime, TotalRows, LastRows, MinRows, MaxRows, TotalDop, 
		LastDop, MinDop, MaxDop, TotalGrantKb, LastGrantKb, MinGrantKb, MaxGrantKb, TotalUsedGrantKb, LastUsedGrantKb, MinUsedGrantKb, 
		MaxUsedGrantKb, TotalIdealGrantKb, LastIdealGrantKb, MinIdealGrantKb, MaxIdealGrantKb, TotalReservedThreads, LastReservedThreads, 
		MinReservedThreads, MaxReservedThreads, TotalUsedThreads, LastUsedThreads, MinUsedThreads, MaxUsedThreads)
	VALUES (creation_time, cacheobjtype, objtype, refcounts, usecounts, size_in_bytes, 
		query_plan_hash, query_hash, statement_start_offset, statement_end_offset,
		last_execution_time, execution_count, total_worker_time, last_worker_time, min_worker_time, 
		max_worker_time,total_physical_reads, last_physical_reads, 
		min_physical_reads, max_physical_reads, total_logical_writes, 
		last_logical_writes, min_logical_writes, max_logical_writes, 
		total_logical_reads, last_logical_reads, min_logical_reads, 
		max_logical_reads, total_clr_time, last_clr_time, min_clr_time, 
		max_clr_time, total_elapsed_time, last_elapsed_time, min_elapsed_time, 
		max_elapsed_time, total_rows, last_rows, min_rows, max_rows, total_dop, 
		last_dop, min_dop, max_dop, total_grant_kb, last_grant_kb, min_grant_kb, 
		max_grant_kb, total_used_grant_kb, last_used_grant_kb, min_used_grant_kb, 
		max_used_grant_kb, total_ideal_grant_kb, last_ideal_grant_kb, min_ideal_grant_kb, 
		max_ideal_grant_kb, total_reserved_threads, last_reserved_threads, min_reserved_threads, 
		max_reserved_threads, total_used_threads, last_used_threads, min_used_threads, max_used_threads)
WHEN MATCHED THEN 
	UPDATE SET CacheObjectType = cacheobjtype, ObjectType = objtype, t.RefCounts = s.refcounts, t.UseCounts = s.usecounts, 
		SizeInBytes = size_in_bytes, LastExecutionTime = last_execution_time, ExecutionCount = execution_count, 
		TotalWorkerTime = total_worker_time, LastWorkerTime = last_worker_time, MinWorkerTime = min_worker_time, 
		MaxWorkerTime = max_worker_time, TotalPhysicalReads = total_physical_reads, LastPhysicalReads = last_physical_reads, 
		MinPhysicalReads = min_physical_reads, MaxPhysicalReads = max_physical_reads, TotalLogicalWrites = total_logical_writes, 
		LastLogicalWrites = last_logical_writes, MinLogicalWrites = min_logical_writes, MaxLogicalWrites = max_logical_writes, 
		TotalLogicalReads = total_logical_reads, LastLogicalReads = last_logical_reads, MinLogicalReads = min_logical_reads, 
		MaxLogicalReads = max_logical_reads, TotalClrTime = total_clr_time, LastClrTime = last_clr_time, MinClrTime = min_clr_time, 
		MaxClrTime = max_clr_time, TotalElapsedTime = total_elapsed_time, LastElapsedTime = last_elapsed_time, MinElapsedTime = min_elapsed_time, 
		MaxElapsedTime = max_elapsed_time, TotalRows = total_rows, LastRows = last_rows, MinRows = min_rows, MaxRows = max_rows, 
		TotalDop = total_dop, LastDop = last_dop, MinDop = min_dop, MaxDop = max_dop, TotalGrantKb = total_grant_kb, LastGrantKb = last_grant_kb, 
		MinGrantKb = min_grant_kb, MaxGrantKb = max_grant_kb, TotalUsedGrantKb = total_used_grant_kb, LastUsedGrantKb = last_used_grant_kb, 
		MinUsedGrantKb = min_used_grant_kb, MaxUsedGrantKb = max_used_grant_kb, TotalIdealGrantKb = total_ideal_grant_kb, 
		LastIdealGrantKb = last_ideal_grant_kb, MinIdealGrantKb = min_ideal_grant_kb, MaxIdealGrantKb = max_ideal_grant_kb, 
		TotalReservedThreads = total_reserved_threads, LastReservedThreads = last_reserved_threads, MinReservedThreads = min_reserved_threads, 
		MaxReservedThreads = max_reserved_threads, TotalUsedThreads = total_used_threads, LastUsedThreads = last_used_threads, 
		MinUsedThreads = min_used_threads, MaxUsedThreads = max_used_threads;



/* MERGE QUERY TEXT */
MERGE Perf_QueryText t
USING (SELECT query_hash, text, name, objectid
		FROM sys.dm_exec_query_stats
		CROSS APPLY sys.dm_exec_sql_text(dm_exec_query_stats.plan_handle)
		INNER JOIN sys.databases ON dm_exec_sql_text.dbid = databases.database_id) s
ON t.QueryHash = s.query_hash
WHEN NOT MATCHED THEN 
	INSERT (QueryHash, QueryText, DatabaseName, ObjectID)
	VALUES (query_hash, text, name, objectid);


/* MERGE QUERY PLAN */
MERGE Perf_QueryPlan t
USING (SELECT query_plan_hash, query_plan, name, objectid
		FROM sys.dm_exec_query_stats
		CROSS APPLY sys.dm_exec_query_plan(dm_exec_query_stats.plan_handle)
		INNER JOIN sys.databases ON dm_exec_query_plan.dbid = databases.database_id) s
ON t.QueryPlanHash = s.query_plan_hash
WHEN NOT MATCHED THEN 
	INSERT (QueryPlanHash, QueryPlan, DatabaseName, ObjectID)
	VALUES (query_plan_hash, query_plan, name, objectid);
