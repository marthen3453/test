﻿#Invoke-Command 'D:\APPS\Storage\TSM\TDPSql\tdpsqlc restore master full /into=masterDR /relocatedir="H:\sysdb_recovery"'

$databases = $args[0]
$instance = $args[1]
[float]$version = $args[2]

IF ($instance -eq "MSSQLSERVER") {
    $thisserver = $env:COMPUTERNAME
    $prodserver = $env:COMPUTERNAME -replace "DR", ""
}

ELSE {
    $thisserver = $env:COMPUTERNAME + "\" + $instance
    $prodserver = ($env:COMPUTERNAME -replace "DR", "") + "\" + $instance
}

IF ($version -lt 6.2) {
	'$fcmPath = (get-itemproperty -path ''HKLM:\SOFTWARE\IBM\flashcopymanager\currentversion\mmc'').path
	dir $fcmPath fmmodule*.dll | select -expand fullname | import-module' |
	Out-File "D:\APPS\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1"
}

ELSE {
	'$fcmPath = (get-itemproperty -path ''HKLM:\SOFTWARE\IBM\flashcopymanager\currentversion\mmc'').path
	dir $fcmPath fmmodule*.dll | select -expand fullname | import-module' |
	Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1"
}

IF ($databases -eq "USER") {
    $db = Invoke-Sqlcmd -ServerInstance $thisserver -Query "SELECT name FROM sys.databases WHERE state_desc = 'RECOVERY_PENDING'" -Database "SF_SQL_Admin" 
    IF ($version -lt 6.2) {
        $db.name | foreach {
            "Restore-DpSqlBackup  " + $_ + " -Full -SqlServer ""$thisserver"" -FromSqlServer ""$prodserver""" |
            Out-File "D:\APPS\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append
        }
    }

    ELSE {
        $db.name | foreach {
            "Restore-DpSqlBackup  " + $_ + " -Full -SqlServer ""$thisserver"" -FromSqlServer ""$prodserver""" |
            Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append
        }
    }
}

ELSE { 
    IF ($version -lt 6.2) {
        "Restore-DpSqlBackup  master -Full -SqlServer ""$thisserver"" -FromSqlServer ""$prodserver"" -IntoDBName masterDR -RelocateDir ""H:\sysdb_recovery""" |
        Out-File "D:\APPS\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

        "Restore-DpSqlBackup  model -Full -SqlServer ""$thisserver"" -FromSqlServer ""$prodserver"" -IntoDBName modelDR -RelocateDir ""H:\sysdb_recovery""" |
        Out-File "D:\APPS\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

        "Restore-DpSqlBackup  msdb -Full -SqlServer ""$thisserver"" -FromSqlServer ""$prodserver"" -IntoDBName msdbDR -RelocateDir ""H:\sysdb_recovery""" |
        Out-File "D:\APPS\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append
    }

    ELSE {
        "Restore-DpSqlBackup  master -Full -SqlServer ""$thisserver"" -FromSqlServer ""$prodserver"" -IntoDBName masterDR -RelocateDir ""F:\MSSQL\BACKUP\F_MP04\BACKUP\sysdb_recovery""" |
        Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

        "Restore-DpSqlBackup  model -Full -SqlServer ""$thisserver"" -FromSqlServer ""$prodserver"" -IntoDBName modelDR -RelocateDir ""F:\MSSQL\BACKUP\F_MP04\BACKUP\sysdb_recovery""" |
        Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

        "Restore-DpSqlBackup  msdb -Full -SqlServer ""$thisserver"" -FromSqlServer ""$prodserver"" -IntoDBName msdbDR -RelocateDir ""F:\MSSQL\BACKUP\F_MP04\BACKUP\sysdb_recovery""" |
        Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append
    }
}