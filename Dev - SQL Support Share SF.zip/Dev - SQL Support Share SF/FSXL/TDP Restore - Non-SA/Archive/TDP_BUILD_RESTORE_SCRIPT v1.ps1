﻿$databases = $args[0]
$dbtype = $args[1]
$instance = $args[2]


'$fcmPath = (get-itemproperty -path ''HKLM:\SOFTWARE\IBM\flashcopymanager\currentversion\mmc'').path
dir $fcmPath fmmodule*.dll | select -expand fullname | import-module' |
Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1"

IF ($type -eq "USER") {
    "Restore-DpSqlBackup  " + $databases + " -Full -Replace " |
    Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append
}

ELSE {
    "net stop ""SQL Server ($instance)""" |
    Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

    "net start ""SQL Server ($instance)"" /m" |
    Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

    "Restore-DpSqlBackup  master -Full -Replace " |
    Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

    "net start ""SQL Server ($instance)""" |
    Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

    "Restore-DpSqlBackup  msdb -Full -Replace " |
    Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

    "Restore-DpSqlBackup  model -Full -Replace " |
    Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append
}