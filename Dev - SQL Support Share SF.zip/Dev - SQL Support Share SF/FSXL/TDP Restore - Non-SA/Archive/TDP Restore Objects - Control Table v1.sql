USE [SF_SQL_Admin];
GO

DROP TABLE SF_TDP_Restore;
GO
DROP PROC sfsp_TDP_RestoreConfiguration;
GO
DROP PROC sfsp_TDP_VerifiedRestore;
GO
DROP PROC sfsp_TDP_BeginRestore;
GO

CREATE TABLE SF_TDP_Restore (RunTime smalldatetime, UserName varchar(512), DBName varchar(512), DBType varchar(24), Executed bit);
GO

CREATE PROC sfsp_TDP_RestoreConfiguration @type varchar(6)
AS
BEGIN
	SET NOCOUNT ON;

	IF UPPER(@type) = 'SYSTEM'
	BEGIN
		INSERT SF_TDP_RESTORE
		SELECT GETDATE(), SUSER_NAME(), 'master', 'SYSTEM', 0
		UNION
		SELECT GETDATE(), SUSER_NAME(), 'msdb', 'SYSTEM', 0
		UNION
		SELECT GETDATE(), SUSER_NAME(), 'model', 'SYSTEM', 0;
	END;

	ELSE IF UPPER(@type) = 'USER'
	BEGIN
		INSERT SF_TDP_RESTORE
		SELECT GETDATE(), SUSER_NAME(), name, 'USER', 0
		FROM sys.databases WHERE state_desc <> 'ONLINE';
	END;

	ELSE
	BEGIN
		RAISERROR('Invalid parameter - must be ''USER'' OR ''SYSTEM''.', 0, 1);
		RETURN;
	END;

	PRINT 'You can now execute sfsp_TDP_BeginRestore ''' + @type + ''', ''' + SUSER_NAME() + '''';
END;
GO

CREATE PROC sfsp_TDP_VerifiedRestore @user varchar(512)
AS
BEGIN
	EXEC msdb..sp_start_job @job_name='SF_SQL_Admin TDP DR Restore'
END;
GO

CREATE PROC sfsp_TDP_BeginRestore @type varchar(6), @user varchar(512)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @cmd nvarchar(max), @databases nvarchar(max);
	SET @databases = '';

	IF UPPER(@type) = 'USER'
	BEGIN
		SELECT DISTINCT @databases = @databases + DBName + ','
		FROM SF_TDP_Restore 
		WHERE RunTime > DATEADD(mi, -15, GETDATE()) 
		AND UserName = @user
		AND Executed = 0;

		IF LEN(@databases) > 0
		BEGIN
			SET @databases = LEFT(@databases, LEN(@databases) - 1);
		END;

		ELSE
		BEGIN
			RAISERROR('No databases.', 0, 1);
			RETURN;
		END;
	END;

	ELSE IF UPPER(@type) = 'SYSTEM'
	BEGIN
		IF EXISTS (SELECT DBName FROM SF_TDP_Restore WHERE RunTime > DATEADD(mi, -15, GETDATE()) 
		AND UserName = @user AND Executed = 0)
		BEGIN
			SET @databases = 'SYSTEM';
		END;

		ELSE
		BEGIN
			RAISERROR('No databases.', 0, 1);
			RETURN;			
		END;
	END;

	ELSE
	BEGIN
		RAISERROR('Invalid parameter - must be ''USER'' OR ''SYSTEM''.', 0, 1);
		RETURN;
	END;

	IF EXISTS (SELECT name FROM msdb..sysjobs WHERE name = 'SF_SQL_Admin TDP DR Restore')
	BEGIN
		EXEC msdb..sp_delete_job @job_name = 'SF_SQL_Admin TDP DR Restore';
	END;

	SET @cmd = N'
			EXEC msdb.dbo.sp_add_job @job_name=N''SF_SQL_Admin TDP DR Restore'', 
					@enabled=0, 
					@notify_level_eventlog=0 
					--@delete_level=3,
					--@owner_login_name=N''sfsa''

			EXEC  msdb.dbo.sp_add_jobstep @job_name=N''SF_SQL_Admin TDP DR Restore'', @step_name=N''Build_Script'', 
					@step_id=1, 
					@subsystem=N''CmdExec'',
					@on_success_action=3, 
					@command=N''powershell "C:\Progra~1\Storage\TSM\SCRIPTS\SQL\TDP_BUILD_RESTORE_SCRIPT.ps1" ' + @databases + 
						' $(ESCAPE_SQUOTE(INST))''
			
			EXEC  msdb.dbo.sp_add_jobstep @job_name=N''SF_SQL_Admin TDP DR Restore'', @step_name=N''Execute_Script'', 
					@step_id=2, 
					@subsystem=N''CmdExec'', 
					@command=N''powershell "C:\Progra~1\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1"'' 

			EXEC msdb.dbo.sp_add_jobserver @job_name=N''SF_SQL_Admin TDP DR Restore'', @server_name = N''(local)''';

	EXEC sp_executesql @cmd;

	EXEC msdb.dbo.sp_update_job @job_name = 'SF_SQL_Admin TDP DR Restore', @owner_login_name=N'sfsa';

	UPDATE SF_TDP_Restore
	SET Executed = 1
	WHERE DBType = @type
	AND UserName = @user;

	EXEC sfsp_TDP_VerifiedRestore '';
END;
GO


GRANT EXECUTE ON [dbo].[sfsp_TDP_BeginRestore] TO [DR_TDP_RESTORE_OPERATOR];
GO
GRANT EXECUTE ON [dbo].[sfsp_TDP_RestoreConfiguration] TO [DR_TDP_RESTORE_OPERATOR];
GO

--USE [msdb]
--GO
--CREATE ROLE [DR_TDP_RESTORE_OPERATOR] AUTHORIZATION [dbo]
--GO
--GRANT EXECUTE ON [dbo].[sp_add_job] TO [DR_TDP_RESTORE_OPERATOR]
--GO
--GRANT EXECUTE ON [dbo].[sp_add_jobserver] TO [DR_TDP_RESTORE_OPERATOR]
--GO
--GRANT EXECUTE ON [dbo].[sp_add_jobstep] TO [DR_TDP_RESTORE_OPERATOR]
--GO
--GRANT EXECUTE ON [dbo].[sp_start_job] TO [DR_TDP_RESTORE_OPERATOR]
--GO
--GRANT SELECT ON [dbo].[sysjobs] TO [DR_TDP_RESTORE_OPERATOR]
--GO


IF EXISTS (SELECT name FROM msdb..sysjobs WHERE name = 'SF_SQL_Admin TDP DR Restore')
	EXEC msdb..sp_delete_job @job_name = 'SF_SQL_Admin TDP DR Restore';

