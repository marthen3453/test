﻿$databases = $args[0]
$instance = $args[1]
$prodserver = $env:COMPUTERNAME -replace "DR", ""

'$fcmPath = (get-itemproperty -path ''HKLM:\SOFTWARE\IBM\flashcopymanager\currentversion\mmc'').path
dir $fcmPath fmmodule*.dll | select -expand fullname | import-module' |
Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1"

IF ($databases -ne "SYSTEM") {
    $databases | foreach {
        "Restore-DpSqlBackup  " + $_ + " -Full -SqlServer "".\$instance"" -FromSqlServer ""$prodserver\$instance""" |
        Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append
    }
}

ELSE { 
    IF ((Invoke-Sqlcmd -ServerInstance $prodserver\$instance -Query "SELECT @@VERSION") -contains "SQL Server 2008") {
        "Restore-DpSqlBackup  master -Full -SqlServer "".\$instance"" -FromSqlServer ""$prodserver\$instance"" -IntoDBName masterDR -RelocateDir ""H:\sysdb_recovery""" |
        Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

        "Restore-DpSqlBackup  model -Full -SqlServer "".\$instance"" -FromSqlServer ""$prodserver\$instance"" -IntoDBName modelDR -RelocateDir ""H:\sysdb_recovery""" |
        Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

        "Restore-DpSqlBackup  msdb -Full -SqlServer "".\$instance"" -FromSqlServer ""$prodserver\$instance"" -IntoDBName msdbDR -RelocateDir ""H:\sysdb_recovery""" |
        Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append
    }

    ELSE {
        "Restore-DpSqlBackup  master -Full -SqlServer "".\$instance"" -FromSqlServer ""$prodserver\$instance"" -IntoDBName masterDR -RelocateDir ""F:\MSSQL\BACKUP\F_MP04\BACKUP\sysdb_recovery""" |
        Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

        "Restore-DpSqlBackup  model -Full -SqlServer "".\$instance"" -FromSqlServer ""$prodserver\$instance"" -IntoDBName modelDR -RelocateDir ""F:\MSSQL\BACKUP\F_MP04\BACKUP\sysdb_recovery""" |
        Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append

        "Restore-DpSqlBackup  msdb -Full -SqlServer "".\$instance"" -FromSqlServer ""$prodserver\$instance"" -IntoDBName msdbDR -RelocateDir ""F:\MSSQL\BACKUP\F_MP04\BACKUP\sysdb_recovery""" |
        Out-File "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1" -Append
    }
}