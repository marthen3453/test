﻿### Variables and passed in values.
[string]$instance = $args[0]
[float]$version = $args[1]

[string]$scriptpath = ""
[string]$recoverypath = ""
[string]$logpath = ""
[string]$optfile = ""
[System.Array]$types = @()

### Set the machine names for the local instance and the prod equivalent:
### * If default instance, refer only to servername.
### * If named instance, append instance name to servername.
### * Set name of prod server by removing DR from the end of the name (this also allows running on a prod machine).
if ($instance -eq "MSSQLSERVER") {
    $thisserver = $env:COMPUTERNAME
    $prodserver = $env:COMPUTERNAME -replace "DR$", ""
    $optfile = "SQL_$env:COMPUTERNAME.opt"
}

else {
    $thisserver = $env:COMPUTERNAME + "\" + $instance
    $prodserver = ($env:COMPUTERNAME -replace "DR$", "") + "\" + $instance
    $optfile = "SQL_$instance.opt"
}

### 6.2 is Server 2008 R2 with a different folder structure than 2012+.
### Set the paths accordingly.
if ($version -lt 6.2) {
	$scriptpath = "D:\APPS\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.ps1"
    $recoverypath = "H:\sysdb_recovery"
    $logpath = "D:\APPS\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_LOG.txt"
}

else {
	$scriptpath = "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_EXECUTE.bat"
    $recoverypath = "F:\MSSQL\BACKUP\F_MP04\BACKUP\sysdb_recovery"
    $logpath = "C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_LOG.txt"
}

### Query the control table for records.  DISTINCT will prevent accidental multiple runs.
$types = Invoke-Sqlcmd -ServerInstance $thisserver -Query "SELECT DISTINCT DBType FROM SF_TDP_Restore WHERE RecoveryComplete = 0" -Database "SF_SQL_Admin" 

### Create/Replace the script file
"" | Out-File $scriptpath

### Loop through the types. (This logic will not typically apply as the proc will run the script as soon as the control file record is created.)
foreach ($type in $types.DBType) {
    if ($type -eq "SYSTEM") { 
        ## Builds the restore script for SYSTEM databases.  
        ## The script will update the control record for a start time, restore the system db's to an alternate location, and log any errors.
        'sqlcmd -S "' + $thisserver + '" -Q "UPDATE SF_TDP_Restore SET RecoveryStartTime = GETDATE() WHERE DBType = ''SYSTEM'' AND RecoveryComplete = 0" -d "SF_SQL_admin"' |
            Out-File $scriptpath -Append

        '"C:\Program Files\Storage\TSM\TDPSql\tdpsqlc.exe" restore master full /SqlServer="' + $thisserver + '" /FromSqlServer="' + $prodserver + 
            '" /Into=masterDR /Relocate="master,mastlog" /To="' + $recoverypath + '\master.mdf,' + $recoverypath + '\mastlog.ldf" /tsmoptfile="' + $env:APPSDIR + '\Storage\TSM\CONFIG\' + $optfile + '"' |
            Out-File $scriptpath -Append

        '"C:\Program Files\Storage\TSM\TDPSql\tdpsqlc.exe" restore msdb full /SqlServer="' + $thisserver + '" /FromSqlServer="' + $prodserver + 
            '" /Into=msdbDR /Relocate="msdbdata,msdblog" /To="' + $recoverypath + '\msdbdata.mdf,' + $recoverypath + '\msdblog.ldf" /tsmoptfile="' + $env:APPSDIR + '\Storage\TSM\CONFIG\' + $optfile + '"' |
            Out-File $scriptpath -Append

        '"C:\Program Files\Storage\TSM\TDPSql\tdpsqlc.exe" restore model full /SqlServer="' + $thisserver + '" /FromSqlServer="' + $prodserver + 
            '" /Into=modelDR /Relocate="modeldev,modellog" /To="' + $recoverypath + '\model.mdf,' + $recoverypath + '\modellog.ldf" /tsmoptfile="' + $env:APPSDIR + '\Storage\TSM\CONFIG\' + $optfile + '"' |
            Out-File $scriptpath -Append
    }

    elseif ($type -eq "USER") {
        ## Builds the restore script for USER databases.  
        ## The script will update the control record for a start time, check databases for the RECOVERY_PENDING status, and log any errors.
        'sqlcmd -S "' + $thisserver + '" -Q "UPDATE SF_TDP_Restore SET RecoveryStartTime = GETDATE() WHERE DBType = ''USER'' AND RecoveryComplete = 0" -d "SF_SQL_admin"' |
            Out-File $scriptpath -Append

        $db = Invoke-Sqlcmd -ServerInstance $thisserver -Query "SELECT name FROM sys.databases WHERE state_desc = 'RECOVERY_PENDING' AND name <> 'SSISDB'" -Database "SF_SQL_Admin" 

        $db.name | foreach {
            '"C:\Program Files\Storage\TSM\TDPSql\tdpsqlc.exe" restore ' + $_ + ' full /SqlServer="' + $thisserver + '" /FromSqlServer="' + $prodserver + '" /tsmoptfile="' + $env:APPSDIR + '\Storage\TSM\CONFIG\' + $optfile + '"' |
                Out-File $scriptpath -Append
        }
    }

    ### Error logging for this script.
    if ($Error) {
        (Get-Date -format G).ToString() + ': ' | Out-File $logpath -Append
        $Error | ForEach {$_ | Out-File $logpath -Append}
    }
}