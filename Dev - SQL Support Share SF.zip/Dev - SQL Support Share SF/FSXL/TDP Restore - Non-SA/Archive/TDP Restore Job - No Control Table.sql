USE [msdb]
GO

DECLARE @path nvarchar(max), @version nvarchar(24), @cmd nvarchar(max);
SELECT @version = windows_release,
	@path = CASE WHEN windows_release < '6.2'
	THEN 'D:\APPS\Storage\TSM\SCRIPTS\SQL\' 
	ELSE 'C:\Program Files\Storage\TSM\SCRIPTS\SQL\' END
FROM sys.dm_os_windows_info

SET @cmd = '
EXEC msdb.dbo.sp_add_job @job_name=N''SF_SQL_Admin TDP DR Restore'', 
		@enabled=0, 
		@owner_login_name=N''sfsa''

EXEC msdb.dbo.sp_add_jobstep @job_name=N''SF_SQL_Admin TDP DR Restore'',
		@step_name=N''Build_Script_System_Databases'', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=3, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N''CmdExec'', 
		@command=N''powershell "' + @path + 'TDP_BUILD_RESTORE_SCRIPT.ps1" SYSTEM $(ESCAPE_SQUOTE(INST)) ' + @version + ''', 
		@flags=0

EXEC msdb.dbo.sp_add_jobstep @job_name=N''SF_SQL_Admin TDP DR Restore'',
		@step_name=N''Build_Script_User_Databases'', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=3, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N''CmdExec'', 
		@command=N''powershell "' + @path + 'TDP_BUILD_RESTORE_SCRIPT.ps1" USER $(ESCAPE_SQUOTE(INST)) ' + @version + ''', 
		@flags=0

EXEC msdb.dbo.sp_add_jobstep @job_name=N''SF_SQL_Admin TDP DR Restore'',
		@step_name=N''Execute_Script'', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N''CmdExec'', 
		@command=N''powershell "' + @path + 'TDP_DR_RESTORE_EXECUTE.ps1"'', 
		@flags=0

EXEC msdb.dbo.sp_add_jobstep @job_name=N''SF_SQL_Admin TDP DR Restore'',
		@step_name=N''Delete_Script'', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N''CmdExec'', 
		@command=N''del "' + @path + 'TDP_DR_RESTORE_EXECUTE.ps1"'', 
		@flags=0
		
EXEC msdb.dbo.sp_add_jobserver @job_name=N''SF_SQL_Admin TDP DR Restore'', @server_name = N''(local)'''

EXEC sp_executesql @cmd;


