USE [SF_SQL_Admin];
GO

IF EXISTS (SELECT name FROM sys.objects WHERE name = 'SF_TDP_Restore')
	DROP TABLE SF_TDP_Restore;
GO
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'sfsp_TDP_DR_Restore')
	DROP PROC sfsp_TDP_DR_Restore;
GO

CREATE TABLE SF_TDP_Restore (RunTime datetime, UserName varchar(512), DBType varchar(8), 
	RecoveryStartTime datetime, RecoveryEndTime datetime, RecoveryComplete bit);
GO

CREATE PROC sfsp_TDP_DR_Restore @type varchar(6)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @starttime datetime, @msg varchar(max), @step int = 1, @jobstatus bit = 0, @stepstatus int = 0, 
		@path nvarchar(max), @version nvarchar(24), @sysdbpath nvarchar(max), @instance varchar(512);
	DECLARE @statustable TABLE (status varchar(128));
	DECLARE @backup TABLE (value varchar(128), data varchar(512));

	SELECT @starttime = DATEADD(mi, -1, GETDATE());
	SELECT @instance = @@SERVICENAME;

	INSERT @backup
	EXECUTE [master].dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'SOFTWARE\Microsoft\MSSQLServer\MSSQLServer', N'BackupDirectory'

	SELECT @sysdbpath = data FROM @backup

	IF EXISTS (SELECT name FROM sys.system_objects WHERE name like 'dm_os_windows_info')
	BEGIN	
		SELECT @version = windows_release,
			@path = CASE WHEN windows_release < '6.2'
			THEN 'D:\APPS\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_LOG.txt' 
			ELSE 'C:\Program Files\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_LOG.txt' END,
			@sysdbpath = CASE WHEN windows_release < '6.2'
			THEN 'H:\sysdb_recovery\' + @instance
			ELSE @sysdbpath + '\sysdb_recovery' END
		FROM sys.dm_os_windows_info;
	END
	ELSE
	BEGIN
		SET @path = 'D:\APPS\Storage\TSM\SCRIPTS\SQL\TDP_DR_RESTORE_LOG.txt'
		SET @sysdbpath = 'H:\sysdb_recovery\'
	END

	INSERT @statustable EXEC xp_servicecontrol 'querystate', 'SQLSERVERAGENT';
	IF (SELECT status FROM @statustable) <> 'Running.'
	BEGIN
		RAISERROR('SQL Agent is offline, please start the service and try again.', 16, 1) WITH NOWAIT;
		RETURN;
	END	

	IF UPPER(@type) = 'SYSTEM'
	BEGIN
		INSERT SF_TDP_RESTORE
		SELECT @starttime, SUSER_NAME(), 'SYSTEM', null, null, 0;
	END;

	ELSE IF UPPER(@type) = 'USER'
	BEGIN
		INSERT SF_TDP_RESTORE
		SELECT @starttime, SUSER_NAME(), 'USER', null, null, 0;
	END;

	ELSE
	BEGIN
		RAISERROR('Invalid parameter - must be ''USER'' OR ''SYSTEM''.', 16, 1);
		RETURN;
	END;

	EXEC msdb.dbo.sp_start_job @job_name = 'SF_SQL_Admin TDP DR Restore';
	RAISERROR ('', 0, 1) WITH NOWAIT;

	WHILE @jobstatus = 0
	BEGIN
		SELECT @msg = '';

		SELECT @msg = step_name + ' has completed with ' + CASE WHEN last_run_outcome = 1 THEN 'success.' ELSE 'failure.' END,
			@stepstatus = last_run_outcome
		FROM msdb.dbo.sysjobsteps sjs
		INNER JOIN msdb.dbo.sysjobs sj ON sj.job_id = sjs.job_id
		WHERE name = 'SF_SQL_Admin TDP DR Restore'
		AND CONVERT(datetime, CONVERT(datetime, CONVERT(char(10), CONVERT(datetime, CONVERT(varchar, last_run_date)), 101) + ' ' + 
			REVERSE(STUFF(STUFF(REVERSE(REPLICATE('0', 6 - LEN(CONVERT(varchar, last_run_time))) + 
			CONVERT(varchar, last_run_time)), 3, 0, ':'), 6, 0, ':')))) >= @starttime
		AND last_run_date <> 0
		AND last_run_time <> 0
		AND step_id = @step;

		IF @msg <> ''
		BEGIN
			IF @stepstatus = 1
				RAISERROR (@msg, 0, 1) WITH NOWAIT;
			ELSE
				RAISERROR (@msg, 16, 1) WITH NOWAIT;
				
			SET @step = @step + 1;
		END;

		IF EXISTS (SELECT last_outcome_message
				FROM msdb.dbo.sysjobservers sjs
				INNER JOIN msdb.dbo.sysjobs sj ON sj.job_id = sjs.job_id
				WHERE name = 'SF_SQL_Admin TDP DR Restore'
				AND CONVERT(datetime, CONVERT(datetime, CONVERT(char(10), CONVERT(datetime, CONVERT(varchar, last_run_date)), 101) + ' ' + 
					REVERSE(STUFF(STUFF(REVERSE(REPLICATE('0', 6 - LEN(CONVERT(varchar, last_run_time))) + 
					CONVERT(varchar, last_run_time)), 3, 0, ':'), 6, 0, ':')))) >= @starttime 
				AND last_run_date <> 0
				AND last_run_time <> 0
				AND (@step = 4 OR @stepstatus <> 1))
		BEGIN
			SELECT @msg = last_outcome_message 
			FROM msdb.dbo.sysjobservers sjs
			INNER JOIN msdb.dbo.sysjobs sj ON sj.job_id = sjs.job_id
			WHERE name = 'SF_SQL_Admin TDP DR Restore';

			RAISERROR (@msg, 0, 1) WITH NOWAIT;
			SET @jobstatus = 1;
		END;
	END;

	IF @type = 'SYSTEM'
	BEGIN
		PRINT CHAR(13) + 'Recovered system database files can be found at: ' + @sysdbpath + CHAR(13)

		SET @msg = 'System database files are located here:'

		SELECT @msg = @msg + CHAR(13) + physical_name 
		FROM sys.master_files
		WHERE database_id IN (1,3,4)

		PRINT @msg
	END

	PRINT ''
	PRINT 'Script errors can be reviewed at ' + @path
END;
GO

