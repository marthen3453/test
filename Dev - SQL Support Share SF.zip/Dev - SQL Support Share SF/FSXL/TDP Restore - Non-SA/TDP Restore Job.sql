USE [msdb]
GO

DECLARE @cmd nvarchar(max), @path nvarchar(max), @version nvarchar(24), 
	@sysdbpath nvarchar(max), @instance varchar(512);

DECLARE @statustable TABLE (status varchar(128));
DECLARE @backup TABLE (value varchar(128), data varchar(512));

INSERT @backup
EXECUTE [master].dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'SOFTWARE\Microsoft\MSSQLServer\MSSQLServer', N'BackupDirectory';

SELECT @sysdbpath = data FROM @backup;
SELECT @instance = @@SERVICENAME;

IF EXISTS (SELECT name FROM sys.system_objects WHERE name like 'dm_os_windows_info')
BEGIN
	SELECT @version = windows_release,
		@path = CASE WHEN windows_release < '6.2'
		THEN 'D:\DATA\SQL\SF_SQL_Admin\TDPRestore\' 
		ELSE 'C:\DATA\SQL\SF_SQL_Admin\TDPRestore\' END,
		@sysdbpath = CASE WHEN windows_release < '6.2'
		THEN 'H:\sysdb_recovery\' + @instance
		ELSE @sysdbpath + '\sysdb_recovery' END
	FROM sys.dm_os_windows_info;
END	
ELSE
BEGIN
	SET @path = 'D:\DATA\SQL\SF_SQL_Admin\TDPRestore\'
	SET @sysdbpath = 'H:\sysdb_recovery\'
END

IF EXISTS (SELECT name FROM msdb..sysjobs WHERE name = 'SF_SQL_Admin TDP DR Restore')
	EXEC sp_delete_job @job_name = 'SF_SQL_Admin TDP DR Restore';

SET @cmd = '
EXEC msdb.dbo.sp_add_job @job_name=N''SF_SQL_Admin TDP DR Restore'', 
		@enabled=0, 
		@owner_login_name=N''sfsa''

EXEC msdb.dbo.sp_add_jobstep @job_name=N''SF_SQL_Admin TDP DR Restore'',
		@step_name=N''Build_Script'', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N''CmdExec'', 
		@command=N''powershell "' + @path + 'TDP_BUILD_RESTORE_SCRIPT.ps1" ' + @instance + 
			' ' + @path + ' ' + @sysdbpath + ''', 
		@flags=0

EXEC msdb.dbo.sp_add_jobstep @job_name=N''SF_SQL_Admin TDP DR Restore'',
		@step_name=N''Execute_Script'', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N''CmdExec'', 
		@command=N''powershell "' + @path + 'TDP_DR_RESTORE_EXECUTE.ps1"'', 
		@flags=0

EXEC msdb.dbo.sp_add_jobstep @job_name=N''SF_SQL_Admin TDP DR Restore'',
		@step_name=N''Delete_Script'', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N''CmdExec'', 
		@command=N''del "' + @path + 'TDP_DR_RESTORE_EXECUTE.ps1"'', 
		@flags=0
		
EXEC msdb.dbo.sp_add_jobserver @job_name=N''SF_SQL_Admin TDP DR Restore'', @server_name = N''(local)''';

EXEC sp_executesql @cmd;


