﻿### LOAD SQLPS
Push-Location
Import-Module sqlps -DisableNameChecking
Pop-Location


### FUNCTIONS


### LOAD XAML
$script = $env:Drive + ":\DATA\SQL\SF_SQL_Admin\TDPRestore\loadapp.ps1 -XamlPath '" + $env:Drive + ":\DATA\SQL\SF_SQL_Admin\TDPRestore\xaml.txt'"
Invoke-Expression $script


### EVENT HANDLERS
$button_Configure.Add_Click({
	if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
		$textBox_Messages.Text += "**********************************************************************************************`n"
		$textBox_Messages.Text += "Access denied.  You must request local administrator access to continue.`n"
		$textBox_Messages.Text += "**********************************************************************************************`n"
		return
	}
	
    Copy-Item "$env:APPSDIR\Storage\TSM\CONFIG\SQL_*" ($env:Drive + ":\DATA\SQL\SF_SQL_Admin\TDPRestore\")
    $count = Get-ChildItem ($env:Drive + ":\DATA\SQL\SF_SQL_Admin\TDPRestore\") | Where Name -Like 'SQL_*' | Measure
    $textBox_Messages.Text += "" + $count.Count + " TDP configuration files copied.`n"
    $button_RestoreSystem.IsEnabled = "True"
    $button_RestoreUserDatabases.IsEnabled = "True"
    
    Get-ChildItem ($env:Drive + ":\DATA\SQL\SF_SQL_Admin\TDPRestore\*.cfg") | Foreach {
        $content = Get-Content $_.FullName
        $content[7] = "LOGFile                  " + $env:Drive + ":\DATA\SQL\SF_SQL_Admin\TDPRestore\" + $_.Name -replace "cfg", "log"
        $content | Set-Content $_.FullName
    }

    $cfgfile = $env:Drive + ":\data\SQL\SF_SQL_Admin\TDPRestore\SQL_*.CFG"
    $machine = ((((Get-Content $cfgfile) -match "SQLSERVer")[0]).Split(" ", [System.StringSplitOptions]::RemoveEmptyEntries)[1] -split "\\")[0]

    $listBox_Instances.Items.Clear()

    $instances = Get-WmiObject Win32_Service | Where {$_.name -like "MSSQL$*" -or $_.name -eq "MSSQLSERVER"}
    $instances | Foreach {
        if ($_.name -eq "MSSQLSERVER") {
            $listBox_Instances.Items.Add($machine + "\" + $_.Name)
        }

        else {
            $listBox_Instances.Items.Add($machine + "\" + $_.Name.Substring(6))
        }
    }

    $listBox_Instances.SelectedIndex = 0
})

$button_RestoreSystem.Add_Click({
    $server = $listBox_Instances.SelectedValue -replace "\\MSSQLSERVER", ""

    $db = Invoke-Sqlcmd -ServerInstance $server -Query "SELECT name FROM sys.databases WHERE name LIKE '%DR'"
    if ($db.Count -gt 0) {
        $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "`n**********************************************************************************************`n"},"Render")
        $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "ERROR: Restored system databases already exist, please drop existing DR databases to run this.`n"},"Render")
        $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "**********************************************************************************************`n"},"Render")
        return
    }

    $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "`n`n-----------------------------------------------------------------------`n"},"Render")
    $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "Restoring system databases to $server`n"},"Render")
    $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "-----------------------------------------------------------------------"},"Render")
    $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "`n"},"Render")

    $sqlConnection = New-Object System.Data.SqlClient.SqlConnection "Integrated Security=SSPI;Initial Catalog=SF_SQL_Admin;Data Source=$server"
    $sqlConnection.Open() 
    $handler = [System.Data.SqlClient.SqlInfoMessageEventHandler] {param($sender, $event) $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += $event.Message + "`n"},"Render")}; 
    $sqlConnection.add_InfoMessage($handler); 
    $sqlConnection.FireInfoMessageEventOnUserErrors = $true;
     
    $sqlCmd = New-Object System.Data.SqlClient.SqlCommand("sfsp_TDP_DR_Restore", $sqlConnection) 
    $sqlCmd.CommandTimeout = 0
    $sqlCmd.CommandType = [System.Data.CommandType]"StoredProcedure"
    $sqlCmd.Parameters.AddWithValue("@type", "SYSTEM") | Out-Null
    $sqlCmd.ExecuteNonQuery()

    $sqlConnection.Close() 

    if ($checkBox_ReplaceSystem.IsChecked -eq $true) {
        $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "`n`n-----------------------------------------------------------------------`n"},"Render")
        $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "Replacing system database files.`n"},"Render")
        $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "-----------------------------------------------------------------------"},"Render")
        $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "`n"},"Render")

        $systemdatabases = Invoke-SqlCmd -ServerInstance $server -Query "
            SELECT f1.physical_name CurrentDB, f2.physical_name DRDB
            FROM sys.master_files f1
            LEFT OUTER JOIN sys.master_files f2 ON f1.name = f2.name
            INNER JOIN sys.databases d ON d.database_id = f2.database_id
            WHERE d.name LIKE '%DR'
            AND f1.database_id IN (1,3,4)"

        $selectedinstance = $listBox_Instances.SelectedValue.Split('\')[1]

        if ((Get-WmiObject -Class Win32_SystemServices | Where {$_ -like "*ClusSvc*"}).PSComputerName -ne $null) {
            Get-ClusterResource | Where {$_.ResourceType -eq "SQL Server" -and $_.Name -like "*$selectedinstance*"} | Stop-ClusterResource
            $textBox_Messages.Text += "Stopped SQL Server cluster resource on $server.`n`n"
        }

        else {
            $instances = Get-WmiObject Win32_Service | Where {$_.name -like "*" + $selectedinstance + "*" -or $_.name -eq "SQLSERVERAGENT"}
            $instances | Foreach { Stop-Service -Name $_.Name -Force }
            $textBox_Messages.Text += "Stopped services on $server`n`n"
        }

        $systemdatabases | Foreach {
            $filename = $_.CurrentDB -split "\\"
            $filename = $filename[$filename.GetUpperBound(0)]
            $filename = $filename -replace "\.", "_old."
            Rename-Item $_.CurrentDB $filename
            $textBox_Messages.Text += $_.CurrentDB + " has been renamed.`n"
            Move-Item $_.DRDB $_.CurrentDB
            $textBox_Messages.Text += $_.DRDB + " has been moved to " + $_.CurrentDB + ".`n"
        }


        if ((Get-WmiObject -Class Win32_SystemServices | Where {$_ -like "*ClusSvc*"}).PSComputerName -ne $null) {
            Get-ClusterResource | Where {$_.ResourceType -eq "SQL Server Agent" -and $_.Name -like "*$selectedinstance*"} | Start-ClusterResource | Out-Null
            $tsmclusterresource = Get-ClusterResource | Where {$_.Name -like "TSM CAD for SQL $selectedinstance*"} 
            $textBox_Messages.Text += "`nStarted SQL Server and Agent cluster resources on $server.`n"
            if ($tsmclusterresource -ne $null) {
                Start-ClusterResource $tsmclusterresource | Out-Null
                $textBox_Messages.Text += "Started TSM cluster resource on $server.`n"
            }
        }

        else {
            $instances.StartService() | Out-Null
            $textBox_Messages.Text += "`nStarted services for $selectedinstance on $server.`n"
        }
    }

    $textBox_Messages.Text += "`n`n-----------------------------------------------------------------------`n"
    $textBox_Messages.Text += "System database restore complete.`n"
    $textBox_Messages.Text += "-----------------------------------------------------------------------`n`n"
})

$button_RestoreUserDatabases.Add_Click({
    $server = $listBox_Instances.SelectedValue -replace "\\MSSQLSERVER", ""

    $db = Invoke-Sqlcmd -ServerInstance $server -Query "SELECT COUNT(*) num FROM sys.databases WHERE state_desc <> 'ONLINE'"
    if ($db.num -le 0) {
        $textBox_Messages.Text += "`n***************************************************************************************`n"
        $textBox_Messages.Text += "ERROR: No user databases pending recovery, please check in SQL Server.`n"
        $textBox_Messages.Text += "***************************************************************************************`n"
        return
    }

    $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "`n`n-----------------------------------------------------------------------`n"},"Render")
    $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "Restoring user databases.`n"},"Render")
    $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "-----------------------------------------------------------------------"},"Render")
    $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += "`n"},"Render")

    $sqlConnection = New-Object System.Data.SqlClient.SqlConnection "Integrated Security=SSPI;Initial Catalog=SF_SQL_Admin;Data Source=$server"
    $sqlConnection.Open() 
    $handler = [System.Data.SqlClient.SqlInfoMessageEventHandler] {param($sender, $event) $XamGUI.Dispatcher.Invoke([action]{$textBox_Messages.Text += $event.Message + "`n"},"Render")}; 
    $sqlConnection.add_InfoMessage($handler); 
    $sqlConnection.FireInfoMessageEventOnUserErrors = $true;
     
    $sqlCmd = New-Object System.Data.SqlClient.SqlCommand("sfsp_TDP_DR_Restore", $sqlConnection) 
    $sqlCmd.CommandTimeout = 0
    $sqlCmd.CommandType = [System.Data.CommandType]"StoredProcedure"
    $sqlCmd.Parameters.AddWithValue("@type", "USER") | Out-Null
    $sqlCmd.ExecuteNonQuery()

    $sqlConnection.Close() 

    $textBox_Messages.Text += "`n`n-----------------------------------------------------------------------`n"
    $textBox_Messages.Text += "User database restore completed.`n"
    $textBox_Messages.Text += "-----------------------------------------------------------------------`n`n"
})


### DISPLAY FORM
$xamGUI.ShowDialog() | Out-Null

