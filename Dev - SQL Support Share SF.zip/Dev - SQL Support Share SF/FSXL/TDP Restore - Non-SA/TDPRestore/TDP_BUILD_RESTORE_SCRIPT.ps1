﻿### Variables and passed in values.
[string]$instance = $args[0]
[string]$apppath = $args[1]
[string]$recoverypath = $args[2]


[string]$machine = ""
[string]$optfile = ""
[string]$cfgfile = ""
[string]$scriptpath = $apppath + "TDP_DR_RESTORE_EXECUTE.ps1"
[string]$logpath = $apppath + "TDP_DR_RESTORE_LOG.txt"
[System.Array]$types = @()

### Set the machine names for the local instance and the prod equivalent:
### * If default instance, refer only to servername.
### * If named instance, append instance name to servername.
### * Set name of prod server by removing DR from the end of the name (this also allows running on a prod machine).
$cfgfile = $env:Drive + ":\data\SQL\SF_SQL_Admin\TDPRestore\SQL_*.CFG"
$machine = ((((Get-Content $cfgfile) -match "SQLSERVer")[0]).Split(" ", [System.StringSplitOptions]::RemoveEmptyEntries)[1] -split "\\")[0]

if ($instance -eq "MSSQLSERVER") {
    $thisserver = $machine
    $prodserver = $machine -replace "DR$", ""
    $optfile = "SQL_$machine.opt"
    $cfgfile = "SQL_$machine.cfg"
}

else {
    $thisserver = $machine + "\" + $instance
    $prodserver = ($machine -replace "DR$", "") + "\" + $instance
    $optfile = "SQL_$instance.opt"
    $cfgfile = "SQL_$instance.cfg"
}

### Query the control table for records.  DISTINCT will prevent accidental multiple runs.
$types = Invoke-Sqlcmd -ServerInstance $thisserver -Query "SELECT DISTINCT DBType FROM SF_TDP_Restore WHERE RecoveryComplete = 0" -Database "SF_SQL_Admin" 

### Check if any results were returned before starting the script file.
if ($types) {
    '$fcmPath = (get-itemproperty -path ''HKLM:\SOFTWARE\IBM\flashcopymanager\currentversion\mmc'').path
    dir $fcmPath fmmodule*.dll | select -expand fullname | import-module' | Out-File $scriptpath
}

### Loop through the types. (This logic will not typically apply as the proc will run the script as soon as the control file record is created.)
foreach ($type in $types.DBType) {
    if ($type -eq "SYSTEM") { 
        ## Builds the restore script for SYSTEM databases.  
        ## The script will update the control record for a start time, restore the system db's to an alternate location, and log any errors.
        "Invoke-Sqlcmd -ServerInstance $thisserver -Query ""UPDATE SF_TDP_Restore SET RecoveryStartTime = GETDATE() WHERE DBType = 'SYSTEM' AND RecoveryComplete = 0"" -Database ""SF_SQL_Admin""" | 
            Out-File $scriptpath -Append

        "Restore-DpSqlBackup  master -Full -Replace -SqlServer ""$thisserver"" -FromSqlServer ""$prodserver"" -IntoDBName masterDR -RelocateDir ""$recoverypath"" -TSMOptFile ""$apppath$optfile"" -ConfigFile ""$apppath$cfgfile""" |
            Out-File $scriptpath -Append

        "Restore-DpSqlBackup  model -Full -Replace -SqlServer ""$thisserver"" -FromSqlServer ""$prodserver"" -IntoDBName modelDR -RelocateDir ""$recoverypath"" -TSMOptFile ""$apppath$optfile"" -ConfigFile ""$apppath$cfgfile""" |
            Out-File $scriptpath -Append

        "Restore-DpSqlBackup  msdb -Full -Replace -SqlServer ""$thisserver"" -FromSqlServer ""$prodserver"" -IntoDBName msdbDR -RelocateDir ""$recoverypath"" -TSMOptFile ""$apppath$optfile"" -ConfigFile ""$apppath$cfgfile""" |
            Out-File $scriptpath -Append

        "IF (!`$Error) { Invoke-Sqlcmd -ServerInstance $thisserver -Query ""UPDATE SF_TDP_Restore SET RecoveryComplete = 1, RecoveryEndTime = GETDATE() WHERE DBType = 'SYSTEM' AND RecoveryComplete = 0"" -Database ""SF_SQL_Admin""}
            ELSE { Invoke-Sqlcmd -ServerInstance $thisserver -Query ""UPDATE SF_TDP_Restore SET RecoveryComplete = null, RecoveryEndTime = null WHERE DBType = 'SYSTEM' AND RecoveryComplete = 0"" -Database ""SF_SQL_Admin""
                (Get-Date -format G).ToString() + ': ' | Out-File ""$logpath"" -Append
                    `$Error | ForEach {`$_ | Out-File ""$logpath"" -Append}}" |
            Out-File $scriptpath -Append
    }

    elseif ($type -eq "USER") {
        ## Builds the restore script for USER databases.  
        ## The script will update the control record for a start time, check databases for the RECOVERY_PENDING status, and log any errors.
        "Invoke-Sqlcmd -ServerInstance $thisserver -Query ""UPDATE SF_TDP_Restore SET RecoveryStartTime = GETDATE() WHERE DBType = 'USER' AND RecoveryComplete = 0"" -Database ""SF_SQL_Admin""" | 
            Out-File $scriptpath -Append

        $db = Invoke-Sqlcmd -ServerInstance $thisserver -Query "SELECT name FROM sys.databases WHERE state_desc = 'RECOVERY_PENDING' AND name <> 'SSISDB'" -Database "SF_SQL_Admin" 

        $db.name | foreach {
            "Restore-DpSqlBackup  " + $_ + " -Full -SqlServer ""$thisserver"" -FromSqlServer ""$prodserver"" -TSMOptFile ""$apppath$optfile"" -ConfigFile ""$apppath$cfgfile""" |
                Out-File $scriptpath -Append
        }

        "IF (!`$Error) { Invoke-Sqlcmd -ServerInstance $thisserver -Query ""UPDATE SF_TDP_Restore SET RecoveryComplete = 1, RecoveryEndTime = GETDATE() WHERE DBType = 'USER' AND RecoveryComplete = 0"" -Database ""SF_SQL_Admin""}
            ELSE { Invoke-Sqlcmd -ServerInstance $thisserver -Query ""UPDATE SF_TDP_Restore SET RecoveryComplete = null, RecoveryEndTime = null WHERE DBType = 'USER' AND RecoveryComplete = 0"" -Database ""SF_SQL_Admin""
                (Get-Date -format G).ToString() + ': ' | Out-File ""$logpath"" -Append
                    `$Error | ForEach {`$_ | Out-File ""$logpath"" -Append}}" |
            Out-File $scriptpath -Append
    }

    ### Error logging for this script.
    if ($Error) {
        (Get-Date -format G).ToString() + ': ' | Out-File $logpath -Append
        $Error | ForEach {$_ | Out-File $logpath -Append}
    }
}