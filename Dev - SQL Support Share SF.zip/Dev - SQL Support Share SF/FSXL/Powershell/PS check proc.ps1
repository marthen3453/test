﻿$cmd = "SELECT distinct CASE WHEN d.ENV_NM = 'MSSQLSERVER' THEN c.SRVR_CLSTR_NM ELSE c.SRVR_CLSTR_NM + '\' + d.ENV_NM END SQLSrv
, RTRIM(UPPER(c.SRVR_CLSTR_NM)) Srv
FROM SFSQL_CDRS..Dbase_App_Srvr_Clstr_Rltn a  
INNER JOIN SFSQL_CDRS..dbase_app b ON a.APP_ID = b.App_ID  
INNER JOIN SFSQL_CDRS..dbase_srvr c ON a.srvr_clstr_nm = c.srvr_clstr_nm  
INNER JOIN SFSQL_CDRS..INSTC d ON a.SRVR_CLSTR_NM = d.SRVR_CLSTR_NM  
where D.ENV_NM <> 'MSSQLSERVER'
and c.DOM_ENV_TXT IN ('OPR.STATEFARM.ORG', 'SUPPORT.STATEFARM.ORG')
and a.srvr_clstr_nm not like '%DR'"

$sqlservers = Invoke-Sqlcmd -ServerInstance "SQLPSQLI1.SUPPORT.STATEFARM.ORG" -Database SFSQL_CDRS -Query $cmd

"Server,Message" | Out-File C:\Users\Public\Documents\Projects\Powershell\Output.csv

foreach ($sql in $sqlservers) {
    if (Test-Connection $sql.Srv -Quiet -Count 1) {
            #Invoke-SqlCmd -ServerInstance $sql -Database SF_SQL_Admin -InputFile "C:\Users\Public\Documents\deploybk.sql"
            $q = Invoke-SqlCmd -ServerInstance $sql.sqlsrv -Database SF_SQL_Admin -Query "sp_helptext 'CheckForMissingBackups'"
            if ($q.Text[52] = "	DECLARE @alwayson_xepath varchar(max) = '';") {
                $sql.sqlsrv + "," + "Proc updated." | Out-File C:\Users\Public\Documents\Projects\Powershell\Output.csv -Append
            }
            else {
                $sql.sqlsrv + "," + "Proc is not updated." | Out-File C:\Users\Public\Documents\Projects\Powershell\Output.csv -Append
            }
    }
}