﻿# CDRS - SERVER: SQLPSQLI1.SUPPORT.STATEFARM.ORG  DATABASE: SFSQL_CDRS
# WSDB - SERVER: WSLD7RZ001,57751  DATABASE: dbDomainInfo

$list = Invoke-SqlCmd -ServerInstance "SQLPSQLI1.SUPPORT.STATEFARM.ORG" -Database SFSQL_CDRS -Query "
    SELECT DISTINCT RTRIM(UPPER(app_nm_txt)) App, RTRIM(UPPER(s.PHYS_SRVR_NM)) PhysicalName, RTRIM(UPPER(i.SQLVIRTUALNAME)) VirtualName, 
	    RTRIM(UPPER(s.SRVR_CLSTR_NM)) ClusterName, RTRIM(UPPER(i.ENV_NM)) Inst, RTRIM(UPPER(DOM_ENV_TXT)) Domain, da.InternalsOnlyInd InternalsOnly
    FROM dbo.INSTC i
    INNER JOIN DBASE_SRVR s ON i.SRVR_CLSTR_NM = s.SRVR_CLSTR_NM
	    INNER JOIN Dbase_App_Srvr_Clstr_Rltn dar ON dar.SRVR_CLSTR_NM = s.SRVR_CLSTR_NM  
	    INNER JOIN DBASE_APP da ON da.APP_ID = dar.App_ID  
    ORDER BY App"

$list2 = @()

$search = "ACTIMI"
foreach ($srv in $list) {
    if ($srv.App -like "*$search*" -or $srv.PhysicalName -like "*$search*" -or $srv.VirtualName -like "*$search*" -or $srv.ClusterName -like "*$search*") {
        $list2 += $srv 
    }
}


$ip = nslookup WTSDSXFS.OPR.SYSTEM.TEST.STATEFARM.ORG
($ip[4] -split '  ' )[1]