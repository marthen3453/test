﻿$cmd = "WITH cdrs 
AS (
SELECT DISTINCT CASE WHEN i.ENV_NM = 'MSSQLSERVER' 
	THEN s.SRVR_CLSTR_NM + '.' + s.DOM_ENV_TXT
	ELSE s.SRVR_CLSTR_NM + '.' + s.DOM_ENV_TXT + '\' + i.ENV_NM
	END SQLSrv, RTRIM(UPPER(s.SRVR_CLSTR_NM)) + '.' + s.DOM_ENV_TXT Srv, RTRIM(UPPER(da.app_nm_txt)) App, app_suprt_alias DBA, 
	s.DOM_ENV_TXT, i.PHYS_SRVR_NM, i.SRVR_CLSTR_NM
FROM [dbo].[INSTC] i
INNER JOIN DBASE_SRVR s ON i.SRVR_CLSTR_NM = s.SRVR_CLSTR_NM
INNER JOIN Dbase_App_Srvr_Clstr_Rltn dar ON dar.SRVR_CLSTR_NM = s.SRVR_CLSTR_NM  
INNER JOIN DBASE_APP da ON da.APP_ID = dar.App_ID
LEFT OUTER JOIN  APP_suprt aps ON UPPER(aps.app_nm_txt) = UPPER(da.app_nm_txt) AND aps.APP_SUPRT_TYPE = 'PrimaryDBA'
WHERE s.DOM_ENV_TXT IN ('UNITOPR.UNITINT.TEST.STATEFARM.ORG', 'OPR.SYSTEM.TEST.STATEFARM.ORG'))

SELECT c.SQLSrv, c.Srv, c.App, c.DBA, c.DOM_ENV_TXT
FROM  cdrs c
INNER JOIN [SQL_CDRS_WSDB].dbDomainInfo.dbo.[WSDBGeneralInfo_sfvw] w ON w.ServerName = COALESCE(c.PHYS_SRVR_NM, c.SRVR_CLSTR_NM)
WHERE w.[Machine Type] LIKE 'VMWare Virtual Machine'"

$sqlservers = Invoke-Sqlcmd -ServerInstance "SQLPSQLI1.SUPPORT.STATEFARM.ORG" -Database SFSQL_CDRS -Query $cmd

$cmd = "
SELECT (SELECT value from sys.configurations where name in ('max server memory (MB)')) MaxMem
,
(select ROUND(CAST(total_physical_memory_kb AS FLOAT) / 1024.0, 0) from sys.dm_os_sys_memory) PhysMem
,
(select cntr_value as counter_value
from sys.dm_os_performance_counters
where
	counter_name = 'Page life expectancy'
	and
	object_name LIKE '%Buffer Manager%') PLE
,
(select ROUND(CAST(cntr_value AS FLOAT) / 1024.0, 0) as counter_value
from sys.dm_os_performance_counters
where
	counter_name = 'Total Server Memory (KB)'
	and
	object_name LIKE '%Memory Manager%') SrvMem"

'Server,Application,DBA,Server Memory (MB), Total Physical Memory (MB), Max Memory (MB), PLE' | Out-File C:\Users\Public\Documents\Projects\Powershell\MemOutput.csv

foreach ($sql in $sqlservers) {
    if (Test-Connection $sql.Srv -Quiet -Count 1) {
        $mem = Invoke-Sqlcmd -ServerInstance $sql.SQLSrv -Query $cmd
        $sql.SQLSrv + ',' + $sql.App + ',' + $sql.DBA + ',' + $mem.SrvMem + ',' + $mem.PhysMem + ',' + $mem.MaxMem + ',' + $mem.PLE  | Out-File C:\Users\Public\Documents\Projects\Powershell\MemOutput.csv -Append
        $mem = $null
    }

    else {
        $sql.SQLSrv + ',' + $sql.App + ',' + 'Server Could not connect.'  | Out-File C:\Users\Public\Documents\Projects\Powershell\MemOutput.csv -Append
    }

    if ($Error -ne $null) {
        $sql.SQLSrv + ',' + $sql.App + ',' + 'SQL Could not connect.'  | Out-File C:\Users\Public\Documents\Projects\Powershell\MemOutput.csv -Append
        $Error.Clear()
    }

}