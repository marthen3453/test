﻿$cmd = "SELECT DISTINCT CASE WHEN i.ENV_NM = 'MSSQLSERVER' 
	THEN s.SRVR_CLSTR_NM
	ELSE s.SRVR_CLSTR_NM + '\' + i.ENV_NM
	END SQLSrv, RTRIM(UPPER(s.SRVR_CLSTR_NM)) Srv, RTRIM(UPPER(da.app_nm_txt)) App, app_suprt_alias DBA
FROM [dbo].[INSTC] i
INNER JOIN DBASE_SRVR s ON i.SRVR_CLSTR_NM = s.SRVR_CLSTR_NM
INNER JOIN Dbase_App_Srvr_Clstr_Rltn dar ON dar.SRVR_CLSTR_NM = s.SRVR_CLSTR_NM  
INNER JOIN DBASE_APP da ON da.APP_ID = dar.App_ID
LEFT OUTER JOIN  APP_suprt aps ON UPPER(aps.app_nm_txt) = UPPER(da.app_nm_txt) AND aps.APP_SUPRT_TYPE = 'PrimaryDBA'
WHERE s.DOM_ENV_TXT IN ('OPR.STATEFARM.ORG', 'SUPPORT.STATEFARM.ORG')
AND s.PHYS_SRVR_NM NOT LIKE '%DR'
ORDER BY App, SQLSrv"

#AND RTRIM(UPPER(app_nm_txt)) IN ('Business of Systems', 'Adaptive Authentication', 'efreedom', 'isam', 
#'tandberg management suite', 'trend micro deep security', 'esipt', 'flood claim tracking')

$sqlservers = Invoke-Sqlcmd -ServerInstance "SQLPSQLI1.SUPPORT.STATEFARM.ORG" -Database SFSQL_CDRS -Query $cmd

$cmd = "CREATE TABLE #tmp (dt datetime, pid varchar(256), txt varchar(max))

INSERT #tmp 
EXEC sp_readerrorlog 0, 1, 'Backup Mismatch'

SELECT @@SERVERNAME srvr, * FROM #tmp"

'"Server","DateTime","PID","Message"' | Out-File C:\Users\Public\Documents\Projects\Powershell\Output.csv

foreach ($sql in $sqlservers) {
    if (Test-Connection $sql.Srv -Quiet -Count 1) {
        $job = Invoke-Sqlcmd -ServerInstance $sql.SQLSrv -Query $cmd
        if ($job.count -ne $null) {
            foreach ($msg in $job) {
                '"' + $msg.srvr + '","' + $msg.dt + '","' + $msg.pid + '","' + $msg.txt + '"' | Out-File C:\Users\Public\Documents\Projects\Powershell\Output.csv -Append
            }
        }
    }

    else {
        '"' + $sql.SQLSrv + '","' + 'Could not connect."' | Out-File C:\Users\Public\Documents\Projects\Powershell\Output.csv -Append
    }
}