﻿$cmd = "SELECT DISTINCT CASE WHEN i.ENV_NM = 'MSSQLSERVER' 
	THEN s.SRVR_CLSTR_NM
	ELSE s.SRVR_CLSTR_NM + '\' + i.ENV_NM
	END SQLSrv, RTRIM(UPPER(s.SRVR_CLSTR_NM)) Srv, RTRIM(UPPER(da.app_nm_txt)) App, app_suprt_alias DBA
FROM [dbo].[INSTC] i
INNER JOIN DBASE_SRVR s ON i.SRVR_CLSTR_NM = s.SRVR_CLSTR_NM
INNER JOIN Dbase_App_Srvr_Clstr_Rltn dar ON dar.SRVR_CLSTR_NM = s.SRVR_CLSTR_NM  
INNER JOIN DBASE_APP da ON da.APP_ID = dar.App_ID
LEFT OUTER JOIN  APP_suprt aps ON UPPER(aps.app_nm_txt) = UPPER(da.app_nm_txt) AND aps.APP_SUPRT_TYPE = 'PrimaryDBA'
WHERE s.DOM_ENV_TXT IN ('OPR.STATEFARM.ORG', 'SUPPORT.STATEFARM.ORG')
AND s.PHYS_SRVR_NM NOT LIKE '%DR'
ORDER BY App, SQLSrv"

#AND RTRIM(UPPER(app_nm_txt)) IN ('Business of Systems', 'Adaptive Authentication', 'efreedom', 'isam', 
#'tandberg management suite', 'trend micro deep security', 'esipt', 'flood claim tracking')

$sqlservers = Invoke-Sqlcmd -ServerInstance "SQLPSQLI1.SUPPORT.STATEFARM.ORG" -Database SFSQL_CDRS -Query $cmd

$cmd = "SELECT TOP 1 name, COALESCE(schedule_id, -1) schedule_id
FROM msdb..sysjobs sj
LEFT OUTER JOIN msdb..sysjobschedules sjs ON sjs.job_id = sj.job_id
WHERE name = 'SF_SQL_Admin TDP Backup Compare'"

'"Message","Server","Application","Primary DBA"' | Out-File C:\Users\Public\Documents\Projects\Powershell\Output.csv

foreach ($sql in $sqlservers) {
    if (Test-Connection $sql.Srv -Quiet -Count 1) {
        $job = Invoke-Sqlcmd -ServerInstance $sql.SQLSrv -Query $cmd
        if ($job.name -eq $null) {
            '"Job does not exist.","' + $sql.SQLSrv + '","' + $sql.App + '","' + $sql.DBA + '"' | Out-File C:\Users\Public\Documents\Projects\Powershell\Output.csv -Append
            continue
        }

        if ($job.schedule_id -eq $null -or $job.schedule_id -eq -1) {
            '"Job has no schedule.","' + $sql.SQLSrv + '","' + $sql.App + '","' + $sql.DBA + '"' | Out-File C:\Users\Public\Documents\Projects\Powershell\Output.csv -Append
            continue
        }

        '"Job exists and has been scheduled.","' + $sql.SQLSrv + '","' + $sql.App + '","' + $sql.DBA + '"' | Out-File C:\Users\Public\Documents\Projects\Powershell\Output.csv -Append
    }

    else {
        '"Could not connect.","' + $sql.SQLSrv + '","' + $sql.App + '","' + $sql.DBA + '"' | Out-File C:\Users\Public\Documents\Projects\Powershell\Output.csv -Append
    }
}