﻿# CDRS - SERVER: SQLPSQLI1.SUPPORT.STATEFARM.ORG  DATABASE: SFSQL_CDRS
# WSDB - SERVER: WSLD7RZ001,57751  DATABASE: dbDomainInfo

### FUNCTION DEFINITIONS
function buildapplist {
    $Global:list  = Invoke-SqlCmd -ServerInstance "SQLPSQLI1.SUPPORT.STATEFARM.ORG" -Database SFSQL_CDRS -Query "
        SELECT DISTINCT RTRIM(UPPER(app_nm_txt)) App, RTRIM(UPPER(s.PHYS_SRVR_NM)) PhysicalName, RTRIM(UPPER(i.SQLVIRTUALNAME)) VirtualName, 
	        RTRIM(UPPER(s.SRVR_CLSTR_NM)) ClusterName, RTRIM(UPPER(i.ENV_NM)) Inst, RTRIM(UPPER(DOM_ENV_TXT)) Domain, da.InternalsOnlyInd InternalsOnly
        FROM dbo.INSTC i
        INNER JOIN DBASE_SRVR s ON i.SRVR_CLSTR_NM = s.SRVR_CLSTR_NM
	        INNER JOIN Dbase_App_Srvr_Clstr_Rltn dar ON dar.SRVR_CLSTR_NM = s.SRVR_CLSTR_NM  
	        INNER JOIN DBASE_APP da ON da.APP_ID = dar.App_ID  
        ORDER BY App"
}

function getCDRS {
    $cdrs = Invoke-SqlCmd -ServerInstance SQLPSQLI1.SUPPORT.STATEFARM.ORG -Database SFSQL_CDRS -Query "SELECT DISTINCT i.SFTWR_PROD_NM ProductVersion, i.SFTWR_PROD_VER_NM VersionNumber, i.SQL_SERV_ACCT_TXT ServiceAccount, 
	    i.PORT_NUM PortNumber
        FROM dbo.INSTC i
        WHERE (i.PHYS_SRVR_NM = '$search' OR i.SRVR_CLSTR_NM = '$search')"

    $textBox_ProductVersion.Text = $cdrs.ProductVersion
    $textBox_VersionNumber.Text = $cdrs.VersionNumber
    $textBox_ServiceAccount.Text = $cdrs.ServiceAccount
    $textBox_Port.Text = $cdrs.PortNumber
    #$textBox_InternalsOnly.Text = $dataGrid_Search.SelectedIndex
    
    $contacts = Invoke-SqlCmd -ServerInstance SQLPSQLI1.SUPPORT.STATEFARM.ORG -Database SFSQL_CDRS -Query "SELECT  APP_SUPRT_ALIAS Alias, APP_SUPRT_NM Name, APP_SUPRT_TYPE Type, SUPRT_GRP_NM_TXT Workgroup
        FROM APP_suprt
        WHERE APP_NM_TXT = 'ACTIMIZE'
        ORDER BY Type"

    $dtContacts.Rows.Clear()

    foreach ($ct in $contacts) {
        
        $dr = $dtContacts.NewRow()
        $dr.Item('Alias') = $ct.Alias
        $dr.Item('Name') = $ct.Name
        $dr.Item('Type') = $ct.Type
        $dr.Item('Workgroup') = $ct.Workgroup
        $dtContacts.Rows.Add($dr)

    }
    
    $dataGrid_Contacts.ItemsSource = $dtContacts.DefaultView
}

function getWSDB {
    $wsdb = Invoke-SqlCmd -ServerInstance "WSLD7RZ001,57751" -Database "dbDomainInfo" -Query "SELECT TOP 1 Location, [Machine Type] MachineType, [Initial Install Date] InstallDate, BehindFirewall, [Operating System] OperatingSystem, 
	    [Organizational Unit] OrganizationalUnit, [Time Zone] TimeZone, Processors, [Memory Size] Memory, [Host Group] HostGroup
        FROM WSDBGeneralInfo_sfvw WHERE servername = '$search'"

    $textBox_Firewall.Text = $wsdb.BehindFirewall
    $textBox_HostGroup.Text = $wsdb.HostGroup
    $textBox_Type.Text = $wsdb.MachineType
    $textBox_InstallDate.Text = $wsdb.InstallDate
    $textBox_OperatingSystem.Text = $wsdb.OperatingSystem
    $textBox_TimeZone.Text = $wsdb.TimeZone
    $textBox_OU.Text = $wsdb.OrganizationalUnit
    $textBox_Processors.Text = $wsdb.Processors
    $textBox_Memory.Text = $wsdb.Memory
    $textBox_Location.Text = $wsdb.Location
}

function getSCOM {

}


### LOAD XML OBJECTS
C:\Users\Public\Documents\Projects\ServerLookup\loadapp.ps1 -XamlPath 'C:\Users\Public\Documents\Projects\ServerLookup\xaml.txt'

### BUILD INITIAL APPLICATION LIST
buildapplist

### SETUP GLOBAL VARS (TABLES)
[System.Data.DataTable] $dtSearch = $null
[System.Data.DataTable] $dtContacts = $null
[System.Data.DataColumn] $dc = $null
[System.Data.DataRow] $dr = $null

$dtSearch = New-Object Data.DataTable
$dc = New-Object Data.DataColumn("Application", [string])
$dtSearch.Columns.Add($dc)
$dc = New-Object Data.DataColumn("PhysicalName", [string])
$dtSearch.Columns.Add($dc)
$dc = New-Object Data.DataColumn("VirtualName", [string])
$dtSearch.Columns.Add($dc)
$dc = New-Object Data.DataColumn("Instance", [string])
$dtSearch.Columns.Add($dc)
$dc = New-Object Data.DataColumn("Domain", [string])
$dtSearch.Columns.Add($dc)

$dtContacts = New-Object Data.DataTable
$dc = New-Object Data.DataColumn("Alias", [string])
$dtContacts.Columns.Add($dc)
$dc = New-Object Data.DataColumn("Name", [string])
$dtContacts.Columns.Add($dc)
$dc = New-Object Data.DataColumn("Type", [string])
$dtContacts.Columns.Add($dc)
$dc = New-Object Data.DataColumn("WorkGroup", [string])
$dtContacts.Columns.Add($dc)


### EVENTS
# TEXT CHANGED ON SEARCH
$textBox_Search.Add_TextChanged({
    $dtSearch.Rows.Clear()

    $search = $textBox_Search.Text
    foreach ($srv in $list) {
        if ($srv.App -like "*$search*" -or $srv.PhysicalName -like "*$search*" -or $srv.VirtualName -like "*$search*" -or $srv.ClusterName -like "*$search*") {
            $dr = $dtSearch.NewRow()
            $dr.Item('Application') = $srv.App
            $dr.Item('PhysicalName') = $srv.PhysicalName
            $dr.Item('VirtualName') = $srv.VirtualName
            $dr.Item('Instance') = $srv.Inst
            $dr.Item('Domain') = $srv.Domain
            $dtSearch.Rows.Add($dr)
        }
    }
    
    $dataGrid_Search.ItemsSource = $dtSearch.DefaultView
})


# SHOW SCOM DISKS BUTTON CLICK
$button_SCOMDisk.Add_Click({

})


# SEARCH GRID SELECTION
$dataGrid_Search.Add_SelectionChanged({
    If ($dataGrid_Search.SelectedItem -ne $null) {
        $Global:search = $dataGrid_Search.SelectedItem.PhysicalName

        getWSDB
        getCDRS
    }
})

### DISPLAY GUI
$xamGUI.WindowStartupLocation = "CenterScreen"
$xamGUI.ShowDialog() | Out-Null