﻿## Enter FQDN of server:
$server = ""

## Enter instance name of primary SQL instance:
$primarysqlinstance = ""


$sql = @"
    IF EXISTS (SELECT name FROM sys.objects WHERE name = 'Perf_CounterData' AND type_desc = 'USER_TABLE')
	    DROP TABLE Perf_CounterData;
    GO
    IF EXISTS (SELECT name FROM sys.objects WHERE name = 'Perf_FileSpace')
    DROP TABLE Perf_FileSpace
    GO
    IF EXISTS (SELECT name FROM sys.objects WHERE name = 'Perf_IndexUsageDatabases')
    DROP TABLE Perf_IndexUsageDatabases
    GO
    IF EXISTS (SELECT name FROM sys.objects WHERE name = 'Perf_IndexUsageStatistics')
    DROP TABLE Perf_IndexUsageStatistics
    GO
    IF EXISTS (SELECT name FROM sys.objects WHERE name = 'Perf_IndexUsageStatistics_Stage')
    DROP TABLE Perf_IndexUsageStatistics_Stage
    GO
    IF EXISTS (SELECT name FROM sys.objects WHERE name = 'Perf_PrimaryInstance')
    DROP TABLE Perf_PrimaryInstance
    GO
    IF EXISTS (SELECT name FROM sys.objects WHERE name = 'Perf_Sessions')
    DROP TABLE Perf_Sessions
    GO
    IF EXISTS (SELECT name FROM sys.objects WHERE name = 'usp_Perf_CollectIndexUsage')
    DROP PROC usp_Perf_CollectIndexUsage
    GO
    IF EXISTS (SELECT name FROM sys.objects WHERE name = 'usp_Perf_IndexUsageReport')
    DROP PROC usp_Perf_IndexUsageReport
    GO
    IF EXISTS (SELECT name FROM sys.objects WHERE name = 'v_Perf_CounterData')
    DROP VIEW v_Perf_CounterData
    GO
    IF EXISTS (SELECT name FROM sys.objects WHERE name = 'Perf_CounterData' AND type_desc = 'SYNONYM')
    DROP SYNONYM Perf_CounterData
    GO

    IF EXISTS (SELECT name FROM msdb..sysjobs WHERE name = 'SF_SQL_Admin Perf_Collect')
    EXEC msdb.dbo.sp_delete_job @job_name='SF_SQL_Admin Perf_Collect', @delete_unused_schedule=1
"@

$batches = $sql -split "GO\r\n"
$connectionString = "Data Source=$server\$primarysqlinstance;Integrated Security=SSPI;Database=SF_SQL_Admin"
$connection = New-Object System.Data.SqlClient.SQLConnection($connectionString)
$connection.Open()
$batches | foreach {
    $cmd = New-Object System.Data.SqlClient.SqlCommand ($_, $connection)
    $cmd.CommandText = $cmd.CommandText -replace "GO", ""
    $cmd.ExecuteNonQuery() | Out-Null
}
$connection.Close()

Remove-Item C:\DATA\SQL\SF_SQL_Admin\SF_PS_Perf_CollectCounters.ps1