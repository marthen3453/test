USE [SF_SQL_Admin];
GO

CREATE TABLE [dbo].[Perf_CounterData](
	[CollectionTime] [smalldatetime] NULL,
	[Class] [varchar](512) NULL,
	[Counter] [varchar](512) NULL,
	[Instance] [varchar](512) NULL,
	[Value] [float] NULL);
GO

CREATE CLUSTERED INDEX [CIX_Perf_CounterData] ON [dbo].[Perf_CounterData] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE [dbo].[Perf_FileSpace](
	[CollectionTime] [smalldatetime] NULL,
	[InstanceName] [varchar](512) NULL,
	[DBName] [varchar](512) NULL,
	[FileName] [varchar](512) NULL,
	[FileGroup] [varchar](512) NULL,
	[Type] [varchar](128) NULL,
	[Size] [int] NULL,
	[Used] [int] NULL);
GO

CREATE CLUSTERED INDEX [CIX_Perf_FileSpace] ON [dbo].[Perf_FileSpace] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE [dbo].[Perf_IndexUsageDatabases](
	[DatabaseName] [nvarchar](512) NULL);
GO

CREATE TABLE [dbo].[Perf_IndexUsageStatistics](
	[LastStartUp] [datetime] NULL,
	[DatabaseName] [nvarchar](512) NULL,
	[TableName] [nvarchar](512) NULL,
	[IndexName] [nvarchar](512) NULL,
	[IndexType] [nvarchar](128) NULL,
	[UserSeeks] [bigint] NULL,
	[SystemSeeks] [bigint] NULL,
	[UserScans] [bigint] NULL,
	[SystemScans] [bigint] NULL,
	[UserLookups] [bigint] NULL,
	[SystemLookups] [bigint] NULL,
	[UserUpdates] [bigint] NULL,
	[SystemUpdates] [bigint] NULL);
GO

CREATE TABLE [dbo].[Perf_IndexUsageStatistics_Stage](
	[LastStartUp] [datetime] NULL,
	[DatabaseName] [nvarchar](512) NULL,
	[TableName] [nvarchar](512) NULL,
	[IndexName] [nvarchar](512) NULL,
	[IndexType] [nvarchar](128) NULL,
	[UserSeeks] [bigint] NULL,
	[SystemSeeks] [bigint] NULL,
	[UserScans] [bigint] NULL,
	[SystemScans] [bigint] NULL,
	[UserLookups] [bigint] NULL,
	[SystemLookups] [bigint] NULL,
	[UserUpdates] [bigint] NULL,
	[SystemUpdates] [bigint] NULL);

GO

CREATE TABLE [dbo].[Perf_PrimaryInstance](
	[InstanceName] [varchar](512) NULL);
GO

CREATE TABLE [dbo].[Perf_Sessions](
	[CollectionTime] [smalldatetime] NULL,
	[LoginTime] [datetime] NULL,
	[SPID] [int] NULL,
	[Status] [varchar](24) NULL,
	[DBName] [varchar](128) NULL,
	[HostName] [varchar](128) NULL,
	[ApplicationName] [varchar](128) NULL,
	[LoginName] [varchar](128) NULL,
	[CPUTime] [int] NULL,
	[Reads] [int] NULL,
	[Writes] [int] NULL,
	[Lastread] [smalldatetime] NULL,
	[LastWrite] [smalldatetime] NULL,
	[SQLText] [varchar](max) NULL);
GO

CREATE CLUSTERED INDEX [CIX_Perf_Sessions] ON [dbo].[Perf_Sessions] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);
GO


CREATE TABLE [dbo].[Perf_WaitStatistics](
	[CollectionTime] [datetime] NULL,
	[WaitType] [varchar](256) NULL,
	[Wait_S] [float] NULL,
	[Resource_S] [float] NULL,
	[Signal_S] [float] NULL,
	[WaitCount] [int] NULL,
	[Percentage] [float] NULL,
	[AvgWait_S] [float] NULL,
	[AvgRes_S] [float] NULL,
	[AvgSig_S] [float] NULL);
GO

CREATE CLUSTERED INDEX [CIX_Perf_WaitStatistics] ON [dbo].[Perf_WaitStatistics] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);