-- TABLES/OBJECTS CREATION

USE [SF_SQL_Admin];
GO

CREATE TABLE [dbo].[Perf_CounterData](
	[CollectionTime] [smalldatetime] NULL,
	[Class] [varchar](512) NULL,
	[Counter] [varchar](512) NULL,
	[Instance] [varchar](512) NULL,
	[Value] [float] NULL);
GO

CREATE CLUSTERED INDEX [CIX_Perf_CounterData] ON [dbo].[Perf_CounterData] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE [dbo].[Perf_FileSpace](
	[CollectionTime] [smalldatetime] NULL,
	[InstanceName] [varchar](512) NULL,
	[DBName] [varchar](512) NULL,
	[FileName] [varchar](512) NULL,
	[FileGroup] [varchar](512) NULL,
	[Type] [varchar](128) NULL,
	[Size] [int] NULL,
	[Used] [int] NULL);
GO

CREATE CLUSTERED INDEX [CIX_Perf_FileSpace] ON [dbo].[Perf_FileSpace] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE [dbo].[Perf_IndexUsageDatabases](
	[DatabaseName] [nvarchar](512) NULL);
GO

CREATE TABLE [dbo].[Perf_IndexUsageStatistics](
	[LastStartUp] [datetime] NULL,
	[DatabaseName] [nvarchar](512) NULL,
	[TableName] [nvarchar](512) NULL,
	[IndexName] [nvarchar](512) NULL,
	[IndexType] [nvarchar](128) NULL,
	[UserSeeks] [bigint] NULL,
	[SystemSeeks] [bigint] NULL,
	[UserScans] [bigint] NULL,
	[SystemScans] [bigint] NULL,
	[UserLookups] [bigint] NULL,
	[SystemLookups] [bigint] NULL,
	[UserUpdates] [bigint] NULL,
	[SystemUpdates] [bigint] NULL);
GO

CREATE CLUSTERED INDEX  [CIX_Perf_IndexUsageStatistics] ON [dbo].[Perf_IndexUsageStatistics] (LastStartUp) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE [dbo].[Perf_IndexUsageStatistics_Stage](
	[LastStartUp] [datetime] NULL,
	[DatabaseName] [nvarchar](512) NULL,
	[TableName] [nvarchar](512) NULL,
	[IndexName] [nvarchar](512) NULL,
	[IndexType] [nvarchar](128) NULL,
	[UserSeeks] [bigint] NULL,
	[SystemSeeks] [bigint] NULL,
	[UserScans] [bigint] NULL,
	[SystemScans] [bigint] NULL,
	[UserLookups] [bigint] NULL,
	[SystemLookups] [bigint] NULL,
	[UserUpdates] [bigint] NULL,
	[SystemUpdates] [bigint] NULL);

GO

CREATE TABLE [dbo].[Perf_PrimaryInstance](
	[InstanceName] [varchar](512) NULL);
GO

CREATE TABLE [dbo].[Perf_Sessions](
	[CollectionTime] [smalldatetime] NULL,
	[LoginTime] [datetime] NULL,
	[SPID] [int] NULL,
	[Status] [varchar](24) NULL,
	[DBName] [varchar](128) NULL,
	[HostName] [varchar](128) NULL,
	[ApplicationName] [varchar](128) NULL,
	[LoginName] [varchar](128) NULL,
	[CPUTime] [int] NULL,
	[Reads] [int] NULL,
	[Writes] [int] NULL,
	[Lastread] [smalldatetime] NULL,
	[LastWrite] [smalldatetime] NULL,
	[SQLText] [varchar](max) NULL);
GO

CREATE CLUSTERED INDEX [CIX_Perf_Sessions] ON [dbo].[Perf_Sessions] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);
GO


CREATE TABLE [dbo].[Perf_WaitStatistics](
	[CollectionTime] [datetime] NULL,
	[WaitType] [varchar](256) NULL,
	[Wait_S] [float] NULL,
	[Resource_S] [float] NULL,
	[Signal_S] [float] NULL,
	[WaitCount] [int] NULL,
	[Percentage] [float] NULL,
	[AvgWait_S] [float] NULL,
	[AvgRes_S] [float] NULL,
	[AvgSig_S] [float] NULL);
GO

CREATE CLUSTERED INDEX [CIX_Perf_WaitStatistics] ON [dbo].[Perf_WaitStatistics] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE Perf_Counters (Counter varchar(1024), SelectList varchar(1024), Filter varchar(1024));
GO

INSERT Perf_Counters VALUES
	('\Processor(_Total)\% Processor Time', 'Path, InstanceName, CookedValue', ''),
	('\LogicalDisk(*)\Disk Reads/sec', 'Path, InstanceName, CookedValue', 'InstanceName -ne "_total"'),
	('\LogicalDisk(*)\Disk Writes/sec', 'Path, InstanceName, CookedValue', 'InstanceName -ne "_total"'),
	('\LogicalDisk(*)\Avg. Disk sec/Read', 'Path, InstanceName, CookedValue', 'InstanceName -ne "_total"'),
	('\LogicalDisk(*)\Avg. Disk sec/Write', 'Path, InstanceName, CookedValue', 'InstanceName -ne "_total"'),
	('\LogicalDisk(*)\% Free Space', 'Path, InstanceName, CookedValue', 'InstanceName -ne "_total"'),
	('\LogicalDisk(*)\Free Megabytes', 'Path, InstanceName, CookedValue', 'InstanceName -ne "_total"'),
	('\Memory\Pages/sec', 'Path, InstanceName, CookedValue', ''),
	('\Memory\Available MBytes', 'Path, InstanceName, CookedValue', ''),
	('\Memory\Pages Input/sec', 'Path, InstanceName, CookedValue', ''),
	('\Paging File(*)\% Usage', 'Path, InstanceName, CookedValue', 'InstanceName -ne "_total"'),
	('\Paging File(*)\% Usage Peak', 'Path, InstanceName, CookedValue', 'InstanceName -ne "_total"'),
	('\Process(*)\% Processor Time', 'Path, InstanceName, @{Name="CookedValue";Expression={$_.CookedValue / $proccount}}', 'InstanceName -Like "sqlservr*"');
GO

CREATE TABLE Perf_Timers (TimerName varchar(24), TimeValue smallint);
GO

INSERT Perf_Timers VALUES ('Collection', 5), ('Retention', 120);
GO



-- STORED PROCEDURES 
USE [SF_SQL_Admin]
GO

CREATE PROC [dbo].[usp_Perf_CollectIndexUsage]
AS
BEGIN
	DECLARE @name varchar(512), @cmd varchar(max);

	TRUNCATE TABLE Perf_IndexUsageStatistics_Stage;
	
	DECLARE getstats CURSOR STATIC
	FOR
	SELECT DatabaseName FROM Perf_IndexUsageDatabases;

	OPEN getstats;

	FETCH NEXT FROM getstats INTO @name
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @cmd = '	SELECT (SELECT sqlserver_start_time FROM sys.dm_os_sys_info) LastStartUp,
			DB_NAME(database_id) DatabaseName, o.name TableName, i.name IndexName,
			i.type_desc IndexType, user_seeks, system_seeks, user_scans, system_scans,
			user_lookups, system_lookups, user_updates, system_updates
			FROM ' + @name + '.sys.dm_db_index_usage_stats ius
			INNER JOIN ' + @name + '.sys.objects o ON o.object_id = ius.object_id
			INNER JOIN ' + @name + '.sys.indexes i ON i.object_id = o.object_id 
			AND i.index_id = ius.index_id
			WHERE ius.database_id = DB_ID(''' + @name + ''')';

		INSERT Perf_IndexUsageStatistics_Stage (LastStartUp, DatabaseName, TableName, IndexName, 
			IndexType, UserSeeks, SystemSeeks, UserScans, SystemScans, UserLookups, 
			SystemLookups, UserUpdates, SystemUpdates)
		EXEC (@cmd);

		FETCH NEXT FROM getstats INTO @name;
	END;

	CLOSE getstats;
	DEALLOCATE getstats;
	
	MERGE Perf_IndexUsageStatistics AS t
	USING (SELECT LastStartUp, DatabaseName, TableName, IndexName, 
		IndexType, UserSeeks, SystemSeeks, UserScans, SystemScans, UserLookups, 
		SystemLookups, UserUpdates, SystemUpdates FROM Perf_IndexUsageStatistics_Stage) AS s
	ON (s.LastStartUp = t.LastStartUp AND s.DatabaseName = t.DatabaseName AND 
		s.TableName = t.TableName AND s.IndexName = t.IndexName)
	WHEN MATCHED THEN
		UPDATE SET t.UserSeeks = s.UserSeeks, t.SystemSeeks = s.SystemSeeks, t.UserScans = s.UserScans, 
		t.SystemScans = s.SystemScans, t.UserLookups = s.UserLookups, t.SystemLookups = s.SystemLookups, 
		t.UserUpdates = s.UserUpdates, t.SystemUpdates = s.SystemUpdates
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (LastStartUp, DatabaseName, TableName, IndexName, 
		IndexType, UserSeeks, SystemSeeks, UserScans, SystemScans, UserLookups, 
		SystemLookups, UserUpdates, SystemUpdates)
		VALUES (s.LastStartUp, s.DatabaseName, s.TableName, s.IndexName, 
		s.IndexType, s.UserSeeks, s.SystemSeeks, s.UserScans, s.SystemScans, s.UserLookups, 
		s.SystemLookups, s.UserUpdates, s.SystemUpdates);

	TRUNCATE TABLE Perf_IndexUsageStatistics_Stage;
END;
GO


USE [SF_SQL_Admin]
GO

CREATE PROC [dbo].[usp_Perf_IndexUsageReport]
AS
BEGIN
	WITH idx
	AS (
		SELECT DatabaseName, TableName, IndexName, IndexType, SUM(UserSeeks + UserScans + UserLookups + 
			SystemSeeks + SystemScans + SystemLookups) Accesses, SUM(UserUpdates + SystemUpdates) Updates
		FROM Perf_IndexUsageStatistics
		GROUP BY DatabaseName, TableName, IndexName, IndexType)

	SELECT DatabaseName, TableName, IndexName, IndexType, Accesses, Updates,
		CASE 
			WHEN Updates = 0 THEN Accesses 
			ELSE CAST(Accesses AS float) / CAST(Updates AS float) * 100 
		END UpdateToAccessRatio
	FROM idx
	ORDER BY UpdateToAccessRatio;
END;
GO


-- JOBS
USE [msdb]
GO

/****** Object:  Job [SF_SQL_Admin Perf_Collect]    Script Date: 5/26/2016 9:58:07 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 5/26/2016 9:58:08 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SF_SQL_Admin Perf_Collect', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sfsa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PS_CounterData]    Script Date: 5/26/2016 9:58:08 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PS_CounterData', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe C:\DATA\SQL\SF_SQL_Admin\SF_PS_Perf_CollectCounters.ps1', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SQL_Sessions]    Script Date: 5/26/2016 9:58:08 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SQL_Sessions', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'INSERT Perf_Sessions
SELECT GETDATE(), login_time, ec.session_id, status, DB_NAME(database_id), host_name, 
program_name, login_name, cpu_time, reads, writes, last_read, last_write, text
FROM sys.dm_exec_connections ec
INNER JOIN sys.dm_exec_sessions es ON es.session_id = ec.session_id
CROSS APPLY sys.dm_exec_sql_text(most_recent_sql_handle);', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SQL_FileSpace]    Script Date: 5/26/2016 9:58:08 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SQL_FileSpace', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @tbl TABLE (InstanceName varchar(512), DBName varchar(512), FileName varchar(512), 
	DataSpaceID int, Type varchar(16), Size decimal(10,2), Used decimal(10,2));

INSERT @tbl
EXEC sp_msforeachdb ''USE [?]
SELECT @@SERVERNAME,
DB_NAME(), name, data_space_id, type_desc,
size/128.0, 
CAST(FILEPROPERTY(name, ''''SpaceUsed'''')/128.0 AS DECIMAL(10,2))
FROM sys.database_files'';

INSERT Perf_FileSpace
SELECT GETDATE(), InstanceName, DBName, FileName, COALESCE(name, ''PRIMARY'') FileGroup, t.Type, 
Size, Used
FROM @tbl t
LEFT OUTER JOIN sys.filegroups fg ON t.DataSpaceID = fg.data_space_id
ORDER BY DBName, t.Type desc;

', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SQL_Counters]    Script Date: 5/26/2016 9:58:08 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SQL_Counters', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*	Counter type rules per MSDN:
	65792 - value as of query time
	1073939712 - base value used to calculate 537003264
		(537003264 value / 1073939712 value)
	272696576 - two samples divided by time
		(value2 - value1) / interval seconds
	1073874176 - uses base value of 1073939712 - two samples each
		(value2 - value1) / (base2 - base1)
*/

-- Amount of time to wait between samples.
DECLARE @wait datetime = ''00:00:10'';
DECLARE @time datetime = GETDATE();

-- Two sample tables and final result set table.  
-- The final result set stores the counter values as varchar for easy formatting
-- such as including % signs, etc.
DECLARE @one AS TABLE (object_name varchar(512), counter_name varchar(512), instance_name varchar(512), cntr_value float, cntr_type int);
DECLARE @two AS TABLE (object_name varchar(512), counter_name varchar(512), instance_name varchar(512), cntr_value float, cntr_type int);
DECLARE @result AS TABLE (collectiontime smalldatetime, object_name varchar(512), counter_name varchar(512), instance_name varchar(512), cntr_value float)

-- Collect the first sample, minus type 65792 (realtime).
INSERT @one 
	SELECT * 
	FROM sys.dm_os_performance_counters
	WHERE cntr_type <> 65792;

-- Wait.
WAITFOR DELAY @wait;

-- Collect the second sample.  Note - filtering of counters can be done at this level to
-- reduce server processing (which is fairly light), be sure the filter matches in both
-- sample sets though.
INSERT @two 
	SELECT * 
	FROM sys.dm_os_performance_counters
	WHERE cntr_type <> 65792;

-- CTE''s will get the base data needed for calculations from the sample tables.
-- This CTE joins the value and base value from the second sample for calculation
-- for the counter type 537003264.
-- Note - This could be pulled directly from the DMV, but I have left it as-is
-- as I am unsure of the accuracy.  This is the MSDN formula, but it may be better
-- to compare both samples for the calculation.
WITH perf_537003264
AS (
	SELECT a.object_name, a.counter_name, a.instance_name, 
		CAST(a.cntr_value AS float) value, CAST(b.cntr_value AS float) base
	FROM @two a
	INNER JOIN @two b ON a.object_name = b.object_name 
		AND a.counter_name = REPLACE(b.counter_name, '' Base'', '''')
		AND a.instance_name = b.instance_name
	WHERE a.cntr_type = 537003264
	AND b.cntr_type = 1073939712
),

-- This CTE gets both sample values for the counter type 272696576 to be divided 
-- by time passed.
perf_272696576
AS (
	SELECT a.object_name, a.counter_name, a.instance_name, 
		CAST(a.cntr_value AS float) value1, CAST(b.cntr_value AS float) value2
	FROM @one a
	INNER JOIN @two b ON a.object_name = b.object_name 
		AND a.counter_name = b.counter_name
		AND a.instance_name = b.instance_name
		AND a.cntr_type = b.cntr_type	
	WHERE a.cntr_type = 272696576
),

-- The next three CTE''s are used to calculate the value for counter type 1073874176.
-- This one suffers from many complexities caused by mismatched naming
-- conventions - thanks Microsoft!  The first CTE gets the two sample values
-- for the main value counter type.
perf_1073874176
AS (
	SELECT a.object_name, a.counter_name, a.instance_name, 
		CAST(a.cntr_value AS float) value1, CAST(b.cntr_value AS float) value2
	FROM @one a
	INNER JOIN @two b ON a.object_name = b.object_name 
		AND a.counter_name = b.counter_name
		AND a.instance_name = b.instance_name
		AND a.cntr_type = b.cntr_type	
	WHERE a.cntr_type = 1073874176
),

-- This CTE gets the two sample values for the base counter type to be used
-- in calculating the above counter type.
perf_1073939712
AS (
	SELECT a.object_name, a.counter_name, a.instance_name, 
		CAST(a.cntr_value AS float) value1, CAST(b.cntr_value AS float) value2
	FROM @one a
	INNER JOIN @two b ON a.object_name = b.object_name 
		AND a.counter_name = b.counter_name
		AND a.instance_name = b.instance_name
		AND a.cntr_type = b.cntr_type	
	WHERE a.cntr_type = 1073939712
),

-- This CTE is where it gets weirder.  Because of poor naming, a UNION
-- was needed to combine the base and value types properly to return all
-- possible instances.  The difference between samples is calculated here
-- to make the division operation easier later.
perf_1073874176_1073939712
AS (
	SELECT a.object_name, a.counter_name, a.instance_name, a.value2 - a.value1 value, b.value2 - b.value1 base 
	FROM perf_1073874176 a
	INNER JOIN perf_1073939712 b ON a.instance_name = b.instance_name
		AND REPLACE(a.counter_name, '' (ms)'', '''') = REPLACE(REPLACE(REPLACE(b.counter_name, '' BS'', ''''), '' (ms)'', ''''), '' base'', '''')
		AND a.object_name = b.object_name

	UNION

	SELECT a.object_name, a.counter_name, a.instance_name, a.value2 - a.value1 value, b.value2 - b.value1 base 
	FROM perf_1073874176 a
	INNER JOIN perf_1073939712 b ON a.instance_name = b.instance_name
		AND REPLACE(REPLACE(REPLACE(a.counter_name, ''Avg '', ''''), ''Avg. '', ''''), '' (ms)'', '''') = REPLACE(REPLACE(b.counter_name, '' (ms)'', ''''), '' base'', '''')
		AND a.object_name = b.object_name
)

-- Now it is time to calculate all values and insert them into the final result set.
-- UNION ALLs are used to make each calculation a separate entity.
-- First up, the type 537003264 is a simple value divided by base (catching /0).
INSERT @result
SELECT @time, object_name, counter_name, instance_name, 
	CASE WHEN base = 0 THEN 0 ELSE value / base END
FROM perf_537003264

UNION ALL

-- This is the calculation for type 272696576, using the wait value in seconds.
SELECT @time, object_name, counter_name, instance_name, 
	(value2 - value1) / DATEPART(s, @wait)
FROM perf_272696576

UNION ALL

-- This is the calculation for type 1073874176, by this point it is a simple
-- division of value and base (checking for /0 errors).
SELECT @time, object_name, counter_name, instance_name, 
	CASE WHEN base = 0 THEN 0 ELSE value / base END
	FROM perf_1073874176_1073939712

UNION ALL

-- The final select just grabs the counter type 65792, which is "realtime".
SELECT @time, object_name, counter_name, instance_name, cntr_value
FROM sys.dm_os_performance_counters
WHERE cntr_type = 65792;

-- The final result set.  This is where filtering could be easily handled
-- to keep the code above (a little more) readable.  An insert to a physical
-- table in the admin database could be added here as well for a recurring job
-- to capture historical performance (and can easily convert into a proc for
-- the same purpose).
WITH result
AS (
	SELECT CollectionTime, SUBSTRING(object_name, CHARINDEX('':'', object_name, 0) + 1, LEN(object_name)) Object_Name, 
		Counter_Name, Instance_Name, Cntr_Value
	FROM @result)

INSERT Perf_CounterData
SELECT CollectionTime, RTRIM(Object_Name), RTRIM(Counter_Name), RTRIM(Instance_Name), Cntr_Value
FROM result
WHERE Counter_Name IN (''Page Life Expectancy'', ''Free list stalls/sec'', ''Lazy writes/sec'', ''Page reads/sec'', ''Page writes/sec'')
AND Object_Name = ''Buffer Manager''

UNION ALL

SELECT CollectionTime, RTRIM(Object_Name), RTRIM(Counter_Name), RTRIM(Instance_Name), Cntr_Value 
FROM result
WHERE Counter_Name IN (''Transactions/sec'')
AND Object_Name = ''Buffer Manager''

UNION ALL

SELECT CollectionTime, RTRIM(Object_Name), RTRIM(Counter_Name), RTRIM(Instance_Name), Cntr_Value 
FROM result
WHERE Counter_Name IN (''User Connections'')
AND Object_Name = ''General Statistics''

UNION ALL

SELECT CollectionTime, RTRIM(Object_Name), RTRIM(Counter_Name), RTRIM(Instance_Name), Cntr_Value 
FROM result
WHERE Counter_Name IN (''Workfiles Created/sec'', ''Worktables Created/sec'', ''Page Splits/sec'')
AND Object_Name = ''Access Methods''

UNION ALL

SELECT CollectionTime, RTRIM(Object_Name), RTRIM(Counter_Name), RTRIM(Instance_Name), Cntr_Value 
FROM result
WHERE Counter_Name IN (''SQL Compilations/sec'', ''SQL Re-Compilations/sec'')
AND Object_Name = ''SQL Statistics''

UNION ALL

SELECT CollectionTime, RTRIM(Object_Name), RTRIM(Counter_Name), RTRIM(Instance_Name), Cntr_Value 
FROM result
WHERE Counter_Name IN (''Transactions/sec'')
AND Object_Name = ''Databases''
AND instance_name NOT IN (''master'', ''model'', ''msdb'', ''_total'', ''mssqlsystemresource'')', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SQL_IndexUsage]    Script Date: 5/26/2016 9:58:08 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SQL_IndexUsage', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'usp_Perf_CollectIndexUsage', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SQL_WaitStats]    Script Date: 5/26/2016 9:58:09 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SQL_WaitStats', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'WITH [Waits] AS
    (SELECT
        [wait_type],
        [wait_time_ms] / 1000.0 AS [WaitS],
        ([wait_time_ms] - [signal_wait_time_ms]) / 1000.0 AS [ResourceS],
        [signal_wait_time_ms] / 1000.0 AS [SignalS],
        [waiting_tasks_count] AS [WaitCount],
       100.0 * [wait_time_ms] / SUM ([wait_time_ms]) OVER() AS [Percentage],
        ROW_NUMBER() OVER(ORDER BY [wait_time_ms] DESC) AS [RowNum]
    FROM sys.dm_os_wait_stats
    WHERE [wait_type] NOT IN (
        N''BROKER_EVENTHANDLER'', N''BROKER_RECEIVE_WAITFOR'',
        N''BROKER_TASK_STOP'', N''BROKER_TO_FLUSH'',
        N''BROKER_TRANSMITTER'', N''CHECKPOINT_QUEUE'',
        N''CHKPT'', N''CLR_AUTO_EVENT'',
        N''CLR_MANUAL_EVENT'', N''CLR_SEMAPHORE'',
 
        -- Maybe uncomment these four if you have mirroring issues
        N''DBMIRROR_DBM_EVENT'', N''DBMIRROR_EVENTS_QUEUE'',
        N''DBMIRROR_WORKER_QUEUE'', N''DBMIRRORING_CMD'',
 
        N''DIRTY_PAGE_POLL'', N''DISPATCHER_QUEUE_SEMAPHORE'',
        N''EXECSYNC'', N''FSAGENT'',
        N''FT_IFTS_SCHEDULER_IDLE_WAIT'', N''FT_IFTSHC_MUTEX'',
 
        -- Maybe uncomment these six if you have AG issues
        N''HADR_CLUSAPI_CALL'', N''HADR_FILESTREAM_IOMGR_IOCOMPLETION'',
        N''HADR_LOGCAPTURE_WAIT'', N''HADR_NOTIFICATION_DEQUEUE'',
        N''HADR_TIMER_TASK'', N''HADR_WORK_QUEUE'',
 
        N''KSOURCE_WAKEUP'', N''LAZYWRITER_SLEEP'',
        N''LOGMGR_QUEUE'', N''MEMORY_ALLOCATION_EXT'',
        N''ONDEMAND_TASK_QUEUE'',
        N''PREEMPTIVE_XE_GETTARGETSTATE'',
        N''PWAIT_ALL_COMPONENTS_INITIALIZED'',
        N''PWAIT_DIRECTLOGCONSUMER_GETNEXT'',
        N''QDS_PERSIST_TASK_MAIN_LOOP_SLEEP'', N''QDS_ASYNC_QUEUE'',
        N''QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP'',
        N''QDS_SHUTDOWN_QUEUE'',
        N''REQUEST_FOR_DEADLOCK_SEARCH'', N''RESOURCE_QUEUE'',
        N''SERVER_IDLE_CHECK'', N''SLEEP_BPOOL_FLUSH'',
        N''SLEEP_DBSTARTUP'', N''SLEEP_DCOMSTARTUP'',
        N''SLEEP_MASTERDBREADY'', N''SLEEP_MASTERMDREADY'',
        N''SLEEP_MASTERUPGRADED'', N''SLEEP_MSDBSTARTUP'',
        N''SLEEP_SYSTEMTASK'', N''SLEEP_TASK'',
        N''SLEEP_TEMPDBSTARTUP'', N''SNI_HTTP_ACCEPT'',
        N''SP_SERVER_DIAGNOSTICS_SLEEP'', N''SQLTRACE_BUFFER_FLUSH'',
        N''SQLTRACE_INCREMENTAL_FLUSH_SLEEP'',
        N''SQLTRACE_WAIT_ENTRIES'', N''WAIT_FOR_RESULTS'',
        N''WAITFOR'', N''WAITFOR_TASKSHUTDOWN'',
        N''WAIT_XTP_RECOVERY'',
        N''WAIT_XTP_HOST_WAIT'', N''WAIT_XTP_OFFLINE_CKPT_NEW_LOG'',
        N''WAIT_XTP_CKPT_CLOSE'', N''XE_DISPATCHER_JOIN'',
        N''XE_DISPATCHER_WAIT'', N''XE_TIMER_EVENT'')
    AND [waiting_tasks_count] > 0
    )

INSERT Perf_WaitStatistics
SELECT GETDATE(),
    MAX ([W1].[wait_type]) AS [WaitType],
    CAST (MAX ([W1].[WaitS]) AS DECIMAL (16,2)) AS [Wait_S],
    CAST (MAX ([W1].[ResourceS]) AS DECIMAL (16,2)) AS [Resource_S],
    CAST (MAX ([W1].[SignalS]) AS DECIMAL (16,2)) AS [Signal_S],
    MAX ([W1].[WaitCount]) AS [WaitCount],
    CAST (MAX ([W1].[Percentage]) AS DECIMAL (5,2)) AS [Percentage],
    CAST ((MAX ([W1].[WaitS]) / MAX ([W1].[WaitCount])) AS DECIMAL (16,4)) AS [AvgWait_S],
    CAST ((MAX ([W1].[ResourceS]) / MAX ([W1].[WaitCount])) AS DECIMAL (16,4)) AS [AvgRes_S],
    CAST ((MAX ([W1].[SignalS]) / MAX ([W1].[WaitCount])) AS DECIMAL (16,4)) AS [AvgSig_S]
--	, CAST (''https://www.sqlskills.com/help/waits/'' + MAX ([W1].[wait_type]) as XML) AS [Help/Info URL]
FROM [Waits] AS [W1]
INNER JOIN [Waits] AS [W2]
    ON [W2].[RowNum] <= [W1].[RowNum]
GROUP BY [W1].[RowNum]
HAVING SUM ([W2].[Percentage]) - MAX( [W1].[Percentage] ) < 95; -- percentage threshold
GO

DBCC SQLPERF (N''sys.dm_os_wait_stats'', CLEAR);
GO', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every 5 minutes', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20160209, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'99d9e102-efad-4adb-923b-7a35e1daf74d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


USE [msdb]
GO

EXEC msdb.dbo.sp_add_job @job_name=N'SF_SQL_Admin Perf_PurgePolicy', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sfsa'

EXEC msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Perf_PurgePolicy', @step_name=N'Purge', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @retention int;
SELECT @retention = MAX(TimeValue) FROM Perf_Timers WHERE TimerName = ''Retention'';

WHILE (SELECT COUNT(*) FROM Perf_CounterData WHERE CollectionTime <= GETDATE() - @retention) > 0
BEGIN
	DELETE TOP (10000) Perf_CounterData
	WHERE CollectionTime <= GETDATE() - @retention;
END;

WHILE (SELECT COUNT(*) FROM Perf_FileSpace WHERE CollectionTime <= GETDATE() - @retention) > 0
BEGIN
	DELETE TOP (10000) Perf_FileSpace
	WHERE CollectionTime <= GETDATE() - @retention;
END;

WHILE (SELECT COUNT(*) FROM Perf_IndexUsageStatistics WHERE LastStartUp <= GETDATE() - @retention) > 0
BEGIN
	DELETE TOP (10000) Perf_IndexUsageStatistics
	WHERE LastStartUp <= GETDATE() - @retention;
END;

WHILE (SELECT COUNT(*) FROM Perf_Sessions WHERE CollectionTime <= GETDATE() - @retention) > 0
BEGIN
	DELETE TOP (10000) Perf_Sessions
	WHERE CollectionTime <= GETDATE() - @retention;
END;

WHILE (SELECT COUNT(*) FROM Perf_WaitStatistics WHERE CollectionTime <= GETDATE() - @retention) > 0
BEGIN
	DELETE TOP (10000) Perf_WaitStatistics
	WHERE CollectionTime <= GETDATE() - @retention;
END;', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

EXEC msdb.dbo.sp_update_job @job_name=N'SF_SQL_Admin Perf_PurgePolicy', @start_step_id = 1

EXEC msdb.dbo.sp_add_jobschedule @job_name=N'SF_SQL_Admin Perf_PurgePolicy', @name=N'Monthly - 1st Monday', 
		@enabled=1, 
		@freq_type=32, 
		@freq_interval=2, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=1, 
		@freq_recurrence_factor=1, 
		@active_start_date=20161115, 
		@active_end_date=99991231, 
		@active_start_time=120000, 
		@active_end_time=235959, 
		@schedule_uid=N'6398f31b-747b-45fa-b993-cca7eb7f2f51'

EXEC msdb.dbo.sp_add_jobserver @job_name=N'SF_SQL_Admin Perf_PurgePolicy', @server_name = N'(local)'
GO