USE [msdb]
GO

IF EXISTS (SELECT name FROM msdb..sysjobs WHERE name = 'SF_SQL_Admin Perf_Collect')
	EXEC msdb.dbo.sp_delete_job @job_name=N'SF_SQL_Admin Perf_Collect';

EXEC msdb.dbo.sp_add_job @job_name=N'SF_SQL_Admin Perf_Collect', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@owner_login_name=N'sfsa'

EXEC  msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Perf_Collect', @step_name=N'Check Collection Timer', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @t smallint;

SELECT @t =
	CASE WHEN DATEDIFF(mi, MAX(CollectionTime), GETDATE()) < 
		(SELECT TimeValue FROM Perf_Timers WHERE TimerName = ''Collection'')
	THEN 0 
	ELSE 1 END
FROM Perf_CounterData;

IF @t = 0
	RAISERROR(16,-1,-1);', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

EXEC msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Perf_Collect', @step_name=N'PS_CounterData', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe C:\DATA\SQL\SF_SQL_Admin\SF_PS_Perf_CollectCounters.ps1', 
		@flags=0

EXEC msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Perf_Collect', @step_name=N'SQL_Sessions', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'INSERT Perf_Sessions
SELECT GETDATE(), login_time, ec.session_id, status, DB_NAME(database_id), host_name, 
program_name, login_name, cpu_time, reads, writes, last_read, last_write, text, most_recent_sql_handle
FROM sys.dm_exec_connections ec
INNER JOIN sys.dm_exec_sessions es ON es.session_id = ec.session_id
CROSS APPLY sys.dm_exec_sql_text(most_recent_sql_handle);', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

EXEC msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Perf_Collect', @step_name=N'SQL_FileSpace', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @tbl TABLE (InstanceName varchar(512), DBName varchar(512), FileName varchar(512), 
	DataSpaceID int, Type varchar(16), Size decimal(10,2), Used decimal(10,2));

INSERT @tbl
EXEC sp_msforeachdb ''USE [?]
SELECT @@SERVERNAME,
DB_NAME(), name, data_space_id, type_desc,
size/128.0, 
CAST(FILEPROPERTY(name, ''''SpaceUsed'''')/128.0 AS DECIMAL(10,2))
FROM sys.database_files'';

INSERT Perf_FileSpace
SELECT GETDATE(), InstanceName, DBName, FileName, COALESCE(name, ''PRIMARY'') FileGroup, t.Type, 
Size, Used
FROM @tbl t
LEFT OUTER JOIN sys.filegroups fg ON t.DataSpaceID = fg.data_space_id
ORDER BY DBName, t.Type desc;

', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

EXEC msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Perf_Collect', @step_name=N'SQL_Counters', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*	Counter type rules per MSDN:
	65792 - value as of query time
	1073939712 - base value used to calculate 537003264
		(537003264 value / 1073939712 value)
	272696576 - two samples divided by time
		(value2 - value1) / interval seconds
	1073874176 - uses base value of 1073939712 - two samples each
		(value2 - value1) / (base2 - base1)
*/

-- Amount of time to wait between samples.
DECLARE @wait datetime = ''00:00:10'';
DECLARE @time datetime = GETDATE();

-- Two sample tables and final result set table.  
-- The final result set stores the counter values as varchar for easy formatting
-- such as including % signs, etc.
DECLARE @one AS TABLE (object_name varchar(512), counter_name varchar(512), instance_name varchar(512), cntr_value float, cntr_type int);
DECLARE @two AS TABLE (object_name varchar(512), counter_name varchar(512), instance_name varchar(512), cntr_value float, cntr_type int);
DECLARE @result AS TABLE (collectiontime smalldatetime, object_name varchar(512), counter_name varchar(512), instance_name varchar(512), cntr_value float)

-- Collect the first sample, minus type 65792 (realtime).
INSERT @one 
	SELECT * 
	FROM sys.dm_os_performance_counters
	WHERE cntr_type <> 65792;

-- Wait.
WAITFOR DELAY @wait;

-- Collect the second sample.  Note - filtering of counters can be done at this level to
-- reduce server processing (which is fairly light), be sure the filter matches in both
-- sample sets though.
INSERT @two 
	SELECT * 
	FROM sys.dm_os_performance_counters
	WHERE cntr_type <> 65792;

-- CTE''s will get the base data needed for calculations from the sample tables.
-- This CTE joins the value and base value from the second sample for calculation
-- for the counter type 537003264.
-- Note - This could be pulled directly from the DMV, but I have left it as-is
-- as I am unsure of the accuracy.  This is the MSDN formula, but it may be better
-- to compare both samples for the calculation.
WITH perf_537003264
AS (
	SELECT a.object_name, a.counter_name, a.instance_name, 
		CAST(a.cntr_value AS float) value, CAST(b.cntr_value AS float) base
	FROM @two a
	INNER JOIN @two b ON a.object_name = b.object_name 
		AND a.counter_name = REPLACE(b.counter_name, '' Base'', '''')
		AND a.instance_name = b.instance_name
	WHERE a.cntr_type = 537003264
	AND b.cntr_type = 1073939712
),

-- This CTE gets both sample values for the counter type 272696576 to be divided 
-- by time passed.
perf_272696576
AS (
	SELECT a.object_name, a.counter_name, a.instance_name, 
		CAST(a.cntr_value AS float) value1, CAST(b.cntr_value AS float) value2
	FROM @one a
	INNER JOIN @two b ON a.object_name = b.object_name 
		AND a.counter_name = b.counter_name
		AND a.instance_name = b.instance_name
		AND a.cntr_type = b.cntr_type	
	WHERE a.cntr_type = 272696576
),

-- The next three CTE''s are used to calculate the value for counter type 1073874176.
-- This one suffers from many complexities caused by mismatched naming
-- conventions - thanks Microsoft!  The first CTE gets the two sample values
-- for the main value counter type.
perf_1073874176
AS (
	SELECT a.object_name, a.counter_name, a.instance_name, 
		CAST(a.cntr_value AS float) value1, CAST(b.cntr_value AS float) value2
	FROM @one a
	INNER JOIN @two b ON a.object_name = b.object_name 
		AND a.counter_name = b.counter_name
		AND a.instance_name = b.instance_name
		AND a.cntr_type = b.cntr_type	
	WHERE a.cntr_type = 1073874176
),

-- This CTE gets the two sample values for the base counter type to be used
-- in calculating the above counter type.
perf_1073939712
AS (
	SELECT a.object_name, a.counter_name, a.instance_name, 
		CAST(a.cntr_value AS float) value1, CAST(b.cntr_value AS float) value2
	FROM @one a
	INNER JOIN @two b ON a.object_name = b.object_name 
		AND a.counter_name = b.counter_name
		AND a.instance_name = b.instance_name
		AND a.cntr_type = b.cntr_type	
	WHERE a.cntr_type = 1073939712
),

-- This CTE is where it gets weirder.  Because of poor naming, a UNION
-- was needed to combine the base and value types properly to return all
-- possible instances.  The difference between samples is calculated here
-- to make the division operation easier later.
perf_1073874176_1073939712
AS (
	SELECT a.object_name, a.counter_name, a.instance_name, a.value2 - a.value1 value, b.value2 - b.value1 base 
	FROM perf_1073874176 a
	INNER JOIN perf_1073939712 b ON a.instance_name = b.instance_name
		AND REPLACE(a.counter_name, '' (ms)'', '''') = REPLACE(REPLACE(REPLACE(b.counter_name, '' BS'', ''''), '' (ms)'', ''''), '' base'', '''')
		AND a.object_name = b.object_name

	UNION

	SELECT a.object_name, a.counter_name, a.instance_name, a.value2 - a.value1 value, b.value2 - b.value1 base 
	FROM perf_1073874176 a
	INNER JOIN perf_1073939712 b ON a.instance_name = b.instance_name
		AND REPLACE(REPLACE(REPLACE(a.counter_name, ''Avg '', ''''), ''Avg. '', ''''), '' (ms)'', '''') = REPLACE(REPLACE(b.counter_name, '' (ms)'', ''''), '' base'', '''')
		AND a.object_name = b.object_name
)

-- Now it is time to calculate all values and insert them into the final result set.
-- UNION ALLs are used to make each calculation a separate entity.
-- First up, the type 537003264 is a simple value divided by base (catching /0).
INSERT @result
SELECT @time, object_name, counter_name, instance_name, 
	CASE WHEN base = 0 THEN 0 ELSE value / base END
FROM perf_537003264

UNION ALL

-- This is the calculation for type 272696576, using the wait value in seconds.
SELECT @time, object_name, counter_name, instance_name, 
	(value2 - value1) / DATEPART(s, @wait)
FROM perf_272696576

UNION ALL

-- This is the calculation for type 1073874176, by this point it is a simple
-- division of value and base (checking for /0 errors).
SELECT @time, object_name, counter_name, instance_name, 
	CASE WHEN base = 0 THEN 0 ELSE value / base END
	FROM perf_1073874176_1073939712

UNION ALL

-- The final select just grabs the counter type 65792, which is "realtime".
SELECT @time, object_name, counter_name, instance_name, cntr_value
FROM sys.dm_os_performance_counters
WHERE cntr_type = 65792;

-- The final result set.  This is where filtering could be easily handled
-- to keep the code above (a little more) readable.  An insert to a physical
-- table in the admin database could be added here as well for a recurring job
-- to capture historical performance (and can easily convert into a proc for
-- the same purpose).
WITH result
AS (
	SELECT CollectionTime, SUBSTRING(object_name, CHARINDEX('':'', object_name, 0) + 1, LEN(object_name)) Object_Name, 
		Counter_Name, Instance_Name, Cntr_Value
	FROM @result)

INSERT Perf_CounterData
SELECT CollectionTime, RTRIM(Object_Name), RTRIM(Counter_Name), RTRIM(Instance_Name), Cntr_Value
FROM result
WHERE Counter_Name IN (''Page Life Expectancy'', ''Free list stalls/sec'', ''Lazy writes/sec'', ''Page reads/sec'', ''Page writes/sec'')
AND Object_Name = ''Buffer Manager''

UNION ALL

SELECT CollectionTime, RTRIM(Object_Name), RTRIM(Counter_Name), RTRIM(Instance_Name), Cntr_Value 
FROM result
WHERE Counter_Name IN (''Transactions/sec'')
AND Object_Name = ''Buffer Manager''

UNION ALL

SELECT CollectionTime, RTRIM(Object_Name), RTRIM(Counter_Name), RTRIM(Instance_Name), Cntr_Value 
FROM result
WHERE Counter_Name IN (''User Connections'')
AND Object_Name = ''General Statistics''

UNION ALL

SELECT CollectionTime, RTRIM(Object_Name), RTRIM(Counter_Name), RTRIM(Instance_Name), Cntr_Value 
FROM result
WHERE Counter_Name IN (''Workfiles Created/sec'', ''Worktables Created/sec'', ''Page Splits/sec'')
AND Object_Name = ''Access Methods''

UNION ALL

SELECT CollectionTime, RTRIM(Object_Name), RTRIM(Counter_Name), RTRIM(Instance_Name), Cntr_Value 
FROM result
WHERE Counter_Name IN (''SQL Compilations/sec'', ''SQL Re-Compilations/sec'')
AND Object_Name = ''SQL Statistics''

UNION ALL

SELECT CollectionTime, RTRIM(Object_Name), RTRIM(Counter_Name), RTRIM(Instance_Name), Cntr_Value 
FROM result
WHERE Counter_Name IN (''Transactions/sec'')
AND Object_Name = ''Databases''
AND instance_name NOT IN (''master'', ''model'', ''msdb'', ''_total'', ''mssqlsystemresource'')', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

EXEC msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Perf_Collect', @step_name=N'SQL_IndexUsage', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'usp_Perf_CollectIndexUsage', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

EXEC msdb.dbo.sp_add_jobstep @job_name=N'SF_SQL_Admin Perf_Collect', @step_name=N'SQL_WaitStats', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'WITH [Waits] AS
    (SELECT
        [wait_type],
        [wait_time_ms] / 1000.0 AS [WaitS],
        ([wait_time_ms] - [signal_wait_time_ms]) / 1000.0 AS [ResourceS],
        [signal_wait_time_ms] / 1000.0 AS [SignalS],
        [waiting_tasks_count] AS [WaitCount],
       100.0 * [wait_time_ms] / SUM ([wait_time_ms]) OVER() AS [Percentage],
        ROW_NUMBER() OVER(ORDER BY [wait_time_ms] DESC) AS [RowNum]
    FROM sys.dm_os_wait_stats
    WHERE [wait_type] NOT IN (
        N''BROKER_EVENTHANDLER'', N''BROKER_RECEIVE_WAITFOR'',
        N''BROKER_TASK_STOP'', N''BROKER_TO_FLUSH'',
        N''BROKER_TRANSMITTER'', N''CHECKPOINT_QUEUE'',
        N''CHKPT'', N''CLR_AUTO_EVENT'',
        N''CLR_MANUAL_EVENT'', N''CLR_SEMAPHORE'',
 
        -- Maybe uncomment these four if you have mirroring issues
        N''DBMIRROR_DBM_EVENT'', N''DBMIRROR_EVENTS_QUEUE'',
        N''DBMIRROR_WORKER_QUEUE'', N''DBMIRRORING_CMD'',
 
        N''DIRTY_PAGE_POLL'', N''DISPATCHER_QUEUE_SEMAPHORE'',
        N''EXECSYNC'', N''FSAGENT'',
        N''FT_IFTS_SCHEDULER_IDLE_WAIT'', N''FT_IFTSHC_MUTEX'',
 
        -- Maybe uncomment these six if you have AG issues
        N''HADR_CLUSAPI_CALL'', N''HADR_FILESTREAM_IOMGR_IOCOMPLETION'',
        N''HADR_LOGCAPTURE_WAIT'', N''HADR_NOTIFICATION_DEQUEUE'',
        N''HADR_TIMER_TASK'', N''HADR_WORK_QUEUE'',
 
        N''KSOURCE_WAKEUP'', N''LAZYWRITER_SLEEP'',
        N''LOGMGR_QUEUE'', N''MEMORY_ALLOCATION_EXT'',
        N''ONDEMAND_TASK_QUEUE'',
        N''PREEMPTIVE_XE_GETTARGETSTATE'',
        N''PWAIT_ALL_COMPONENTS_INITIALIZED'',
        N''PWAIT_DIRECTLOGCONSUMER_GETNEXT'',
        N''QDS_PERSIST_TASK_MAIN_LOOP_SLEEP'', N''QDS_ASYNC_QUEUE'',
        N''QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP'',
        N''QDS_SHUTDOWN_QUEUE'',
        N''REQUEST_FOR_DEADLOCK_SEARCH'', N''RESOURCE_QUEUE'',
        N''SERVER_IDLE_CHECK'', N''SLEEP_BPOOL_FLUSH'',
        N''SLEEP_DBSTARTUP'', N''SLEEP_DCOMSTARTUP'',
        N''SLEEP_MASTERDBREADY'', N''SLEEP_MASTERMDREADY'',
        N''SLEEP_MASTERUPGRADED'', N''SLEEP_MSDBSTARTUP'',
        N''SLEEP_SYSTEMTASK'', N''SLEEP_TASK'',
        N''SLEEP_TEMPDBSTARTUP'', N''SNI_HTTP_ACCEPT'',
        N''SP_SERVER_DIAGNOSTICS_SLEEP'', N''SQLTRACE_BUFFER_FLUSH'',
        N''SQLTRACE_INCREMENTAL_FLUSH_SLEEP'',
        N''SQLTRACE_WAIT_ENTRIES'', N''WAIT_FOR_RESULTS'',
        N''WAITFOR'', N''WAITFOR_TASKSHUTDOWN'',
        N''WAIT_XTP_RECOVERY'',
        N''WAIT_XTP_HOST_WAIT'', N''WAIT_XTP_OFFLINE_CKPT_NEW_LOG'',
        N''WAIT_XTP_CKPT_CLOSE'', N''XE_DISPATCHER_JOIN'',
        N''XE_DISPATCHER_WAIT'', N''XE_TIMER_EVENT'')
    AND [waiting_tasks_count] > 0
    )

INSERT Perf_WaitStatistics
SELECT GETDATE(),
    MAX ([W1].[wait_type]) AS [WaitType],
    CAST (MAX ([W1].[WaitS]) AS DECIMAL (16,2)) AS [Wait_S],
    CAST (MAX ([W1].[ResourceS]) AS DECIMAL (16,2)) AS [Resource_S],
    CAST (MAX ([W1].[SignalS]) AS DECIMAL (16,2)) AS [Signal_S],
    MAX ([W1].[WaitCount]) AS [WaitCount],
    CAST (MAX ([W1].[Percentage]) AS DECIMAL (5,2)) AS [Percentage],
    CAST ((MAX ([W1].[WaitS]) / MAX ([W1].[WaitCount])) AS DECIMAL (16,4)) AS [AvgWait_S],
    CAST ((MAX ([W1].[ResourceS]) / MAX ([W1].[WaitCount])) AS DECIMAL (16,4)) AS [AvgRes_S],
    CAST ((MAX ([W1].[SignalS]) / MAX ([W1].[WaitCount])) AS DECIMAL (16,4)) AS [AvgSig_S]
--	, CAST (''https://www.sqlskills.com/help/waits/'' + MAX ([W1].[wait_type]) as XML) AS [Help/Info URL]
FROM [Waits] AS [W1]
INNER JOIN [Waits] AS [W2]
    ON [W2].[RowNum] <= [W1].[RowNum]
GROUP BY [W1].[RowNum]
HAVING SUM ([W2].[Percentage]) - MAX( [W1].[Percentage] ) < 95; -- percentage threshold
GO

DBCC SQLPERF (N''sys.dm_os_wait_stats'', CLEAR);
GO', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0

EXEC msdb.dbo.sp_update_job @job_name=N'SF_SQL_Admin Perf_Collect', @start_step_id = 1

EXEC msdb.dbo.sp_add_jobschedule @job_name=N'SF_SQL_Admin Perf_Collect', @name=N'Every  minute', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20160209, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'99d9e102-efad-4adb-923b-7a35e1daf74d'

EXEC msdb.dbo.sp_add_jobserver @job_name=N'SF_SQL_Admin Perf_Collect', @server_name = N'(local)'
GO


