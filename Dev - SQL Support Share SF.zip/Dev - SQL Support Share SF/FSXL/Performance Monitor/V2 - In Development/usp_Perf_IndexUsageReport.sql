USE [SF_SQL_Admin]
GO
/****** Object:  StoredProcedure [dbo].[usp_Perf_IndexUsageReport]    Script Date: 4/6/2016 10:03:12 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [dbo].[usp_Perf_IndexUsageReport]
AS
BEGIN
	WITH idx
	AS (
		SELECT DatabaseName, TableName, IndexName, IndexType, SUM(UserSeeks + UserScans + UserLookups + 
			SystemSeeks + SystemScans + SystemLookups) Accesses, SUM(UserUpdates + SystemUpdates) Updates
		FROM Perf_IndexUsageStatistics
		GROUP BY DatabaseName, TableName, IndexName, IndexType)

	SELECT DatabaseName, TableName, IndexName, IndexType, Accesses, Updates,
		CASE 
			WHEN Updates = 0 THEN Accesses 
			ELSE CAST(Accesses AS float) / CAST(Updates AS float) * 100 
		END UpdateToAccessRatio
	FROM idx
	ORDER BY UpdateToAccessRatio;
END;
GO
