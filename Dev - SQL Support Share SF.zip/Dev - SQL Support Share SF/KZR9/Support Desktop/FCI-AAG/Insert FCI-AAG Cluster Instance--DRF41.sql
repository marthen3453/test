DECLARE @ClustNodeNm	VARCHAR(20)

CREATE TABLE #MPs
(
	mountpoint	VARCHAR(256)
)

SET @ClustNodeNm = 'WTSDRF41'

INSERT INTO #MPs
EXEC SQL_CDRS_WSDB.dbDomainInfo.dbo.sql_sp_GetWSDBMountPointData
	@Server = @ClustNodeNm, -- varchar(50)
    @UsageVariable = '' -- varchar(50)

DELETE FROM dbo.MOUNTPOINT_PASSTHROUGH WHERE dbase_srvr_nm = @ClustNodeNm

INSERT INTO dbo.MOUNTPOINT_PASSTHROUGH
SELECT @ClustNodeNm, * FROM #MPs WHERE mountpoint != ''

TRUNCATE TABLE #MPs

SET @ClustNodeNm = 'WTSDRF42'

INSERT INTO #MPs
EXEC SQL_CDRS_WSDB.dbDomainInfo.dbo.sql_sp_GetWSDBMountPointData
	@Server = @ClustNodeNm, -- varchar(50)
    @UsageVariable = '' -- varchar(50)

DELETE FROM dbo.MOUNTPOINT_PASSTHROUGH WHERE dbase_srvr_nm = @ClustNodeNm

INSERT INTO dbo.MOUNTPOINT_PASSTHROUGH
SELECT 
	@ClustNodeNm, mountpoint
FROM 
	#MPs a
WHERE mountpoint != ''

DROP TABLE #MPs

EXECUTE [dbo].[insertInstc2012CLUSTER2] 
   'WVSDRF4101'
  ,'WMSDRF4101'
  ,'SQL SERVER 2014 SP1'
  ,'12.00.4100.1'
  ,1
  ,'SVC_SQL_COMP2012'
  ,57801
  ,'CLUSTER'
  ,'WINDOWS'
  ,'10.250.225.73'
  ,'255.255.255.128'
  ,'WVSDRF4101'
  ,'WTSDRF41'
  ,'WTSDRF42'
  ,'F'
  ,'N'
  ,'FCI-AAG'
  ,'Y'
  ,'KZR9'
  ,0
  ,3719
  ,'N'
GO


--EXECUTE [dbo].[insertInstc2012CLUSTER2] 
--   'WVSDRF4101'
--  ,'WMSDRF4101'
--  ,'SQL SERVER 2014 SP1'
--  ,'12.00.4100.1'
--  ,1
--  ,'SVC_SQL_COMP2012'
--  ,57801
--  ,'CLUSTER'
--  ,'WINDOWS'
--  ,'10.250.225.73'
--  ,'255.255.255.128'
--  ,'WVSDRF4101'
--  ,'WTSDRF41'
--  ,'WTSDRF42'
--  ,'F'
--  ,'N'
--  ,'FCI-AAG'
--  ,'Y'
--  ,'KZR9'
--  ,0
--  ,3719
--  ,'N'
--GO

--EXEC dbo.insertInstc2012CLUSTER2
--	@SRVR_CLSTR_NM = '', -- varchar(12)
--    @ENV_NM = '', -- varchar(16)
--    @SFTWR_PROD_NM = '', -- varchar(50)
--    @SFTWR_PROD_VER_NM = '', -- varchar(20)
--    @ENV_CD = 0, -- smallint
--    @SQL_SERV_ACCT_TXT = '', -- varchar(120)
--    @PORT_NUM = 0, -- int
--    @LoadType = '', -- varchar(25)
--    @AUTH_OPTN_NM = '', -- varchar(10)
--    @IP_ADDR_NUM = '', -- varchar(15)
--    @SBNET_MASK_NUM = '', -- varchar(15)
--    @SQLVIRTUALNAME = '', -- varchar(128)
--    @PhysServerName = '', -- varchar(20)
--    @FailoverServerName = '', -- varchar(20)
--    @Drive = '', -- char(1)
--    @OVERRIDEINSTALL = '', -- char(1)
--    @SRVRTYPE = '', -- varchar(20)
--    @ALWYON_STTS = '', -- char(1)
--    @USERID = '', -- varchar(6)
--    @BACKUPBEGINHOUR = 0, -- int
--    @APP_ID = 0, -- int
--    @AddFeatureAS = '' -- char(1)
