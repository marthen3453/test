SELECT * FROM dbo.INSTC WHERE SRVR_CLSTR_NM IN ( 'WVSDRF4101', 'WTSD9XRH', 'WVSD9XRB01')


SELECT * FROM dbo.DBASE_APP WHERE APP_NM_TXT LIKE 'SQL 2012%'




Select top 1 clustertype from [sqlpwsdb1.opr.statefarm.org.].dbdomaininfo.dbo.tblcluster a 
inner join [sqlpwsdb1.opr.statefarm.org.].dbdomaininfo.dbo.tblMasterNode b on a.masternode_id = b.masternode_id 
Inner join [sqlpwsdb1.opr.statefarm.org.].dbdomaininfo.dbo.tblServerNode c on a.masternode_id = c.masternode_id 
inner join [sqlpwsdb1.opr.statefarm.org.].dbdomaininfo.dbo.tblServerInfo d on c.servinfo_id = d.servinfo_id 
where right(comname,len(comname)-3) = 'DRF41'


EXEC dbo.sfsp_LOAD_CONFIG_ALL
	@PHYS_SRVR_NM = 'WTSD9XRB', -- varchar(10)
    @ENV_NM = N'WMSD9XRB01', -- nvarchar(20)
    @FILE_TYPE = N'CONFIG' -- nvarchar(10)


EXEC dbo.sfsp_LOAD_CONFIG_ALL
	@PHYS_SRVR_NM = 'WTSD9XRB', -- varchar(10)
    @ENV_NM = N'WMSD9XRB01', -- nvarchar(20)
    @FILE_TYPE = N'MSI' -- nvarchar(10)



EXEC dbo.sfsp_LOAD_CONFIG_ALL
	@PHYS_SRVR_NM = 'WTSD9XRC', -- varchar(10)
    @ENV_NM = N'WMSD9XRB01', -- nvarchar(20)
    @FILE_TYPE = N'CONFIG' -- nvarchar(10)

EXEC dbo.sfsp_LOAD_CONFIG_ALL
	@PHYS_SRVR_NM = 'WTSD9XRC', -- varchar(10)
    @ENV_NM = N'WMSD9XRB01', -- nvarchar(20)
    @FILE_TYPE = N'MSI' -- nvarchar(10)



EXEC dbo.sfsp_LOAD_CONFIG_ALL
	@PHYS_SRVR_NM = 'WTSD9XRH', -- varchar(10)
    @ENV_NM = N'WMSD9XRB02', -- nvarchar(20)
    @FILE_TYPE = N'CONFIG' -- nvarchar(10)

EXEC dbo.sfsp_LOAD_CONFIG_ALL
	@PHYS_SRVR_NM = 'WTSD9XRH', -- varchar(10)
    @ENV_NM = N'WMSD9XRB02', -- nvarchar(20)
    @FILE_TYPE = N'MSI' -- nvarchar(10)



EXEC dbo.sfsp_ADMIN_Get_ClusterName
	@PHYS_SRVR_NM = 'WTSD9XRB', -- varchar(10)
    @ENV_NM = N'WMSD9XRB01' -- nvarchar(20)

EXEC dbo.sfsp_ADMIN_Get_ClusterName
	@PHYS_SRVR_NM = 'WTSD9XRC', -- varchar(10)
    @ENV_NM = N'WMSD9XRB01' -- nvarchar(20)


EXEC dbo.sfsp_ADMIN_Get_ClusterName
	@PHYS_SRVR_NM = 'WTSD9XRH', -- varchar(10)
    @ENV_NM = N'WMSD9XRB02' -- nvarchar(20)



EXEC dbo.sfsp_ADMIN_Get_ClusterName
	@PHYS_SRVR_NM = 'WTSDRF41', -- varchar(10)
    @ENV_NM = N'WMSDRF4101' -- nvarchar(20)

EXEC dbo.sfsp_ADMIN_Get_ClusterName
	@PHYS_SRVR_NM = 'WTSDRF43', -- varchar(10)
    @ENV_NM = N'WMSDRF4101' -- nvarchar(20)

EXEC dbo.sfsp_ADMIN_Get_ClusterName
	@PHYS_SRVR_NM = 'WTSDRF42', -- varchar(10)
    @ENV_NM = N'WMSDRF4102' -- nvarchar(20)

EXEC dbo.sfsp_ADMIN_Get_ClusterName
	@PHYS_SRVR_NM = 'WTSDRF43', -- varchar(10)
    @ENV_NM = N'WMSDRF4102' -- nvarchar(20)


