

sp_configure 'show advanced options', 1
GO

reconfigure
go


IF	((SELECT CONVERT(NVARCHAR(256), SERVERPROPERTY('InstanceName'))) LIKE 'WMSDYTK20%')
BEGIN
	EXEC sp_configure 'min server memory (MB)', 512
END
ELSE
BEGIN 
	EXEC sp_configure 'min server memory (MB)', 1024
END

GO

IF	((SELECT CONVERT(NVARCHAR(256), SERVERPROPERTY('InstanceName'))) LIKE 'WMSDYTK20%')
BEGIN
	EXEC sp_configure 'max server memory (MB)', 12288
END
ELSE
BEGIN 
	EXEC sp_configure 'max server memory (MB)', 20480
END

GO

reconfigure
go
