USE [msdb]
GO

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'master Consistency-SF Maintenance-Su')
EXEC msdb.dbo.sp_delete_job @job_name = N'master Consistency-SF Maintenance-Su', @delete_unused_schedule=1
GO

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'master Reindex-SF Maintenance-Sa')
EXEC msdb.dbo.sp_delete_job @job_name = N'master Reindex-SF Maintenance-Sa', @delete_unused_schedule=1
GO

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'master Statistics-SF Maintenance-MoTuWeThFrSa')
EXEC msdb.dbo.sp_delete_job @job_name = N'master Statistics-SF Maintenance-MoTuWeThFrSa', @delete_unused_schedule=1
GO

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'master TDPFullBackup-SF Maintenance-SuMoTuWeThFrSa')
EXEC msdb.dbo.sp_delete_job @job_name = N'master TDPFullBackup-SF Maintenance-SuMoTuWeThFrSa', @delete_unused_schedule=1
GO

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'msdb Consistency-SF Maintenance-Su')
EXEC msdb.dbo.sp_delete_job @job_name = N'msdb Consistency-SF Maintenance-Su', @delete_unused_schedule=1
GO

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'msdb Reindex-SF Maintenance-Sa')
EXEC msdb.dbo.sp_delete_job @job_name = N'msdb Reindex-SF Maintenance-Sa', @delete_unused_schedule=1
GO

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'msdb Statistics-SF Maintenance-MoTuWeThFrSa')
EXEC msdb.dbo.sp_delete_job @job_name = N'msdb Statistics-SF Maintenance-MoTuWeThFrSa', @delete_unused_schedule=1
GO

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'msdb TDPFullBackup-SF Maintenance-SuMoTuWeThFrSa')
EXEC msdb.dbo.sp_delete_job @job_name = N'msdb TDPFullBackup-SF Maintenance-SuMoTuWeThFrSa', @delete_unused_schedule=1
GO

