SET NOCOUNT ON

DECLARE	@DataDriveLoc	VARCHAR(64)
,		@DataFileLoc	VARCHAR(64)
,		@LogFileLoc		VARCHAR(128)
,		@NumDataDrive	TINYINT
,		@LoopCount		TINYINT
,		@DBLoopName		VARCHAR(128)
,		@DBStartNum		TINYINT
,		@DBEndNum		TINYINT
,		@DBFileSizeMB	VARCHAR(10)
,		@DBGrowthSizeMB	VARCHAR(10)
,		@DBMaxSizeMB	VARCHAR(10)
,		@DBName			VARCHAR(128)
,		@cmd			VARCHAR(1024)

SELECT	@NumDataDrive = 1

SELECT @DBFileSizeMB = '100'
SELECT @DBGrowthSizeMB = '100'
SELECT @DBMaxSizeMB = '5000'


CREATE TABLE #DBNameCounts
(	DBLoopName	VARCHAR(64)
,	DBStartNum	TINYINT
,	DBEndNum	TINYINT
)

INSERT INTO #DBNameCounts
VALUES
--	(	'PROD_SPC_MySites_#', 110, 119	)
--,	(	'PROD_SPC_MySites_Exec_#', 12, 13	)


--	(	'PROD_SPC_MySites_#', 110, 119	)
--,	(	'PROD_SPC_MySites_Exec_#', 12, 13	)

--	(	'PROD_SPS_AccessServices', 0, 0	)
--,	(	'PROD_Partner_SPS_PerformancePoint', 0, 0	)
--,	(	'PROD_Partner_SPS_StateService', 0, 0	)

--	(	'DEV_Partner_SPS_Admin', 0, 0	)
--,	(	'DEV_Partner_SPS_SecureStore', 0, 0	)
--,	(	'DEV_Partner_SPS_WordAutomation', 0, 0	)
--,	(	'DEV_Partner_SPS_PowerPivot', 0, 0	)
--,	(	'DEV_Partner_SPS_PerformancePoint', 0, 0	)
--,	(	'DEV_Partner_SPS_StateService', 0, 0	)

--	(	'TEST_Partner_SPS_Admin', 0, 0	)
--,	(	'TEST_Partner_SPS_SecureStore', 0, 0	)
--,	(	'TEST_Partner_SPS_WordAutomation', 0, 0	)
--,	(	'TEST_Partner_SPS_PowerPivot', 0, 0	)
--,	(	'TEST_Partner_SPS_PerformancePoint', 0, 0	)
--,	(	'TEST_Partner_SPS_StateService', 0, 0	)

--	(	'PROD_SB_Gateway', 0, 0	)
--,	(	'PROD_SB_Management', 0, 0	)
--,	(	'PROD_SB_Message_10', 0, 0	)
--,	(	'PROD_WF_Instance', 0, 0	)
--,	(	'PROD_WF_Management', 0, 0	)
--,	(	'PROD_WF_Resource', 0, 0	)



--	(	'PROD_DR_SPS_Admin', 0, 0	)
--,	(	'PROD_DR_SPS_SecureStore', 0, 0	)

--(	'TEST_Partner_SPC_Ent_Collab_01', 0, 0	)

/*  WPSDYTK6 cluster  */
-- ('PROD_SPC_DECOMM_Collab_#', 10, 19 )
--, ('PROD_SPC_DECOMM_Collab_#', 110, 119 )
--, ('PROD_SPC_DECOMM_Collab_Buffer_1', 0, 0 )

-- ('PROD_SPC_DECOMM_Collab_#', 30, 39 )
--, ('PROD_SPC_DECOMM_Collab_#', 130, 139 )
--, ('PROD_SPC_DECOMM_Collab_Buffer_3', 0, 0 )

-- ('PROD_SPC_DECOMM_Collab_#', 50, 59 )
--, ('PROD_SPC_DECOMM_Collab_#', 150, 159 )
--, ('PROD_SPC_DECOMM_Collab_Buffer_5', 0, 0 )

-- ('PROD_SPC_DECOMM_Collab_#', 70, 79 )
--, ('PROD_SPC_DECOMM_Collab_#', 170, 179 )
--, ('PROD_SPC_DECOMM_Collab_Buffer_7', 0, 0 )

-- ('PROD_SPC_DECOMM_Collab_#', 90, 99 )
--, ('PROD_SPC_DECOMM_Collab_#', 190, 199 )
--, ('PROD_SPC_DECOMM_Collab_Buffer_9', 0, 0 )


/*  WPSDYTK8 cluster  */
--  ('PROD_SPC_DECOMM_Collab_#', 20, 29 )				
--, ('PROD_SPC_DECOMM_Collab_#', 120, 129 )
--, ('PROD_SPC_DECOMM_Collab_Buffer_2', 0, 0 )

-- ('PROD_SPC_DECOMM_Collab_#', 40, 49 )
--, ('PROD_SPC_DECOMM_Collab_#', 140, 149 )
--, ('PROD_SPC_DECOMM_Collab_Buffer_4', 0, 0 )

-- ('PROD_SPC_DECOMM_Collab_#', 60, 69 )
--, ('PROD_SPC_DECOMM_Collab_#', 160, 169 )
--, ('PROD_SPC_DECOMM_Collab_Buffer_6', 0, 0 )

-- ('PROD_SPC_DECOMM_Collab_#', 80, 89 )
--, ('PROD_SPC_DECOMM_Collab_#', 180, 189 )
--, ('PROD_SPC_DECOMM_Collab_Buffer_8', 0, 0 )

-- ('PROD_SPC_DECOMM_Collab_#', 100, 109 )
--, ('PROD_SPC_DECOMM_Collab_#', 200, 209 )
--, ('PROD_SPC_DECOMM_Collab_Buffer_10', 0, 0 )



/*  WPSDYTK4 cluster  */
-- ('PROD_SPC_DECOMM_MySites_#', 10, 19 )
--, ('PROD_SPC_DECOMM_MySites_#', 110, 119 )
--, ('PROD_SPC_DECOMM_MySites_Buffer_1', 0, 0 )

-- ('PROD_SPC_DECOMM_MySites_#', 20, 29 )
--, ('PROD_SPC_DECOMM_MySites_#', 120, 129  )
--, ('PROD_SPC_DECOMM_MySites_Buffer_2', 0, 0 )

-- ('PROD_SPC_DECOMM_MySites_#', 30, 39 )
--, ('PROD_SPC_DECOMM_MySites_#', 130, 139 )
--, ('PROD_SPC_DECOMM_MySites_Buffer_3', 0, 0 )




/*  WPSDZCZK cluster  */
-- ('PROD_SPC_CLC_#', 10, 19 )
--, ('PROD_SPC_DECOMM_CLC_#', 10, 19 )
--, ('PROD_SPC_DECOMM_CLC_Buffer_1', 0, 0 )

-- ('PROD_SPC_DECOMM_CLC_MySites_#', 10, 19 )
--, ('PROD_SPC_DECOMM_CLC_MySites_Buffer_1', 0, 0 )

-- ('PROD_SPC_DECOMM_CLC_MySites_#', 20, 29 )
--, ('PROD_SPC_DECOMM_CLC_MySites_Buffer_2', 0, 0 )


/*  WPSDYTK0 cluster  */
-- ('PROD_SPC_CLD_#', 10, 19 )
--, ('PROD_SPC_DECOMM_CLD_#', 10, 19 )
--, ('PROD_SPC_DECOMM_CLD_Buffer_1', 0, 0 )

-- ('PROD_SPC_DECOMM_CLD_MySites_#', 10, 19 )
--, ('PROD_SPC_DECOMM_CLD_MySites_Buffer_1', 0, 0 )
	


/*  B2B Test Non-Legal  */
--	('TEST_Partner_CONFIG', 0, 0 )
--,	('TEST_Partner_SPS_Admin', 0, 0 )
--,	('PROD_Partner_SPC_Collab_#', 10, 11 )
--,	('TEST_Partner_SPS_SearchAdmin', 0, 0 )
--,	('TEST_Partner_SPS_AnalyticsReporting', 0, 0 )
--,	('TEST_Partner_SPS_Crawl_#', 10, 10 )
--,	('TEST_Partner_SPS_Link_#', 10, 10 )
--,	('TEST_Partner_SPS_SecureStore', 0, 0 )
--,	('TEST_Partner_SPS_Usage', 0, 0 )
--,	('TEST_Partner_SPS_ManagedMetadata', 0, 0 )
--,	('TEST_Partner_SPS_StateService', 0, 0 )
--,	('SF_SP2016_CONFIG_FILES', 0, 0)



/*  B2B Test Legal  */

--	('TEST_Partner_CLD_CONFIG', 0, 0 )
--,	('TEST_Partner_CLD_SPS_Admin', 0, 0 )
--,	('TEST_Partner_CLD_SPS_SearchAdmin', 0, 0 )
--,	('TEST_Partner_CLD_SPS_AnalyticsReporting', 0, 0 )
--,	('TEST_Partner_CLD_SPS_SecureStore', 0, 0 )
--,	('TEST_Partner_CLD_SPS_Usage', 0, 0 )
--,	('TEST_Partner_CLD_SPS_StateService', 0, 0 )
--,	('TEST_Partner_CLD_SPC_Collab_#', 10, 10 )
--,	('TEST_Partner_CLD_SPS_Crawl_#', 10, 10 )
--,	('TEST_Partner_CLD_SPS_Link_#', 10, 10 )











/********************************************************************************************************/
/********************************************************************************************************/
/********************************************************************************************************/
/********************************************************************************************************/
/********************************************************************************************************/
/********************************************************************************************************/

DECLARE DBListCursor CURSOR STATIC FOR
SELECT 
	DBLoopName
,	DBStartNum
,	DBEndNum
FROM
	#DBNameCounts

OPEN DBListCursor

FETCH FIRST FROM DBListCursor INTO @DBLoopName, @DBStartNum, @DBEndNum

CREATE TABLE #databases
(	DBName	VARCHAR(64)
)

WHILE @@FETCH_STATUS = 0
BEGIN
	IF @DBStartNum = 0 AND @DBEndNum = 0
	BEGIN
		INSERT INTO #databases
		SELECT @DBLoopName
	END
	ELSE 
	BEGIN
		SET @LoopCount = @DBStartNum

		WHILE @LoopCount <= @DBEndNum
		BEGIN
			INSERT INTO #databases
			SELECT REPLACE(@DBLoopName, '#', CONVERT(VARCHAR(3), @LoopCount))

			SET @LoopCount = @LoopCount + 1
		END
	END

	FETCH NEXT FROM DBListCursor INTO @DBLoopName, @DBStartNum, @DBEndNum
END

--SELECT	@DataDriveLoc = LEFT(physical_name, 18) FROM sys.master_files WHERE name = 'SF_SQL_Admin'
--SELECT	@LogFileLoc = LEFT(physical_name, 21) FROM sys.master_files WHERE name = 'SF_SQL_Admin_log'

EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultData', @DataDriveLoc OUTPUT
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultLog', @LogFileLoc OUTPUT

SELECT @DataDriveLoc = LEFT(@DataDriveLoc, 18)
SELECT @LogFileLoc = LEFT(@LogFileLoc, 21) + '\'

--SELECT 
--	DBName 
--FROM 
--	#databases

DECLARE DBNameCursor CURSOR STATIC FOR
SELECT 
	DBName 
FROM 
	#databases

OPEN DBNameCursor

FETCH FIRST FROM DBNameCursor INTO @DBName

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @LoopCount = 1

	WHILE @LoopCount <= @NumDataDrive
	BEGIN
		SELECT @DataFileLoc = @DataDriveLoc + (RIGHT('00' + CONVERT(VARCHAR(4), @LoopCount), 2)) + '\'
	
		IF @LoopCount = 1
		BEGIN
			IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = @DBName)
			BEGIN
				PRINT '--' + @DBName + ' - CreatingDatabase' + ' - Data File: ' + @DataFileLoc + ' - Log File: ' + @LogFileLoc
				SELECT @cmd = 'CREATE DATABASE ' + @DBName + ' ON 
( NAME = N''' + @DBName + '_' + (RIGHT('00' + CONVERT(VARCHAR(4), @LoopCount), 2)) + 
''', FILENAME = N''' + @DataFileLoc +  @DBName + '_' + (RIGHT('00' + CONVERT(VARCHAR(4), @LoopCount), 2)) + '.mdf'' , SIZE = ' + @DBFileSizeMB + 'MB , MAXSIZE = ' + @DBMaxSizeMB + 'MB , FILEGROWTH = ' + @DBGrowthSizeMB + 'MB )
 LOG ON 
( NAME = N''' + @DBName + '_log'', FILENAME = N''' + @LogFileLoc + @DBName + '_log.ldf'' , SIZE = ' + @DBFileSizeMB + 'MB , MAXSIZE = ' + @DBMaxSizeMB + 'MB , FILEGROWTH = ' + @DBGrowthSizeMB + 'MB )
COLLATE Latin1_General_CI_AS_KS_WS;
EXEC ' + @DBName + '.dbo.sp_changedbowner @loginame = N''sfsa'', @map = false;'


				PRINT @cmd
				PRINT ''
				EXEC (@cmd)
			END
		END
		ELSE
		BEGIN
			IF NOT EXISTS (SELECT name FROM sys.master_files WHERE name = @DBName + '_' + (RIGHT('00' + CONVERT(VARCHAR(4), @LoopCount), 2)))
			BEGIN
				PRINT '--' + @DBName + ' - AddingFile' + ' - Data File: ' +  @DataFileLoc
				SELECT @cmd = 'ALTER DATABASE ' + @DBName + ' ADD FILE 
( NAME = N''' + @DBName + '_' + (RIGHT('00' + CONVERT(VARCHAR(4), @LoopCount), 2)) +
''', FILENAME = N''' + @DataFileLoc +  @DBName + '_' + (RIGHT('00' + CONVERT(VARCHAR(4), @LoopCount), 2)) + '.mdf'' , SIZE = ' + @DBFileSizeMB + 'MB , MAXSIZE = ' + @DBMaxSizeMB + 'MB , FILEGROWTH = ' + @DBGrowthSizeMB + 'MB )'

				PRINT @cmd
				PRINT ''
				EXEC (@cmd)
			END
		END

		SET @LoopCount = @LoopCount + 1
	END
	
	FETCH NEXT FROM DBNameCursor INTO @DBName

END

CLOSE DBListCursor
DEALLOCATE DBListCursor

CLOSE DBNameCursor
DEALLOCATE DBNameCursor

DROP TABLE #DBNameCounts
DROP TABLE #databases