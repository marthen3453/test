SELECT 
	database_name
,	AVG(backup_size) AS AvgFullSize
,	AVG(compressed_backup_size) AS AvgCompSize
,	AVG(compressed_backup_size)/AVG(backup_size) AS AvgCompRatio
INTO 
	#CompRatios
FROM 
	msdb..backupset 
WHERE 
	backup_start_date >= DATEADD(DAY, -3, GETDATE())
	AND
	database_name NOT IN ('master', 'model', 'msdb', 'tempdb', 'SF_SQL_ADMIN')
	AND
	database_name IN (SELECT name FROM sys.databases WHERE state_desc = 'ONLINE' AND is_read_only = 0)
	AND
	type = 'D'
GROUP BY
	database_name

SELECT 
	database_name ,
    AvgFullSize/1024/1024/1024 AS FullSizeGB,
    AvgCompSize/1024/1024/1024 AS CompressedSizeGB,
    AvgCompRatio AS CompressionRatio
FROM 
	#CompRatios
--WHERE
--	database_name LIKE '%MySite%'

SELECT 
	SUM(AvgCompSize)/1024/1024/1024 AS SP2010BackupReqSpace
FROM 
	#CompRatios
--WHERE
--	database_name LIKE '%MySite%'



DROP TABLE #CompRatios