--SELECT GETDATE()

select 
	COUNT(*) AS blocked_session_count 
from 
	sys.dm_exec_requests 
where 
	blocking_session_id <> 0  


SELECT 
	* 
FROM 
	sys.dm_exec_requests
WHERE
	session_id IN 
	(
		select blocking_session_id 
		from sys.dm_exec_requests
		where blocking_session_id <> 0
	)
	AND 
	blocking_session_id = 0
ORDER BY
	session_id

select 
	* 
from 
	sys.dm_exec_sessions 
where 
	session_id in 
	(	
		SELECT 
			session_id 
		FROM 
			sys.dm_exec_requests
		WHERE
			session_id IN 
			(
				select blocking_session_id 
				from sys.dm_exec_requests 
				where blocking_session_id <> 0
			)
			AND 
			blocking_session_id = 0
	)
ORDER BY
	session_id


select 
	* 
from 
	sys.dm_exec_connections 
	cross apply sys.dm_exec_sql_text(most_recent_sql_handle) 
where 
	session_id in 
	(
		SELECT 
			session_id 
		FROM 
			sys.dm_exec_requests
		WHERE
			session_id IN 
			(
				select blocking_session_id 
				from sys.dm_exec_requests 
				where blocking_session_id <> 0
			)
			AND 
			blocking_session_id = 0
	)
ORDER BY
	session_id

--select object_name(object_id) from sys.partitions where partition_id =72057594484948992 


--SELECT * FROM sys.databases where database_id = 74


--SELECT TOP 50 * FROM msdb.dbo.sqlpig_processor_usage_sf WHERE Report_Time >= '2014-06-27 11:30' ORDER BY Report_Time DESC