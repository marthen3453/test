DECLARE @TempLocation	VARCHAR(128)
,		@TempTotalFiles	TINYINT
,		@TempFileNum	TINYINT
,		@cmd			VARCHAR(5000)

/*  MODIFY THIS VALUE!!  */
SET @TempTotalFiles = 8



/*  NO MODIFICATIONS PAST THIS LINE!!  */
SET @TempFileNum = 2
SET @cmd = ''

SELECT 
	@TempLocation = LEFT(physical_name, LEN(physical_name)-10)
	--*
FROM tempdb.sys.database_files
WHERE name = 'tempdev'

--SELECT @TempLocation AS TempLocationValue

WHILE @TempFileNum <= @TempTotalFiles
BEGIN
	IF NOT EXISTS (SELECT * FROM tempdb.sys.database_files WHERE name = 'tempdev_' + RIGHT('00' + CONVERT(VARCHAR(3), @TempFileNum), 2) )
	BEGIN
		SET @cmd = @cmd + 'ALTER DATABASE [tempdb] ADD FILE ( NAME =N''tempdev_' + RIGHT('00' + CONVERT(VARCHAR(3), @TempFileNum), 2) + ''', FILENAME =N''' + @TempLocation + 'tempdev_' + RIGHT('00' + CONVERT(VARCHAR(3), @TempFileNum), 2) + '.ndf'', SIZE = 500MB, MAXSIZE = 5000MB, FILEGROWTH = 500MB );'+CHAR(13)+CHAR(10)
	END
	
	SET @TempFileNum = @TempFileNum + 1
END

PRINT @cmd

EXEC (@cmd)


SELECT * FROM tempdb.sys.database_files