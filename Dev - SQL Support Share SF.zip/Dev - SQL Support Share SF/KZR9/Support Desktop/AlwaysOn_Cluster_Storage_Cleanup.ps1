#Title
#Variables
$ServerName = $env:computername
$log = ".\Log\AlwaysOn_Storage_Cleanup.log"
$script:errorlevel = 0
$workingdirectory = $PWD

#Functions
function WriteToLog {
	Param ($msg,$msgtype)
	#Examples:
		#writetolog "$msg"
		#writetolog "$msg" "ERROR"
	if ($msgtype -ne $null) {
		if ($msgtype -eq "ERROR") {$script:errorlevel = 1}
		$msgtype = "["+$msgtype+"] "
	}
	$msg = $($msg | Out-String)
	$retries = 5
	$addcontent = $null
	$i = 1
	$capturederror = $null
	do { 
		try {
		Add-Content -Value "$(Get-date -Format 'yyyyMMdd-HH:mm:ss') $msgtype$msg" -Path $log -ErrorAction Stop
		}
		catch {
			$capturederror = $_
		}
		if ($capturederror -ne $null) {
			$i++
			Start-Sleep -Seconds 1
		}
		else {$addcontent = "Success"}
	} until ($addcontent -eq "Success" -or $i -gt $retries)
	Write-host "$msgtype$msg" 
    Write-Debug "$msgtype$msg" 
}

function ExitScript {
	#Examples:
		#ExitScript
	switch ($script:errorlevel){
		0 {
			writetolog "Exiting script with a status of: Success"
			exit 0
		}
		default {
			writetolog "Exiting script with a status of: Failed" "ERROR"
			exit 1
		}
	}
}

function trycatch {
	param ($command,[switch]$exitonfailure)
	#Examples:
		#$variable = trycatch -command "command"
		#$variable = trycatch -command "command" -exitonfailure
	try {
		$tryresult = $null
		$tryresult = Invoke-Expression -Command $command -ErrorAction Stop
	}
	catch {
		$capturederror = $_
		writetolog $capturederror "ERROR"
		if ($exitonfailure) {ExitScript}
		else {return $capturederror}
	}
	return $tryresult
}

#Main
#create the log file
if (!(Test-Path $log)) {New-Item -ItemType File -Path $log -force | Out-Null}
writetolog "Script Started."

writetolog "Remove all disks from Available Storage"
get-cluster | Get-ClusterResource | where {$_.OwnerGroup -like "Available Storage"} | Remove-ClusterResource -force -confirm:$false -erroraction SilentlyContinue

writetolog "Bring all disks online & clear persistent reservations"
$offlinedisks = @(Invoke-Command -ScriptBlock {"list disk" | diskpart | Where {$_ -match "Offline"}})
writetolog "offlinedisks = "
writetolog "$($offlinedisks | Out-String)"
foreach ($disk in $offlinedisks) {
	$trimmeddisk = ($disk.trim().replace("  ",",").split(","))[0]
	writetolog "Bring $trimmeddisk online"
	$tempdiskpart = Invoke-Command -ScriptBlock {"Select $trimmeddisk","online disk" | diskpart}
	writetolog "($tempdiskpart | out-string).trim()"
	writetolog "Clear any read-only flags for $trimmeddisk"
	$tempdiskpart = Invoke-Command -ScriptBlock {"select $trimmeddisk","attributes disk clear readonly" | diskpart}
	writetolog "($tempdiskpart | out-string).trim()"
	$disknum = ($trimmeddisk.split(" "))[1]
	writetolog "Clear the persistent reservation for $trimmeddisk"
	$tempdiskpart = Invoke-Command -ScriptBlock {CLUSTER NODE /CLEARPR:$disknum}
	writetolog "($tempdiskpart | out-string).trim()"
}

exitscript
