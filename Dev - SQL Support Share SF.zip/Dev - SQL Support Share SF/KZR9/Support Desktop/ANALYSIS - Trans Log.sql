--SELECT
--	COUNT(*) AS TotalSessions
--FROM
--	sys.dm_exec_sessions

--SELECT
--	COUNT(*) AS NotSleeping
--FROM
--	sys.dm_exec_sessions
--WHERE
--	status != 'sleeping'

--SELECT
--	TOP 50 *
--FROM
--	SFSQL_SessionState.dbo.SState
----WHERE
--	--Uid = 'c1@o6InUJF4SpJ7Chnfpp0aXw'
--	--Data LIKE 'ActvRecs%'
--ORDER BY
--	[Expiration] ASC

--SELECT
--	COUNT(*) AS ExpiredRecCount
--,	MIN(expiration) AS OldestRec
--FROM
--	SFSQL_SessionState.dbo.SState
--WHERE
--	Expiration <= GETDATE()

SELECT
	[Checkpoint Begin]
FROM
	SFSQL_SessionState.sys.fn_dblog(null,null)
WHERE
	[Checkpoint Begin] IS NOT NULL
ORDER BY
	[Current LSN], 
	[Transaction ID]

SELECT
	Operation
,	COUNT(*) AS OperationCount
FROM
	SFSQL_SessionState.sys.fn_dblog(null,null)
GROUP BY
	Operation
ORDER BY
	COUNT(*) DESC

--SELECT
--	*
--FROM
--	SFSQL_SessionState.sys.fn_dblog(null,null)
--WHERE
--	[Checkpoint Begin] IS NOT NULL
--ORDER BY
--	[Current LSN], 
--	[Transaction ID]


	