DECLARE @dbname		VARCHAR(256)
,		@srvcmd		VARCHAR(2048)
,		@dbcmd		VARCHAR(2048)
,		@acct01	VARCHAR(64)
,		@acct02	VARCHAR(64)
,		@acct03	VARCHAR(64)


SET @acct01 = ''
SET @acct02 = ''
SET @acct03 = ''

SELECT @srvcmd = '
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE [name] = ''' + @acct01 + ''')
BEGIN
	CREATE LOGIN [' + @acct01 + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]
END

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE [name] = ''' + @acct02 + ''')
BEGIN
	CREATE LOGIN [' + @acct02 + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]

END

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE [name] = ''' + @acct03 + ''')
BEGIN
	CREATE LOGIN [' + @acct03 + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]

END

GRANT VIEW SERVER STATE TO [' + @acct01 + ']
GRANT VIEW ANY DEFINITION TO [' + @acct01 + ']

GRANT VIEW SERVER STATE TO [' + @acct02 + ']
GRANT VIEW ANY DEFINITION TO [' + @acct02 + ']

'

--PRINT @srvcmd
EXEC (@srvcmd)

DECLARE dbcursor CURSOR STATIC FOR
SELECT name AS DatabaseName FROM sys.databases
WHERE
	database_id > 4
	AND
	name != 'SF_SQL_Admin'
	AND
	source_database_id IS NULL
--WHERE
--	name IN ('', '', '', '')

OPEN dbcursor

FETCH FIRST FROM dbcursor INTO @dbname

WHILE @@FETCH_STATUS = 0
BEGIN 
	SELECT @dbcmd = 'USE [' + @dbname + ']
	IF NOT EXISTS (SELECT * FROM sys.database_principals a INNER JOIN [master].sys.server_principals b ON a.sid = b.sid WHERE b.name = ''' + @acct01 + ''')
	BEGIN
		CREATE USER [' + @acct01 + '] FOR LOGIN [' + @acct01 + ']
		ALTER ROLE [db_datareader] ADD MEMBER [' + @acct01 + ']
	END

	IF NOT EXISTS (SELECT * FROM sys.database_principals a INNER JOIN [master].sys.server_principals b ON a.sid = b.sid WHERE b.name = ''' + @acct02 + ''')
	BEGIN
		CREATE USER [' + @acct02 + '] FOR LOGIN [' + @acct02 + ']
		ALTER ROLE [db_datareader] ADD MEMBER [' + @acct02 + ']
	END

	IF NOT EXISTS (SELECT * FROM sys.database_principals a INNER JOIN [master].sys.server_principals b ON a.sid = b.sid WHERE b.name = ''' + @acct03 + ''')
	BEGIN
		CREATE USER [' + @acct03 + '] FOR LOGIN [' + @acct03 + ']
		ALTER ROLE [db_datareader] ADD MEMBER [' + @acct03 + ']
	END

	'

	--PRINT @dbcmd
	EXEC (@dbcmd)

	FETCH NEXT FROM dbcursor INTO @dbname
END

CLOSE dbcursor
DEALLOCATE dbcursor




