﻿####WS08 Cluster Install 6.1 (1.1)####

####Variables####
$Log = ".\log\WS08_Cluster_Install.log"
$script:errorlevel = 0

####Functions####
function WriteToLog {
	Param ($msg,$msgtype)
	if ($msgtype -ne $null) {
		if ($msgtype -eq "ERROR") {$script:errorlevel = 1}
		$msgtype = "["+$msgtype+"] "
	}
	$retries = 5
	$addcontent = $null
	$i = 1
	$capturederror = $null
	do { 
		try {
		Add-Content -Value "$(Get-date -Format 'yyyyMMdd-HH:mm:ss') $msgtype$msg" -Path $log -ErrorAction Stop
		}
		catch {
			$capturederror = $_
		}
		if ($capturederror -ne $null) {
			$i++
			Start-Sleep -Seconds 1
		}
		else {$addcontent = "Success"}
	} until ($addcontent -eq "Success" -or $i -gt $retries)
	Write-host "$msgtype$msg" 
    Write-Debug "$msgtype$msg" 
}

function ExitScript {
	switch ($script:errorlevel){
		0 {
			writetolog "Exiting script with a status of: Success"
			exit 0
		}
		default {
			writetolog "Exiting script with a status of: Failed" "ERROR"
			exit 1
		}
	}
}

function ServerOSCheck{

	$OSWmi = Get-WmiObject -Class win32_operatingsystem
	$OSCheck = $OSWmi.caption
	$serverOS = $null

	Get-Date
	" "
	if ($OSCheck -like "*2008 Enterprise*"){
		$serverOS = "WS08"
	}
	elseif ($OSCheck -like "*2008 R2 Enterprise*" ){
		$serverOS = "WS08R2"
	}
	elseif ($OSCheck -like "*Windows Server 2012*" ){
		$serverOS = "WS12"
	}
    elseif ($OSCheck -like "*Windows Server 2016*" ){
		$serverOS = "WS16"
	}
	else{
		$serverOS = $OSCheck
	}
	return $serverOS
}
####WS08R1 Functions####
Function WindowsFeatureWS08{
	Param ($Feature,[switch]$add,[switch]$remove,$InstalledString,$NotInstalledString)
	#check if the feature is installed
	$servermanagerquery = servermanagercmd -query
	$Featurequery = $null
	$Installed = $null
	$Installed = $servermanagerquery | Select-String "$InstalledString"
	$NOTInstalled = $null
	$NOTInstalled = $servermanagerquery | Select-String "$NotInstalledString"
	
	if ($Installed -eq $null -and $NOTInstalled -eq $null) {
		writetolog "Installed string $installedString not found and Not Installed String $NotInstalledString not found." "ERROR"
		writetolog "Verify the Installed String and Not Installed string" "ERROR"
		writetolog "$Feature not found or Installed string or Not Installed string not found" "ERROR"
		exitscript
	}
	if ($NotInstalled -ne $null){
		writetolog "The Windows Feature $Feature was not installed."
		if ($add -eq $true) {
			writetolog "Installing $Feature"
			#Add Feature
			$capturederror = $null
			try {
				Invoke-Expression -command "servermanagercmd -install $Feature"
			}
			catch {
				writetolog $capturederror "ERROR"
				exitscript
			}
			#verify
			$retries = 10
			$i = 0
			Do {
				$i++
				Start-Sleep -Seconds 10
				$servermanagerquery = $null
				$servermanagerquery = servermanagercmd -query
				$Installed = $null
				$Installed = $servermanagerquery | Select-String "$InstalledString"
			}
			until ($installed -ne $null -or $i -gt $retries)
			if ($Installed -ne $null) {
				writetolog "$Feature was installed successfully."
			}
			else {
				writetolog "$Feature was not installed successfully." "ERROR"
				exitscript
			}
		}
	}
	elseif ($Installed -ne $null) {
		writetolog "The Windows Feature $Feature was already installed."
		if ($remove -eq $true) {
			writetolog "Uninstalling $Feature"
			#Remove Feature
			$capturederror = $null
			try {
				Invoke-Expression -command "servermanagercmd -remove $Feature"
			}
			catch {
				writetolog $capturederror "ERROR"
				exitscript
			}
			#verify
			$retries = 10
			$i = 0
			Do {
				$i++
				Start-Sleep -Seconds 10
				$servermanagerquery = $null
				$servermanagerquery = servermanagercmd -query
				$NotInstalled = $null
				$NotInstalled = $servermanagerquery | Select-String "$NotInstalledString"
			}
			until ($NotInstalled -ne $null -or $i -gt $retries)
			if ($Installed -ne $null) {
				writetolog "$Feature was removed successfully."
			}
			else {
				writetolog "$Feature was not removed successfully." "ERROR"
				exitscript
			}
		}
	}
}    

####WS08R2 Functions####
Function ImportModuleServerManager()
{
	#Checking for Module being loaded
	# --- Load the ServerManager Module
	if (-not (Get-Module | Where-Object {$_.Name -eq "ServerManager"})) 
	{ 
         writetolog "ServerManager Module NOT loaded, loading it now..."
        $capturederror = $null
		try {
			Import-Module ServerManager 
		}
			catch {
				$capturederror = $_
				 writetolog $capturederror  "ERROR"
				 ExitScript
			}
		if ($capturederror -eq $null) {
		writetolog "ServerManager Module loaded successfully!"
		}
    } 
}

Function WindowsFeatureWS08R2{
	Param ($Feature,[switch]$add,[switch]$remove)
	#check if the feature is installed
	$Featurestatus = $Null
	$Featurestatus = get-windowsfeature "$feature"
	if ($featurestatus.installed -eq $False){
		writetolog "The Windows Feature $Feature was not installed."
		if ($add -eq $true) {
			writetolog "Installing $Feature"
			#Add Feature
			$temp = $null
			try {
				$temp = Add-WindowsFeature $Feature
			}
			catch {
				$capturederror = $_
				writetolog $capturederror "ERROR"
				exitscript
			}
			#Verify
			if ((get-windowsfeature "$feature").installed -eq $true) {
				writetolog "$feature was successfully installed"
			}
			else {
				writetolog "$feature was not successfully installed" "ERROR"
				exitscript
			}
		}
	}
	elseif ($featurestatus.installed -eq $True) {
		writetolog "The Windows Feature $Feature was already installed."
		if ($remove -eq $true) {
			writetolog "Removing $Feature"
			#Remove Feature
			try {
				$temp = Remove-WindowsFeature $Feature
			}
			catch {
				$capturederror = $_
				writetolog $capturederror "ERROR"
				exitscript
			}
			#verify
			if ((get-windowsfeature "$feature").installed -eq $false) {
				writetolog "$feature was successfully removed"
			}
			else {
				writetolog "$feature was not successfully removed" "ERROR"
				exitscript
			}

		}
	}
	elseif ($Featurestatus -eq $null) {
		writetolog "$Feature was not found and is not installable on this server."
		exitscript
	}
}    


####WS12 Functions####
Function WindowsFeatureWS12{
	Param ($Feature,[switch]$Add,[switch]$Remove,[switch]$IncludeAllSubFeature,[switch]$IncludeManagementTools)
	#check if the feature is installed
	$Featurestatus = $Null
	$Featurestatus = get-windowsfeature "$feature"
	if ($featurestatus.installed -eq $False){
		writetolog "The Windows Feature $Feature was not installed."
		if ($add -eq $true) {
			writetolog "Installing $Feature"
			#Add Feature
			$temp = $null
			
			try {
				if ($IncludeAllSubFeature) {$temp = Install-WindowsFeature -name $Feature -IncludeAllSubFeature}
				elseif ($IncludeManagementTools) {$temp = Install-WindowsFeature -name $Feature -IncludeManagementTools}
				else {$temp = Install-WindowsFeature -name $Feature}
			}
			catch {
				$capturederror = $_
				writetolog $capturederror "ERROR"
				exitscript
			}
			#Verify
			if ((get-windowsfeature "$feature").installed -eq $true) {
				writetolog "$feature was successfully installed"
			}
			else {
				writetolog "$feature was not successfully installed" "ERROR"
				exitscript
			}
		}
	}
	elseif ($featurestatus.installed -eq $True) {
		writetolog "The Windows Feature $Feature was already installed."
		if ($remove -eq $true) {
			writetolog "Removing $Feature"
			#Remove Feature
			try {
				if ($IncludeManagementTools) {$temp = uninstall-WindowsFeature -name $Feature -IncludeManagementTools}
				else {$temp = uninstall-WindowsFeature -name $Feature}
			}
			catch {
				$capturederror = $_
				writetolog $capturederror "ERROR"
				exitscript
			}
			#verify
			if ((get-windowsfeature "$feature").installed -eq $false) {
				writetolog "$feature was successfully removed"
			}
			else {
				writetolog "$feature was not successfully removed" "ERROR"
				exitscript
			}

		}
	}
	elseif ($Featurestatus -eq $null) {
		writetolog "$Feature was not found and is not installable on this server."
		exitscript
	}
} 


####Main####
$ServerOS = serveroscheck
if ($serverOS -eq "WS08R2" -or $serverOS -eq "WS12" -or $serverOS -eq "WS16") {importmoduleservermanager}

if ($serverOS -eq "WS16") {
	writetolog "Server OS is Windows Server 2016"
	
	$Feature = "Failover-Clustering"
	WindowsFeatureWS12 -feature $Feature -add -IncludeManagementTools
	
	$Feature = "RSAT-Clustering-CmdInterface"
	WindowsFeatureWS12 -feature $Feature -add
	
	$Feature = "RSAT-Clustering-AutomationServer"
	WindowsFeatureWS12 -feature $Feature -add

	$temp = get-windowsfeature *cluster* | Out-string
	writetolog $temp
}

if ($serverOS -eq "WS12") {
	writetolog "Server OS is Windows Server 2012"
	
	$Feature = "Failover-Clustering"
	WindowsFeatureWS12 -feature $Feature -add -IncludeManagementTools
	
	$Feature = "RSAT-Clustering-CmdInterface"
	WindowsFeatureWS12 -feature $Feature -add
	
	$Feature = "RSAT-Clustering-AutomationServer"
	WindowsFeatureWS12 -feature $Feature -add

	$temp = get-windowsfeature *cluster* | Out-string
	writetolog $temp
}

if ($serverOS -eq "WS08R2") {
	writetolog "Server OS is Windows Server 2008 R2"
	
	$Feature = "Failover-Clustering"
	WindowsFeatureWS08R2 -feature $Feature -add
	
	$temp = get-windowsfeature *cluster* | Out-string
	writetolog $temp
}

if ($serverOS -eq "WS08") {
	writetolog "Server OS is Windows Server 2008"
	
	$Feature = "Failover-Clustering"
	$InstalledString = "\[X\] Failover Clustering  \[Failover-Clustering\]"
	$NotInstalledString = "\[ \] Failover Clustering  \[Failover-Clustering\]"
	WindowsFeatureWS08 -Feature $Feature -add -InstalledString $installedstring -NotInstalledString $NotInstalledString
}

exitscript
