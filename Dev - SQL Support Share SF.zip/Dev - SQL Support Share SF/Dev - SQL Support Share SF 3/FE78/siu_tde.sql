--Enable EKM Provider option
sp_configure 'show advanced', 1
GO
RECONFIGURE
GO
sp_configure 'EKM provider enabled', 1
GO
RECONFIGURE
GO


--Register Luka EKM Provider
--Open a query window, and then run the following command:
CREATE CRYPTOGRAPHIC PROVIDER SIU_Luna_Cryp
FROM FILE = 'C:\Program Files\SafeNet\LunaClient\EKM\LunaEKM.DLL'


/**************************************************************************************************
*The next step is to create a CREDENTIAL for the Luna EKM Provider.				  *
*Then the CREDENTIAL must be mapped to a Login such as our support account.			  *
*The account needs to login to access MASTER and create a key.					  *
**************************************************************************************************/
CREATE CREDENTIAL SIU_Luna_Cred
WITH IDENTITY='SQL_LunaCredential', SECRET='Lx3T-W9Cw-sQpE-49TH' --Get Secret from Stephen Druessel
FOR CRYPTOGRAPHIC PROVIDER SIU_Luna_Cryp

--Create login and map the credential to it
CREATE LOGIN [SUPPORT\SIA_FE78] FROM WINDOWS WITH DEFAULT_DATABASE=[master]
GO

ALTER LOGIN [SUPPORT\SIA_FE78]
ADD CREDENTIAL SIU_Luna_Cred



/**************************************************************************************************
*Next we create an asymmetric key based off the provider we created.				  *
*Then we create a credential that will bind to a SQL account, which will use the key to		  *
*encrypt and decrypt the database.								  *
**************************************************************************************************/
Use master;
CREATE ASYMMETRIC KEY EKM_SIU_RSA2048_FrstB
FROM Provider SIU_Luna_Cryp
WITH ALGORITHM = RSA_2048,
PROVIDER_KEY_NAME = 'EKM_RSA_2048_Key',
CREATION_DISPOSITION=CREATE_NEW

CREATE CREDENTIAL luna_tde_cred 
WITH IDENTITY = 'tde_cred_identity' 
, SECRET = 'Lx3T-W9Cw-sQpE-49TH' --Get Secret from Stephen Druessel
FOR CRYPTOGRAPHIC PROVIDER SIU_Luna_Cryp ;

CREATE LOGIN SQL_Luna_TDE
FROM ASYMMETRIC KEY EKM_SIU_RSA2048_FrstB;
GO
ALTER LOGIN SQL_Luna_TDE
ADD CREDENTIAL luna_tde_cred;
GO


/**************************************************************************************************
*Now we create a database encrpytion key based off the asymmetric key, then enable encryption.	  *
*Repeat for each database needing encryption.							  *
**************************************************************************************************/
Use SFSQL_SIU_00037;
GO
CREATE DATABASE ENCRYPTION KEY
WITH ALGORITHM = AES_256
ENCRYPTION BY SERVER ASYMMETRIC KEY EKM_SIU_RSA2048_FrstB;
GO
ALTER DATABASE SFSQL_SIU_00037
SET ENCRYPTION ON;
GO

--Check encryption status and progress for databases
SELECT DB_NAME (e.database_id) AS DatabaseName,
e.database_id,
e.encryption_state,
CASE e.encryption_state
WHEN 0 THEN 'No database encryption key present, no encryption'
WHEN 1 THEN 'Unencrypted'
WHEN 2 THEN 'Encryption in progress'
WHEN 3 THEN 'Encrypted'
WHEN 4 THEN 'Key change in progress'
WHEN 5 THEN 'Decryption in progress'
END AS encryption_state_desc,
c.name,
e.percent_complete
FROM sys.dm_database_encryption_keys AS e
LEFT JOIN master.sys.asymmetric_keys AS c
ON e.encryptor_thumbprint = c.thumbprint
GO




--Additional queries for verification if needed
--1. To view the list of EKM providers:
SELECT [provider_id]
,[name]
,[guid]
,[version]
,[dll_path]
,[is_enabled]
FROM [model].[sys].[cryptographic_providers]

--2. To view the provider properties:
SELECT [provider_id],[guid],[provider_version]
,[sqlcrypt_version]
,[friendly_name]
,[authentication_type]
,[symmetric_key_support]
,[symmetric_key_persistance]
,[symmetric_key_export]
,[symmetric_key_import]
,[asymmetric_key_support]
,[asymmetric_key_persistance]
,[asymmetric_key_export]
,[asymmetric_key_import]
FROM [master].[sys].[dm_cryptographic_provider_properties]

--3. To view the asymmetric keys for Luna EKM Provider:
 select * from sys.asymmetric_keys

--4. Check encryption status and progress for databases
SELECT DB_NAME (e.database_id) AS DatabaseName,
e.database_id,
e.encryption_state,
CASE e.encryption_state
WHEN 0 THEN 'No database encryption key present, no encryption'
WHEN 1 THEN 'Unencrypted'
WHEN 2 THEN 'Encryption in progress'
WHEN 3 THEN 'Encrypted'
WHEN 4 THEN 'Key change in progress'
WHEN 5 THEN 'Decryption in progress'
END AS encryption_state_desc,
c.name,
e.percent_complete
FROM sys.dm_database_encryption_keys AS e
LEFT JOIN master.sys.asymmetric_keys AS c
ON e.encryptor_thumbprint = c.thumbprint
GO