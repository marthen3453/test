/*
PART 1 - Backup database on source server
*/ 

BACKUP DATABASE [StateFarm_FTP] 
TO  DISK = N'F:\MSSQL\BACKUP\F_MP04\BACKUP\StateFarm_FTP_March2016_Marvin.bak' 
WITH  COPY_ONLY, NOFORMAT, NOINIT,  
NAME = N'StateFarm_FTP-Full Database Backup', 
SKIP, NOREWIND, NOUNLOAD, COMPRESSION,  
STATS = 10
GO

BACKUP DATABASE [StateFarm_MarketData_FTP] 
TO  DISK = N'F:\MSSQL\BACKUP\F_MP04\BACKUP\StateFarm_MarketData_FTP_March2016_Marvin.bak' 
WITH  COPY_ONLY, NOFORMAT, NOINIT,  
NAME = N'StateFarm_MarketData_FTP-Full Database Backup', 
SKIP, NOREWIND, NOUNLOAD, COMPRESSION,  
STATS = 10
GO


BACKUP DATABASE [StateFarm_PositionData_FTP] 
TO  DISK = N'F:\MSSQL\BACKUP\F_MP04\BACKUP\StateFarm_PositionData_FTP_March2016_Marvin.bak' 
WITH  COPY_ONLY, NOFORMAT, NOINIT,  
NAME = N'StateFarm_PositionData_FTP-Full Database Backup', 
SKIP, NOREWIND, NOUNLOAD, COMPRESSION,  
STATS = 10
GO

/*
PART 2 - Restore database on target server
*/ 

USE [master]
RESTORE DATABASE [StateFarm_FTP_March2016_Marvin] 
FROM  DISK = N'F:\MSSQL\BACKUP\F_MP04\BACKUP\StateFarm_FTP_March2016_Marvin.bak' 
WITH  FILE = 1,  
MOVE N'StateFarm_Data' TO N'F:\MSSQL\DATA\F_MP01\DATA\StateFarm_FTP_March2016_Marvin.mdf',  
MOVE N'StateFarm_Data2' TO N'F:\MSSQL\DATA\F_MP01\DATA\StateFarm_FTP_March2016_Marvin_1.ndf',  
MOVE N'StateFarm_Data3' TO N'F:\MSSQL\DATA\F_MP01\DATA\StateFarm_FTP_March2016_Marvin_2.ndf',  
MOVE N'StateFarm_Data4' TO N'F:\MSSQL\DATA\F_MP01\DATA\StateFarm_FTP_March2016_Marvin_3.ndf',  
MOVE N'StateFarm_Log' TO N'F:\MSSQL\LOGS\F_MP02\LOGS\StateFarm_FTP_March2016_Marvin_4.ldf',  
MOVE N'StateFarm_Log2' TO N'F:\MSSQL\LOGS\F_MP02\LOGS\StateFarm_FTP_March2016_Marvin_5.ldf',  
NOUNLOAD,  
STATS = 5
GO

USE [master]
RESTORE DATABASE [StateFarm_MarketData_FTP_March2016_Marvin] 
FROM  DISK = N'F:\MSSQL\BACKUP\F_MP04\BACKUP\StateFarm_MarketData_FTP_March2016_Marvin.bak' 
WITH  FILE = 1,  
MOVE N'AN_StateFarm_MarketData' TO N'F:\MSSQL\DATA\F_MP01\DATA\StateFarm_MarketData_FTP_March2016_Marvin.mdf',  
MOVE N'AN_StateFarm_MarketData2' TO N'F:\MSSQL\DATA\F_MP01\DATA\StateFarm_MarketData_FTP_March2016_Marvin_1.ndf', 
MOVE N'AN_StateFarm_MarketData_log' TO N'F:\MSSQL\LOGS\F_MP02\LOGS\StateFarm_MarketData_FTP_March2016_Marvin_2.ldf',  
NOUNLOAD,  
STATS = 5
GO

USE [master]
RESTORE DATABASE [StateFarm_PositionData_FTP_March2016_Marvin] 
FROM  DISK = N'F:\MSSQL\BACKUP\F_MP04\BACKUP\StateFarm_PositionData_FTP_March2016_Marvin.bak' 
WITH  FILE = 1,  
MOVE N'AN_StateFarm_PositionData' TO N'F:\MSSQL\DATA\F_MP01\DATA\StateFarm_PositionData_FTP_March2016_Marvin.mdf',  
MOVE N'AN_StateFarm_PositionData2' TO N'F:\MSSQL\DATA\F_MP01\DATA\StateFarm_PositionData_FTP_March2016_Marvin_1.ndf',  
MOVE N'AN_StateFarm_PositionData_log' TO N'F:\MSSQL\LOGS\F_MP02\LOGS\StateFarm_PositionData_FTP_March2016_Marvin_2.ldf',  
NOUNLOAD,  
STATS = 5
GO

/*
PART 3 - Fix database ownership on target server
*/ 

USE [StateFarm_FTP_March2016_Marvin]
GO
EXEC sp_changedbowner 'sfsa'
GO

USE [StateFarm_MarketData_FTP_March2016_Marvin]
GO
EXEC sp_changedbowner 'sfsa'
GO


USE [StateFarm_PositionData_FTP_March2016_Marvin]
GO
EXEC sp_changedbowner 'sfsa'
GO
