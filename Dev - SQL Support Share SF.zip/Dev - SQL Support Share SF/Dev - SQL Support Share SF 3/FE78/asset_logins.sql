USE [sfsql_smsreport]
GO

CREATE USER [SUPPORT\SEA_U72F] FOR LOGIN [SUPPORT\SEA_U72F]
CREATE USER [WTSCRB6P\UTL_PATROL] FOR LOGIN [WTSCRB6P\UTL_PATROL]
CREATE USER [SUPPORT\SEA_U8MC] FOR LOGIN [SUPPORT\SEA_U8MC]
CREATE USER [l3tu] FOR LOGIN [l3tu]
CREATE USER [sdly] FOR LOGIN [sdly]
CREATE USER [MSY9] FOR LOGIN [MSY9]
CREATE USER [UTL_ITAR-SMS] FOR LOGIN [UTL_ITAR-SMS]
CREATE USER [JBRQ ] FOR LOGIN [JBRQ ]
CREATE USER [CMPPRPFRM_ID] FOR LOGIN [CMPPRPFRM_ID]
CREATE USER [WSISMUser] FOR LOGIN [WSISMUser]
CREATE USER [ARMKPI] FOR LOGIN [ARMKPI]
CREATE USER [WSDSUBSYSPRC] FOR LOGIN [WSDSUBSYSPRC]
CREATE USER [CNSB] FOR LOGIN [CNSB]
CREATE USER [SUPPORT\SIA_JBRQ] FOR LOGIN [SUPPORT\SIA_JBRQ]
CREATE USER [OPRETLAB] FOR LOGIN [OPRETLAB]
CREATE USER [SUPPORT\SEA_U5M8] FOR LOGIN [SUPPORT\SEA_U5M8]
CREATE USER [Optimid] FOR LOGIN [Optimid]
CREATE USER [UNTOPR\CTM_AMR] FOR LOGIN [UNTOPR\CTM_AMR]
CREATE USER [SUPPORT\WEA_U0DD] FOR LOGIN [SUPPORT\WEA_U0DD]
CREATE USER [SUPPORT\SEA_U8UF] FOR LOGIN [SUPPORT\SEA_U8UF]
CREATE USER [SUPPORT\SEA_UJOR] FOR LOGIN [SUPPORT\SEA_UJOR]
CREATE USER [SUPPORT\SEA_UM2M] FOR LOGIN [SUPPORT\SEA_UM2M]
CREATE USER [UNTOPR\gv4h] FOR LOGIN [UNTOPR\gv4h]
CREATE USER [untopr\HCT7] FOR LOGIN [untopr\HCT7]
CREATE USER [UNTOPR\u72f] FOR LOGIN [UNTOPR\u72f]

EXEC sp_AddRoleMember 'db_owner', 'dbo'
EXEC sp_AddRoleMember 'db_owner', 'SUPPORT\SEA_U72F'
EXEC sp_AddRoleMember 'db_owner', 'SUPPORT\SEA_U8MC'
EXEC sp_AddRoleMember 'db_owner', 'UNTOPR\SQL_ITREPORTING_APPADMIN_DLG'
EXEC sp_AddRoleMember 'db_owner', 'l3tu'
EXEC sp_AddRoleMember 'db_owner', 'JBRQ '
EXEC sp_AddRoleMember 'db_owner', 'SUPPORT\SIA_JBRQ'
EXEC sp_AddRoleMember 'db_owner', 'SUPPORT\SEA_U5M8'
EXEC sp_AddRoleMember 'db_owner', 'UNTOPR\CTM_AMR'
EXEC sp_AddRoleMember 'db_owner', 'SUPPORT\WEA_U0DD'
EXEC sp_AddRoleMember 'db_owner', 'SUPPORT\SEA_U8UF'
EXEC sp_AddRoleMember 'db_owner', 'SUPPORT\SEA_UJOR'
EXEC sp_AddRoleMember 'db_owner', 'SUPPORT\SEA_UM2M'
EXEC sp_AddRoleMember 'db_owner', 'UNTOPR\gv4h'
EXEC sp_AddRoleMember 'db_owner', 'untopr\HCT7'
EXEC sp_AddRoleMember 'db_owner', 'UNTOPR\u72f'
EXEC sp_AddRoleMember 'db_owner', 'UNTOPR\UNITOPR_SQL_AMReport_DBO_DLG'
EXEC sp_AddRoleMember 'db_ddladmin', 'UTL_ITAR-SMS'
EXEC sp_AddRoleMember 'db_ddladmin', 'SUPPORT\SEA_U5M8'
EXEC sp_AddRoleMember 'db_ddladmin', 'UNTOPR\UNITOPR_SQL_AMReport_DDL_DLG'
EXEC sp_AddRoleMember 'db_datareader', 'UNTOPR\SQL_ITREPORTING_RPT_ALL_DLG'
EXEC sp_AddRoleMember 'db_datareader', 'UNTOPR\SQL_ITREPORTING_DATAADMIN_ALL_DLG'
EXEC sp_AddRoleMember 'db_datareader', 'UNTOPR\SQL_ITREPORTING_APPACCT_DLG'
EXEC sp_AddRoleMember 'db_datareader', 'sdly'
EXEC sp_AddRoleMember 'db_datareader', 'MSY9'
EXEC sp_AddRoleMember 'db_datareader', 'UTL_ITAR-SMS'
EXEC sp_AddRoleMember 'db_datareader', 'CMPPRPFRM_ID'
EXEC sp_AddRoleMember 'db_datareader', 'WSISMUser'
EXEC sp_AddRoleMember 'db_datareader', 'ARMKPI'
EXEC sp_AddRoleMember 'db_datareader', 'WSDSUBSYSPRC'
EXEC sp_AddRoleMember 'db_datareader', 'CNSB'
EXEC sp_AddRoleMember 'db_datareader', 'OPRETLAB'
EXEC sp_AddRoleMember 'db_datareader', 'SUPPORT\SEA_U5M8'
EXEC sp_AddRoleMember 'db_datareader', 'Optimid'
EXEC sp_AddRoleMember 'db_datareader', 'UNTOPR\UNITOPR_SQL_AMReport_RO_DLG'
EXEC sp_AddRoleMember 'db_datareader', 'UNTOPR\UNITOPR_SQL_AMReport_RW_DLG'
EXEC sp_AddRoleMember 'db_datawriter', 'UNTOPR\SQL_ITREPORTING_DATAADMIN_ALL_DLG'
EXEC sp_AddRoleMember 'db_datawriter', 'UNTOPR\SQL_ITREPORTING_APPACCT_DLG'
EXEC sp_AddRoleMember 'db_datawriter', 'UTL_ITAR-SMS'
EXEC sp_AddRoleMember 'db_datawriter', 'WSISMUser'
EXEC sp_AddRoleMember 'db_datawriter', 'WSDSUBSYSPRC'
EXEC sp_AddRoleMember 'db_datawriter', 'SUPPORT\SEA_U5M8'
EXEC sp_AddRoleMember 'db_datawriter', 'Optimid'
EXEC sp_AddRoleMember 'db_datawriter', 'UNTOPR\UNITOPR_SQL_AMReport_RW_DLG'