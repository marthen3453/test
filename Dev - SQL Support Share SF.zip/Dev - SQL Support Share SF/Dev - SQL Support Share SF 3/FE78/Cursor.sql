
DECLARE @dbname varchar(50),
		@cmd varchar(512)

DECLARE DropDB CURSOR STATIC

FOR SELECT name
FROM sys.databases
WHERE name NOT IN ('msdb', 'master', 'model', 'SF_SQL_Admin', 'tempdb');

OPEN DROPDB

FETCH FIRST FROM DROPDB INTO @dbname

WHILE @@FETCH_STATUS = 0 
BEGIN
SET @cmd =  'ALTER DATABASE [' + @dbname + '] SET OFFLINE WITH ROLLBACK IMMEDIATE' 

--PRINT @cmd
EXEC (@cmd)

FETCH NEXT FROM DROPDB INTO @dbname
END

CLOSE DROPDB

DEALLOCATE DROPDB;