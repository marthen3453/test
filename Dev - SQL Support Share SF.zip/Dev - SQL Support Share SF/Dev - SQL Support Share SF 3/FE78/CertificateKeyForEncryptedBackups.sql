/* PRODUCTION SERVER */

-- Query to check certificates on server
USE master
GO

SELECT * 
FROM sys.certificates;

-- Query to backup certificates

BACKUP CERTIFICATE LatitudeProdBackupEncryptCert 
TO FILE = 'F:\MSSQL\BACKUP\F_MP04\BACKUP\LatitudeProdBackupEncryptCert.crt'
    WITH PRIVATE KEY ( FILE = 'F:\MSSQL\BACKUP\F_MP04\BACKUP\LatitudeProdBackupEncryptCert.key' , 
    ENCRYPTION BY PASSWORD = 'Tempor@ryPassw0rd' );

/* TEST SERVER */

-- Query to restore certificate
CREATE CERTIFICATE LatitudeProdBackupEncryptCert 
    FROM FILE = 'F:\MSSQL\BACKUP\F_MP04\BACKUP\LatitudeProdBackupEncryptCert.crt' 
    WITH PRIVATE KEY (FILE = 'F:\MSSQL\BACKUP\F_MP04\BACKUP\LatitudeProdBackupEncryptCert.key', 
    DECRYPTION BY PASSWORD = 'Tempor@ryPassw0rd');
GO  

-- Query to see if new certificate is created
SELECT *
FROM sys.certificates;