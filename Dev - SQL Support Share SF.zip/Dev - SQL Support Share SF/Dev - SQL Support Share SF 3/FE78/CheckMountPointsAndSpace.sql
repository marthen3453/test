 SELECT 
	DISTINCT 
	logical_volume_name AS 'Volume Name'
,	volume_mount_point AS 'Mount Point'
,	CONVERT(varchar(11), CONVERT(decimal(6,2),(CONVERT(decimal(20,2),total_bytes) - CONVERT(decimal(20,2),available_bytes))/1024/1024/1024)) + ' GB' AS 'Used Space (GB)'
,	CONVERT(varchar(11),CONVERT(decimal(6,2),CONVERT(decimal(20,2),available_bytes)/1024/1024/1024)) + ' GB' AS 'Free Space (GB)'
,	CONVERT(varchar(11),CONVERT(decimal(6,2),CONVERT(decimal(20,2),total_bytes)/1024/1024/1024)) + ' GB' AS 'Total Space (GB)'
,	CONVERT(varchar(7),CONVERT(decimal(5,2),CONVERT(decimal(20,2),available_bytes)/CONVERT(decimal(20,2),total_bytes)*100)) + ' %' AS 'Percent Free'
FROM 
	sys.master_files AS f
	CROSS APPLY 
	sys.dm_os_volume_stats(f.database_id, f.FILE_ID)
ORDER BY logical_volume_name;

