SELECT * FROM dbo.sysjobhistory WHERE job_id = '476EC503-52F1-4C62-873B-7CC1DED49B26';

SELECT * FROM dbo.sysjobs;

SELECT SERVERPROPERTY('CURRENT_TIMESTAMP')

SELECT getdate()



SELECT 12, '000000' + CONVERT(VARCHAR(6),12), RIGHT('000000' + CONVERT(VARCHAR(6),12) , 6) 


SELECT * FROM sysjobservers WHERE last_run_outcome = 0

SELECT * FROM sys.servers

SELECT * FROM dbo.restorehistory;

SELECT * FROM dbo.sysalerts;

SELECT * FROM sysutility_mi_smo_objects_to_collect_internal

SELECT * FROM dbo.sf_backup_history;

SELECT * FROM dbo.DTA_tuninglog;