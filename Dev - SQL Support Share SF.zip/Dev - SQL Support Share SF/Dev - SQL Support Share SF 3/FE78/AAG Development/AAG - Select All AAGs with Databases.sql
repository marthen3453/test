SELECT 
	--*
	a.name AS AAGName
,	b.database_name AS DBName
FROM
	sys.availability_groups a
	INNER JOIN
	sys.availability_databases_cluster b
		ON a.group_id = b.group_id
WHERE
	@@SERVERNAME LIKE 'WPSDXZZJ%' 
ORDER BY
	1, 2




/*
SharePoint database for ESearch Internal


*/