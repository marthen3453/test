DECLARE @AccountName	VARCHAR(128)
,		@cmd			VARCHAR(512)

IF EXISTS 
(		SELECT 
			*
		FROM 
			sys.server_permissions a
			INNER JOIN
			sys.server_principals b
				ON a.grantee_principal_id = b.principal_id
		WHERE 
			grantor_principal_id != 1 
			AND 
			class_desc = 'ENDPOINT'
)
BEGIN 
	SELECT 
		@AccountName = b.name 
	FROM 
		sys.server_permissions a
		INNER JOIN
		sys.server_principals b
			ON a.grantee_principal_id = b.principal_id
	WHERE 
		grantor_principal_id != 1 
		AND 
		class_desc = 'ENDPOINT'


	SET @cmd = '
	ALTER AUTHORIZATION ON ENDPOINT::[Hadr_endpoint] TO [sfsa]

	GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [' + @AccountName + '] AS [sfsa];
	'

	--PRINT @cmd

	EXEC (@cmd)
END