SELECT 
	CASE 
		WHEN (SUBSTRING(@@SERVERNAME, 4, 5) = SUBSTRING(@@SERVERNAME, 13, 5)) THEN 'PRIMARY'
		ELSE 'SECONDARY'
	END AS Server_Role
,	role_desc AS AAG_Role
FROM sys.dm_hadr_availability_replica_states 
WHERE role_desc = 'PRIMARY'


DECLARE @AAGName	VARCHAR(16)
,		@cmd		VARCHAR(256)
,		@PriSrvNm	VARCHAR(64)
,		@SecSrvNm	VARCHAR(64)
,		@cmd2		VARCHAR(512)
,		@setASync	BIT
,		@SrvrNm		VARCHAR(128)


/**************************************/
/*
	SET TO 1 TO SET AAGs TO ASYNC MODE.  SET TO 0 TO SET AAGs BACK TO SYNC WITH AUTO FAILOVER
*/
SET @setASync = 0

/*
	SET TO SERVER NAME WITH %
*/
SET @SrvrNm = 'WPSDYTK6%'

/**************************************/
/**************************************/

IF @@SERVERNAME LIKE @SrvrNm
BEGIN
	PRINT 'ALTERING AAGs ON ' + @SrvrNm

	DECLARE AAGCursor CURSOR STATIC FOR 
	SELECT name FROM sys.availability_groups

	OPEN AAGCursor

	FETCH FIRST FROM AAGCursor INTO @AAGName

	WHILE @@FETCH_STATUS = 0
	BEGIN

		IF @setASync = 1
		BEGIN
			SELECT 
				@PriSrvNm = replica_server_name
			FROM 
				sys.availability_replicas
			WHERE
				replica_server_name = @@SERVERNAME

			SELECT 
				@SecSrvNm = a.replica_server_name
			FROM 
				sys.availability_replicas a
				INNER JOIN sys.dm_hadr_cluster_members b ON LEFT(a.replica_server_name, 8) = b.member_name
			WHERE
				b.number_of_quorum_votes = 1
				AND
				a.replica_server_name != @@SERVERNAME

			SELECT @cmd2 = '
			ALTER AVAILABILITY GROUP [' + @AAGName + ']
			MODIFY REPLICA ON N''' + @SecSrvNm + ''' WITH (FAILOVER_MODE = MANUAL)

			ALTER AVAILABILITY GROUP [' + @AAGName + ']
			MODIFY REPLICA ON N''' + @SecSrvNm + ''' WITH (AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT)

			ALTER AVAILABILITY GROUP [' + @AAGName + ']
			MODIFY REPLICA ON N''' + @PriSrvNm + ''' WITH (FAILOVER_MODE = MANUAL)
			'

			--PRINT @cmd2
			EXEC (@cmd2)
		END
		ELSE
		BEGIN
			SELECT 
				@PriSrvNm = replica_server_name
			FROM 
				sys.availability_replicas
			WHERE
				replica_server_name = @@SERVERNAME

			SELECT 
				@SecSrvNm = a.replica_server_name
			FROM 
				sys.availability_replicas a
				INNER JOIN sys.dm_hadr_cluster_members b ON LEFT(a.replica_server_name, 8) = b.member_name
			WHERE
				b.number_of_quorum_votes = 1
				AND
				a.replica_server_name != @@SERVERNAME

			SELECT @cmd2 = '
			ALTER AVAILABILITY GROUP [' + @AAGName + ']
			MODIFY REPLICA ON N''' + @PriSrvNm + ''' WITH (FAILOVER_MODE = AUTOMATIC)

			ALTER AVAILABILITY GROUP [' + @AAGName + ']
			MODIFY REPLICA ON N''' + @SecSrvNm + ''' WITH (AVAILABILITY_MODE = SYNCHRONOUS_COMMIT)

			ALTER AVAILABILITY GROUP [' + @AAGName + ']
			MODIFY REPLICA ON N''' + @SecSrvNm + ''' WITH (FAILOVER_MODE = AUTOMATIC)
			'

			--PRINT @cmd2
			EXEC (@cmd2)
		END


		FETCH NEXT FROM AAGCursor INTO @AAGName
	END

	CLOSE AAGCursor
	DEALLOCATE AAGCursor

END