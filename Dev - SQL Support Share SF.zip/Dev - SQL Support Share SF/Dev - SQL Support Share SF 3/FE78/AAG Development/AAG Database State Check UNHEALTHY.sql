SELECT 
	b.name AS DatabaseName
,	a.* 
FROM 
	sys.dm_hadr_database_replica_states a
	INNER JOIN
	sys.databases b ON b.database_id = a.database_id
WHERE 
	a.is_local = 1 
	AND 
	a.synchronization_health != 2



SELECT 
	b.dns_name
,	b.port
,	a.state
,	a.state_desc
FROM 
	sys.dm_tcp_listener_states a
	INNER JOIN
	sys.availability_group_listeners b
		ON a.port = b.port
WHERE [state] != 0
