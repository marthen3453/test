SET NOCOUNT ON 
CREATE TABLE #AAGConfig
(
	AAGNumber				TINYINT
,	AAGName					VARCHAR(16)
,	AAGListenerPriIP		VARCHAR(16)
,	AAGListenerPriSubnet	VARCHAR(16)
,	AAGListenerSecIP		VARCHAR(16)
,	AAGListenerSecSubnet	VARCHAR(16)
,	PrimaryServer			VARCHAR(16)
,	PrimaryInstanceName		VARCHAR(128)
,	PrimaryFailoverMode		VARCHAR(64)
,	PrimaryAvailMode		VARCHAR(64)
,	PrimaryBackupPriority	VARCHAR(2)
,	PrimaryRole				VARCHAR(64)
,	SecondaryServer			VARCHAR(16)
,	SecondaryInstanceName	VARCHAR(128)
,	SecondaryFailoverMode	VARCHAR(64)
,	SecondaryAvailMode		VARCHAR(64)
,	SecondaryBackupPriority	VARCHAR(2)
,	SecondaryRole			VARCHAR(64)
,	ASynchServer			VARCHAR(16)
,	ASynchInstanceName		VARCHAR(128)
,	ASynchFailoverMode		VARCHAR(64)
,	ASynchAvailMode			VARCHAR(64)
,	ASynchBackupPriority	VARCHAR(2)
,	ASynchRole				VARCHAR(64)
)

INSERT INTO #AAGConfig VALUES
(	1, 'AAG_WMSDZCZK01', '10.96.63.94', '255.255.255.0', '10.128.62.185', '255.255.255.0', 
		'WPSDZCZK', 'WMSDZCZK01', 'AUTOMATIC', 'SYNCHRONOUS_COMMIT', '0', '(ALLOW_CONNECTIONS = ALL)', 
		'WPSDZCZL', 'WMSDZCZK05', 'AUTOMATIC', 'SYNCHRONOUS_COMMIT', '0', '(ALLOW_CONNECTIONS = ALL)', 
		'WPSDZNT7', 'WMSDZCZK09', 'MANUAL', 'ASYNCHRONOUS_COMMIT', '50', '(ALLOW_CONNECTIONS = ALL)'
)
,(	2, 'AAG_WMSDZCZK02', '10.96.63.95', '255.255.255.0', '10.128.62.186', '255.255.255.0', 
		'WPSDZCZK', 'WMSDZCZK02', 'AUTOMATIC', 'SYNCHRONOUS_COMMIT', '0', '(ALLOW_CONNECTIONS = ALL)', 
		'WPSDZCZL', 'WMSDZCZK06', 'AUTOMATIC', 'SYNCHRONOUS_COMMIT', '0', '(ALLOW_CONNECTIONS = ALL)', 
		'WPSDZNT7', 'WMSDZCZK10', 'MANUAL', 'ASYNCHRONOUS_COMMIT', '50', '(ALLOW_CONNECTIONS = ALL)'
)
,(	3, 'AAG_WMSDZCZK03', '10.96.63.96', '255.255.255.0', '10.128.62.187', '255.255.255.0', 
		'WPSDZCZK', 'WMSDZCZK03', 'AUTOMATIC', 'SYNCHRONOUS_COMMIT', '0', '(ALLOW_CONNECTIONS = ALL)', 
		'WPSDZCZL', 'WMSDZCZK07', 'AUTOMATIC', 'SYNCHRONOUS_COMMIT', '0', '(ALLOW_CONNECTIONS = ALL)', 
		'WPSDZNT7', 'WMSDZCZK11', 'MANUAL', 'ASYNCHRONOUS_COMMIT', '50', '(ALLOW_CONNECTIONS = ALL)'
)
,(	4, 'AAG_WMSDZCZK04', '10.96.63.97', '255.255.255.0', '10.128.62.188', '255.255.255.0', 
		'WPSDZCZK', 'WMSDZCZK04', 'AUTOMATIC', 'SYNCHRONOUS_COMMIT', '0', '(ALLOW_CONNECTIONS = ALL)', 
		'WPSDZCZL', 'WMSDZCZK08', 'AUTOMATIC', 'SYNCHRONOUS_COMMIT', '0', '(ALLOW_CONNECTIONS = ALL)', 
		'WPSDZNT7', 'WMSDZCZK12', 'MANUAL', 'ASYNCHRONOUS_COMMIT', '50', '(ALLOW_CONNECTIONS = ALL)'
)


/********************************************************************************************************************************/
/********************************************************************************************************************************/
/********************************************************************************************************************************/
/********************************************************************************************************************************/
/********************************************************************************************************************************/

DECLARE	@ListenerPortStartNum	INT
,		@EndpointPortStartNum	INT
,		@FullDomainName			VARCHAR(256)
,		@SQLServiceAccountName	VARCHAR(256)
,		@cmd					VARCHAR(2048)

SET @ListenerPortStartNum = 57750
SET @EndpointPortStartNum = 57780

SELECT @FullDomainName = 
	CASE DEFAULT_DOMAIN()
		WHEN 'OPR' THEN 'opr.statefarm.org'
		WHEN 'OPRSYS' THEN 'opr.system.test.statefarm.org'
		WHEN 'UNTOPR' THEN 'unitopr.unitint.test.statefarm.org'
		WHEN 'SUPPORT' THEN 'support.statefarm.org'
		ELSE ''
	END

EXEC [master].dbo.xp_instance_regread
              @rootkey      = N'HKEY_LOCAL_MACHINE',
              @key          = N'SYSTEM\CurrentControlSet\Services\MSSQLServer',
              @value_name   = N'ObjectName',
              @value        = @SQLServiceAccountName OUTPUT

IF EXISTS (SELECT 1 FROM #AAGConfig WHERE PrimaryServer + '\' + PrimaryInstanceName = @@SERVERNAME)
BEGIN
	PRINT '/****  PRIMARY SERVER  ****/'

	/****  PRIMARY SERVER  ****/
	SET @EndpointPortStartNum = @EndpointPortStartNum + (SELECT MIN(AAGNumber) FROM #AAGConfig WHERE PrimaryServer + '\' + PrimaryInstanceName = @@SERVERNAME)

	SET @cmd = 'USE [master]
	
	IF NOT EXISTS (SELECT 1 FROM [master].sys.server_principals WHERE name = ''' + @SQLServiceAccountName + ''')
		CREATE LOGIN [' + @SQLServiceAccountName + '] FROM WINDOWS
	
	IF NOT EXISTS (SELECT 1 FROM sys.endpoints WHERE name = N''Hadr_endpoint'')
		CREATE ENDPOINT [Hadr_endpoint] 
			AS TCP (LISTENER_PORT = ' + CONVERT(VARCHAR(5), @EndpointPortStartNum) + ')
			FOR DATA_MIRRORING (ROLE = ALL, ENCRYPTION = REQUIRED ALGORITHM AES)
	
	IF (SELECT state FROM sys.endpoints WHERE name = N''Hadr_endpoint'') <> 0
	BEGIN
		ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED;
	END
	
	GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [' + @SQLServiceAccountName + '];
		
	IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name=''AlwaysOn_health'')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=ON);
	END
	IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name=''AlwaysOn_health'')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
	END
	'
	
	--PRINT @cmd
	PRINT '/****  CONFIGURING ENDPOINTS  ****/ '
	EXEC (@cmd)

	WAITFOR DELAY '00:00:05'

	IF EXISTS (	SELECT 
					1
				FROM 
					#AAGConfig a
					LEFT OUTER JOIN
					master.sys.availability_groups b
						ON 	a.AAGName = b.name
				WHERE 
					a.PrimaryServer + '\' + a.PrimaryInstanceName = @@SERVERNAME
					AND
					b.name IS NULL
				)
	BEGIN
		DECLARE 	@NewAAGName					VARCHAR(16)
		,			@NewAAGListenerPriIP		VARCHAR(16)
		,			@NewAAGListenerPriSubnet	VARCHAR(16)
		,			@NewAAGListenerSecIP		VARCHAR(16)
		,			@NewAAGListenerSecSubnet	VARCHAR(16)
		,			@NewAAGListenerPort			VARCHAR(5)
		,			@NewPrimaryServer			VARCHAR(16)
		,			@NewPrimaryInstanceName		VARCHAR(128)
		,			@NewPrimaryFailoverMode		VARCHAR(64)
		,			@NewPrimaryAvailMode		VARCHAR(64)
		,			@NewPrimaryBackupPriority	VARCHAR(2)
		,			@NewPrimaryRole				VARCHAR(64)
		,			@NewSecondaryServer			VARCHAR(16)
		,			@NewSecondaryInstanceName	VARCHAR(128)
		,			@NewSecondaryFailoverMode	VARCHAR(64)
		,			@NewSecondaryAvailMode		VARCHAR(64)
		,			@NewSecondaryBackupPriority	VARCHAR(2)
		,			@NewSecondaryRole			VARCHAR(64)
		,			@NewASynchServer			VARCHAR(16)
		,			@NewASynchInstanceName		VARCHAR(128)
		,			@NewASynchFailoverMode		VARCHAR(64)
		,			@NewASynchAvailMode			VARCHAR(64)
		,			@NewASynchBackupPriority	VARCHAR(2)
		,			@NewASynchRole				VARCHAR(64)
		,			@AAGcmd						VARCHAR(5120)

		DECLARE AAGCursor CURSOR STATIC FOR
		SELECT 
			AAGName
		,	AAGListenerPriIP
		,	AAGListenerPriSubnet
		,	AAGListenerSecIP
		,	AAGListenerSecSubnet
		,	CONVERT(VARCHAR(5), @ListenerPortStartNum + AAGNumber) AS AAGListenerPortNum
		,	PrimaryServer
		,	PrimaryInstanceName
		,	PrimaryFailoverMode
		,	PrimaryAvailMode
		,	PrimaryBackupPriority
		,	PrimaryRole
		,	SecondaryServer
		,	SecondaryInstanceName
		,	SecondaryFailoverMode
		,	SecondaryAvailMode
		,	SecondaryBackupPriority
		,	SecondaryRole
		,	ASynchServer
		,	ASynchInstanceName
		,	ASynchFailoverMode
		,	ASynchAvailMode
		,	ASynchBackupPriority
		,	ASynchRole
		FROM 
			#AAGConfig a
			LEFT OUTER JOIN
			master.sys.availability_groups b
				ON 	a.AAGName = b.name
		WHERE 
			a.PrimaryServer + '\' + a.PrimaryInstanceName = @@SERVERNAME
			AND
			b.name IS NULL

		OPEN AAGCursor

		FETCH FIRST FROM AAGCursor INTO 
			@NewAAGName, @NewAAGListenerPriIP, @NewAAGListenerPriSubnet, @NewAAGListenerSecIP, @NewAAGListenerSecSubnet, @NewAAGListenerPort, 
			@NewPrimaryServer, @NewPrimaryInstanceName, @NewPrimaryFailoverMode, @NewPrimaryAvailMode, @NewPrimaryBackupPriority, @NewPrimaryRole, 
			@NewSecondaryServer, @NewSecondaryInstanceName, @NewSecondaryFailoverMode, @NewSecondaryAvailMode, @NewSecondaryBackupPriority, @NewSecondaryRole, 
			@NewASynchServer, @NewASynchInstanceName, @NewASynchFailoverMode, @NewASynchAvailMode, @NewASynchBackupPriority, @NewASynchRole

		WHILE @@FETCH_STATUS = 0
		BEGIN
			
			SET @AAGcmd = '
			CREATE AVAILABILITY GROUP [' + @NewAAGName + ']
			WITH (AUTOMATED_BACKUP_PREFERENCE = SECONDARY)
			FOR 
			REPLICA ON 
				N''' + @NewPrimaryServer + '\' + @NewPrimaryInstanceName + ''' WITH (ENDPOINT_URL = N''TCP://' + @NewPrimaryServer + '.' + @FullDomainName + ':' + CONVERT(VARCHAR(5), @EndpointPortStartNum) + ''', FAILOVER_MODE = ' + @NewPrimaryFailoverMode + ', AVAILABILITY_MODE = ' + @NewPrimaryAvailMode + ', BACKUP_PRIORITY = ' + @NewPrimaryBackupPriority + ', SECONDARY_ROLE' + @NewPrimaryRole + '),
				N''' + @NewSecondaryServer + '\' + @NewSecondaryInstanceName + ''' WITH (ENDPOINT_URL = N''TCP://' + @NewSecondaryServer + '.' + @FullDomainName + ':' + CONVERT(VARCHAR(5), @EndpointPortStartNum) + ''', FAILOVER_MODE = ' + @NewSecondaryFailoverMode + ', AVAILABILITY_MODE = ' + @NewSecondaryAvailMode + ', BACKUP_PRIORITY = ' + @NewSecondaryBackupPriority + ', SECONDARY_ROLE' + @NewSecondaryRole + '),
				N''' + @NewASynchServer + '\' + @NewASynchInstanceName + ''' WITH (ENDPOINT_URL = N''TCP://' + @NewASynchServer + '.' + @FullDomainName + ':' + CONVERT(VARCHAR(5), @EndpointPortStartNum) + ''', FAILOVER_MODE = ' + @NewASynchFailoverMode + ', AVAILABILITY_MODE = ' + @NewASynchAvailMode + ', BACKUP_PRIORITY = ' + @NewASynchBackupPriority + ', SECONDARY_ROLE' + @NewASynchRole + ');

			
			
			ALTER AVAILABILITY GROUP [' + @NewAAGName + ']
			ADD LISTENER N''' + @NewAAGName + ''' (
			WITH IP
			((N''' + @NewAAGListenerPriIP + ''', N''' + @NewAAGListenerPriSubnet + '''),
			(N''' + @NewAAGListenerSecIP + ''', N''' + @NewAAGListenerSecSubnet + ''')
			)
			, PORT=' + @NewAAGListenerPort + ');

			
			'

			--PRINT @AAGcmd
			PRINT '/****  CONFIGURING PRIMARY AAG  ****/ '
			EXEC (@AAGcmd)

			FETCH NEXT FROM AAGCursor INTO 
				@NewAAGName, @NewAAGListenerPriIP, @NewAAGListenerPriSubnet, @NewAAGListenerSecIP, @NewAAGListenerSecSubnet, @NewAAGListenerPort, 
				@NewPrimaryServer, @NewPrimaryInstanceName, @NewPrimaryFailoverMode, @NewPrimaryAvailMode, @NewPrimaryBackupPriority, @NewPrimaryRole, 
				@NewSecondaryServer, @NewSecondaryInstanceName, @NewSecondaryFailoverMode, @NewSecondaryAvailMode, @NewSecondaryBackupPriority, @NewSecondaryRole, 
				@NewASynchServer, @NewASynchInstanceName, @NewASynchFailoverMode, @NewASynchAvailMode, @NewASynchBackupPriority, @NewASynchRole
		END --End Cursor Loop

		CLOSE AAGCursor
		DEALLOCATE AAGCursor

	END --End Create AAGs

/****  PRIMARY SERVER  ****/

END --End Primary Server
ELSE IF EXISTS (SELECT 1 FROM #AAGConfig WHERE (SecondaryServer + '\' + SecondaryInstanceName = @@SERVERNAME) OR (ASynchServer + '\' + ASynchInstanceName = @@SERVERNAME))
BEGIN
	PRINT '/****  SECONDARY SERVER  ****/'

/****  SECONDARY SERVERS  ****/
	SET @EndpointPortStartNum = @EndpointPortStartNum + (SELECT AAGNumber FROM #AAGConfig WHERE (SecondaryServer + '\' + SecondaryInstanceName = @@SERVERNAME) OR (ASynchServer + '\' + ASynchInstanceName = @@SERVERNAME))

	SET @cmd = 'USE [master]
	
	IF NOT EXISTS (SELECT 1 FROM [master].sys.server_principals WHERE name = ''' + @SQLServiceAccountName + ''')
		CREATE LOGIN [' + @SQLServiceAccountName + '] FROM WINDOWS
	
	IF NOT EXISTS (SELECT 1 FROM sys.endpoints WHERE name = N''Hadr_endpoint'')
		CREATE ENDPOINT [Hadr_endpoint] 
			AS TCP (LISTENER_PORT = ' + CONVERT(VARCHAR(5), @EndpointPortStartNum) + ')
			FOR DATA_MIRRORING (ROLE = ALL, ENCRYPTION = REQUIRED ALGORITHM AES)
	
	IF (SELECT state FROM sys.endpoints WHERE name = N''Hadr_endpoint'') <> 0
	BEGIN
		ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED;
	END
	
	GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [' + @SQLServiceAccountName + '];
		
	IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name=''AlwaysOn_health'')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=ON);
	END
	IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name=''AlwaysOn_health'')
	BEGIN
	  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
	END
	'
	
	--PRINT @cmd
	PRINT '/****  CONFIGURING ENDPOINTS  ****/ '
	EXEC (@cmd)

	WHILE NOT EXISTS (	SELECT 1 FROM #AAGConfig a INNER JOIN master.sys.availability_groups_cluster b ON a.AAGName = b.name WHERE
			(a.SecondaryServer + '\' + a.SecondaryInstanceName = @@SERVERNAME) OR (a.ASynchServer + '\' + a.ASynchInstanceName = @@SERVERNAME)
		)
	BEGIN
		WAITFOR DELAY '00:00:05'
	END

	IF EXISTS (	SELECT 
					AAGName
				FROM 
					#AAGConfig a
					INNER JOIN
					master.sys.availability_groups_cluster b
						ON 	a.AAGName = b.name
				WHERE 
					(a.SecondaryServer + '\' + a.SecondaryInstanceName = @@SERVERNAME) OR (a.ASynchServer + '\' + a.ASynchInstanceName = @@SERVERNAME)
					AND
					b.name IS NOT NULL
				)
	BEGIN
		WAITFOR DELAY '00:00:05'
		
		DECLARE 	@NewAAGNameSec					VARCHAR(16)
		,			@AAGcmdSec						VARCHAR(5120)

		DECLARE AAGCursor CURSOR STATIC FOR
		SELECT 
			AAGName
		FROM 
			#AAGConfig a
			INNER JOIN
			master.sys.availability_groups_cluster b
				ON 	a.AAGName = b.name
		WHERE 
			(a.SecondaryServer + '\' + a.SecondaryInstanceName = @@SERVERNAME) OR (a.ASynchServer + '\' + a.ASynchInstanceName = @@SERVERNAME)
			AND
			b.name IS NOT NULL

		OPEN AAGCursor

		FETCH FIRST FROM AAGCursor INTO @NewAAGNameSec

		WHILE @@FETCH_STATUS = 0
		BEGIN
			
			SET @AAGcmdSec = '
			ALTER AVAILABILITY GROUP ' + @NewAAGNameSec + ' JOIN;
			'

			--PRINT @AAGcmdSec
			PRINT '/****  CONFIGURING SECONDARY AAG  ****/ '
			EXEC (@AAGcmdSec)

			FETCH NEXT FROM AAGCursor INTO @NewAAGNameSec
		END --End Cursor Loop

		CLOSE AAGCursor
		DEALLOCATE AAGCursor
	END

/****  SECONDARY SERVER  ****/
END
ELSE 
BEGIN
	PRINT '/* NO CONFIGURATION VALUE */'
END


DROP TABLE #AAGConfig
