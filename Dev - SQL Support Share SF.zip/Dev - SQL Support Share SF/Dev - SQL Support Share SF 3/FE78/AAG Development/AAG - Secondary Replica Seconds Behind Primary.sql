WITH PR(database_id, last_commit_time) AS 
(
SELECT dr_state.database_id AS database_id, dr_state.last_commit_time FROM 
((sys.availability_groups AS ag JOIN sys.availability_replicas AS ar ON ar.group_id = ag.group_id)
JOIN sys.dm_hadr_availability_replica_states AS ar_state ON ar.replica_id = ar_state.replica_id)
JOIN sys.dm_hadr_database_replica_states AS dr_state ON ag.group_id = dr_state.group_id AND dr_state.replica_id = ar_state.replica_id
WHERE ar_state.role = 1
)
SELECT ar.replica_server_name AS 'Replica Instance', DB.name AS 'Database Name', 
DATEDIFF(s, dr_state.last_commit_time, PR.last_commit_time) AS 'Seconds Behind Primary'
FROM
((sys.availability_groups AS ag JOIN sys.availability_replicas AS ar ON ar.group_id = ag.group_id)
JOIN sys.dm_hadr_availability_replica_states AS ar_state ON ar.replica_id = ar_state.replica_id)
JOIN sys.dm_hadr_database_replica_states AS dr_state ON ag.group_id = dr_state.group_id AND dr_state.replica_id = ar_state.replica_id
JOIN PR ON PR.database_id = dr_state.database_id
JOIN sys.databases DB ON PR.database_id = DB.database_id
WHERE
ar_state.role!=1 AND dr_state.synchronization_state=1 AND DATEDIFF(s, dr_state.last_commit_time, PR.last_commit_time) > 0 
AND (SUBSTRING(@@SERVERNAME, 4, 5) = SUBSTRING(@@SERVERNAME, 13, 5))
ORDER BY
	2 ASC, 1 ASC



