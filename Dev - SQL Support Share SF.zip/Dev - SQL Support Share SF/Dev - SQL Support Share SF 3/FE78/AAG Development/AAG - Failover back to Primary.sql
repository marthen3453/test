SELECT
	@@SERVERNAME AS [Node\Instance Name]
,	CASE 
		WHEN (SUBSTRING(@@SERVERNAME, 4, 5) = SUBSTRING(@@SERVERNAME, 13, 5)) THEN 'PRIMARY'
		ELSE 'SECONDARY'
	END AS Server_Role
,	role_desc AS AAG_Role
FROM sys.dm_hadr_availability_replica_states 
WHERE role_desc = 'PRIMARY'



--DECLARE @AAGName	VARCHAR(16)
--,		@cmd		VARCHAR(256)

--DECLARE AAGCursor CURSOR STATIC FOR 
--SELECT name FROM sys.availability_groups

--OPEN AAGCursor

--FETCH FIRST FROM AAGCursor INTO @AAGName

--WHILE @@FETCH_STATUS = 0
--BEGIN
--	--SELECT @AAGName
--	IF 
--		(SUBSTRING(@@SERVERNAME, 4, 5) = SUBSTRING(@@SERVERNAME, 13, 5))
--		AND
--		@AAGName IS NOT NULL
--		AND
--		(
--			(	SELECT 
--					role_desc
--				FROM 
--					sys.dm_hadr_availability_replica_states a
--					INNER JOIN
--					sys.availability_replicas b
--						ON a.replica_id = b.replica_id
--					INNER JOIN
--					sys.availability_groups c
--						ON a.group_id = c.group_id
--						AND c.name = @AAGName
--				WHERE
--					replica_server_name = @@SERVERNAME
--			) 
--			!= 'PRIMARY'
--		)
--	BEGIN
--		PRINT @@SERVERNAME + '  --  ' + @AAGName

--		SET @cmd = 'ALTER AVAILABILITY GROUP ' + @AAGName + ' FAILOVER;'

--		--PRINT @cmd
--		EXEC(@cmd)

--	END

--	FETCH NEXT FROM AAGCursor INTO @AAGName
--END

--CLOSE AAGCursor
--DEALLOCATE AAGCursor
