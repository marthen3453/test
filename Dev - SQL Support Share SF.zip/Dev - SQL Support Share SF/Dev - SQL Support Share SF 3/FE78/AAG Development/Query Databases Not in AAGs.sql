SELECT
	*
FROM
	sys.databases a
	LEFT OUTER JOIN
    sys.dm_hadr_availability_replica_states b ON b.replica_id = a.replica_id
WHERE
	b.replica_id IS NULL
	AND
	a.name NOT IN ('master', 'model', 'msdb', 'tempdb', 'SF_SQL_ADMIN', 'SP2013Migration')
	AND
	a.name LIKE 'TEST_%'
	AND
	SUBSTRING(@@SERVERNAME, 4, 5) = SUBSTRING(@@SERVERNAME, 13, 5)