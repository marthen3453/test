SELECT 
	a.replica_server_name
,    a.availability_mode_desc
,    a.failover_mode_desc
,	CASE 
		WHEN (SUBSTRING(replica_server_name, 4, 5) = SUBSTRING(replica_server_name, 13, 5)) THEN 'PRIMARY'
		WHEN (SUBSTRING(replica_server_name, 4, 5) != SUBSTRING(replica_server_name, 13, 5)) AND a.availability_mode = 1 AND a.failover_mode = 0 THEN 'AUTO-FAIL SECONDARY'
		WHEN (SUBSTRING(replica_server_name, 4, 5) != SUBSTRING(replica_server_name, 13, 5)) AND a.availability_mode = 0 AND a.failover_mode = 1 THEN 'TERTIARY DR'
		ELSE 'MISC SECONDARY'
	END AS ExpectedRole
,	b.role_desc AS CurrentRole
FROM 
	sys.availability_replicas a
	INNER JOIN
	sys.dm_hadr_availability_replica_states b
		ON a.group_id = b.group_id AND a.replica_id = b.replica_id
ORDER BY
	RIGHT(a.replica_server_name, 2) ASC