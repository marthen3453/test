﻿## Static 

## Server Name, Instance Names, Physical Memory (from DMV)

## Dynamic (500ms delay)

## select * from sys.dm_os_performance_counters 
## where object_name like '%:Memory Manager%'
## and (counter_name in ('Target Server Memory (KB)', 'Total Server Memory (KB)'))

## select * from sys.dm_os_performance_counters
## where object_name like '%:Buffer Manager%' 
## and (counter_name in ('Page life Expectancy'))

## SELECT * FROM
## sys.dm_os_sys_info

## SELECT total_physical_memory_kb, available_physical_memory_kb, CAST((total_physical_memory_kb - available_physical_memory_kb) AS DECIMAL(10,2))/(total_physical_memory_kb)*100 AS 'Percent Committed Bytes In Use', system_memory_state_desc 
## FROM sys.dm_os_sys_memory

## Clear script off screen ##
cls

## Load SQL SMO ##
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("System.Data") | Out-Null


## Initialize some variables ##
$fqdn = $null
$fqdn = "WPSDYTK3.OPR.STATEFARM.ORG\WMSDYTK212"
$server= $fqdn.Substring(0,8)
$instance = $fqdn.Substring(($fqdn.Length-10),10)
$domain = $fqdn.TrimStart($server + ".")
$domain = $domain.TrimEnd("\" + $instance)
$delay = 5000

Write-Host "Server:" $server
Write-Host "Instance:" $instance
Write-Host "Domain:" $domain

Write-Host ""

## Get list of SQL Server Instances ## 
$InstanceArray = Get-Service -ComputerName $server -DisplayName "*SQL Server (*"

## Setting up blank array ##
$Instances = $null;
$count = $InstanceArray.Count
$n = 0;

## For each line, add instance name to Instances array ## 
foreach($line in $InstanceArray) {
    $Instances += $InstanceArray[$n].DisplayName.Substring(12,10);
    
    $n++;

    if($n -lt $count) {
    $Instances +=  ", "
    }    
 }
 
Write-Host "Instances:" $Instances

Write-Host ""

$InstanceObject = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $fqdn 
$db = $InstanceObject.Databases["master"]
$ds = New-Object "System.Data.DataSet"
$ds2 = New-Object "System.Data.DataSet"
$ds3 = New-Object "System.Data.DataSet"

# Start
write-host 'Launching IE...'
$ie = new-object -com "InternetExplorer.Application"
$ie.navigate("about:blank")
$ie.visible = $true
#[System.Threading.Thread]::Sleep(500)
$doc = $ie.document

# Loop until Status Bar is disabled
#$ie.FullScreen = $true
$ie.StatusBar = $true

        $html = "<div id=static>"
		
		$query = "SELECT object_name AS 'Object' , counter_name AS 'Counter Name', cntr_value AS 'Counter Value'
        FROM sys.dm_os_performance_counters 
        WHERE object_name LIKE '%:Memory Manager%'
        AND (counter_name IN ('Target Server Memory (KB)', 'Total Server Memory (KB)'))"

        $query2 = "SELECT object_name AS 'Object' , counter_name AS 'Counter Name', cntr_value AS 'Counter Value'
                   FROM sys.dm_os_performance_counters
                   WHERE object_name LIKE '%:Buffer Manager%' 
                   AND (counter_name IN ('Page life Expectancy'))"

        $query3 = "SELECT total_physical_memory_kb, available_physical_memory_kb, CAST((total_physical_memory_kb - available_physical_memory_kb) AS DECIMAL(20,2))/(total_physical_memory_kb)*100 AS 'Percent Committed Bytes In Use', system_memory_state_desc 
                   FROM sys.dm_os_sys_memory"

        $html += "<header style=`"text-align: center`">"
        $html += "<h1>SQL Server Memory Report</h1>" 
        $html += "</header>"

        $html += "<form>"
            $html += "<table>"
                $html += "<tr>"
                    $html += "<td>"
                        $html += "<b>Server Name: </b>"
                    $html += "</td>"
                    $html += "<td>"
                        $html += "<input type=text name=server value=" + $server + ">"
                    $html += "</td>"
                $html += "</tr>"
                $html += "<tr>"
                    $html += "<td>"
                        $html += "<b>Instance Name: </b>"
                    $html += "</td>"
                    $html += "<td>"
                        $html += "<input type=text name=instance value=" + $instance + ">"
                    $html += "</td>"
                $html += "</tr>"
                $html += "<tr>"
                     $html += "<td>"
                          $html += "<b>Last Update:</b>"
                     $html += "</td>"
                    $html += "<td>"
                        $html += "<span id=lastUpdateDate `"" + $date + "`" </span>"
                    $html += "</td>"
                $html += "</tr>"
                $html += "<tr>"
                    $html += "<td>"
                        $html += "<input type=submit value=Submit>"
                    $html += "</td>"
                $html += "</tr>"
            $html += "</table>"
        $html += "</form>"
        
        $html += "</div>"

        $html += "<div id=dynamic>"
        
        $html += "</div>"

		$doc.body.innerHTML = $html 


do {
        $html = $null
        
        $ds = $db.ExecuteWithResults($query)

        $ds2 = $db.ExecuteWithResults($query2)
        
        $ds3 = $db.ExecuteWithResults($query3)

		$date = Get-Date

        $html += "<b>Query 1:</b> " + $query + "<br /> <br />"
		
        $html += "<table border=`"2`" padding=`"1`">"
	
		foreach ($Column in $ds.Tables[0].Columns)
		{
			$html += "<th>" + $Column.ColumnName + "</th>"
		}
		
		foreach ($Row in $ds.Tables[0].Rows)
		{
		
			$html += "<tr>"
			
			foreach ($Column in $ds.Tables[0].Columns)
			{
					$html += "<td>" + $Row[$Column].ToString() + "</td>"
			}

			$html += "</tr>"

		}
		
		$html += "</table>"

        $html += "<br />"

        ######################################
        
        $html += "<b>Query 2:</b> " + $query2 + "<br /> <br />"

        $html += "<table border=`"2`" padding=`"1`">"
	
		foreach ($Column in $ds2.Tables[0].Columns)
		{
			$html += "<th>" + $Column.ColumnName + "</th>"
		}
		
		foreach ($Row in $ds2.Tables[0].Rows)
		{
		
			$html += "<tr>"
			
			foreach ($Column in $ds2.Tables[0].Columns)
			{
					$html += "<td>" + $Row[$Column].ToString() + "</td>"
			}

			$html += "</tr>"

		}
		
		$html += "</table>"

        $html += "<br />"

        ###################################################

        $html += "<b>Query 3:</b> " + $query3 + "<br /> <br />"

        $html += "<table border=`"2`" padding=`"1`">"
	
		foreach ($Column in $ds3.Tables[0].Columns)
		{
			$html += "<th>" + $Column.ColumnName + "</th>"
		}
		
		foreach ($Row in $ds3.Tables[0].Rows)
		{
		
			$html += "<tr>"
			
			foreach ($Column in $ds3.Tables[0].Columns)
			{
					$html += "<td>" + $Row[$Column].ToString() + "</td>"
			}

			$html += "</tr>"

		}
		
		$html += "</table>"
        
        $doc.getElementById("dynamic").innerhtml = $html
        $doc.getElementById("lastUpdateDate").innertext = $date
        
		[System.Threading.Thread]::Sleep($delay)
	}
while ($ie.StatusBar)

# Close the browser
$ie.FullScreen = $false
$ie.StatusBar = $true
$ie.Quit()
