﻿## Clear the screen ##
cls 

## Load the .NET assembly ##
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null

## Provide the list of SQL Server instances ## 
$instanceList = "WTSDWRGG.UNITOPR.UNITINT.TEST.STATEFARM.ORG\WTSDWRGG01", "WTSDWRGG.UNITOPR.UNITINT.TEST.STATEFARM.ORG\WTSDWRGG02";

## For each SQL Server instance, display some information and save it in the results variable ##
$results = $null;
$results = foreach($svr in $instanceList) {

    ## Build the SQL Server .NET object ##
    $InstanceObject = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $svr;

    ## Get instance information from SMO ## 
    $InstanceObject.Information | SELECT Parent, Product, Edition, VersionString;
};

## Display the results ##
$results | Format-Table -AutoSize;


## For each SQL Server instance, display database information and save it in the results variable ##
$results = $null;
$results = foreach($svr in $instanceList) {

    ## Build the SQL Server .NET object ##
    $DatabaseObject = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $svr;

    ## Get database information from SMO ##
    $DatabaseObject.Databases | SELECT Name, Owner, RecoveryModel, LastBackupDate | Sort-Object Name

    ""
};

## Display the results ##
$results | Format-Table -AutoSize

## For each SQL Server instance, display job information and save it in the results variable ##
$results = $null;
$results = foreach($svr in $instanceList) {
    
    ## Build the SQL Server .NET Object ## 
    $JobObject = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $svr;

    $JobObject.JobServer.jobs | SELECT Name, IsEnabled, LastRunDate, LastRunOutcome | Sort-Object LastRunOutcome

    ""
};

$results | Format-Table -AutoSize;