﻿   ### Skip a line ###
   Write-Output ""
   Write-Output "Instructions: Follow the server prompts to see server information, instance information, database information, and file information."
   Write-Output ""


    ### Prompt user to find out which server they would like to find information about ###
    $server = Read-Host 'Please enter the Server Name'
    
    ### Create connection to SQL PBM Database on WPSDGP33 Server using integrated login ###
	$conn1 = New-Object System.Data.SqlClient.SqlConnection
	$conn1.ConnectionString = "Server=WPSDGP33.SUPPORT.STATEFARM.ORG;Database=SFSQL_PBM;integrated security=SSPI;"
	$conn1.Open()

    ### Query that selects FQDN, Processor, Core Count, Total Physical Memory, Manufacturer, Model, Virtual (Y/N), and Location for a given server ### 
	$query1 = "SELECT DISTINCT FullName AS 'FQDN',
               CASE 
                    WHEN ISVirtualMachine = 'True' THEN 'Virtual'
                    ELSE 'Non-Virtual'
               END AS 'Virtual',
               CASE
                    WHEN OfficeName = 'ISCC' THEN 'ISC-C'
                    WHEN OfficeName = 'ISCE' THEN 'ISC-E'
                    WHEN OfficeName = 'ISCW' THEN 'ISC-W' 
                    ELSE OfficeName
              END AS 'Location',
              PROCESSOR AS 'Processor', CORECOUNT AS 'Core Count', TOTALPHYSICALMEMORY/1024/1024 AS 'Memory (GB)'
              FROM [SFSQL_PBM].[dbo].[sf_sql_dashboard_sccm]
              WHERE SERVERNAME = '"+ $server + "';"

    ### Execute the query through the connection ###
	$cmd1 = New-Object System.Data.SqlClient.SqlCommand($query1,$conn1)
	$result1 = $cmd1.ExecuteReader()
 

    ### Create a table and load the data into it ###
    $table1 = new-object System.Data.DataTable
    $table1.Load($result1)

    $fqdn = $table1.rows.item(0).item(0)
    

    ### Send the table out to a text file ###
    $table1 | out-file  '\\WPWD3K8R\c$\Users\sia_fe78\Documents\Report1.txt'
    $table1


    ### Press enter to see instance information ###
    Read-Host 'Press enter to continue'

    
    ### Create connection to SQL SQL CDRS Database on WPSDGP33 Server using integrated login ###
	$conn2 = New-Object System.Data.SqlClient.SqlConnection
	$conn2.ConnectionString = "Server=WPSDGP33.SUPPORT.STATEFARM.ORG;Database=SFSQL_CDRS;integrated security=SSPI;"
	$conn2.Open()

    ### Query that selects server cluster name, cluster type, instances, and their port numbers ### 
	$query2 = "SELECT DISTINCT b.ENV_NM AS 'Instance', b.PORT_NUM AS 'Port', SFTWR_PROD_NM + ' (' +  b.SFTWR_PROD_VER_NM + ')' AS 'Version',
              CASE
	                WHEN b.SRVRTYPE IN('ALWAYSON CLUSTE', 'ALWYAYSON', 'ALWAYSON') AND a.SRVR_CLSTR_TYPE_NM = 'NONCLUSTERED' THEN 'AAG'
	                WHEN a.SRVR_CLSTR_TYPE_NM IN ('N+1', 'N+1 CLUSTER') AND SRVRTYPE IN ('N+1', 'N+1 Cluster') THEN 'FCI'
	                WHEN SRVR_CLSTR_TYPE_NM = 'CLUSTERED' THEN 'FCI'
	                WHEN b.SRVRTYPE = 'NONCLUSTERED' THEN 'STANDALONE' 
	                WHEN b.SRVRTYPE IS NULL OR b.SRVRTYPE = '' THEN 'STANDALONE'
	                ELSE SRVRTYPE
              END AS 'Server Type'
              FROM SRVR_CLSTR a
              INNER JOIN INSTC b ON (a.SRVR_CLSTR_NM = b.SRVR_CLSTR_NM)
              WHERE a.SRVR_CLSTR_NM = '" + $server + "'
              ORDER BY ENV_NM;"

    ### Execute the query through the connection ###
	$cmd2 = New-Object System.Data.SqlClient.SqlCommand($query2,$conn2)
	$result2 = $cmd2.ExecuteReader()

    ### Create a table and load the data into it ###
    $table2 = new-object System.Data.DataTable
    $table2.Load($result2)

    ### Send the table out to a text file ###
    $table2 | out-file  '\\WPWD3K8R\c$\Users\sia_fe78\Documents\Report2.txt' 
    $table2

    ### Prompt user to find out which instance and port they would like to find information about ###
    $instance = Read-Host 'Please enter the Instance'

    ### Blank Space ###
    Write-Output ""

    ### Create connection to Master Database in a specific Instance of SQL Server using integrated login ###
    $conn3 = New-Object System.Data.SqlClient.SqlConnection

    IF($instance -eq "MSSQLSERVER") {
        $conn3.ConnectionString = "Server = " + $fqdn +";Database=master;integrated security=SSPI;"
    } ELSE {
	    $conn3.ConnectionString = "Server = " + $fqdn + "\" + $instance +";Database=master;integrated security=SSPI;"
    }

    $conn3.Open()

    ### Query that selects database name, physical file name, file type, state, recovery model, size, max size, and auto-growth ### 
    $query3 = "DECLARE @DBName		VARCHAR(256)
    ,	@cmd		VARCHAR(3000)

    CREATE TABLE #FinalResults
    (	
	    ClusterName			VARCHAR(36)
    ,	DatabaseName		VARCHAR(128)
    ,	DatabaseFileName	VARCHAR(128)
    ,	FileType			VARCHAR(32)
    ,	DatabaseState		VARCHAR(32)
    ,	Size_MB				DECIMAL(20,2)
    ,	Space_Used_MB		DECIMAL(20,2)
    ,	Available_MB		DECIMAL(20,2)
    )

    SELECT 
	    @@ServerName AS ClusterName
    ,	a.[name] AS DatabaseName
    ,	b.[file_id] AS DatabaseFileID
    ,	b.[name] AS DatabaseFileName
    ,	b.type_desc AS FileType
    ,	b.[state_desc] AS DatabaseState
    ,	b.[size] AS DatabaseSize
    INTO #Databases
    FROM
	    sys.databases a
	    INNER JOIN
	    sys.master_files b
		    ON a.database_id = b.database_id
    --WHERE
	    --a.[name] NOT IN ('master', 'model', 'tempdb', 'msdb', 'SF_SQL_ADMIN')
	    --AND
	    --b.[type_desc] = 'ROWS'
	    --AND
	    --@@ServerName IN ('WPSDYTK4\WMSDYTK401', 'WPSDYTK4\WMSDYTK402', 'WPSDYTK4\WMSDYTK403')
	    --AND
	    --a.name LIKE '%SPC_MySite%'
    ORDER BY
	    a.[name] ASC

    --SELECT * FROM #Databases

    DECLARE DBs CURSOR STATIC FOR
    SELECT DISTINCT
	    [DatabaseName]
    FROM
	    #Databases

    OPEN DBs

    FETCH FIRST FROM DBs INTO @DBName

    WHILE @@FETCH_STATUS = 0
    BEGIN

	    SET @cmd = '
	    USE [' + @DBName + ']
	    SELECT 
		    ''' + @DBName + '''AS DatabaseName
	    ,	[file_id] AS DatabaseFileID
	    ,	[name] AS DatabaseFileName
	    ,	CAST([size]/128.0 as DECIMAL(10,2)) AS Size_MB
	    ,	CAST(FILEPROPERTY(name, ''SpaceUsed'')/128.0 as DECIMAL(10,2)) as Space_Used_MB
	    ,	CAST([size]/128.0-(FILEPROPERTY(name, ''SpaceUsed'')/128.0) AS DECIMAL(10,2)) AS Available_MB
	    INTO ##DBInfo
	    FROM 
		    [' + @DBName + '].sys.database_files'

	    --PRINT @cmd
	    EXEC(@cmd)

	    INSERT INTO #FinalResults
	    SELECT 
		    @@ServerName AS ClusterName
	    ,	a.DatabaseName
	    ,	a.DatabaseFileName
	    ,	a.FileType
	    ,	a.DatabaseState
	    ,	b.Size_MB
	    ,	b.Space_Used_MB
	    ,	b.Available_MB
	    FROM
		    #Databases a
		    INNER JOIN
		    ##DBInfo b
			    ON a.DatabaseName COLLATE SQL_Latin1_General_CP1_CI_AS = b.DatabaseName COLLATE SQL_Latin1_General_CP1_CI_AS
			    AND a.DatabaseFileID = b.DatabaseFileID

	    DROP TABLE ##DBInfo

	    FETCH NEXT FROM DBs INTO @DBName
    END

    SELECT 
	    ClusterName
    ,	DatabaseName
    ,	FileType
    ,	SUM(Size_MB) AS DBDataSize_MB
    ,	SUM(Space_Used_MB) AS DBSpaceUsed_MB
    ,	SUM(Available_MB) AS DBAvailSpace_MB
    ,	CONVERT(DECIMAL(4,2),((SUM(Available_MB)/SUM(Size_MB))*100)) AS DBPercentFree
    FROM 
	    #FinalResults
    GROUP BY
	    ClusterName, DatabaseName, FileType
    ORDER BY
	    DatabaseName ASC, FileType DESC

    CLOSE DBs
    DEALLOCATE DBs

    DROP TABLE #Databases
    DROP TABLE #FinalResults;"

    ### Execute the query through the connection ###
	$cmd3 = New-Object System.Data.SqlClient.SqlCommand($query3,$conn3)
	$result3 = $cmd3.ExecuteReader()

    ### Create a table and load the data into it ###
    $table3 = new-object System.Data.DataTable
    $table3.Load($result3)

    ### Send the table out to a text file ###
    $table3 | out-file  '\\WPWD3K8R\c$\Users\sia_fe78\Documents\Report3.txt' 
    $table3

    
    ### Press enter to see instance information ###
    Read-Host 'Press enter to continue'

    ### Blank Space ###
    Write-Output ""

    ### Create connection to Master Database in a specific Instance of SQL Server using integrated login ###
    $conn4 = New-Object System.Data.SqlClient.SqlConnection

    IF($instance -eq "MSSQLSERVER") {
        $conn4.ConnectionString = "Server = " + $fqdn +";Database=master;integrated security=SSPI;"
    } ELSE {
	    $conn4.ConnectionString = "Server = " + $fqdn + "\" + $instance +";Database=master;integrated security=SSPI;"
    }

    $conn4.Open()

    ### Query that selects database name, physical file name, file type, state, recovery model, size, max size, and auto-growth ### 
    $query4 = "DECLARE @DBName		VARCHAR(256)
    ,	@cmd		VARCHAR(3000)

    CREATE TABLE #FinalResults
    (	
	    ClusterName			VARCHAR(36)
    ,	DatabaseName		VARCHAR(128)
    ,	DatabaseFileName	VARCHAR(128)
    ,	FileType			VARCHAR(32)
    ,	DatabaseState		VARCHAR(32)
    ,	Size_MB				DECIMAL(20,2)
    ,	Space_Used_MB		DECIMAL(20,2)
    ,	Available_MB		DECIMAL(20,2)
    )

    SELECT 
	    @@ServerName AS ClusterName
    ,	a.[name] AS DatabaseName
    ,	b.[file_id] AS DatabaseFileID
    ,	b.[name] AS DatabaseFileName
    ,	b.type_desc AS FileType
    ,	b.[state_desc] AS DatabaseState
    ,	b.[size] AS DatabaseSize
    INTO #Databases
    FROM
	    sys.databases a
	    INNER JOIN
	    sys.master_files b
		    ON a.database_id = b.database_id
    --WHERE
	    --a.[name] NOT IN ('master', 'model', 'tempdb', 'msdb', 'SF_SQL_ADMIN')
	    --AND
	    --b.[type_desc] = 'ROWS'
	    --AND
	    --@@ServerName IN ('WPSDYTK4\WMSDYTK401', 'WPSDYTK4\WMSDYTK402', 'WPSDYTK4\WMSDYTK403')
	    --AND
	    --a.name LIKE '%SPC_MySite%'
    ORDER BY
	    a.[name] ASC

    --SELECT * FROM #Databases

    DECLARE DBs CURSOR STATIC FOR
    SELECT DISTINCT
	    [DatabaseName]
    FROM
	    #Databases

    OPEN DBs

    FETCH FIRST FROM DBs INTO @DBName

    WHILE @@FETCH_STATUS = 0
    BEGIN

	    SET @cmd = '
	    USE [' + @DBName + ']
	    SELECT 
		    ''' + @DBName + '''AS DatabaseName
	    ,	[file_id] AS DatabaseFileID
	    ,	[name] AS DatabaseFileName
	    ,	CAST([size]/128.0 as DECIMAL(10,2)) AS Size_MB
	    ,	CAST(FILEPROPERTY(name, ''SpaceUsed'')/128.0 as DECIMAL(10,2)) as Space_Used_MB
	    ,	CAST([size]/128.0-(FILEPROPERTY(name, ''SpaceUsed'')/128.0) AS DECIMAL(10,2)) AS Available_MB
	    INTO ##DBInfo
	    FROM 
		    [' + @DBName + '].sys.database_files'

	    --PRINT @cmd
	    EXEC(@cmd)

	    INSERT INTO #FinalResults
	    SELECT 
		    @@ServerName AS ClusterName
	    ,	a.DatabaseName
	    ,	a.DatabaseFileName
	    ,	a.FileType
	    ,	a.DatabaseState
	    ,	b.Size_MB
	    ,	b.Space_Used_MB
	    ,	b.Available_MB
	    FROM
		    #Databases a
		    INNER JOIN
		    ##DBInfo b
			    ON a.DatabaseName COLLATE SQL_Latin1_General_CP1_CI_AS = b.DatabaseName COLLATE SQL_Latin1_General_CP1_CI_AS
			    AND a.DatabaseFileID = b.DatabaseFileID

	    DROP TABLE ##DBInfo

	    FETCH NEXT FROM DBs INTO @DBName
    END

    SELECT 
    	DatabaseName
    ,	DatabaseFileName
    ,	FileType
    ,	Size_MB
    ,	Space_Used_MB
    ,	Available_MB
    ,	CONVERT(DECIMAL(4,2),((Available_MB/Size_MB)*100)) AS FilePercentFree

    FROM 
	    #FinalResults
    ORDER BY
	    DatabaseName ASC
    ,	FileType DESC
    ,	DatabaseFileName ASC

    CLOSE DBs
    DEALLOCATE DBs

    DROP TABLE #Databases
    DROP TABLE #FinalResults;"


    ### Execute the query through the connection ###
	$cmd4 = New-Object System.Data.SqlClient.SqlCommand($query4,$conn4)
	$result4 = $cmd4.ExecuteReader()

    ### Create a table and load the data into it ###
    $table4 = new-object System.Data.DataTable
    $table4.Load($result4)

    ### Send the table out to a text file ###
    $table4 | out-file  '\\WPWD3K8R\c$\Users\sia_fe78\Documents\Report4.txt' 
    $table4