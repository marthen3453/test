﻿# Clear the console screen
cls


# Update these two variables as the issuance is updated
[System.String] $IssuanceVersion = "1.0"
[System.String] $IssuanceName = "SQL-CLSTR-DEPENDENCY-FIX-11.0-1.0"


# Config paths and common variables
[System.String] $SQLServerVersion = "2012"
[System.DateTime] $CurDateTime = ([System.DateTime]::Now)
[System.String] $LogFilePath = $ENV:DATADIR + "\SQL\Logs\"
[System.String] $ConfigFilePath = $ENV:DATADIR + "\SQL\Config\"
[System.String] $LibraryFilePath = $ENV:DATADIR + "\SQL\Library\"
[System.String] $LibraryFile = $LibraryFilePath + "SQL-PowerShell-Library.psm1"
[System.String] $ScriptsFilePath = $ENV:DATADIR + "\SQL\Scripts\"
[System.String] $SFSQLAdminFilePath = $ENV:DATADIR + "\SQL\SF_SQL_Admin\"
[System.String] $LogFile = $LogFilePath + $IssuanceName + "_" + $CurDateTime.ToString("yyyy-MM-dd_hh-mm-ss") + ".log"
[System.String] $LogFileScripter = $LogFilePath + $IssuanceName + ".log"
[System.String] $IssuanceFail = "Issuance Failed"
[System.String] $IssuanceSuccess = "Issuance Success"
[System.String] $ApplicationDirectory = $env:APPSDIR
[System.String] $ComputerName = $env:COMPUTERNAME
[System.String] $Domain = $env:MCHRESDM
[System.String] $UserDomain = $env:NBDOMNAME
[System.String] $RunPath = $PSScriptRoot


# Import the $LibraryFile (SQL-PowerShell-Library.psm1)
Import-Module -Name $LibraryFile -DisableNameChecking -NoClobber

try
{
    ###############################################################################################################################
    # Log Header
    ###############################################################################################################################

    if (Test-Path $LogFileScripter)
    {
        Remove-Item $LogFileScripter -Force
    }

    WritetoLog $LogFile $LogFileScripter ($IssuanceName + " (" + $IssuanceVersion + ")") "I"
    WritetoLog $LogFile $LogFileScripter ("Script start time: " + $CurDateTime.ToString("yyyy-MM-dd hh:mm:ss")) "I"
    WritetoLog $LogFile $LogFileScripter ("User Context = " + ($env:USERNAME)) "I"
    WritetoLog $LogFile $LogFileScripter ("Detail log available at " + $LogFile) "I"
    WriteToLog $LogFile $LogFileScripter ("Starting Script...") "I"
		
    WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"



    ###############################################################################################################################
    # Retrieve Cluster Name
    ###############################################################################################################################

    WriteToLog $LogFile $LogFileScripter ("Begin - Retrieve Cluster Name") "I"

    try
    {
        # Get cluster's name using 'Get-Cluster' cmdlet
        $Cluster = Get-Cluster
        
        if($Cluster -ne $null) 
        {
            # If cluster's name is not null, then the cluster was found
            WriteToLog $LogFile $LogFileScripter ("    Cluster found! The current cluster is " + $Cluster + ".") "I"
            WriteToLog $LogFile $LogFileScripter ("End - Retrieve Cluster Name") "I"
        }  
        else
        {
            # If cluster's name is null, then no cluster was found.
            return
        }
    }
    catch
    {
        # Error message for when cluster is null
        WriteToLog $logFile $logFilescripter ("    Unable to retrieve current cluster from the Get-Cluster cmdlet. Please check that you are running this script on a Cluster Server.") "E"
        WriteToLog $logFile $logFilescripter ("  " + $_.Exception.Message) "E"
        WriteToLog $logFile $logFilescripter ("  " + $issuanceFail) "E"
        throw $_.Exception
    }

    WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"



    ###############################################################################################################################
    # Retrieve list of SQL Server Roles in Cluster
    ###############################################################################################################################

    WriteToLog $LogFile $LogFileScripter ("Begin - Retrieve a list of SQL Server Roles on " + $Cluster) "I"

    try
    {
        # Get a list of Cluster Roles for the current cluster
        $ClusterRolesList = Get-ClusterGroup | Where-Object {$_.Name -like "SQL_*"} 

        $ClusterRoles = @()
        $a = 0

        # For each item in ClusterRolesList, add it to the ClusterRoles array
        foreach($item in $ClusterRolesList)
        {
            $ClusterRoles += $ClusterRolesList[$a].Name
            $a++
        }
        
        if($ClusterRoles -ne $null) 
        {
            # If ClusterRoles is not null, then the cluster roles were found
            $ClusterRolesList = ($ClusterRolesList | Select -ExpandProperty Name) -join ", "

            WriteToLog $logFile $LogFileScripter ("    " + $ClusterRoles.Count.toString() + " SQL Server Cluster roles returned from Get-ClusterGroup cmdlet:") "I"
            WriteToLog $logFile $LogFileScripter ("        " + $ClusterRolesList) "I"
            WriteToLog $LogFile $LogFileScripter ("End - Retrieve a list of SQL Server Roles on " + $Cluster) "I"
        }
        else
        {
            # If ClusterRoles is null, then the cluster roles were not found
            return
        }
    }
    catch
    {
        WriteToLog $logFile $logFilescripter ("    Unable to retrieve a list of cluster roles from the 'Get-ClusterGroup' cmdlet. Please check that you are running this script on a Clustered Server.") "E"
        WriteToLog $logFile $logFilescripter ("  " + $_.Exception.Message) "E"
        WriteToLog $logFile $logFilescripter ("  " + $issuanceFail) "E"
        throw $_.Exception   
    }

    # For each cluster role in the Cluster Roles array, do the following...
    foreach($item in $ClusterRoles) 
    {

        ###############################################################################################################################
        # Query SQL CDRS for Proper Owner Nodes
        ###############################################################################################################################

        WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
        WriteToLog $LogFile $LogFileScripter (" ") "I"
        
        WriteToLog $LogFile $LogFileScripter ("Begin - Query SQL CDRS for Proper Owner Nodes") "I"

        try
        {
            # SQL-CDRS Connection Settings
            $ServerName = "SQLPSQLI1.SUPPORT.STATEFARM.ORG"
	        $UserName = "sql_ro"
	        $Password = "Sqlalsk123!!!!"
            $DatabaseName = "SFSQL_CDRS"

            # SQL Query
            $SqlText = "SELECT DISTINCT a.PHYS_SRVR_NM AS 'Owner Node' FROM dbo.LOAD_CONFIG AS a WHERE 'SQL_' + a.ENV_NM = '" + $item + "' AND a.KEY_NM = 'INSTALL_DATE' AND ISDATE(a.KEY_VAL) = 1;"

            # Execute SQL-CDRS Query
            $NodesList = RunSQLCDRSInitialDataCall $ServerName $DatabaseName $UserName $Password $SqlText 

            if($NodesList -ne $null)
            {
                # If NodesList is not null, then the query returned results                
                $NodesString = @()
                
                foreach($Node in $NodesList) 
                {
                    [System.String] $tempstring = $Node.'Owner Node'
                    $NodesString += $tempstring

                }

                $Nodes = ( $NodesList | Select -ExpandProperty 'Owner Node') -join ", "

                WriteToLog $logFile $LogFileScripter ("    The following are possible SQL Server nodes returned from SQL CDRS query for " + $item + ":") "I"
                WriteToLog $LogFile $LogFileScripter ("     " + $Nodes) "I"
                WriteToLog $LogFile $LogFileScripter ("End - Query SQL CDRS for Proper Owner Nodes") "I"
            }
            else
            {
                # If NodesList is null, then the SQL CDRS query failed or did not return any results
                return
            }
        }
        catch
        {
            WriteToLog $logFile $LogFileScripter ("    No SQL Server nodes returned from SQL CDRS query for " + $item + ". Please check that " + $item + " is participating in a cluster.") "E"
            WriteToLog $logFile $LogFileScripter ("  " + $issuanceFail) "E"
        }


        WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter (" ") "I"


        ###############################################################################################################################
        # Begin - Set SQL Server Dependencies
        ###############################################################################################################################

        WriteToLog $LogFile $LogFileScripter ("Begin - Set SQL Server Dependencies") "I"

        try
        {
            WriteToLog $LogFile $LogFileScripter ("    Retrieving list of old SQL Server Dependencies...") "I"
            WriteToLog $LogFile $LogFileScripter (" ") "I"

            # Find the SQL Server Role Group
            $ClusterRoleGroup = Get-ClusterResource | Where-Object {$_.OwnerGroup -eq $item -and $_.ResourceType -eq "SQL Server"}

            if($ClusterRoleGroup -eq $null) 
            {
                # If Cluster Role Group was not found, exit out of this try/catch
                return
            }
            else
            {
                # If Cluster Role Group was found, continue on and generate a list of the old SQL Server Dependencies
                $OldDependencyList = Get-ClusterResourceDependency -InputObject $ClusterRoleGroup | Select -ExpandProperty DependencyExpression

                WriteToLog $LogFile $LogFileScripter ("    Previous SQL Server Dependency List is:") "I"
                WriteToLog $LogFile $LogFileScripter ("    " + $OldDependencyList) "I"
                WriteToLog $LogFile $LogFileScripter (" ") "I"

                WriteToLog $LogFile $LogFileScripter ("    Retrieving list of correct SQL Server Dependencies...") "I"
                WriteToLog $LogFile $LogFileScripter (" ") "I"
                
                 # Get Resource List (Physical Disks and Network Names)
                $ResourceList = Get-ClusterResource | Where-Object {$_.OwnerGroup -eq $item -and ($_.ResourceType -eq "Physical Disk" -or $_.ResourceType -eq "Network Name")} | SELECT Name

                if($ResourceList -eq $null)
                {
                    # If Resource List is empty, then exit and do not try to set dependencies
                    return
                }
                else 
                {
                    $n = 0

                    # For each item in ResourceList, correct the syntax to adhere to the following: ([RESOURCE]) 
                    foreach($line in $ResourceList) 
                    {
                        $ResourceList[$n].Name = "([" +  $ResourceList[$n].Name + "])" 
                        $n++
                    }
                    
                    # For each item in resource list separate it by an "and" 
                    $ResourceList =  ($ResourceList | Select -ExpandProperty Name) -join " and "

                    WriteToLog $LogFile $LogFileScripter ("    Correct SQL Server Dependency to be set is:") "I"
                    WriteToLog $LogFile $LogFileScripter ("    " + $ResourceList) "I"
                    WriteToLog $LogFile $LogFileScripter (" ") "I"

                    WriteToLog $LogFile $LogFileScripter ("    Setting SQL Server dependencies...") "I"
                    WriteToLog $LogFile $LogFileScripter (" ") "I"

                    # Set the resource list as the new dependencies
                    Set-ClusterResourceDependency -InputObject $ClusterRoleGroup -Dependency $ResourceList

                    # Check to see if the dependencies were set successfully
                    $NewDependencyList = Get-ClusterResourceDependency -InputObject $ClusterRoleGroup | Select -ExpandProperty DependencyExpression

                    if($NewDependencyList -eq $null)
                    {
                        # If new dependency list is empty, then dependencies were not added successfully
                        return
                    }
                    else
                    {
                        # If new dependency list is not empty, assume they were set correctly
                        WriteToLog $LogFile $LogFileScripter ("    New SQL Server Dependency List is:") "I"
                        WriteToLog $LogFile $LogFileScripter ("    " + $NewDependencyList) "I"
                        WriteToLog $LogFile $LogFileScripter ("End - Set SQL Server Dependencies") "I"
                    }
  
                }
            }
        }
        catch
        {
            WriteToLog $logFile $logFilescripter ("  Failure occured during the setting SQL Server Cluster Resource Dependencies") "E"
            WriteToLog $logFile $logFilescripter ("  " + $_.Exception.Message) "E"
            WriteToLog $logFile $logFilescripter ("  " + $issuanceFail) "E"
            throw $_.Exception   
        }

        WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter (" ") "I"



        ###############################################################################################################################
        # Set Cluster Resources Possible Owners
        ###############################################################################################################################

        WriteToLog $LogFile $LogFileScripter ("Begin - Set Cluster Resources Possible Owners") "I"

        try
        {
            $Resources = Get-ClusterResource | Where-Object {$_.OwnerGroup -eq $item -and $_.Name -notlike "SQL Server Agent*" -and $_.Name -notlike "TSM*"}

            if($Resources -eq $null) 
            {
                # If resources is empty, then an error has occured, so exit
                return
            }
            else
            {
                # If resources are found, continue

                foreach($Resource in $Resources) 
                {

                    # Retrieve a list of old resource owners
                    $OldResourceOwners = Get-ClusterOwnerNode -Resource $Resource
                    
                    $String1 = $null

                    foreach($OwnerNode in $OldResourceOwners.OwnerNodes) 
                    {
                        $String1 += $OwnerNode.Name + ", " 
                    }

                    $String1 = $String1.Remove($String1.Length-2,2)
                    

                    WriteToLog $LogFile $LogFileScripter ("    " + "Old: "+ $OldResourceOwners.ClusterObject.Name + "`t`t`t {" + $String1 + "}") "I"

                    # Set the resources owners
                    Set-ClusterOwnerNode -Resource $Resource -Owners $NodesString

                    # Get the resources new owners
                    $NewResourceOwners = Get-ClusterOwnerNode -Resource $Resource

                    $String2 = $null

                    foreach($OwnerNode in $NewResourceOwners.OwnerNodes) 
                    {
                        $String2 += $OwnerNode.Name + ", " 
                    }

                    $String2 = $String2.Remove($String2.Length-2,2)

                    WriteToLog $LogFile $LogFileScripter ("    " + "New: "+ $NewResourceOwners.ClusterObject.Name + "`t`t`t {" + $String2 + "}") "I"

                    WriteToLog $LogFile $LogFileScripter (" ") "I"
                }

                WriteToLog $LogFile $LogFIleScripter ("End - Set Cluster Resources Possible Owners")

            }
        }
        catch
        {
            WriteToLog $logFile $logFilescripter ("  Failure occured during setting cluster resources' possible owners.") "E"
            WriteToLog $logFile $logFilescripter ("  " + $_.Exception.Message) "E"
            WriteToLog $logFile $logFilescripter ("  " + $issuanceFail) "E"
            throw $_.Exception
        }

        WriteToLog $LogFile $LogFileScripter (" ") "I"
        WriteToLog $LogFile $LogFileScripter (" ") "I"

        ###############################################################################################################################
        # Set Cluster Group's Preferred Owner 
        ###############################################################################################################################

        WriteToLog $LogFile $LogFileScripter ("Begin - Set Cluster Group's Preferred Owner") "I"

        try
        {
            WriteToLog $LogFile $LogFileScripter ("    Looking up Cluster Group's Preferred Owners...") "I"
            WriteToLog $LogFile $LogFileScripter ("") "I"
            
            # Get old preferred owners
            $OldPreferredOwners = Get-ClusterOwnerNode -Group $item

            WriteToLog $LogFile $LogFileScripter ("    " + "Old Preferred Owners for " + $item + ":" + " `t `t" + "{" + $OldPreferredOwners.OwnerNodes + "}")
            WriteToLog $LogFile $LogFileScripter ("") "I"
            WriteToLog $LogFile $LogFileScripter ("    Setting Cluster Group's New Preferred Owners...") "I"
            WriteToLog $LogFile $LogFileScripter ("") "I"

            # Set new preferred owners
            Set-ClusterOwnerNode -Group $item -Owners $NodesString

            # Get new preferred owners
            $NewPreferredOwners= Get-ClusterOwnerNode -Group $item

            if($NewPreferredOwners -eq $null) 
            {
                # New owners were not set properly, shoot an error
                return
            }

            WriteToLog $LogFile $LogFileScripter ("    " + "New Preferred Owners for " + $item + ":" +" `t `t" + "{" + $NewPreferredOwners.OwnerNodes + "}")
            WriteToLog $LogFIle $LogFileScripter ("End - Set Cluster Group's Preferred Owner") "I"
        }
        catch
        {
            WriteToLog $logFile $logFilescripter ("  Failure occured while setting cluster group's preferred owners.") "E"
            WriteToLog $logFile $logFilescripter ("  " + $_.Exception.Message) "E"
            WriteToLog $logFile $logFilescripter ("  " + $issuanceFail) "E"
            throw $_.Exception   
        }
    }

    ###############################################################################################################################
    # Log Success Footer 
    ###############################################################################################################################

    WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"

    WritetoLog $LogFile $LogFileScripter ("Script end time: " + ([System.DateTime]::Now).ToString("yyyy-MM-dd hh:mm:ss")) "I"
	WriteToLog $LogFile $LogFileScripter ($IssuanceSuccess) "I"

}
catch
{
    ###############################################################################################################################
    # Log Failure Footer 
    ###############################################################################################################################

    WriteToLog $LogFile $LogFileScripter (" ") "I"
    WriteToLog $LogFile $LogFileScripter ("***************************************************************************************************") "I"
    WriteToLog $LogFile $LogFileScripter (" ") "I"

    WriteToLog $LogFile $LogFileScripter ($_.Exception) "E"
    WriteToLog $LogFile $LogFileScripter ($IssuanceFail) "E"
    throw $_.Exception
}