/**
List all databases on instance 
**/
SELECT DISTINCT name
FROM sys.databases;

/**
List all files on Database
**/
SELECT d.name AS 'Database Name', m.name AS 'File Name', m.type_desc AS 'File Type', m.physical_name AS 'File Location', m.size*8/1024 AS 'File Size'
FROM sys.master_files AS m
INNER JOIN sys.databases AS d ON (d.database_id = m.database_id)
ORDER BY [Database Name], [File Type] DESC;


/**
Find database sizes
**/
SELECT d.name, SUM(size*8/1024) AS 'Database Size (MB)'
FROM sys.master_files AS m
INNER JOIN sys.databases AS d ON (d.database_id = m.database_id)
GROUP BY d.name;

EXEC sp_spaceused;

CREATE TABLE #DatabaseInfo (
	name varchar(100),
	db_size varchar(20),
	owner varchar(20),
	dbid smallint,
	created smalldatetime,
	status varchar(250),
	compatability_level varchar(250));

INSERT INTO #DatabaseInfo
EXEC SP_HELPDB;

SELECT *
FROM #DatabaseInfo;

DROP TABLE #DatabaseInfo;

