SET NOCOUNT ON

/** Declaring variables **/
DECLARE @BackupDir			VARCHAR(256) -- backup directory
,		@DBName				VARCHAR(256) -- database name
,		@BackupFullCMD		VARCHAR(1024) -- full backup command
,		@BackupLogCMD		VARCHAR(1024) -- log backup command
,		@RestoreFullCMD		VARCHAR(1024) -- full restore command
,		@RestoreLogCMD		VARCHAR(1024) -- log restore command
,		@AAGName			VARCHAR(16) -- availability group name
,		@AAGPrimaryCMD		VARCHAR(512) -- availability group primary command
,		@AAGSecondaryCMD	VARCHAR(512) -- availability group secondary command

/** Runs an extended store procedure that returns the backup directory path (i.e. F:\MSSQL\BACKUP\F_MP04\BACKUP) and assigns it to the @BackupDir variable **/
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'BackupDirectory', @BackupDir OUTPUT

/** If the count of the availability groups is equal to one, then do the following...
		1.) Set the @AAGName variable to the name column from the availability groups table

	ELSE print the following...

		1.) More than one availability group!!!
		2.) Choose availability group name and databases separately!!!
		3.) Lists current availability group names
**/
IF (SELECT COUNT(*) FROM master.sys.availability_groups) = 1
BEGIN
	SELECT @AAGName = name FROM master.sys.availability_groups
END
ELSE 
BEGIN
	PRINT '**** MORE THAN ONE AVAILABILITY GROUP!!!! ****'
	PRINT '**** CHOOSE AAG NAME AND DATABASES SEPARATELY!!!! ****'
	SELECT '**** MORE THAN ONE AVAILABILITY GROUP!!!! ****'
	SELECT '**** CHOOSE AAG NAME AND DATABASES SEPARATELY!!!! ****'
	SELECT name FROM master.sys.availability_groups
	
	/****  CHOOSE AAG NAME HERE ****/
	SELECT @AAGName = 'WSLDWRGJ03'
	/****  CHOOSE AAG NAME HERE ****/

END

--SELECT @BackupDir
--SELECT @AAGName

DECLARE DBNames CURSOR STATIC FOR
SELECT name FROM sys.databases 

/**** SELECT ALL DATABASES HERE ****/
--WHERE name NOT IN ('master', 'model', 'msdb', 'tempdb', 'reportserver', 'reportservertempdb', 'SF_SQL_ADMIN') 
/**** SELECT ALL DATABASES HERE ****/

/**** SELECT SPECIFIC DATABASES HERE ****/
WHERE name IN ('AAG_Test_DB03')
/**** SELECT SPECIFIC DATABASES HERE ****/

ORDER BY name ASC

OPEN DBNames

FETCH FIRST FROM DBNames INTO @DBName

WHILE @@FETCH_STATUS = 0
BEGIN

	--PRINT @DBName

	SELECT @BackupFullCMD = 'BACKUP DATABASE ' + @DBName + '
	TO DISK = N''' + @BackupDir + '\' + @DBName + '_FullDB.BAK''
	WITH  
		--COPY_ONLY, 
	NOFORMAT, INIT, SKIP, NOREWIND, NOUNLOAD, COMPRESSION;'

	SELECT @BackupLogCMD = 'BACKUP LOG ' + @DBName + '
	TO DISK = N''' + @BackupDir + '\' + @DBName + '_TrnLog.BAK''
	WITH  NOFORMAT, INIT, SKIP, NOREWIND, NOUNLOAD, COMPRESSION;'

	--PRINT @BackupFullCMD
	--PRINT ''
	--PRINT @BackupLogCMD
	--PRINT ''

	SELECT @RestoreFullCMD = 'RESTORE DATABASE ' + @DBName + '
	FROM DISK = N''' + @BackupDir + '\' + @DBName + '_FullDB.BAK''
		WITH REPLACE, NORECOVERY'

	SELECT @RestoreLogCMD = 'RESTORE DATABASE ' + @DBName + '
	FROM DISK = N''' + @BackupDir + '\' + @DBName + '_TrnLog.BAK''
		WITH NORECOVERY'

	SELECT @AAGSecondaryCMD = 'ALTER DATABASE [' + @DBName + '] SET HADR AVAILABILITY GROUP = [' + @AAGName + '];'

	PRINT ''
	PRINT ''
	PRINT @RestoreFullCMD
	PRINT ''
	PRINT @RestoreLogCMD
	PRINT ''
	PRINT @AAGSecondaryCMD
	PRINT ''

	IF NOT EXISTS (
					SELECT 
						1 
					FROM 
						master.sys.databases a
						INNER JOIN
						master.sys.availability_replicas b
							ON a.replica_id = b.replica_id
								AND b.replica_server_name = @@SERVERNAME
								AND a.name = @DBName
					)
	BEGIN
		SELECT @AAGPrimaryCMD = 'ALTER AVAILABILITY GROUP ' + @AAGName + ' ADD DATABASE [' + @DBName + '];'
	END
	ELSE 
		SELECT @AAGPrimaryCMD = NULL
	
	EXEC (@BackupFullCMD)
	EXEC (@BackupLogCMD)
	EXEC (@AAGPrimaryCMD)

	FETCH NEXT FROM DBNames INTO @DBName
END

CLOSE DBNames
DEALLOCATE DBNames





