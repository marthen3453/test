DECLARE @DBName		VARCHAR(256)
,		@cmd		VARCHAR(3000)

CREATE TABLE #FinalResults
(	
	ClusterName			VARCHAR(36)
,	DatabaseName		VARCHAR(128)
,	DatabaseFileName	VARCHAR(128)
,	FileType			VARCHAR(32)
,	DatabaseState		VARCHAR(32)
,	Size_MB				DECIMAL(20,2)
,	Space_Used_MB		DECIMAL(20,2)
,	Available_MB		DECIMAL(20,2)
)

SELECT 
	@@ServerName AS ClusterName
,	a.[name] AS DatabaseName
,	b.[file_id] AS DatabaseFileID
,	b.[name] AS DatabaseFileName
,	b.type_desc AS FileType
,	b.[state_desc] AS DatabaseState
,	b.[size] AS DatabaseSize
INTO #Databases
FROM
	sys.databases a
	INNER JOIN
	sys.master_files b
		ON a.database_id = b.database_id
--WHERE
	--a.[name] NOT IN ('master', 'model', 'tempdb', 'msdb', 'SF_SQL_ADMIN')
	--AND
	--b.[type_desc] = 'ROWS'
	--AND
	--@@ServerName IN ('WPSDYTK4\WMSDYTK401', 'WPSDYTK4\WMSDYTK402', 'WPSDYTK4\WMSDYTK403')
	--AND
	--a.name LIKE '%SPC_MySite%'
ORDER BY
	a.[name] ASC

--SELECT * FROM #Databases

DECLARE DBs CURSOR STATIC FOR
SELECT DISTINCT
	[DatabaseName]
FROM
	#Databases

OPEN DBs

FETCH FIRST FROM DBs INTO @DBName

WHILE @@FETCH_STATUS = 0
BEGIN

	SET @cmd = '
	USE [' + @DBName + ']
	SELECT 
		''' + @DBName + '''AS DatabaseName
	,	[file_id] AS DatabaseFileID
	,	[name] AS DatabaseFileName
	,	CAST([size]/128.0 as DECIMAL(10,2)) AS Size_MB
	,	CAST(FILEPROPERTY(name, ''SpaceUsed'')/128.0 as DECIMAL(10,2)) as Space_Used_MB
	,	CAST([size]/128.0-(FILEPROPERTY(name, ''SpaceUsed'')/128.0) AS DECIMAL(10,2)) AS Available_MB
	INTO ##DBInfo
	FROM 
		[' + @DBName + '].sys.database_files'

	--PRINT @cmd
	EXEC(@cmd)

	INSERT INTO #FinalResults
	SELECT 
		@@ServerName AS ClusterName
	,	a.DatabaseName
	,	a.DatabaseFileName
	,	a.FileType
	,	a.DatabaseState
	,	b.Size_MB
	,	b.Space_Used_MB
	,	b.Available_MB
	FROM
		#Databases a
		INNER JOIN
		##DBInfo b
			ON a.DatabaseName COLLATE SQL_Latin1_General_CP1_CI_AS = b.DatabaseName COLLATE SQL_Latin1_General_CP1_CI_AS
			AND a.DatabaseFileID = b.DatabaseFileID

	DROP TABLE ##DBInfo

	FETCH NEXT FROM DBs INTO @DBName
END

SELECT 
	ClusterName
,	DatabaseName
,	DatabaseFileName
,	FileType
,	Size_MB
,	Space_Used_MB
,	Available_MB
,	CONVERT(DECIMAL(4,2),((Available_MB/Size_MB)*100)) AS FilePercentFree

FROM 
	#FinalResults
ORDER BY
	DatabaseName ASC
,	FileType DESC
,	DatabaseFileName ASC

SELECT 
	ClusterName
,	DatabaseName
,	FileType
,	SUM(Size_MB) AS DBDataSize_MB
,	SUM(Space_Used_MB) AS DBSpaceUsed_MB
,	SUM(Available_MB) AS DBAvailSpace_MB
,	CONVERT(DECIMAL(4,2),((SUM(Available_MB)/SUM(Size_MB))*100)) AS DBPercentFree
FROM 
	#FinalResults
GROUP BY
	ClusterName, DatabaseName, FileType
ORDER BY
	DatabaseName ASC, FileType DESC

CLOSE DBs
DEALLOCATE DBs

DROP TABLE #Databases
DROP TABLE #FinalResults

