SELECT database_name, type, backup_start_date, backup_finish_date
FROM dbo.backupset
WHERE type = 'D'
-- AND (database_name = 'DOCUMEDCPRD' OR database_name = 'DOCUMEDCBAMPRD')
AND database_name NOT IN ('master', 'model', 'msdb', 'tempdb')
-- AND DATEDIFF(minute, backup_start_date, backup_finish_date) > 0
ORDER BY backup_start_date DESC;
