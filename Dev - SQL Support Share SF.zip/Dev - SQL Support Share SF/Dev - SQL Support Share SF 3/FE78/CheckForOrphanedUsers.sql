USE SCR_BPMAINDB
GO

sp_change_users_login 'REPORT'