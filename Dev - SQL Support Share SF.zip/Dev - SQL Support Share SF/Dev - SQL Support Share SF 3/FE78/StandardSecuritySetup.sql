USE [SF_SQL_Admin]
GO

DECLARE	@return_value int

EXEC	@return_value = [dbo].[DatabaseStandardSecuritySetup]
		@DBName = model,
		@Security_Group_Base_Name = DELLOME

SELECT	'Return Value' = @return_value

GO
