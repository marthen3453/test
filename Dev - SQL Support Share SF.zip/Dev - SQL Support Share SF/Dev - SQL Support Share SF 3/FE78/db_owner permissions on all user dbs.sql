DECLARE @dbname		VARCHAR(256)
,		@srvcmd		VARCHAR(4096)
,		@dbcmd		VARCHAR(4096)
,		@extgroup	VARCHAR(64)
,		@intgroup	VARCHAR(64)
,		@farmacct	VARCHAR(64)
,		@stcacct	VARCHAR(64)

SET @extgroup = 'SUPPORT\SA_CPS_ES3_G'
SET @intgroup = 'SUPPORT\SA_CPS_IS3_G'
SET @farmacct = 'OPR\SVC_SP2013_PROD_FARM'

SELECT @srvcmd = '
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE [name] = ''' + @extgroup + ''')
BEGIN
	CREATE LOGIN [' + @extgroup + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]
END

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE [name] = ''' + @intgroup + ''')
BEGIN
	CREATE LOGIN [' + @intgroup + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]

END

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE [name] = ''' + @farmacct + ''')
BEGIN
	CREATE LOGIN [' + @farmacct + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]

END

GRANT VIEW SERVER STATE TO [' + @extgroup + ']
GRANT VIEW ANY DEFINITION TO [' + @extgroup + ']

GRANT VIEW SERVER STATE TO [' + @intgroup + ']
GRANT VIEW ANY DEFINITION TO [' + @intgroup + ']

'

--PRINT @srvcmd
EXEC (@srvcmd)

DECLARE dbcursor CURSOR STATIC FOR
SELECT name AS DatabaseName FROM sys.databases
WHERE
	database_id > 4
	AND
	name != 'SF_SQL_Admin'
	AND
	source_database_id IS NULL
	AND
	replica_id IS NULL

OPEN dbcursor

FETCH FIRST FROM dbcursor INTO @dbname

WHILE @@FETCH_STATUS = 0
BEGIN 
	SELECT @dbcmd = 'USE [' + @dbname + ']
	IF NOT EXISTS (SELECT * FROM sys.database_principals a INNER JOIN [master].sys.server_principals b ON a.sid = b.sid WHERE b.name = ''' + @extgroup + ''')
	BEGIN
		CREATE USER [' + @extgroup + '] FOR LOGIN [' + @extgroup + ']
	END
	ALTER ROLE [db_datareader] ADD MEMBER [' + @extgroup + ']
	
	IF NOT EXISTS (SELECT * FROM sys.database_principals a INNER JOIN [master].sys.server_principals b ON a.sid = b.sid WHERE b.name = ''' + @intgroup + ''')
	BEGIN
		CREATE USER [' + @intgroup + '] FOR LOGIN [' + @intgroup + ']
	END
	ALTER ROLE [db_datareader] ADD MEMBER [' + @intgroup + ']

	IF NOT EXISTS (SELECT * FROM sys.database_principals a INNER JOIN [master].sys.server_principals b ON a.sid = b.sid WHERE b.name = ''' + @farmacct + ''')
	BEGIN
		CREATE USER [' + @farmacct + '] FOR LOGIN [' + @farmacct + ']
	END
	ALTER ROLE [db_owner] ADD MEMBER [' + @farmacct + ']

	'

	--PRINT @dbcmd
	EXEC (@dbcmd)

	FETCH NEXT FROM dbcursor INTO @dbname
END

CLOSE dbcursor
DEALLOCATE dbcursor




