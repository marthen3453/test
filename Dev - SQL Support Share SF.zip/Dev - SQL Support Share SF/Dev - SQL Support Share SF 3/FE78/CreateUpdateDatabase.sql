
















































										   
USE [master]
GO

IF EXISTS (SELECT * FROM sysdatabases WHERE name = 'ADI_JobManager')
BACKUP DATABASE [ADI_JobManager] TO  DISK = N'ADI_JobManager.bak' WITH NOFORMAT, NOINIT,  NAME = N'ADI_JobManager-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO

IF NOT EXISTS (SELECT * FROM sysdatabases WHERE name = 'ADI_JobManager')
CREATE DATABASE [ADI_JobManager]
GO

EXEC dbo.sp_dbcmptlevel @dbname=N'ADI_JobManager', @new_cmptlevel=100
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [ADI_JobManager].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [ADI_JobManager] SET ANSI_NULL_DEFAULT OFF
GO	
ALTER DATABASE [ADI_JobManager] SET ANSI_NULLS OFF
GO
ALTER DATABASE [ADI_JobManager] SET ANSI_PADDING OFF
GO
ALTER DATABASE [ADI_JobManager] SET ANSI_WARNINGS OFF
GO
ALTER DATABASE [ADI_JobManager] SET ARITHABORT OFF
GO
ALTER DATABASE [ADI_JobManager] SET AUTO_CLOSE OFF
GO
ALTER DATABASE [ADI_JobManager] SET AUTO_CREATE_STATISTICS ON
GO
ALTER DATABASE [ADI_JobManager] SET AUTO_SHRINK OFF
GO
ALTER DATABASE [ADI_JobManager] SET AUTO_UPDATE_STATISTICS ON
GO
ALTER DATABASE [ADI_JobManager] SET CURSOR_CLOSE_ON_COMMIT OFF
GO
ALTER DATABASE [ADI_JobManager] SET CURSOR_DEFAULT  GLOBAL
GO
ALTER DATABASE [ADI_JobManager] SET CONCAT_NULL_YIELDS_NULL OFF
GO
ALTER DATABASE [ADI_JobManager] SET NUMERIC_ROUNDABORT OFF
GO
ALTER DATABASE [ADI_JobManager] SET QUOTED_IDENTIFIER OFF
GO
ALTER DATABASE [ADI_JobManager] SET RECURSIVE_TRIGGERS OFF
GO
ALTER DATABASE [ADI_JobManager] SET  READ_WRITE
GO
ALTER DATABASE [ADI_JobManager] SET RECOVERY SIMPLE
GO
ALTER DATABASE [ADI_JobManager] SET  MULTI_USER
GO
ALTER DATABASE [ADI_JobManager] SET TORN_PAGE_DETECTION ON
GO
if ( ((@@microsoftversion / power(2, 24) = 8) and (@@microsoftversion & 0xffff >= 760)) or 
        (@@microsoftversion / power(2, 24) >= 9) )begin 
    --exec dbo.sp_dboption @dbname =  N'ADI_JobManager', @optname = 'db chaining', @optvalue = 'OFF'
	ALTER DATABASE ADI_JobManager SET DB_CHAINING OFF; 
 end
GO

USE [ADI_JobManager]
GO

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[VERSION]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[VERSION](
    [index] [int] NOT NULL,
    [field_index] [int] NULL DEFAULT ((0)),
    [version] [int] NULL DEFAULT ((0)),
    [description] [ntext]  NULL,
 CONSTRAINT [aaaaaVERSION_PK] PRIMARY KEY NONCLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetPendingJobsByJobID]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPendingJobsByJobID]
    @ParamJobID [int]
AS
BEGIN

SELECT SCHEDULE.starttime, SCHEDULE.scheduletype, SCHEDULE.scheduletime
FROM SCHEDULE
WHERE (((SCHEDULE.starttime)<GETDATE()) AND ((SCHEDULE.jobid)=@ParamJobID));

END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetPendingJobs]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetPendingJobs]
AS
BEGIN

SELECT DISTINCT SCHEDULE.jobid
FROM SCHEDULE
WHERE (((SCHEDULE.starttime)<GETDATE()));

END
' 
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[PASTE ERRORS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[PASTE ERRORS](
    [paramnumber] [int] NULL,
    [paramstring] [nvarchar](1000)  NULL
) ON [PRIMARY]
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MISC]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	DROP TABLE [dbo].[MISC];

GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MISC]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[MISC](
    [versionmajor] [smallint] NOT NULL,
    [versionminor] [smallint] NOT NULL,
    [versionbuild] [int] NOT NULL
) ON [PRIMARY]

INSERT INTO [dbo].[MISC] ([versionmajor],[versionminor],[versionbuild]) VALUES(2015, 1, 0)
END
GO

--At the start of the script we need to remove sessionid and create processid, machinename instead
--Because all the triggers will be created anew and they refer these new fields in MM_USER_ACTIONS table
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MM_USER_ACTIONS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	IF EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[MM_USER_ACTIONS]') AND name = N'sessionid')
		ALTER TABLE [dbo].[MM_USER_ACTIONS] DROP COLUMN sessionid

	IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[MM_USER_ACTIONS]') AND name = N'processid')
		ALTER TABLE [dbo].[MM_USER_ACTIONS] ADD [processid] [int] NULL

	IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[MM_USER_ACTIONS]') AND name = N'machinename')
		ALTER TABLE [dbo].[MM_USER_ACTIONS] ADD [machinename] [nchar](255)  NULL
	ELSE
		ALTER TABLE [dbo].[MM_USER_ACTIONS] ALTER COLUMN [machinename] [nchar](255)  NULL
END

GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MAPMGR_DB_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_MAPMGR_DB_UPDATE];

GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MAPMGR_DB_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_MAPMGR_DB_INSERT];

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MAPMGR_DB]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[MAPMGR_DB](
    [index] [int] NOT NULL,
    [database_name] [nvarchar](255)  NULL,
    [description] [ntext]  NULL,
    [orgnization] [nvarchar](50)  NULL,
    [user_name] [nvarchar](30)  NULL,
    [user_memo] [ntext]  NULL,
    [subsystem_number] [smallint] NULL DEFAULT ((0)),
    [report_number] [smallint] NULL DEFAULT ((0)),
    [create_time] [datetime] NULL,
    [last_modify_time] [datetime] NULL,
    [version] [nvarchar](10)  NOT NULL,
 CONSTRAINT [aaaaaMAPMGR_DB_PK] PRIMARY KEY NONCLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

INSERT INTO [dbo].[MAPMGR_DB]
           ([index]
		   ,[database_name]
           ,[description]
           ,[user_name]
           ,[create_time]
           ,[last_modify_time]
           ,[version])
     VALUES
           (1
		   ,'ADI_JobManager'
           ,'This is a SQL Server Database'
           ,'xxx'
           ,'12:00:00 AM'
           ,'12:00:00 AM'
           ,'2015.1.0')

END

ELSE

UPDATE [dbo].[MAPMGR_DB] SET [version] = '2015.1.0', [database_name]='ADI_JobManager', 
		[description] = 'This is a SQL Server Database'

GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MAPMGR_DB]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[MAPMGR_DB]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MAPMGR_DB_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_MAPMGR_DB_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MAPMGR_DB_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_MAPMGR_DB_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[MAPMGR_DB]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[MAPMGR_DB]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[MAPMGR_DB] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[MAPMGR_DB] SET temporary = [index]')
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'aaaaaMAPMGR_DB_PK'))
				ALTER TABLE [dbo].[MAPMGR_DB] DROP Constraint aaaaaMAPMGR_DB_PK; 
			ALTER TABLE [dbo].[MAPMGR_DB] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[MAPMGR_DB] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[MAPMGR_DB].temporary', 'index', 'COLUMN';
			ALTER TABLE [dbo].[MAPMGR_DB] ADD CONSTRAINT aaaaaMAPMGR_DB_PK PRIMARY KEY([index]);  
		END 
	END
END	

GO

BEGIN
-- update version number
	UPDATE [dbo].[MAPMGR_DB] SET [version]='2015.1.0'
END
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MAPMGR_DB_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_MAPMGR_DB_INSERT]
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_MAPMGR_DB_INSERT] 
   ON  [dbo].[MAPMGR_DB] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''MAPMGR_DB''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''[index]=''+convert(nvarchar(15),NEW.[index]),
                (''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''database_name=''+''''''''+ISNULL(Replace(NEW.database_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''orgnization=''+''''''''+ISNULL(Replace(NEW.orgnization,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[user_name]=''+''''''''+ISNULL(Replace(NEW.[user_name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''subsystem_number=''+ISNULL(convert(nvarchar(15),NEW.subsystem_number),'''') +''|#''+
                ''report_number=''+ISNULL(convert(nvarchar(15),NEW.report_number),'''') +''|#''+
                ''create_time=''+ CASE WHEN NEW.create_time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.create_time)+'''''''' END +''|#''+
                ''last_modify_time=''+ CASE WHEN NEW.last_modify_time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.last_modify_time)+'''''''' END +''|#''+
                ''version=''+''''''''+NEW.version+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(ORG.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''user_memo=''+''''''''+ISNULL(Replace(cast(ORG.user_memo as nvarchar(MAX)),'''''''',''''''''''''),'''')+'''''''') from INSERTED NEW,dbo.MAPMGR_DB ORG
where ORG.[index] = NEW.[index];
END
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MAPMGR_DB_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_MAPMGR_DB_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_MAPMGR_DB_UPDATE] 
   ON  [dbo].[MAPMGR_DB] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''MAPMGR_DB''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''database_name=''+''''''''+ISNULL(Replace(OLD.database_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''orgnization=''+''''''''+ISNULL(Replace(OLD.orgnization,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[user_name]=''+''''''''+ISNULL(Replace(OLD.[user_name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''subsystem_number=''+ISNULL(convert(nvarchar(15),OLD.subsystem_number),'''') +''|#''+
                ''report_number=''+ISNULL(convert(nvarchar(15),OLD.report_number),'''') +''|#''+
                ''create_time=''+ CASE WHEN OLD.create_time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.create_time)+'''''''' END +''|#''+
                ''last_modify_time=''+ CASE WHEN OLD.last_modify_time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.last_modify_time)+'''''''' END +''|#''+
                ''version=''+''''''''+OLD.version+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''user_memo=''+''''''''+ISNULL(Replace(cast(OLD.user_memo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+
                '' where ''+''[index]=''+convert(nvarchar(15),OLD.[index]),
                ''database_name=''+''''''''+ISNULL(Replace(NEW.database_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''orgnization=''+''''''''+ISNULL(Replace(NEW.orgnization,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[user_name]=''+''''''''+ISNULL(Replace(NEW.[user_name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''subsystem_number=''+ISNULL(convert(nvarchar(15),NEW.subsystem_number),'''') +''|#''+
                ''report_number=''+ISNULL(convert(nvarchar(15),NEW.report_number),'''') +''|#''+
                ''create_time=''+ CASE WHEN NEW.create_time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.create_time)+'''''''' END +''|#''+
                ''last_modify_time=''+ CASE WHEN NEW.last_modify_time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.last_modify_time)+'''''''' END +''|#''+
                ''version=''+''''''''+NEW.version+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(NEW.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''user_memo=''+''''''''+ISNULL(Replace(cast(NEW.user_memo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+
                '' where ''+''[index]=''+convert(nvarchar(15),NEW.[index]) from DELETED OLD,INSERTED NEW
 where NEW.[index] = OLD.[index];
END
--update the field in MAPMGR_DB table
UPDATE dbo.MAPMGR_DB
SET database_name=NEW.database_name,
    orgnization=NEW.orgnization,
    [user_name]=NEW.[user_name],
    subsystem_number=NEW.subsystem_number,
    report_number=NEW.report_number,
    create_time=NEW.create_time,
    last_modify_time=NEW.last_modify_time,
    version=NEW.version,
    description=NEW.description,
    user_memo=NEW.user_memo
    from INSERTED NEW
    where MAPMGR_DB.[index] in (NEW.[index]);
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),OLD.[index])+''|#''+
                ''database_name=''+''''''''+ISNULL(Replace(OLD.database_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''orgnization=''+''''''''+ISNULL(Replace(OLD.orgnization,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[user_name]=''+''''''''+ISNULL(Replace(OLD.[user_name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''subsystem_number=''+ISNULL(convert(nvarchar(15),OLD.subsystem_number),'''') +''|#''+
                ''report_number=''+ISNULL(convert(nvarchar(15),OLD.report_number),'''') +''|#''+
                ''create_time=''+ CASE WHEN OLD.create_time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.create_time)+'''''''' END +''|#''+
                ''last_modify_time=''+ CASE WHEN OLD.last_modify_time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.last_modify_time)+'''''''' END +''|#''+
                ''version=''+''''''''+OLD.version+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''user_memo=''+''''''''+ISNULL(Replace(cast(OLD.user_memo as nvarchar(MAX)),'''''''',''''''''''''),'''')+'''''''',
                ''[index]=''+convert(nvarchar(15),OLD.[index]) from DELETED OLD;
end
--Delete the field from MAPMGR_DB table
DELETE FROM MAPMGR_DB where [index] in (SELECT OLD.[index] from DELETED OLD);
END
END

' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SERVERS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[SERVERS](
    [name] [nvarchar](350)  NOT NULL,
    [type] [nvarchar](70)  NOT NULL,
 CONSTRAINT [PK_Servers] PRIMARY KEY CLUSTERED 
(
    [name] ASC,
    [type] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[SERVERS]') AND name = N'Name')
CREATE NONCLUSTERED INDEX [Name] ON [dbo].[SERVERS] 
(
    [name] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[SERVERS]') AND name = N'Type')
CREATE NONCLUSTERED INDEX [Type] ON [dbo].[SERVERS] 
(
    [type] ASC
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SERVERS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_SERVERS_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_SERVERS_INSERT] 
   ON  [dbo].[SERVERS] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''SERVERS''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''name=''+''''''''+NEW.name+'''''''',
                ''name=''+''''''''+NEW.name+''''''''+''|#''+
                ''type=''+''''''''+NEW.type+'''''''' from INSERTED NEW,SERVERS ORG
where ORG.name = NEW.name;

END
END

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SERVERS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_SERVERS_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_SERVERS_UPDATE] 
   ON  [dbo].[SERVERS] 
   AFTER UPDATE,DELETE
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @modifiedColumns int,
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''SERVERS''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''name=''+''''''''+OLD.name+''''''''+''|#''+
                ''type=''+''''''''+OLD.type+'''''''',

                ''name=''+''''''''+NEW.name+''''''''+''|#''+
                ''type=''+''''''''+NEW.type+'''''''' from DELETED OLD,INSERTED NEW
				where NEW.name = OLD.name;
end
END
--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''name=''+''''''''+OLD.name+'''''''',
                ''name=''+''''''''+OLD.name+''''''''+''|#''+
                ''type=''+''''''''+OLD.type+'''''''' from DELETED OLD;
end
END

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
'
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetMachinesFromjobID]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetMachinesFromjobID]
AS
BEGIN

SELECT SERVERS.name
FROM GetJobType INNER JOIN SERVERS ON GetJobType.Type = SERVERS.type;


END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetParameters]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetParameters]
    @pJobID [int]
AS
BEGIN

SELECT PARAMETERS.paramstring
FROM [PARAMETERS]
WHERE (((PARAMETERS.jobid)=@pJobID))
ORDER BY PARAMETERS.paramnumber;



END
' 
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SOURCE_FIELD]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[SOURCE_FIELD](
    [index] [int] NOT NULL,
    [field_number] [int] NULL,
    [input_record_index] [int] NULL,
    [subsystem_index] [int] NULL,
    [name] [nvarchar](255)  NOT NULL,
    [data_type] [nvarchar](1)  NOT NULL,
    [value_type] [nvarchar](1)  NULL,
    [default_value] [nvarchar](255)  NULL,
    [address] [int] NULL,
    [length] [smallint] NULL,
    [right] [smallint] NULL,
    [date_format] [nvarchar](1)  NULL,
    [date_slash] [nvarchar](1)  NULL,
    [repeat] [nvarchar](1)  NULL,
    [decimal] [nvarchar](1)  NULL,
    [comma] [nvarchar](1)  NULL,
    [justify] [nvarchar](1)  NULL,
    [zero] [nvarchar](1)  NULL,
    [sign] [nvarchar](1)  NULL,
    [source] [nvarchar](1)  NULL,
    [version] [int] NULL DEFAULT ((0)),
    [pcf_use] [nvarchar](1)  NULL,
    [docmemo] [ntext]  NULL,
    [data_subtype] [int] NULL,
    [valid] [bit] NULL,
    [folderid] [int] NOT NULL DEFAULT ((0)),
 CONSTRAINT [Index] PRIMARY KEY CLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

--INSERT Global Data for INPUT_RECORD table

INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('1','4','2','0','Run Date','D','','','0','8','0','2','N','N','','','','','','B','0','S','','13','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('2','3','2','0','Processing Date','D','','','0','8','0','2','N','N','','','','','','B','0','S','','13','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('3','1','2','0','Subsystem ID','X','','','0','6','0','','','N','','','','','','B','0','S','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('4','2','2','0','Subsystem Description','X','','','0','30','0','','','N','','','','','','B','0','S','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('5','5','2','0','A&F Total Balance','S','','','0','15','2','','','N','','','','','','B','0','S','','15','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('6','6','2','0','A&F Total Records','N','','','0','8','0','','','N','','','','','','B','0','S','','22','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('7','7','2','0','Schedule Time Interval','N','','','0','4','0','','','W','','','','','','B','0','S','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('8','8','2','0','Schedule Interval End Date','D','','','0','8','0','2','','W','','','','','','B','0','S','','13','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('9','9','2','0','Report Name','X','','','0','20','0','','','N','','','','','','B','0','S','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('10','10','2','0','Report Description','X','','','0','30','0','','','N','','','','','','B','0','S','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('11','11','2','0','Master Record Count','N','','','0','8','0','','','N','','','','','','B','0','S','','22','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('12','12','2','0','Page Number','N','','','0','4','0','','','N','','','','','','B','0','S','','22','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('13','1','2','0','Category Name','X','','','0','30','0','','','N','','','','','','B','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('14','2','2','0','Category Description','X','','','0','30','0','','','N','','','','','','B','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('15','7','2','0','Scheduled Repricing PCT','S','','','0','11','2','','','W','','','','','','B','0','C','','15','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('16','8','2','0','Remaining Life Balance','S','','','0','11','2','','','W','','','','','','B','0','C','','15','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('17','9','2','0','Amortizing Balance','S','','','0','11','2','','','W','','','','','','B','0','C','','15','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('18','10','2','0','Principal Cash Flow','S','','','0','11','2','','','W','','','','','','B','0','C','','15','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('19','11','2','0','Interest Cash Flow','S','','','0','11','2','','','W','','','','','','B','0','C','','15','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('20','12','2','0','Repricing Balance','S','','','0','11','2','','','W','','','','','','B','0','C','','15','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('21','13','2','0','Repricing Int Cash Flow','S','','','0','11','2','','','W','','','','','','B','0','C','','15','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('22','14','2','0','Remaining Balance','S','','','0','11','2','','','W','','','','','','B','0','C','','15','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('23','15','2','0','Category Record Count','N','','','0','8','0','','','N','','','','','','B','0','C','','22','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('24','16','2','0','Remaining Amortization Term','N','','','0','4','0','','','N','','','','','','B','0','C','','22','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('25','17','2','0','Remaining Balloon Term','N','','','0','4','0','','','N','','','','','','B','0','C','','22','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('26','18','2','0','Funding Spread','R','','','0','7','5','','','N','','','','','','B','0','C','','14','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('27','19','2','0','T Coupon Rate','R','','','0','7','5','','','N','','','','','','B','0','C','','14','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('28','20','2','0','T Current Book Yield','R','','','0','7','5','','','N','','','','','','B','0','C','','14','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('29','21','2','0','T Lowest Lifetime Rate','R','','','0','7','5','','','N','','','','','','B','0','C','','14','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('30','22','2','0','T Highest Lifetime Rate','R','','','0','7','5','','','N','','','','','','B','0','C','','14','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('31','23','2','0','T Maximum Rate Change','R','','','0','7','5','','','N','','','','','','B','0','C','','14','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('32','24','2','0','T Funding Rate','R','','','0','7','5','','','N','','','','','','B','0','C','','14','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('33','25','2','0','T Repricing Spread Value','S','','','0','7','4','','','N','','','','','','B','0','C','','15','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('34','38','1','0','Bank Name','X','','','0','30','0','','','N','','','','','','G','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('35','39','1','0','User Name','X','','','0','20','0','','','N','','','','','','G','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('36','40','1','0','Account-Reference-Number','X','','','0','20','0','','','N','','','','','','G','1','C','The unique number which identifies the transaction within the particular application subsystem.  Normally the Account Number is applicable here.  In some systems, however, the Account Number alone is inadequate to uniquely identify one record from another; another field may need to be used in conjunction with, or appended to, the Account Number that Users'' may aggregate by specific criteria. Having either no Account-Number or a non-unique account number will make it more difficult to identify transactions in the QA process and in A&F exception reports.','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('37','33','1','0','Transaction Status Code','X','','','305','3','0','','','N','','','','','','G','1','S','The following status codes identify the current status of the instrument:
ACT:  Currently active account.
NEW:  Currently active account which is new this month.   CLS:  Closed account. 
CGO:  Charged off. 
FCL:  Currently in forclosure
NON:  Non accruing','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('38','2','1','0','Transaction Class Type','X','','','1','3','0','','','N','','','','','','G','1','S','Identifies the type of transaction represented by a record.    Codes in this field are used to represent all components of a  transaction. 
REG   Regular Transaction 
LCM   Loan Commitment (often called a facility) 
CML   Commitment Tied Loan (often called a takedown)  CPL    Participation Out - Total Balance, Commitment tied  POT   Participation Out - Total Balance, Uncommitted  POP    Participation Out - Piece 
POB    Participation Out - Piece Retained by Bank 
PIT      Participation In  BUY       Buy of Entire Transaction  SEL     Sell Entire Translation.   This field is used for categorization purposes, not in any  schedules.  
For example, a revolver with a takedown loan that has been  partially sold to another bank really represents three different  elements of exposure for the bank:  the potential loan (the  revolver limit), the actual loan, and the reduced actual loan  (the loan less participation).  Consequently, it is important to  put out a record for each so that each element of the exposure  and the net exposure can be analyzed.  Participations can be structured so that the entire amount is  participated for the exact term, or pieces can be participated,  or the term can differ from the term that the customer has agreed  with the bank.  Similarly, a facility can be participated.  If  that were to happen, the actual participation of the principal  would only occur on takedown, although fees or points would  likely change prior to takedown.  Because bank holding companies are made up of many legal  entities, it is possible for the bank to participate to some  other entity within itself.  These are all the options  represented in the codes available.','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('39','3','2','0','Sub Category Name #1','X','','','0','20','0','','','N','','','','','','B','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('40','4','2','0','Sub Category Name #2','X','','','0','20','0','','','N','','','','','','B','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('41','5','2','0','Sub Category Name #3','X','','','0','20','0','','','N','','','','','','B','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('42','6','2','0','Sub Category Name #4','X','','','0','20','0','','','N','','','','','','B','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('43','3','1','0','Current Book Principal','F','','','4','8','0','','','N','','','','','','G','0','S','The remaining principal balance outstanding as of the Processing Date.  The ''book'' value of the financial instrument.  In general, this is the amount that would be reported to the General Ledger as the balance for the instrument.  In the creation of DCS financial schedules, CURRENT-BOOK-PRINCIPAL is used as the balance in the Remaining-Life-Schedule, the Summary-Schedule and to derive percentage of portfolio repricing in the Scheduled-Repricing-Schedule.  In the Amortization, Principal-Cash-Flow, Remaining-Balance, Interest-Cash-Flow, Repricing and Repricing-Interest-Cash-Flow schedules, CURRENT-BOOK-PRINCIPAL is the starting point on which all cash flow calculations are based.  All standard financial schedule weighted averages are based on the value of CURRENT-BOOK-PRINCIPAL.  The equivalent to CURRENT-BOOK-PRINCIPAL will virtually always be available somewhere in the source file, although some calculation or manipulation of fields may be required.  CURRENT-BOOK-PRINCIPAL should never be defaulted.  Instances of a zero-balance transaction should be verified accoring to current procedures.  In the case where the caustomer has financied verious feeds in addition to the requrested principal, you should always reflect the total outstanding amount.  In the case of discount loans, CURRENT-BOOK-PRINCIPAL will be the total amount of the note, net of payments.   Use in creation of Standard DCS financial schedules:  Remaining-Life-Schedule:  CURRENT-BOOK-PRINCIPAL is the amount shown in the Remaining Life  Schedule buckets   Category Totals:  CURRENT-BOOK-PRINCIPAL is accumulated in the Total Book Principal field and used to calculate the weighted average Coupon Rate.    Scheduled Repricing:  To calculate the percentage of the portfolio repricing in a given month, the CURRENT-BOOK-PRINCIPAL for all instrument repricing in the month is aggregated and divided by the total CURRENT-BOOK-PRINCIPAL for the portfolio as a whole.     Amortization, Principal-Cash-Flow, Remaining-Balance,  Repricing, Interest-Cash-Flow, Repricing-Interest-Cash-Flow:  Except in the special case of discount securities (AMORTIZATION-CODE = DSC), the value of CURRENT-BOOK-PRINCIPAL is used as the starting point for the calculation of Interest and principal cash flows.     For Discount Securities, CURRENT-BOOK-PRINCIPAL should represent the current book value of the instrument.  This will often be avilable on the source system or may be calculated by combining the purchase price of the instrument with the premium amount accreted to-date or the discount amount accrued to-date.   CURRENT-BOOK-PRINCIPAL should always be a positive number (even in the case of liabilities), except in the case of participations (TRANSACTION-CLASS-TYPE = POP, which should have a negative CURRENT-BOOK-PRINCIPAL.    The A&F will produce warning messages if the length of the field representing the current principal balance in the Source System indicates a possible value of $1 billion or greater (10 digits or more to the left of the decimal) since the field CURRENT-BOOK-PRINCIPAL will truncate values greater than $999,999,999.99.This is definitoin for Current book Principal','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('44','4','1','0','Current Book Yield','F','','','19','8','0','','','N','','','','','','G','0','S','The current book yield will equal the coupon rate in all cases except the following:  
-  the instrument was bought at a premium/discount
-  the instrument was priced at discount
-  when fees are embedded in total return
-  for a Participated-PART SOLD portion, the "POP", of an instrument
Schedules impacted: (for "POP" only) - 
-  Scheduled Repricing 
-  Principal Cashflow
-  Interest Cashflow
-  Repricing Interest Cashflow 
-  Repricing 
-  Amortization
-  Remaining Life
-  Remaining Balance 
This field is used in the calculation of schedules only when an Instrument is a participation (TRANSACTION-CLASS-TYPE = POP).
In the case of participations, COUPON-RATE contains the interest rate for the original loan while CURRENT-BOOK-YIELD contains the stated rate for the Participated portion.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('45','5','1','0','Coupon Rate','F','','','34','8','0','','','N','','','','','','G','0','S','The stated, or contractual, rate of the instrument; not the discount rate, or the yield.  This should always be in the filed.  Beware of things like APR, book yield, rates that fold in special fees, etc. 
DCS Financial Schedules impacted: 
-  Total Book Principal and Weighted Average Rate
-  Scheduled Repricing
-  Principal Cashflow
-  Interest Cashflow
-  Repricing Interest Cashflow
-  Repricing
-  Amortization 
-  Remaining Life 
-  Remaining Balance 
COUPON-RATE is used to calculate Interest Cash Flow for all TRANSACTION-CLASS-TYPEs except for the "POP" type, the ''Part Sold'' of a Participated Instrument.  CURRENT-BOOK-YIELD is the active field for Interest calculation of "POP" records.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('46','6','1','0','Reference Number','X','','','49','20','0','','','N','','','','','','G','0','S','The unique number which identifies the transaction within the  particular application subsystem.  Normally the Account Number is  applicable here. In some systems, however, the Account Number  alone is inadequate to uniquely identify one record from another;  another field may need to be used in conjunction with, or  appended to, the Account Number that Users'' may aggregate by  specific criteria.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('47','7','1','0','Accrual Method','X','','','49','2','0','','','N','','','','','','G','0','S','The interest accrual parameters used in calculating interest cash-flow.  The Accrual Method is represented as a two character code.  The first character represents number of days per month for which interest is accrued; the second character is the annual basis.  Field Values:  
Code  Accrual Days per month  Daily Accrual Rate Divisor
                                                   (Days Per Year) 
A0     Actual (28 to 31)                    360  
A5     Actual (28 to 31)                    360  
00          30                                     360  
05          30                                     365  
AA     Actual (28 to 31)            Actual (365 or 366)  0A          30                              Actual (365 or 366)   Examples:       
The Interest accrual formula (for 1 month''s interest), given an Accrual-Method = A0 will be:  
Rate * Days-This-Month
                ----------------------
                                  360 
Given an Accrual Method = 00 the formula will be:        
Principal *Rate * 30
              ----------------------
                    360 
DCS Financial Schedules impacted are: 
 -  Principal Cashflow Schedule (PLCF) 
 - Interest Cashflow Schedule (PLCI) 
 - Repricing Schedule (PLBR) 
 - Amortization Schedule (PLBA) 
 - Maturity Schedule (PLBM) 
 - Remaining Life Schedule (PLBL)  
 NOTE:  The A&F program will produce an error message for each instrument without a valid Accrual-Method and will use the code ''00'' (30/360) in accrual calculations for that instrument.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('48','8','1','0','Current Maturity Date','B','','','71','8','0','','','N','','','','','','G','0','S','The legal date on which a financial instrument matures.  On an amortizing instrument (e.g. mortgage or automobile loan), this is the date on which the last payment, including any balloon payment, is expected to be paid.  On a non-amortizing Term instrument (e.g. a Certificate of Deposit or a short-term commercial loan), this is the date on which the instrument must be paid off or renewed.  For non-amortizing, non-term instruments (e.g. Demand Loans, Demand Deposits, Savings Accounts), the Current-Maturity-Date does not apply and should be given the value ''9999999''.     Financial Schedules impacted:
-  Scheduled Repricing
-  Principal Cashflow
-  Interest Cashflow
-  Repricing Interest Cashflow
-  Repricing 
-  Amortization
-  Remaining Life
-  Remaining Balance
When it applies, CURRENT-MATURITY-DATE is generally a direct move.  If not, it may be possible to derive the Current-Maturity-Date from some combination of Next-Payment-Date, Payment-Frequency, Payment-Amount and Outstanding-Balance.  In some cases (e.g. revolving lines of credit), the Current-Maturity-Date may be approximated by   In those cases you will have to calculate the date from the payment date and term.
It is possible that an instrument may be open-ended, either by definition (a Demand Note) or in theory (a Passbook Savings account).  When the contractual Maturity Date is not available in the Transaction Source System, the A&F will make some assumptions:
  Zero fill - indicates to the A&F that CURRENT-MATURITY-DATE is equal to the PROCESSING-DATE plus 1 Day.    Nine fill (the default) - indicates to the A&F that the CURRENT-MATURITY-DATE  is equal to the most future date possible in the Program''s horizon:  12/31/2049    When REPRICING-CODE  is ''FM'', the A&F assumes that the NEXT-REPRICING-DATE is the CURRENT-MATURITY-DATE, regardless of the value in the NEXT-REPRICING-DATE field.                                                  
When an Instrument is designated to ''amortize at maturity'' (see AMORTIZATION-CODE), the A&F assumes that the NEXT-PRINCIPAL-PAYMENT-DATE is the CURRENT-MATURITY-DATE, regardless of the PRINCIPAL-PAYMENT-FREQUENCY or NEXT-PRINCIPAL-PAYMENT-DATE mapped to the UTR.
The A&F will not calculate any amortization of Principal after the CURRENT-MATURITY-DATE.  If there is still unamortized Principal at the CURRENT-MATURITY-DATE, that outstanding amount will be treated as a Balloon Payment.
The Amortizaiton (PLBA) Schedule can impact the Remaining Life (PLBL) Schedule when an instrument is amortized to zero before the CURRENT-MATURITY-DATE.  In this case, the A&F will place the CURRENT-BOOK-PRINCIPAL into the Time Interval bucket that coincides with the Date when the CURRENT-BOOK-PRINCIPAL has amortized to zero, regardless of the CURRENT-MATURITY-DATE.  To receive this extra "check" on the true Remaining Life of an instrument, both the Amortization Schedule and the Remaining Life Schedule must be chosen as active Output Schedules for any given run of the A&F against a particular Universal Transaction File.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('49','9','1','0','Repricing Code','X','','','79','2','0','','','N','','','','','','G','0','S','Identifies the type of repricing that is applicable to the loan.  This is used to categorize loans for repricing modeling and  interest rate sensitivity analysis. 
Schedules impacted:  - Scheduled Repricing
                                   - Repricing
                                   -   Repricing Interest Cashflow 
The codes are: 
FM   Fixed to Maturity -- all fixed-rate instruments 
FL   Floating -- changes whenever the driving rate changes or a  specified number of days afterwards. 
PS   Periodic Relative, Single Driver -- changes at various    points which are time increments from the loan date  
PD   Periodic Relative, Dual Driver -- changes at various points  which are time increments from the loan date                                                            
PC   Periodic Calendar -- changes at various calendar points  which are unrelated to the loan date 
IR   Irregular -- non-regular explicit schedule supported by    special trailer records    The values in this field trigger specific assumptions during  Schedule calculation.
 When REPRICING-CODE = `FM'' -- Fixed to Maturity       REPRICING-FREQUENCY is assumed to be `AMAT''; the A&F ignores       any other.       NEXT-REPRICING-DATE is assumed to be       `CURRENT-MATURITY-DATE'', regardless of the date mapped to  the field. 
When REPRICING-CODE = `FL'' -- Floating       REPRICING-FREQUENCY is assumed to be `FLTR''; any other is  ignored.       NEXT-REPRICING-DATE is assumed to be  `PROCESS-DATE-PLUS-1-DAY, regardless of the date mapped to  the field.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('50','10','1','0','Repricing Frequency','X','','','81','4','0','','','N','','','','','','G','0','S','The interval, generally expressed as a number of days or months,  between repricing opportunities on an instrument.    Legal Values include: 
FLTR  Floating  Dnnn  Every nnn Days    Periodic, starting from NEXT-REPRICING -DATE
Mnnn  Every nnn Months  Periodic, starting from NEXT-REPRICING -DATE
AMAT  At Maturity       Reprices at CURRENT-MATURITY-DATE
(The following codes are supported by the system but are not recommended for use in new conversions)
 WKLY  Weekly            Same as D007 
1MON  1st of Month      Same as M001 when NEXT-REPRICING-DAY = 1
15MN  15th of Month     Same as M001 when NEXT-REPRICING-DAY = 15
LMON  Last Day of Month Same as M001 when NEXT-REPRICING-DAY = last day of month
MTLY  Monthly  Same as M001
EVNM  Even Months Same as M002 when NEXT-REPRICING-MONTH is even
ODDM  Odd Months        Same as M002 when NEXT-REPRICING-MONTH  is odd
QTRL  Quarterly      Same as M003
Snnn  Semiannually      Same as M006, repricing on the first of  month nn, nn+6   the month
A0nn  Annually          Same as M012, repricing on the first of   month nn  the month                   
Fixed Rate instruments should be mapped to Reprice "at Maturity",  i.e., `AMAT''. 
This information can be derived often by product-type, i.e., the  source system file contains specific codes to indicate Repricing  Frequency.  If a record has a "TYPE=C", "TCODE=4", "RBYTE=1", signifying a `90-Day CD'' in the Transaction System, then `QTRL''  is an appropriate value for records with those particular  characteristics.
More often, this information will be derived from a manipulation  of activity Dates; often, historical information may be required.  Look for things relating to: Initial Rate-Change-Date, Prior  Rate-Change-Date, Next Rate-Change-Date, etc.  In the case of REPRICING-FREQUENCY, `Mnnn'' is a very handy tool.  This code works well with Adjustable Rate Mortgages, where  Principal commonly reprices every "1 YEAR" (`M012''), "3 YEARS",  (`M036''), or "5 YEARS" (`M060''). 
When REPRICING-CODE = `FM'' -- Fixed to Maturity         REPRICING-FREQUENCY is assumed to be `AMAT''; the A&F ignores  any other.       NEXT-REPRICING-DATE is assumed to be       `CURRENT-MATURITY-DATE'', regardless of the date mapped to  the field. 
When REPRICING-CODE = `FL'' -- Floating       REPRICING-FREQUENCY is assumed to be `FLTR''; any other is  ignored.       NEXT-REPRICING-DATE is assumed to be       `PROCESS-DATE-PLUS-1-DAY, regardless of the date mapped to   the field.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('51','11','1','0','Next Repricing Date','B','','','85','8','0','','','N','','','','','','G','0','S','The next date at which the bank has the option to change the interest rate on the instrument.
 For fixed rate instruments, the logical NEXT-REPRICING-DATE is the maturity date (CURRENT-MATURITY-DATE).  Variable rate instruments might have NEXT-REPRICING-DATE specified in the contract.  In designing the conversion logic for NEXT-REPRICING-DATE, the mapper should not allow the NEXT-REPRICING-DATE be later than the CURRENT-MATURITY-DATE. 
NEXT-REPRICING-DATE is used by the Data Collection System in the creation of the Scheduled-Repricing-Pct, Repricing and Repricing-Interest-Cash-Flow and in the assignment of Funding Rates to matched funded instruments.  If repricing is instrument specific, the date may be in the file, or may have to be calculated from the the last repricing date or the effective date of the loan and the repricing interval.
For purposes of schedule creation and assignment of funding rates, the A&F will treat any instrument with a REPRICING-CODE = FM (fixed to maturity) as if its NEXT-REPRICING-DATE = CURRENT-MATURITY-DATE, regardless of the value in this field.
Likewise, the system will treat any instrument with a REPRICING-CODE = FL (floating) as if its NEXT-REPRICING-DATE = PROCESSING-DATE + 1 day, regardless of the value of this field.
If the assigned NEXT-REPRICING-DATE is greater than the CURRENT-MATURITY-DATE for the instrument, the system will treat the instrument as if its NEXT-REPRICING-DATE = CURRENT-MATURITY-DATE.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('52','12','1','0','Amortization Code','X','','','93','3','0','','','N','','','','','','G','0','S','The AMORTIZATION-CODE represents the principal and interest cash flow characteristics of a given instrument and regulates the calculation of financial cash flow schedules by the Data Colleciton System.  DCS recognizes a number of variations.  All variations use one of six basic cash flow calculation formulas  (P&I, P+I, MAT, INT, PRN, DSC).     The AMORTIZATION-CODE is used by the Data Collection System (DCS) in the creation of most of the financial schedules and in other financial calculations.  The only financial schedules not affected by AMORTIZATION-CODE are the Remaining Life Schedule, The Scheduled Repricing Schedule and the Category Summaries.     The basic AMORTIZATION-CODES are: 
INT   --- CURRENT-BOOK-PRINCIPAL due at maturity, interest flows based on INTEREST-PAYMENT-FREQUENCY. (e.g. a Time Deposit or a Construction Loan)
MAT   --- CURRENT-BOOK-PRINCIPAL and interest due at maturity.  (e.g. Short Term Time Deposits, Short Term Commercial Loans) 
 PRN --- Amortizes over time.  PAYMENT-AMOUNT contains only principal, no interest will be accrued regardless of the COUPON-RATE.  (e.g. a Demand Deposit)
 P&I --- Amortizes over time.  PAYMENT-AMOUNT contains both Principal and Interest (e.g. level payment installment loan, mortgage loan).  Interest is calculated and subtracted from  the payment amount using a simple interest algorithm.  The remainder of the payment is subtracted from the outstanding balance.  If the calculated interest due is greater than the payment amount, unpaid interest (negative amortization) will be accumulated and displayed on the DCS Category Summary Report but will not be added to outstanding balance.  
P+I --- Principal and interest are paid over time.  PAYMENT-AMOUNT contains principal only.  Interest due is calculated and added on to the billed amount.   The entire payment-amount is subtracted from the outstanding balance at each payment interval.  
DSC   --- Principal is due at maturity. If applicable, interest may be paid over time or at maturity.  Premium or Discount amount is included in the interest portion due at maturity.  This Amortization-Code applies specifically to securities purchased at a premium or discount.  Principal amortized will be equal to the face-value of the Security net of the Premium or Discount.    The following are variations on the six basic amortization methods.  Each code uses one of the amortization methods outlined above but offers additional information about the character of a given instrument.   PNI   --- Like ''P&I''.  The PAYMENT-AMOUNT contains both principal and interest.  The loan was negotiated such that the payment amount was calculated based on a maturity date farther into the future than the actual maturity date in the file.  A Balloon Payment is expected. 
FIX   --- Like ''P&I''.  The PAYMENT-AMOUNT contains both principal and interst, however it is recognized in advance that Negative Amortization can occur because the payment is fixed even though the transaction has a variable rate.  R78   --- Like ''P&I''.  Rule of 78ths type loan, using the "Sum-of-the-Years''-Digits" calculation (algorithm currently not implemented). 
EXP   --- Like ''P&I''.  Explicit payments schedules which change over time.  The original payment information is contained in the UTR, while the changes are contained in trailer UTR records.  If a payment amount is present, it is assumed the amount contains interest.
REV   --- Revolving Credit Line.  Like ''P+I'' when PAYMENT-AMOUNT > 0; Like ''INT'' when PAYMENT-AMOUNT = 0.  DEM   --- A Demand Instrument.  Like ''P+I'' when PAYMENT-AMOUNT > 0; Like ''INT'' when PAYMENT-AMOUNT = 0.
DIS   --- Discounted Loan.  Like ''PRN''; assumes Interest at inception.
NOTES:  When an instrument is characterized as being due at maturity, the A&F will ignore any PAYMENT-AMOUNT value.  Conversly, when instruments are expected to amortize over time, the PAYMENT-AMOUNT is expected to be greater than zero.  A zero PAYMENT-AMOUNT with an amortizing AMORTIZATION-CODE will cause the A&F to produce an error message and to assume an AMORTIZATION-CODE of MAT or INT.   When both principal and interest are paid over time, DCS uses the principal payment schedule characteristics to calculate both interest and principal cash flows, regardless of the interest payment schedule characteristics specified.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('53','13','1','0','Principal Payment Frequency','X','','','96','4','0','','','N','','','','','','G','0','S','For an amortizing instrument, this field indicates how often  principal payments will be made.   This field is used by the Data Collection System (DCS) to calculate the Principal (and Interest) cash flows for amortizing instruments.  These cash flows are used to build the Principal Cash Flow, Amortization and Repricing Schedules.   PRINCIPAL-PAYMENT-FREQUENCY is also used to build the Interest cash flow and Repricing Interest Cash Flow schedules for amortizing instruments because principal payment characteristics override interest payment characteristics for amortizing loans in DCS processing.  
Legal Values include: 
Dnnn  Every nnn Days    Periodic, starting from NEXT-INTEREST-  PAYMENT-DATE 
Mnnn  Every nnn Months  Periodic, starting from NEXT-INTEREST- PAYMENT-DATE
 AMAT  At Maturity       Single payment on the CURRENT-MATURITY  DATE
EXPL  Explicit          Single payment on the NEXT-INTEREST- AYMENT-DATE  
 (The following codes are supported by the system but are not recommended for use in new conversions) 
 WKLY  Weekly            Same as D007
 1MON  1st of Month      Same as M001 when NEXT-INTEREST-PAYMENT-  DAY = 1
15MN  15th of Month     Same as M001 when NEXT-INTEREST-PAYMENT-  DAY = 15 LMON 
Last Day of Month Same as M001 when NEXT-INTEREST-PAYMENT-  DAY = last day of month
MTLY  Monthly           Same as M001  EVNM  Even Months       Same as M002 when NEXT-INTEREST-PAYMENT-                            MONTH is even ODDM  Odd Months        Same as M002 when NEXT-INTEREST-PAYMENT-                            MONTH is odd QTRL  Quarterly         Same as M003 S0nn  Semiannually      Same as M006, payments on the first of         month nn, nn+6    the month A0nn  Annually          Same as M012, payments on the first of         month nn          the month','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('54','14','1','0','Next Principal Payment Date','B','','','100','8','0','','','N','','','','','','G','0','S','The anticipated next principal payment date.  For amortizing instruments, this is the date on which the next scheduled principal payment is due.  For non-amortizing instruments, this is the date on which the instrument matures and is either paid off or renewed. 
For instruments on which the entire principal is due at maturity, the NEXT-PRINCIPAL-PAYMENT-DATE should be equal to the CURRENT-MATURITY-DATE.
For instruments which do not amortize and which have no set maturity date, the NEXT-PRINCIPAL-PAYMENT-DATE should be 99/99/99.
 For instruments which are past due, the NEXT-PRINCIPAL-PAYMENT-DATE should be the date on which the oldest overdue principal payment was supposed to be paid.
In the creation of financial schedules, DCS will use the NEXT-PRINCIPAL-PAYMENT-DATE in the calculation both principal and interest cash flows for all amortizing instruments (AMORTIZATION-CODE <> MAT, INT, DSC).  
NEXT-REPRICING-DATE','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('55','15','1','0','Payment Amount','F','','','108','8','0','','','N','','','','','','G','0','S','The regular or next payment amount related to the next term of  payment.   It may be composed of principal only or both principal  and interest.  A PAYMENT-AMOUNT of Interest Only is currently not  interpreted by the A&F.  It should be in the file.    Schedules impacted:
 - Principal Cash-flow 
 - Repricing 
 - Amortization 
 - Remaining Balance 
When an instrument has been defined as amortizing over time, DCS requires that this field will have a value greater than $0.00.  When the AMORTIZATION-CODE indicates an amortizing instrument and the PAYMENT-AMOUNT is zero, DCS will produce an error message, treat the instrument as if it were not an amortizer and base interest cash flow calculations on the instrument''s interest payment frequency and date.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('56','16','1','0','Interest Payment Code','X','','','123','15','4','','','N','','','','','','G','0','S','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('57','17','1','0','Interest Compound Frequency','B','','','126','4','0','','','N','','','','','','G','0','S','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('58','18','1','0','Interest Payment Frequency','X','','','130','4','0','','','N','','','','','','G','0','S','The interval between interest payments on the instrument.    This field is used by the Data Collection System (DCS) to calculate the Interest cash flows for non-amortizing instruments.  For amortizing instruments, DCS overrides ININTEREST-PAYMENT-FREQUENCY with PRINCIPAL-PAYMENT-FREQUENCY.  The interest cash flows are used to build the Interest Cash Flow and Repricing Interest Cash Flow schedules.   Legal Values include: 
Dnnn  Every nnn Days      Periodic, starting from NEXT-INTERE- PAYMENT-DATE
Mnnn  Every nnn Months  Periodic, starting from NEXT-INTERE- PAYMENT-DATE
AMAT  At Maturity             ngle payment on the CURRENT-MATURITY DATE
EXPL            Explicit          Single payment on the NEXT-INTERE- PAYMENT-DATE 
(The following codes are supported by the system but are not recommended for use in new conversions)
WKLY  Weekly            Same as D007
1MON  1st of Month     Same as M001 when NEXT-INTERE-PAYMENT-                 
DAY = 1 15MN  15th of Month     Same as M001 when NEXT-INTERE-PAYMENT-  DAY = 15
LMON  Last Day of Month Same as M001 when NEXT-INTERE-PAYMENT-                            DAY = last day of month 
MTLY  Monthly           Same as M001
EVNM  Even Months       Same as M002 when NEXT-INTERE-PAYMENT- MONTH is even
ODDM  Odd Months        Same as M002 when NEXT-INTERE-PAYMENT- MONTH is odd
QTRL  Quarterly         Same as M003
Snnn  miannually        Same as M006, payments on the first of  month nn, nn+6    the month
A0nn  Annually          Same as M012, payments on the first of  month nn  the month','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('59','19','1','0','Next Interest Payment Date','B','','','134','8','0','','','N','','','','','','G','0','S','The anticipated next interest payment date.  This is the date on which any interest accrued (since the last interest payment) will be paid, or, in the case of some types of deposits, added back into the total balance for the instrument, 
For instruments on which the interest and principal are paid in a single payment (level payment or add on loans), the NEXT-INTEREST-PAYMENT-DATE will be equal to the NEXT-PRINCIPAL-PAYMENT-DATE. 
In the creation of financial schedules, DCS will only use the NEXT-INTEREST-PAYMENT-DATE in the calculation of interest cash flows for non-amortizing instruments which may pay interest over time. (AMORTIZATION-CODE = INT, DSC). 
For those instruments which do not pay interest, the NEXT-INTEREST-PAYMENT-DATE should be 99/99/99. 
For those instruments which pay interest at maturity, the NEXT-INREREST-PAYMENT-DATE should be the same as the CURRENT-MATURITY-DATE.
When a loan is past due, the NEXT-INTEREST-PAYMENT-DATE may be in the past.  In that case, it would be the date on which the oldest overdue payment should have been paid.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('60','20','1','0','Original Trans Purch Date','B','','','142','8','0','','','N','','','','','','G','0','S','The original effective date of the instrument.  If the bank purchases an instrument sometime during its life, the original issue date of the loan rather than the purchase date should be recorded here.
ORIG-TRANS-PURCH-DATE is used by DCS in the calculation of interest cash flows for non-amortizing instruments which pay interest at maturity (AMORTIZATION-CODE = MAT or the combination of AMORTIZATION-CODE = INT or DSC and INTEREST-PAYMENT-FREQUENCY = AMAT) 
For those instruments, the accrual term is calculated as the interval between ORIG-TRANS-PURCH-DATE and CURRENT-MATURITY-DATE.
If ORIG-TRANS-PURCH-DATE is defaulted (contains zeros) or contains an invalid date, DCS will substitute the PROCESSING-DATE in its schedule calculations.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('61','21','1','0','Original Book Value','F','','','150','8','0','','','N','','','','','','G','0','S','The original amount of principal paid or received for an instrument.  For loans this is the original proceeds amount, for deposits, the original deposited amount and for securities, the purchase price.  For credit cards, lines of credit, demand deposits, non-term savings accounts and other instruments on which the principal balance fluctuates, ORIGINAL-BOOK-VALUE will not be relevant and may be mapped as zero. 
The ORIGINAL-BOOK-VALUE is used by DCS in the calculation of interest cash flows for those non-amortizing instruments on which interest is due at maturity (AMORTIZATION-CODE = MAT, sometimes DSC) and for discount securities (AMORTIZATION-CODE = DSC).
For non-amortizing instruments where interest is due at maturity, the interest due is calculated based on ORIGINAL-BOOK-VALUE, rather than the more usual CURRENT-BOOK-PRINCIPAL.
In the case of discount securities, interest cash-flow is calculated based on the face value of the instrument (ORIGINAL-BOOK-VALUE minus the `signed'' (+/-) value in PREM-DISC-AT-TRANS-PURCH).','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('62','22','1','0','Prem Disc At Trans Purch','F','','','165','8','0','','','N','','','','','','G','0','S','This field is used for investment system instruments and certain loans which were bought at a premuim or discount.  This field contains that premium (positive number) or discount (negative number).','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('63','23','1','0','Prepay Percent Per Month','F','','','180','8','0','','','N','','','','','','G','0','S','For an instrument on which the payments have been accelerated, by aggreement between the customer and the bank, this is the rate at which the instrument is being prepaid.  This field applies only to loans and is rarely available on source application files.
In the DCS financial schedules, this field may be used with the prepayment option to accellerate the amortization of the instrument.  If this field is not zero, DCS will accelerate payments on the loan using this rate and the CPR prepayment calculation method. 
PSA tables can be used to fill the value of this field by selecting the correct CPR from the tables based on the current interest rate environment and the current interest rate of the instrument.
Note:  No ramp up (based on the age of the instrument) is used when calculating CPR prepayment as is sometimes assumed when using PSA tables.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('64','24','1','0','Lowest Lifetime Rate','F','','','195','8','0','','','N','','','','','','G','0','S','The minimum rate to which a variable loan can fall over its life.  This "floor" rate is normally set at the time the instrument is negotiated and, if applicable, should therefore be in the file.  Often, documentation indicates that an instrument has a variable, floating, or adjustable interest rate that is unknown at this time (i.e. Prime Rate) or unavailable (held only on the Note Agreement itself).  Unless a particular type of business is regulated on this issue, the ''default'' of "0.0000%" is the best assumption when an actual LOWEST-LIFETIME-RATE is unknown. 
For fixed instruments, the value in the UTR field COUPON-RATE should be mapped to this field.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('65','25','1','0','Highest Lifetime Rate','F','','','210','8','0','','','N','','','','','','G','0','S','The ceiling rate.  The maximum to which a variable rate instrument''s interest rate can rise to over its (the instrument''s) life.
The HIGHEST-LIFETIME-RATE should not be confused with the MAXIMUM-RATE-CHANGE (also known as the cap) which is the largest change allowed in the interest rate at any given repricing opportunity.
The ceiling rate is normally set at the time the instrument is negotiated, and when applicable, should be in the file.  For common types of instruments, such as mortgage or installment loans and certificates of deposit, the hightest lifetime rate may be assigned at the product level or may be hard-coded in the application system processing logic.
For fixed rate instruments, the HIGHEST-LIFETIME-RATE should be mapped as equal to the COUPON-RATE.
For variable rates instruments for which no interest rate ceiling exists, the HIGHEST-LIFETIME-RATE should be 99.9999.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('66','26','1','0','Maximum Rate Change','F','','','225','8','0','','','N','','','','','','G','0','S','The maximum change in the stated interest rate at any  one repricing point.  For variable loans this may be in the file; for fixed loans, map ''0.00000''. 
If this information cannot be specifically derived from a Transaction  ource  ystem field, the best solution is to subtract the LOWE T-LIFETIME-RATE from the HIGHE T-LIFETIME-RATE.  (Notice that this field''s ''default'' is the result of subtrcting the default of the LOWE T-LIFETIME-RATE from the ''default'' of the HIGHE T-LIFETIME-RATE.)','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('67','27','1','0','Repricing Spread Value','F','','','240','8','0','','','N','','','','','','G','0','S','The spread, expressed either as a percentage or in basis points, between the driving rate and the interest rate on the instrument.
When the REPRICING-SPREAD-TYPE is ''+'' or ''-'' the REPRICING-SPREAD-VALUE will be expressed in basis points (e.g. Prime + 200 basis points).  When the REPRICING-SPREAD-TYPE is ''*'' the REPRICING-SPREAD-VALUE will be expressed as a percentage (e.g. 110% of Prime).','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('68','28','1','0','Last Repricing Date','B','','','255','8','0','','','N','','','','','','G','0','S','The last date at which the bank had the option to change the interest rate on the instrument.
For fixed rate instruments, the logical LAST-REPRICI G-DATE is the issue date (ORIGI AL-TRA S-PURCH-DATE).  Variable rate instruments might have LAST-REPRICI G-DATE specified in the contract.  In designing the conversion logic for LAST-REPRICI G-DATE, the mapper should not allow the LAST-REPRICI G-DATE to be earlier than the ORIGI AL-TRA S-PURCH-DATE. 
LAST-REPRICI G-DATE is used by the Data Collection System in the assignment of Funding Rates.
If repricing is instrument specific, the date may be in the file, or you may have to calculate the LAST-REPRICI G-DATE from the the next repricing date or the effective date of the loan and the repricing interval.
For purposes of schedule creation and assignment of funding rates, the A&F will treat any instrument with a REPRICI G-CODE = FM (fixed to maturity) as if its LAST-REPRICI G-DATE = ORIGI AL-TRA S-PURCH-DATE, regardless of the value in this field. 
Likewise, the system will treat any instrument with a REPRICI G-CODE = FL (floating) as if its LAST-REPRICI G-DATE = PROCESSI G-DATE, regardless of the value of this field.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('69','29','1','0','Amortization Date','B','','','263','8','0','','','N','','','','','','G','0','S','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('70','30','1','0','Funding Rate','F','','','271','8','0','','','N','','','','','','G','0','S','The Funding Funds Transfer Pricing Rate for the instrument.  Also known as the Transer Rate, the Funding Rate and the Cost-of-Funds Rate.  This is the interest rate paid by the Bank to obtain the funds needed to back an asset.
In some cases, the Funding Funds Transfer Pricing rate will be available in the source system file.  In other cases, the DCS Funding Funds Transfer Pricing Module (Funding Module) will be used to derive the appropriate rate from a historical table of funding rates.  See the definition for FUNDING-INDEX for more information on the Funding Module and the assignment of funding rates. 
When funding based on the original loan characteristics is desired, the original balance substitutes for the current balance, the first payment substitutes for the next principal payment date.  ORIGINAL-BOOK-VALUE can be used for the original balance for fixed rate instruments, however the balance as it existed when the instrument last repriced is seldom stored on the account record.  This value can be simulated by using the DCS function called ORIGINAL-BALANCE. This is calculated based on the current calance, current interest rate, payment amount and the last repricing date.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('71','31','1','0','Funding Index','B','','','286','4','0','','','N','','','','','','G','0','S','The Funding Rate Index to which the instrument is tied.  This code is used by the Data Collection System to access the Funding Funds Transfer Pricing Table which in turn is used to assign an accurate funding rate. 
There are two basic types of Funding: Matched Funding and Indexed Funding. 
For those instruments which are Index Funded, the system will assign the funding rate in effect for the instrument''s FUNDING-INDEX as of the LAST-REPRICING-DATE.
For Matched Funded instruments, the system will create a Repricing Schedule, breaking down the instrument into its individual cash flows.  Rates will be assigned to each individual cash flow based on the LAST-REPRICING-DATE and its repricing or payment due date.  A weighted average funding rate will then be calculated based on the assigned funding rates for the individual cash flows.
In general, the values of FUNDING-INDEX are determined by the Bank and centrally maintained in the Funding Funds Transfer Pricing Table.  There are a few conventions which must be maintained: 
FUNDING-INDEX = 1 through 10 and 99 are reserved system standard indices.  Their meanings and uses are pre-set and cannot be changed.
FUNDING-INDEX = 3 indicates an instrument which was funded prior to the current run of DCS and will not be funded.
FUNDING-INDEX = 99 indicates an instrument which may not be funded.  Any instrument with FUNDING-INDEX = 99 will be assigned a the funding rate from the finding table which may be zero.  The difference here is that no error message will be produced for a funding rate of zero.
For FUNDING-INDEX = 11 to 999, the system PROCESSING-DATE is used instead of LAST-REPRICING-DATE to find the appropriate funding rate from the Table.   For FUNDING-INDEX between 1000 and 1999, the LAST-REPRICING-DATE will be used to assign the appropriate funding rate from the Table.
FUNDING-INDEX 1, 2, 4, 5, 8 and 9 are reserved Matched Funding Indices. These indices will cause the system to assign the funding rate based on the funding yield curve.  FUNDING-INDEX = 1 (Match Fund cash flows) will cause the system to create a repricing/amortization schedule for the instrument, look up matched funding rates for each cash flow based on its repricing term and calculate a weighted average matched funding rate for the instrument as a whole.  The weighting factor is the amortizing balance for each cash flow.
FUNDING-INDEX = 5 is calculated the same as cach flow method 1 however the weight factor is the amortizing balance for each cash flow times the number of months this cash flow will be on the books.
FUNDING-INDEX = 8 or 9 is exactly the save as FUNDING-INDEX 5 and 1 respectively except that it tells DCS to expect payment trailer records. 
FUNDING-INDEX = 2 (Match Fund - ignore cash flows) will assign a single matched funding rate to the instrument as a whole based on the LAST-REPRICING-DATE and the NEXT-REPRICING-DATE (but not taking cash flows into account) 
FUNDING-INDEX = 4 is calculated the same as FUNDING-INDEX 2 except that the NEXT-REPRICING-DATE is replaced by the Duration Date calculated using the standard Duration formula.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('72','32','1','0','Average Balance','F','','','290','8','0','','','N','','','','','','G','0','S',' The average outstanding principal balance for the instrument for the current month.
Some subsystems have an accumulated balance field which contains  an accumulater which is updated each day the instrument was on the   books by adding the balance as it existed on that day.  By  dividing this number by the number of days in the month will give  the average balance.
Otherwise the average balance must be calculated as follows:
For non-amortizing instruments not originated or maturing in the current month, AVERAGE-BALANCE will be equal to CURRENT-BOOK- PRINCIPAL.  For instruments originated or maturing this month, the average balance is calculated by multiplying  CURRENT-BOOK-PRINCIPAL by the number of days on the books this month divided by the total number of days in this month. 
Amortizing instruments may use a special DCS function which given the current balance, the payment amount, the interest rate, the
last payment date, and the transaction status code, the average  balance can be simulated by assuming that a single regular payment was made.  The assumption is made that the current balance at the  end of month was the same for each day after the last payment date, and by adding the amortizing principal amount of the last  regular payment to the current balance, the balance as it existed  prior to the last payment can be simulated.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('73','34','1','0','Repricing Drive Rate','X','','','308','3','0','','','N','','','','','','G','0','S','This is the driving rate the instrument uses whenever it reprices.This field is not used while amortizing the instrument, however  instruments are very often grouped based on their driving rate.','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('74','35','1','0','Interest Income','F','','','311','8','0','','','N','','','','','','G','0','S','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('75','1','5','0','UTFREAD-HEADER-REC','X','L','','1','20','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('76','2','5','0','R-UTR-COMPATIBILITY-FLAG','X','L','','1','6','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('77','3','5','0','R-UTR-PROCESSING-DATE','D','L','','7','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('78','4','5','0','FILLER','X','L','','15','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('79','5','5','0','R-UTR-VERSION-NUMBER','X','L','','18','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('80','1','6','0','GL-CLASS-TYPE','X','L','','1','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('81','2','6','0','GL-ACCOUNT-TYPE','X','L','','4','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('82','3','6','0','GL-SNAPSHOT-BALANCE','F','L','','7','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('83','4','6','0','GL-AVERAGE-BALANCE','F','L','','15','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('84','5','6','0','GL-INCOME-EXPENSE','F','L','','23','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('85','6','6','0','GL-STATUS-CODE','X','L','','31','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('86','7','6','0','GL-ACCOUNT-NUMBER','X','L','','34','30','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('87','8','6','0','GL-ACCRUAL-METHOD','X','L','','64','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('88','9','6','0','GL-RATE','F','L','','66','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('89','10','6','0','GL-FUNDING-RATE','F','L','','74','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('90','11','6','0','GL-FUNDING-INDEX','B','L','','82','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('91','12','6','0','GL-CORP-NUMBER','X','L','','84','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('92','13','6','0','GL-ACCT-NUMBER','X','L','','87','10','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('93','14','6','0','GL-PRIMARY-ACCT-NUM','N','L','','97','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('94','15','6','0','GL-CENTER','X','L','','100','10','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('95','16','6','0','GL-BRANCH-CC','X','L','','110','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('96','17','6','0','GL-ACCOUNT-DESC','X','L','','113','30','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('97','18','6','0','GL-CURRENCY','X','L','','143','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('98','19','6','0','GL-CODE','X','L','','146','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('99','1','7','0','UTR-HASH-TOTAL-RECORD','X','L','','1','351','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('100','2','7','0','H-CLASS-TYPE','X','L','','1','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('101','3','7','0','H-NUM-RECS','N','L','','4','8','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('102','4','7','0','G-SUBSYSTEM','X','L','','12','170','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('103','5','7','0','H-EOM-BAL-ASSETS','S','L','','12','17','2','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('104','6','7','0','H-AVG-BAL-ASSETS','S','L','','29','17','2','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('105','7','7','0','H-IE-ASSETS','S','L','','46','17','2','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('106','8','7','0','H-NIIE-ASSETS','S','L','','63','17','2','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('107','9','7','0','H-MEMO-ASSETS','S','L','','80','17','2','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('108','10','7','0','H-EOM-BAL-LIABS','S','L','','97','17','2','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('109','11','7','0','H-AVG-BAL-LIABS','S','L','','114','17','2','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('110','12','7','0','H-IE-LIABS','S','L','','131','17','2','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('111','13','7','0','H-NIIE-LIABS','S','L','','148','17','2','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('112','14','7','0','H-MEMO-LIABS','S','L','','165','17','2','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('113','15','7','0','T-SUBSYSTEM','X','L','','182','170','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('114','16','7','0','H-PRINCIPAL','S','L','','182','14','2','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('115','17','7','0','H-RATE','S','L','','196','6','4','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('116','18','7','0','FILLER','X','L','','202','150','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('117','1','8','0','UTR43','X','L','','1','563','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('118','2','8','0','STANDARD-FIELDS','X','L','','1','563','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('119','3','8','0','TRANSACTION-CLASS-TYPE','X','L','','1','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('120','4','8','0','CURRENT-BOOK-PRINCIPAL','F','L','','4','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('121','5','8','0','CURRENT-BOOK-YIELD','F','L','','12','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('122','6','8','0','COUPON-RATE','F','L','','20','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('123','7','8','0','ACCOUNT-REFERENCE-NUM','X','L','','28','20','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('124','8','8','0','ACCRUAL-METHOD','X','L','','48','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('125','9','8','0','CURRENT-MATURITY-DATE','C','L','','50','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('126','10','8','0','REPRICING-CODE','X','L','','54','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('127','11','8','0','REPRICING-FREQUENCY','X','L','','56','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('128','12','8','0','NEXT-REPRICING-DATE','C','L','','60','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('129','13','8','0','AMORTIZATION-CODE','X','L','','64','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('130','14','8','0','PRINCIPAL-PAYMENT-FREQUENCY','X','L','','67','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('131','15','8','0','NEXT-PRINCIPAL-PAYMENT-DATE','C','L','','71','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('132','16','8','0','PAYMENT-AMOUNT','F','L','','75','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('133','17','8','0','INTEREST-PAYMENT-CODE','X','L','','83','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('134','18','8','0','INTEREST-COMPOUND-FREQUENCY','B','L','','86','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('135','19','8','0','INTEREST-PAYMENT-FREQUENCY','X','L','','88','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('136','20','8','0','NEXT-INTEREST-PAYMENT-DATE','C','L','','92','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('137','21','8','0','ORIGINAL-TRANS-PURCH-DATE','C','L','','96','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('138','22','8','0','ORIGINAL-BOOK-VALUE','F','L','','100','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('139','23','8','0','PREM-DISC-AT-TRANS-PURCH','F','L','','108','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('140','24','8','0','PREPAY-PERCENT-PER-MONTH','F','L','','116','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('141','25','8','0','LOWEST-LIFETIME-RATE','F','L','','124','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('142','26','8','0','HIGHEST-LIFETIME-RATE','F','L','','132','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('143','27','8','0','MAXIMUM-RATE-CHANGE','F','L','','140','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('144','28','8','0','REPRICING-SPREAD-VALUE','F','L','','148','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('145','29','8','0','LAST-REPRICING-DATE','C','L','','156','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('146','30','8','0','AMORTIZATION-DATE','C','L','','160','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('147','31','8','0','FUNDING-RATE','F','L','','164','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('148','32','8','0','FUNDING-INDEX','B','L','','172','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('149','33','8','0','AVERAGE-BALANCE','F','L','','174','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('150','34','8','0','PROCESSING-DATE','C','L','','182','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('151','35','8','0','GL-ACCOUNT-NUMBER','X','L','','186','10','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('152','36','8','0','TRANSACTION-STATUS-CODE','X','L','','196','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('153','37','8','0','SUBSYSID','X','L','','199','6','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('154','38','8','0','ACCRUED-NEG-AMORT-AMT','F','L','','205','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('155','39','8','0','ACCT-NUM','X','L','','213','20','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('156','40','8','0','ALC-FLAG','X','L','','233','1','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('157','41','8','0','AMT-OVERDUE-30','F','L','','234','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('158','42','8','0','AMT-OVERDUE-60','F','L','','242','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('159','43','8','0','AMT-OVERDUE-90','F','L','','250','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('160','44','8','0','AMT-OVERDUE-GT-90','F','L','','258','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('161','45','8','0','BALLOON-PMT-AMT','F','L','','266','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('162','46','8','0','BANK-NUM','X','L','','274','10','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('163','47','8','0','BRANCH-NUM','X','L','','284','10','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('164','48','8','0','CHARGE-OFFS','B','L','','294','10','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('165','49','8','0','CMT-AVAILABLE','F','L','','299','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('166','50','8','0','COLLATERAL-VALUE','F','L','','307','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('167','51','8','0','COLLATERAL-CODE','X','L','','315','5','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('168','52','8','0','COLLATERAL-VALUE-DATE','C','L','','320','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('169','53','8','0','CONSTRUCTION-CODE','X','L','','324','5','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('170','54','8','0','COST','F','L','','329','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('171','55','8','0','CREDIT-RISK-RATING-CODE','X','L','','337','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('172','56','8','0','CUR-MARKET-VALUE','F','L','','340','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('173','57','8','0','CURRENCY','X','L','','348','20','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('174','58','8','0','CUSTOMER-NUM','X','L','','368','20','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('175','59','8','0','DISCOUNT-RATE','F','L','','388','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('176','60','8','0','DURATION','B','L','','396','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('177','61','8','0','FEES-ACCUMULATED','F','L','','398','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('178','62','8','0','GL-CODE','X','L','','406','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('179','63','8','0','GL-I-E-ACCOUNT-NUMBER','X','L','','410','10','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('180','64','8','0','INCOME-EXPENSE','F','L','','420','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('181','65','8','0','INSURANCE-CODE','X','L','','428','1','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('182','66','8','0','INT-RATE-RISK-CATEGORY','X','L','','429','1','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('183','67','8','0','INT-PURCHASED','F','L','','430','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('184','68','8','0','INT-RECEIVABLE','F','L','','438','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('185','69','8','0','LAST-REVIEW-DATE','C','L','','446','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('186','70','8','0','MONTHS-TO-ORIGIN','B','L','','450','10','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('187','71','8','0','NON-ACCRUAL','X','L','','455','1','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('188','72','8','0','OFFICER-ORIGINATOR-NUM','X','L','','456','10','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('189','73','8','0','OFFICER-SERVICER-NUM','X','L','','466','10','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('190','74','8','0','ORIG-DATE','C','L','','476','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('191','75','8','0','ORIG-TERM','B','L','','480','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('192','76','8','0','PAST-DUE-IN-DAYS','B','L','','482','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('193','77','8','0','PRESENT-VALUE','F','L','','484','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('194','78','8','0','PROCESS-THRU-DATE','C','L','','492','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('195','79','8','0','PRODUCT-CODE','X','L','','496','6','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('196','80','8','0','RECOVERIES','B','L','','502','10','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('197','81','8','0','REMAINING-TERM','B','L','','507','6','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('198','82','8','0','REMAINING-TERM-IN-DAYS','B','L','','510','6','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('199','83','8','0','RENEWAL-FLAG','X','L','','513','1','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('200','84','8','0','REPRICING-DRIVE-RATE','X','L','','514','6','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('201','85','8','0','RESP-CNTR-NUM','X','L','','520','10','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('202','86','8','0','RESTRUCTURED-DATE','C','L','','530','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('203','87','8','0','RESTRUCTURED-INDICATOR','X','L','','534','1','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('204','88','8','0','RISK-BASED-CAPITAL-CODE','X','L','','535','10','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('205','89','8','0','SIC-CODE','X','L','','545','10','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('206','90','8','0','SPLIT-GRADE-NUMBER','X','L','','555','1','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('207','91','8','0','SPLIT-GRADE-PERCENT','F','L','','556','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('208','1','9','0','SUBSYSTEM-ID','X','L','','1','6','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('209','2','9','0','HDR-PROCESSING-DATE','D','L','','7','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('210','3','9','0','FILLER','X','L','','15','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('211','4','9','0','VERSION-NUMBER','X','L','','18','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('212','1','10','0','UTR43','X','L','','1','195','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('213','2','10','0','TRANSACTION-CLASS-TYPE','X','L','','1','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('214','3','10','0','CURRENT-BOOK-PRINCIPAL','F','L','','4','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('215','4','10','0','CURRENT-BOOK-YIELD','F','L','','12','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('216','5','10','0','COUPON-RATE','F','L','','20','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('217','6','10','0','REFERENCE-NUMBER','X','L','','28','20','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('218','7','10','0','ACCRUAL-METHOD','X','L','','48','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('219','8','10','0','CURRENT-MATURITY-DATE','C','L','','50','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('220','9','10','0','REPRICING-CODE','X','L','','54','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('221','10','10','0','REPRICING-FREQUENCY','X','L','','56','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('222','11','10','0','NEXT-REPRICING-DATE','C','L','','60','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('223','12','10','0','AMORTIZATION-CODE','X','L','','64','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('224','13','10','0','PRINCIPAL-PAYMENT-FREQUENCY','X','L','','67','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('225','14','10','0','NEXT-PRINCIPAL-PAYMENT-DATE','C','L','','71','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('226','15','10','0','PAYMENT-AMOUNT','F','L','','75','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('227','16','10','0','INTEREST-PAYMENT-CODE','X','L','','83','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('228','17','10','0','INTEREST-COMPOUND-FREQUENCY','B','L','','86','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('229','18','10','0','INTEREST-PAYMENT-FREQUENCY','X','L','','88','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('230','19','10','0','NEXT-INTEREST-PAYMENT-DATE','C','L','','92','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('231','20','10','0','ORIGINAL-TRANS-PURCH-DATE','C','L','','96','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('232','21','10','0','ORIGINAL-BOOK-VALUE','F','L','','100','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('233','22','10','0','PREM-DISC-AT-TRANS-PURCH','F','L','','108','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('234','23','10','0','PREPAY-PERCENT-PER-MONTH','F','L','','116','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('235','24','10','0','LOWEST-LIFETIME-RATE','F','L','','124','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('236','25','10','0','HIGHEST-LIFETIME-RATE','F','L','','132','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('237','26','10','0','MAXIMUM-RATE-CHANGE','F','L','','140','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('238','27','10','0','REPRICING-SPREAD-VALUE','F','L','','148','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('239','28','10','0','LAST-REPRICING-DATE','C','L','','156','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('240','29','10','0','AMORTIZATION-DATE','C','L','','160','8','0','2','N','N','N','N','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('241','30','10','0','FUNDING-RATE','F','L','','164','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('242','31','10','0','FUNDING-INDEX','B','L','','172','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('243','32','10','0','AVERAGE-BALANCE','F','L','','174','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('244','33','10','0','TRANSACTION-STATUS-CODE','X','L','','182','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('245','34','10','0','REPRICING-DRIVE-RATE','X','L','','185','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('246','35','10','0','INTEREST-INCOME','F','L','','188','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('247','1','11','0','END-OF-FILE-RECORD','X','L','','1','31','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('248','2','11','0','END-OF-FILE-CODE','X','L','','1','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('249','3','11','0','TOTAL-RECORD-COUNT','N','L','','4','8','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('250','4','11','0','TOTAL-PRINCIPAL','S','L','','12','14','2','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('251','5','11','0','WAVG-COUPON-RATE','S','L','','26','6','4','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('252','1','12','0','TRAILER-RECS(1)','X','L','','1','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('253','2','12','0','T-TRANSACTION-CLASS-TYPE(1)','X','L','','1','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('254','3','12','0','T-ACCRUAL-METHOD(1)','X','L','','4','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('255','4','12','0','T-CURRENT-BOOK-YIELD(1)','F','L','','6','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('256','5','12','0','T-COUPON-RATE(1)','F','L','','14','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('257','6','12','0','T-AMORTIZATION-CODE(1)','X','L','','22','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('258','7','12','0','T-PRINCIPAL-PAYMENT-FREQ(1)','X','L','','25','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('259','8','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(1)','C','L','','29','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('260','9','12','0','T-PAYMENT-AMOUNT(1)','F','L','','33','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('261','10','12','0','T-INTEREST-PAYMENT-CODE(1)','X','L','','41','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('262','11','12','0','T-INTEREST-COMPOUND-FREQ(1)','B','L','','44','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('263','12','12','0','T-INTEREST-PAYMENT-FREQ(1)','X','L','','46','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('264','13','12','0','T-NEXT-INTEREST-PAYMNT-DT(1)','C','L','','50','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('265','14','12','0','T-PAY-SCHEDULE-START-DT(1)','C','L','','54','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('266','15','12','0','TRAILER-RECS(2)','X','L','','58','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('267','16','12','0','T-TRANSACTION-CLASS-TYPE(2)','X','L','','58','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('268','17','12','0','T-ACCRUAL-METHOD(2)','X','L','','61','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('269','18','12','0','T-CURRENT-BOOK-YIELD(2)','F','L','','63','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('270','19','12','0','T-COUPON-RATE(2)','F','L','','71','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('271','20','12','0','T-AMORTIZATION-CODE(2)','X','L','','79','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('272','21','12','0','T-PRINCIPAL-PAYMENT-FREQ(2)','X','L','','82','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('273','22','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(2)','C','L','','86','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('274','23','12','0','T-PAYMENT-AMOUNT(2)','F','L','','90','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('275','24','12','0','T-INTEREST-PAYMENT-CODE(2)','X','L','','98','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('276','25','12','0','T-INTEREST-COMPOUND-FREQ(2)','B','L','','101','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('277','26','12','0','T-INTEREST-PAYMENT-FREQ(2)','X','L','','103','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('278','27','12','0','T-NEXT-INTEREST-PAYMNT-DT(2)','C','L','','107','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('279','28','12','0','T-PAY-SCHEDULE-START-DT(2)','C','L','','111','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('280','29','12','0','TRAILER-RECS(3)','X','L','','115','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('281','30','12','0','T-TRANSACTION-CLASS-TYPE(3)','X','L','','115','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('282','31','12','0','T-ACCRUAL-METHOD(3)','X','L','','118','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('283','32','12','0','T-CURRENT-BOOK-YIELD(3)','F','L','','120','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('284','33','12','0','T-COUPON-RATE(3)','F','L','','128','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('285','34','12','0','T-AMORTIZATION-CODE(3)','X','L','','136','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('286','35','12','0','T-PRINCIPAL-PAYMENT-FREQ(3)','X','L','','139','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('287','36','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(3)','C','L','','143','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('288','37','12','0','T-PAYMENT-AMOUNT(3)','F','L','','147','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('289','38','12','0','T-INTEREST-PAYMENT-CODE(3)','X','L','','155','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('290','39','12','0','T-INTEREST-COMPOUND-FREQ(3)','B','L','','158','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('291','40','12','0','T-INTEREST-PAYMENT-FREQ(3)','X','L','','160','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('292','41','12','0','T-NEXT-INTEREST-PAYMNT-DT(3)','C','L','','164','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('293','42','12','0','T-PAY-SCHEDULE-START-DT(3)','C','L','','168','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('294','43','12','0','TRAILER-RECS(4)','X','L','','172','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('295','44','12','0','T-TRANSACTION-CLASS-TYPE(4)','X','L','','172','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('296','45','12','0','T-ACCRUAL-METHOD(4)','X','L','','175','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('297','46','12','0','T-CURRENT-BOOK-YIELD(4)','F','L','','177','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('298','47','12','0','T-COUPON-RATE(4)','F','L','','185','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('299','48','12','0','T-AMORTIZATION-CODE(4)','X','L','','193','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('300','49','12','0','T-PRINCIPAL-PAYMENT-FREQ(4)','X','L','','196','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('301','50','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(4)','C','L','','200','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('302','51','12','0','T-PAYMENT-AMOUNT(4)','F','L','','204','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('303','52','12','0','T-INTEREST-PAYMENT-CODE(4)','X','L','','212','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('304','53','12','0','T-INTEREST-COMPOUND-FREQ(4)','B','L','','215','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('305','54','12','0','T-INTEREST-PAYMENT-FREQ(4)','X','L','','217','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('306','55','12','0','T-NEXT-INTEREST-PAYMNT-DT(4)','C','L','','221','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('307','56','12','0','T-PAY-SCHEDULE-START-DT(4)','C','L','','225','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('308','57','12','0','TRAILER-RECS(5)','X','L','','229','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('309','58','12','0','T-TRANSACTION-CLASS-TYPE(5)','X','L','','229','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('310','59','12','0','T-ACCRUAL-METHOD(5)','X','L','','232','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('311','60','12','0','T-CURRENT-BOOK-YIELD(5)','F','L','','234','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('312','61','12','0','T-COUPON-RATE(5)','F','L','','242','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('313','62','12','0','T-AMORTIZATION-CODE(5)','X','L','','250','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('314','63','12','0','T-PRINCIPAL-PAYMENT-FREQ(5)','X','L','','253','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('315','64','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(5)','C','L','','257','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('316','65','12','0','T-PAYMENT-AMOUNT(5)','F','L','','261','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('317','66','12','0','T-INTEREST-PAYMENT-CODE(5)','X','L','','269','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('318','67','12','0','T-INTEREST-COMPOUND-FREQ(5)','B','L','','272','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('319','68','12','0','T-INTEREST-PAYMENT-FREQ(5)','X','L','','274','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('320','69','12','0','T-NEXT-INTEREST-PAYMNT-DT(5)','C','L','','278','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('321','70','12','0','T-PAY-SCHEDULE-START-DT(5)','C','L','','282','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('322','71','12','0','TRAILER-RECS(6)','X','L','','286','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('323','72','12','0','T-TRANSACTION-CLASS-TYPE(6)','X','L','','286','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('324','73','12','0','T-ACCRUAL-METHOD(6)','X','L','','289','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('325','74','12','0','T-CURRENT-BOOK-YIELD(6)','F','L','','291','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('326','75','12','0','T-COUPON-RATE(6)','F','L','','299','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('327','76','12','0','T-AMORTIZATION-CODE(6)','X','L','','307','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('328','77','12','0','T-PRINCIPAL-PAYMENT-FREQ(6)','X','L','','310','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('329','78','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(6)','C','L','','314','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('330','79','12','0','T-PAYMENT-AMOUNT(6)','F','L','','318','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('331','80','12','0','T-INTEREST-PAYMENT-CODE(6)','X','L','','326','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('332','81','12','0','T-INTEREST-COMPOUND-FREQ(6)','B','L','','329','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('333','82','12','0','T-INTEREST-PAYMENT-FREQ(6)','X','L','','331','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('334','83','12','0','T-NEXT-INTEREST-PAYMNT-DT(6)','C','L','','335','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('335','84','12','0','T-PAY-SCHEDULE-START-DT(6)','C','L','','339','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('336','85','12','0','TRAILER-RECS(7)','X','L','','343','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('337','86','12','0','T-TRANSACTION-CLASS-TYPE(7)','X','L','','343','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('338','87','12','0','T-ACCRUAL-METHOD(7)','X','L','','346','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('339','88','12','0','T-CURRENT-BOOK-YIELD(7)','F','L','','348','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('340','89','12','0','T-COUPON-RATE(7)','F','L','','356','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('341','90','12','0','T-AMORTIZATION-CODE(7)','X','L','','364','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('342','91','12','0','T-PRINCIPAL-PAYMENT-FREQ(7)','X','L','','367','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('343','92','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(7)','C','L','','371','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('344','93','12','0','T-PAYMENT-AMOUNT(7)','F','L','','375','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('345','94','12','0','T-INTEREST-PAYMENT-CODE(7)','X','L','','383','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('346','95','12','0','T-INTEREST-COMPOUND-FREQ(7)','B','L','','386','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('347','96','12','0','T-INTEREST-PAYMENT-FREQ(7)','X','L','','388','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('348','97','12','0','T-NEXT-INTEREST-PAYMNT-DT(7)','C','L','','392','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('349','98','12','0','T-PAY-SCHEDULE-START-DT(7)','C','L','','396','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('350','99','12','0','TRAILER-RECS(8)','X','L','','400','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('351','100','12','0','T-TRANSACTION-CLASS-TYPE(8)','X','L','','400','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('352','101','12','0','T-ACCRUAL-METHOD(8)','X','L','','403','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('353','102','12','0','T-CURRENT-BOOK-YIELD(8)','F','L','','405','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('354','103','12','0','T-COUPON-RATE(8)','F','L','','413','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('355','104','12','0','T-AMORTIZATION-CODE(8)','X','L','','421','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('356','105','12','0','T-PRINCIPAL-PAYMENT-FREQ(8)','X','L','','424','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('357','106','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(8)','C','L','','428','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('358','107','12','0','T-PAYMENT-AMOUNT(8)','F','L','','432','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('359','108','12','0','T-INTEREST-PAYMENT-CODE(8)','X','L','','440','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('360','109','12','0','T-INTEREST-COMPOUND-FREQ(8)','B','L','','443','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('361','110','12','0','T-INTEREST-PAYMENT-FREQ(8)','X','L','','445','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('362','111','12','0','T-NEXT-INTEREST-PAYMNT-DT(8)','C','L','','449','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('363','112','12','0','T-PAY-SCHEDULE-START-DT(8)','C','L','','453','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('364','113','12','0','TRAILER-RECS(9)','X','L','','457','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('365','114','12','0','T-TRANSACTION-CLASS-TYPE(9)','X','L','','457','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('366','115','12','0','T-ACCRUAL-METHOD(9)','X','L','','460','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('367','116','12','0','T-CURRENT-BOOK-YIELD(9)','F','L','','462','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('368','117','12','0','T-COUPON-RATE(9)','F','L','','470','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('369','118','12','0','T-AMORTIZATION-CODE(9)','X','L','','478','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('370','119','12','0','T-PRINCIPAL-PAYMENT-FREQ(9)','X','L','','481','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('371','120','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(9)','C','L','','485','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('372','121','12','0','T-PAYMENT-AMOUNT(9)','F','L','','489','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('373','122','12','0','T-INTEREST-PAYMENT-CODE(9)','X','L','','497','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('374','123','12','0','T-INTEREST-COMPOUND-FREQ(9)','B','L','','500','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('375','124','12','0','T-INTEREST-PAYMENT-FREQ(9)','X','L','','502','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('376','125','12','0','T-NEXT-INTEREST-PAYMNT-DT(9)','C','L','','506','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('377','126','12','0','T-PAY-SCHEDULE-START-DT(9)','C','L','','510','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('378','127','12','0','TRAILER-RECS(10)','X','L','','514','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('379','128','12','0','T-TRANSACTION-CLASS-TYPE(10)','X','L','','514','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('380','129','12','0','T-ACCRUAL-METHOD(10)','X','L','','517','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('381','130','12','0','T-CURRENT-BOOK-YIELD(10)','F','L','','519','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('382','131','12','0','T-COUPON-RATE(10)','F','L','','527','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('383','132','12','0','T-AMORTIZATION-CODE(10)','X','L','','535','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('384','133','12','0','T-PRINCIPAL-PAYMENT-FREQ(10)','X','L','','538','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('385','134','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(10)','C','L','','542','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('386','135','12','0','T-PAYMENT-AMOUNT(10)','F','L','','546','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('387','136','12','0','T-INTEREST-PAYMENT-CODE(10)','X','L','','554','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('388','137','12','0','T-INTEREST-COMPOUND-FREQ(10)','B','L','','557','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('389','138','12','0','T-INTEREST-PAYMENT-FREQ(10)','X','L','','559','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('390','139','12','0','T-NEXT-INTEREST-PAYMNT-DT(10)','C','L','','563','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('391','140','12','0','T-PAY-SCHEDULE-START-DT(10)','C','L','','567','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('392','141','12','0','TRAILER-RECS(11)','X','L','','571','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('393','142','12','0','T-TRANSACTION-CLASS-TYPE(11)','X','L','','571','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('394','143','12','0','T-ACCRUAL-METHOD(11)','X','L','','574','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('395','144','12','0','T-CURRENT-BOOK-YIELD(11)','F','L','','576','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('396','145','12','0','T-COUPON-RATE(11)','F','L','','584','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('397','146','12','0','T-AMORTIZATION-CODE(11)','X','L','','592','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('398','147','12','0','T-PRINCIPAL-PAYMENT-FREQ(11)','X','L','','595','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('399','148','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(11)','C','L','','599','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('400','149','12','0','T-PAYMENT-AMOUNT(11)','F','L','','603','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('401','150','12','0','T-INTEREST-PAYMENT-CODE(11)','X','L','','611','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('402','151','12','0','T-INTEREST-COMPOUND-FREQ(11)','B','L','','614','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('403','152','12','0','T-INTEREST-PAYMENT-FREQ(11)','X','L','','616','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('404','153','12','0','T-NEXT-INTEREST-PAYMNT-DT(11)','C','L','','620','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('405','154','12','0','T-PAY-SCHEDULE-START-DT(11)','C','L','','624','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('406','155','12','0','TRAILER-RECS(12)','X','L','','628','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('407','156','12','0','T-TRANSACTION-CLASS-TYPE(12)','X','L','','628','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('408','157','12','0','T-ACCRUAL-METHOD(12)','X','L','','631','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('409','158','12','0','T-CURRENT-BOOK-YIELD(12)','F','L','','633','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('410','159','12','0','T-COUPON-RATE(12)','F','L','','641','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('411','160','12','0','T-AMORTIZATION-CODE(12)','X','L','','649','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('412','161','12','0','T-PRINCIPAL-PAYMENT-FREQ(12)','X','L','','652','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('413','162','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(12)','C','L','','656','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('414','163','12','0','T-PAYMENT-AMOUNT(12)','F','L','','660','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('415','164','12','0','T-INTEREST-PAYMENT-CODE(12)','X','L','','668','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('416','165','12','0','T-INTEREST-COMPOUND-FREQ(12)','B','L','','671','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('417','166','12','0','T-INTEREST-PAYMENT-FREQ(12)','X','L','','673','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('418','167','12','0','T-NEXT-INTEREST-PAYMNT-DT(12)','C','L','','677','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('419','168','12','0','T-PAY-SCHEDULE-START-DT(12)','C','L','','681','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('420','169','12','0','TRAILER-RECS(13)','X','L','','685','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('421','170','12','0','T-TRANSACTION-CLASS-TYPE(13)','X','L','','685','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('422','171','12','0','T-ACCRUAL-METHOD(13)','X','L','','688','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('423','172','12','0','T-CURRENT-BOOK-YIELD(13)','F','L','','690','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('424','173','12','0','T-COUPON-RATE(13)','F','L','','698','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('425','174','12','0','T-AMORTIZATION-CODE(13)','X','L','','706','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('426','175','12','0','T-PRINCIPAL-PAYMENT-FREQ(13)','X','L','','709','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('427','176','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(13)','C','L','','713','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('428','177','12','0','T-PAYMENT-AMOUNT(13)','F','L','','717','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('429','178','12','0','T-INTEREST-PAYMENT-CODE(13)','X','L','','725','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('430','179','12','0','T-INTEREST-COMPOUND-FREQ(13)','B','L','','728','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('431','180','12','0','T-INTEREST-PAYMENT-FREQ(13)','X','L','','730','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('432','181','12','0','T-NEXT-INTEREST-PAYMNT-DT(13)','C','L','','734','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('433','182','12','0','T-PAY-SCHEDULE-START-DT(13)','C','L','','738','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('434','183','12','0','TRAILER-RECS(14)','X','L','','742','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('435','184','12','0','T-TRANSACTION-CLASS-TYPE(14)','X','L','','742','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('436','185','12','0','T-ACCRUAL-METHOD(14)','X','L','','745','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('437','186','12','0','T-CURRENT-BOOK-YIELD(14)','F','L','','747','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('438','187','12','0','T-COUPON-RATE(14)','F','L','','755','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('439','188','12','0','T-AMORTIZATION-CODE(14)','X','L','','763','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('440','189','12','0','T-PRINCIPAL-PAYMENT-FREQ(14)','X','L','','766','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('441','190','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(14)','C','L','','770','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('442','191','12','0','T-PAYMENT-AMOUNT(14)','F','L','','774','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('443','192','12','0','T-INTEREST-PAYMENT-CODE(14)','X','L','','782','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('444','193','12','0','T-INTEREST-COMPOUND-FREQ(14)','B','L','','785','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('445','194','12','0','T-INTEREST-PAYMENT-FREQ(14)','X','L','','787','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('446','195','12','0','T-NEXT-INTEREST-PAYMNT-DT(14)','C','L','','791','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('447','196','12','0','T-PAY-SCHEDULE-START-DT(14)','C','L','','795','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('448','197','12','0','TRAILER-RECS(15)','X','L','','799','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('449','198','12','0','T-TRANSACTION-CLASS-TYPE(15)','X','L','','799','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('450','199','12','0','T-ACCRUAL-METHOD(15)','X','L','','802','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('451','200','12','0','T-CURRENT-BOOK-YIELD(15)','F','L','','804','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('452','201','12','0','T-COUPON-RATE(15)','F','L','','812','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('453','202','12','0','T-AMORTIZATION-CODE(15)','X','L','','820','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('454','203','12','0','T-PRINCIPAL-PAYMENT-FREQ(15)','X','L','','823','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('455','204','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(15)','C','L','','827','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('456','205','12','0','T-PAYMENT-AMOUNT(15)','F','L','','831','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('457','206','12','0','T-INTEREST-PAYMENT-CODE(15)','X','L','','839','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('458','207','12','0','T-INTEREST-COMPOUND-FREQ(15)','B','L','','842','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('459','208','12','0','T-INTEREST-PAYMENT-FREQ(15)','X','L','','844','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('460','209','12','0','T-NEXT-INTEREST-PAYMNT-DT(15)','C','L','','848','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('461','210','12','0','T-PAY-SCHEDULE-START-DT(15)','C','L','','852','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('462','211','12','0','TRAILER-RECS(16)','X','L','','856','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('463','212','12','0','T-TRANSACTION-CLASS-TYPE(16)','X','L','','856','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('464','213','12','0','T-ACCRUAL-METHOD(16)','X','L','','859','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('465','214','12','0','T-CURRENT-BOOK-YIELD(16)','F','L','','861','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('466','215','12','0','T-COUPON-RATE(16)','F','L','','869','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('467','216','12','0','T-AMORTIZATION-CODE(16)','X','L','','877','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('468','217','12','0','T-PRINCIPAL-PAYMENT-FREQ(16)','X','L','','880','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('469','218','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(16)','C','L','','884','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('470','219','12','0','T-PAYMENT-AMOUNT(16)','F','L','','888','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('471','220','12','0','T-INTEREST-PAYMENT-CODE(16)','X','L','','896','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('472','221','12','0','T-INTEREST-COMPOUND-FREQ(16)','B','L','','899','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('473','222','12','0','T-INTEREST-PAYMENT-FREQ(16)','X','L','','901','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('474','223','12','0','T-NEXT-INTEREST-PAYMNT-DT(16)','C','L','','905','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('475','224','12','0','T-PAY-SCHEDULE-START-DT(16)','C','L','','909','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('476','225','12','0','TRAILER-RECS(17)','X','L','','913','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('477','226','12','0','T-TRANSACTION-CLASS-TYPE(17)','X','L','','913','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('478','227','12','0','T-ACCRUAL-METHOD(17)','X','L','','916','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('479','228','12','0','T-CURRENT-BOOK-YIELD(17)','F','L','','918','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('480','229','12','0','T-COUPON-RATE(17)','F','L','','926','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('481','230','12','0','T-AMORTIZATION-CODE(17)','X','L','','934','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('482','231','12','0','T-PRINCIPAL-PAYMENT-FREQ(17)','X','L','','937','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('483','232','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(17)','C','L','','941','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('484','233','12','0','T-PAYMENT-AMOUNT(17)','F','L','','945','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('485','234','12','0','T-INTEREST-PAYMENT-CODE(17)','X','L','','953','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('486','235','12','0','T-INTEREST-COMPOUND-FREQ(17)','B','L','','956','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('487','236','12','0','T-INTEREST-PAYMENT-FREQ(17)','X','L','','958','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('488','237','12','0','T-NEXT-INTEREST-PAYMNT-DT(17)','C','L','','962','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('489','238','12','0','T-PAY-SCHEDULE-START-DT(17)','C','L','','966','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('490','239','12','0','TRAILER-RECS(18)','X','L','','970','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('491','240','12','0','T-TRANSACTION-CLASS-TYPE(18)','X','L','','970','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('492','241','12','0','T-ACCRUAL-METHOD(18)','X','L','','973','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('493','242','12','0','T-CURRENT-BOOK-YIELD(18)','F','L','','975','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('494','243','12','0','T-COUPON-RATE(18)','F','L','','983','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('495','244','12','0','T-AMORTIZATION-CODE(18)','X','L','','991','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('496','245','12','0','T-PRINCIPAL-PAYMENT-FREQ(18)','X','L','','994','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('497','246','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(18)','C','L','','998','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('498','247','12','0','T-PAYMENT-AMOUNT(18)','F','L','','1002','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('499','248','12','0','T-INTEREST-PAYMENT-CODE(18)','X','L','','1010','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('500','249','12','0','T-INTEREST-COMPOUND-FREQ(18)','B','L','','1013','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('501','250','12','0','T-INTEREST-PAYMENT-FREQ(18)','X','L','','1015','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('502','251','12','0','T-NEXT-INTEREST-PAYMNT-DT(18)','C','L','','1019','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('503','252','12','0','T-PAY-SCHEDULE-START-DT(18)','C','L','','1023','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('504','253','12','0','TRAILER-RECS(19)','X','L','','1027','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('505','254','12','0','T-TRANSACTION-CLASS-TYPE(19)','X','L','','1027','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('506','255','12','0','T-ACCRUAL-METHOD(19)','X','L','','1030','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('507','256','12','0','T-CURRENT-BOOK-YIELD(19)','F','L','','1032','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('508','257','12','0','T-COUPON-RATE(19)','F','L','','1040','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('509','258','12','0','T-AMORTIZATION-CODE(19)','X','L','','1048','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('510','259','12','0','T-PRINCIPAL-PAYMENT-FREQ(19)','X','L','','1051','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('511','260','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(19)','C','L','','1055','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('512','261','12','0','T-PAYMENT-AMOUNT(19)','F','L','','1059','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('513','262','12','0','T-INTEREST-PAYMENT-CODE(19)','X','L','','1067','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('514','263','12','0','T-INTEREST-COMPOUND-FREQ(19)','B','L','','1070','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('515','264','12','0','T-INTEREST-PAYMENT-FREQ(19)','X','L','','1072','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('516','265','12','0','T-NEXT-INTEREST-PAYMNT-DT(19)','C','L','','1076','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('517','266','12','0','T-PAY-SCHEDULE-START-DT(19)','C','L','','1080','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('518','267','12','0','TRAILER-RECS(20)','X','L','','1084','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('519','268','12','0','T-TRANSACTION-CLASS-TYPE(20)','X','L','','1084','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('520','269','12','0','T-ACCRUAL-METHOD(20)','X','L','','1087','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('521','270','12','0','T-CURRENT-BOOK-YIELD(20)','F','L','','1089','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('522','271','12','0','T-COUPON-RATE(20)','F','L','','1097','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('523','272','12','0','T-AMORTIZATION-CODE(20)','X','L','','1105','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('524','273','12','0','T-PRINCIPAL-PAYMENT-FREQ(20)','X','L','','1108','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('525','274','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(20)','C','L','','1112','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('526','275','12','0','T-PAYMENT-AMOUNT(20)','F','L','','1116','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('527','276','12','0','T-INTEREST-PAYMENT-CODE(20)','X','L','','1124','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('528','277','12','0','T-INTEREST-COMPOUND-FREQ(20)','B','L','','1127','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('529','278','12','0','T-INTEREST-PAYMENT-FREQ(20)','X','L','','1129','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('530','279','12','0','T-NEXT-INTEREST-PAYMNT-DT(20)','C','L','','1133','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('531','280','12','0','T-PAY-SCHEDULE-START-DT(20)','C','L','','1137','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('532','281','12','0','TRAILER-RECS(21)','X','L','','1141','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('533','282','12','0','T-TRANSACTION-CLASS-TYPE(21)','X','L','','1141','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('534','283','12','0','T-ACCRUAL-METHOD(21)','X','L','','1144','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('535','284','12','0','T-CURRENT-BOOK-YIELD(21)','F','L','','1146','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('536','285','12','0','T-COUPON-RATE(21)','F','L','','1154','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('537','286','12','0','T-AMORTIZATION-CODE(21)','X','L','','1162','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('538','287','12','0','T-PRINCIPAL-PAYMENT-FREQ(21)','X','L','','1165','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('539','288','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(21)','C','L','','1169','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('540','289','12','0','T-PAYMENT-AMOUNT(21)','F','L','','1173','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('541','290','12','0','T-INTEREST-PAYMENT-CODE(21)','X','L','','1181','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('542','291','12','0','T-INTEREST-COMPOUND-FREQ(21)','B','L','','1184','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('543','292','12','0','T-INTEREST-PAYMENT-FREQ(21)','X','L','','1186','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('544','293','12','0','T-NEXT-INTEREST-PAYMNT-DT(21)','C','L','','1190','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('545','294','12','0','T-PAY-SCHEDULE-START-DT(21)','C','L','','1194','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('546','295','12','0','TRAILER-RECS(22)','X','L','','1198','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('547','296','12','0','T-TRANSACTION-CLASS-TYPE(22)','X','L','','1198','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('548','297','12','0','T-ACCRUAL-METHOD(22)','X','L','','1201','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('549','298','12','0','T-CURRENT-BOOK-YIELD(22)','F','L','','1203','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('550','299','12','0','T-COUPON-RATE(22)','F','L','','1211','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('551','300','12','0','T-AMORTIZATION-CODE(22)','X','L','','1219','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('552','301','12','0','T-PRINCIPAL-PAYMENT-FREQ(22)','X','L','','1222','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('553','302','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(22)','C','L','','1226','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('554','303','12','0','T-PAYMENT-AMOUNT(22)','F','L','','1230','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('555','304','12','0','T-INTEREST-PAYMENT-CODE(22)','X','L','','1238','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('556','305','12','0','T-INTEREST-COMPOUND-FREQ(22)','B','L','','1241','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('557','306','12','0','T-INTEREST-PAYMENT-FREQ(22)','X','L','','1243','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('558','307','12','0','T-NEXT-INTEREST-PAYMNT-DT(22)','C','L','','1247','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('559','308','12','0','T-PAY-SCHEDULE-START-DT(22)','C','L','','1251','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('560','309','12','0','TRAILER-RECS(23)','X','L','','1255','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('561','310','12','0','T-TRANSACTION-CLASS-TYPE(23)','X','L','','1255','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('562','311','12','0','T-ACCRUAL-METHOD(23)','X','L','','1258','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('563','312','12','0','T-CURRENT-BOOK-YIELD(23)','F','L','','1260','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('564','313','12','0','T-COUPON-RATE(23)','F','L','','1268','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('565','314','12','0','T-AMORTIZATION-CODE(23)','X','L','','1276','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('566','315','12','0','T-PRINCIPAL-PAYMENT-FREQ(23)','X','L','','1279','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('567','316','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(23)','C','L','','1283','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('568','317','12','0','T-PAYMENT-AMOUNT(23)','F','L','','1287','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('569','318','12','0','T-INTEREST-PAYMENT-CODE(23)','X','L','','1295','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('570','319','12','0','T-INTEREST-COMPOUND-FREQ(23)','B','L','','1298','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('571','320','12','0','T-INTEREST-PAYMENT-FREQ(23)','X','L','','1300','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('572','321','12','0','T-NEXT-INTEREST-PAYMNT-DT(23)','C','L','','1304','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('573','322','12','0','T-PAY-SCHEDULE-START-DT(23)','C','L','','1308','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('574','323','12','0','TRAILER-RECS(24)','X','L','','1312','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('575','324','12','0','T-TRANSACTION-CLASS-TYPE(24)','X','L','','1312','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('576','325','12','0','T-ACCRUAL-METHOD(24)','X','L','','1315','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('577','326','12','0','T-CURRENT-BOOK-YIELD(24)','F','L','','1317','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('578','327','12','0','T-COUPON-RATE(24)','F','L','','1325','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('579','328','12','0','T-AMORTIZATION-CODE(24)','X','L','','1333','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('580','329','12','0','T-PRINCIPAL-PAYMENT-FREQ(24)','X','L','','1336','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('581','330','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(24)','C','L','','1340','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('582','331','12','0','T-PAYMENT-AMOUNT(24)','F','L','','1344','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('583','332','12','0','T-INTEREST-PAYMENT-CODE(24)','X','L','','1352','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('584','333','12','0','T-INTEREST-COMPOUND-FREQ(24)','B','L','','1355','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('585','334','12','0','T-INTEREST-PAYMENT-FREQ(24)','X','L','','1357','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('586','335','12','0','T-NEXT-INTEREST-PAYMNT-DT(24)','C','L','','1361','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('587','336','12','0','T-PAY-SCHEDULE-START-DT(24)','C','L','','1365','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('588','337','12','0','TRAILER-RECS(25)','X','L','','1369','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('589','338','12','0','T-TRANSACTION-CLASS-TYPE(25)','X','L','','1369','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('590','339','12','0','T-ACCRUAL-METHOD(25)','X','L','','1372','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('591','340','12','0','T-CURRENT-BOOK-YIELD(25)','F','L','','1374','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('592','341','12','0','T-COUPON-RATE(25)','F','L','','1382','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('593','342','12','0','T-AMORTIZATION-CODE(25)','X','L','','1390','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('594','343','12','0','T-PRINCIPAL-PAYMENT-FREQ(25)','X','L','','1393','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('595','344','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(25)','C','L','','1397','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('596','345','12','0','T-PAYMENT-AMOUNT(25)','F','L','','1401','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('597','346','12','0','T-INTEREST-PAYMENT-CODE(25)','X','L','','1409','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('598','347','12','0','T-INTEREST-COMPOUND-FREQ(25)','B','L','','1412','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('599','348','12','0','T-INTEREST-PAYMENT-FREQ(25)','X','L','','1414','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('600','349','12','0','T-NEXT-INTEREST-PAYMNT-DT(25)','C','L','','1418','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('601','350','12','0','T-PAY-SCHEDULE-START-DT(25)','C','L','','1422','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('602','351','12','0','TRAILER-RECS(26)','X','L','','1426','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('603','352','12','0','T-TRANSACTION-CLASS-TYPE(26)','X','L','','1426','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('604','353','12','0','T-ACCRUAL-METHOD(26)','X','L','','1429','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('605','354','12','0','T-CURRENT-BOOK-YIELD(26)','F','L','','1431','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('606','355','12','0','T-COUPON-RATE(26)','F','L','','1439','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('607','356','12','0','T-AMORTIZATION-CODE(26)','X','L','','1447','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('608','357','12','0','T-PRINCIPAL-PAYMENT-FREQ(26)','X','L','','1450','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('609','358','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(26)','C','L','','1454','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('610','359','12','0','T-PAYMENT-AMOUNT(26)','F','L','','1458','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('611','360','12','0','T-INTEREST-PAYMENT-CODE(26)','X','L','','1466','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('612','361','12','0','T-INTEREST-COMPOUND-FREQ(26)','B','L','','1469','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('613','362','12','0','T-INTEREST-PAYMENT-FREQ(26)','X','L','','1471','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('614','363','12','0','T-NEXT-INTEREST-PAYMNT-DT(26)','C','L','','1475','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('615','364','12','0','T-PAY-SCHEDULE-START-DT(26)','C','L','','1479','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('616','365','12','0','TRAILER-RECS(27)','X','L','','1483','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('617','366','12','0','T-TRANSACTION-CLASS-TYPE(27)','X','L','','1483','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('618','367','12','0','T-ACCRUAL-METHOD(27)','X','L','','1486','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('619','368','12','0','T-CURRENT-BOOK-YIELD(27)','F','L','','1488','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('620','369','12','0','T-COUPON-RATE(27)','F','L','','1496','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('621','370','12','0','T-AMORTIZATION-CODE(27)','X','L','','1504','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('622','371','12','0','T-PRINCIPAL-PAYMENT-FREQ(27)','X','L','','1507','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('623','372','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(27)','C','L','','1511','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('624','373','12','0','T-PAYMENT-AMOUNT(27)','F','L','','1515','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('625','374','12','0','T-INTEREST-PAYMENT-CODE(27)','X','L','','1523','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('626','375','12','0','T-INTEREST-COMPOUND-FREQ(27)','B','L','','1526','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('627','376','12','0','T-INTEREST-PAYMENT-FREQ(27)','X','L','','1528','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('628','377','12','0','T-NEXT-INTEREST-PAYMNT-DT(27)','C','L','','1532','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('629','378','12','0','T-PAY-SCHEDULE-START-DT(27)','C','L','','1536','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('630','379','12','0','TRAILER-RECS(28)','X','L','','1540','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('631','380','12','0','T-TRANSACTION-CLASS-TYPE(28)','X','L','','1540','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('632','381','12','0','T-ACCRUAL-METHOD(28)','X','L','','1543','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('633','382','12','0','T-CURRENT-BOOK-YIELD(28)','F','L','','1545','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('634','383','12','0','T-COUPON-RATE(28)','F','L','','1553','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('635','384','12','0','T-AMORTIZATION-CODE(28)','X','L','','1561','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('636','385','12','0','T-PRINCIPAL-PAYMENT-FREQ(28)','X','L','','1564','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('637','386','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(28)','C','L','','1568','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('638','387','12','0','T-PAYMENT-AMOUNT(28)','F','L','','1572','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('639','388','12','0','T-INTEREST-PAYMENT-CODE(28)','X','L','','1580','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('640','389','12','0','T-INTEREST-COMPOUND-FREQ(28)','B','L','','1583','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('641','390','12','0','T-INTEREST-PAYMENT-FREQ(28)','X','L','','1585','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('642','391','12','0','T-NEXT-INTEREST-PAYMNT-DT(28)','C','L','','1589','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('643','392','12','0','T-PAY-SCHEDULE-START-DT(28)','C','L','','1593','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('644','393','12','0','TRAILER-RECS(29)','X','L','','1597','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('645','394','12','0','T-TRANSACTION-CLASS-TYPE(29)','X','L','','1597','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('646','395','12','0','T-ACCRUAL-METHOD(29)','X','L','','1600','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('647','396','12','0','T-CURRENT-BOOK-YIELD(29)','F','L','','1602','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('648','397','12','0','T-COUPON-RATE(29)','F','L','','1610','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('649','398','12','0','T-AMORTIZATION-CODE(29)','X','L','','1618','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('650','399','12','0','T-PRINCIPAL-PAYMENT-FREQ(29)','X','L','','1621','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('651','400','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(29)','C','L','','1625','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('652','401','12','0','T-PAYMENT-AMOUNT(29)','F','L','','1629','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('653','402','12','0','T-INTEREST-PAYMENT-CODE(29)','X','L','','1637','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('654','403','12','0','T-INTEREST-COMPOUND-FREQ(29)','B','L','','1640','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('655','404','12','0','T-INTEREST-PAYMENT-FREQ(29)','X','L','','1642','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('656','405','12','0','T-NEXT-INTEREST-PAYMNT-DT(29)','C','L','','1646','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('657','406','12','0','T-PAY-SCHEDULE-START-DT(29)','C','L','','1650','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('658','407','12','0','TRAILER-RECS(30)','X','L','','1654','57','0','','Y','N','','Y','L','L','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('659','408','12','0','T-TRANSACTION-CLASS-TYPE(30)','X','L','','1654','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('660','409','12','0','T-ACCRUAL-METHOD(30)','X','L','','1657','2','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('661','410','12','0','T-CURRENT-BOOK-YIELD(30)','F','L','','1659','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('662','411','12','0','T-COUPON-RATE(30)','F','L','','1667','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('663','412','12','0','T-AMORTIZATION-CODE(30)','X','L','','1675','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('664','413','12','0','T-PRINCIPAL-PAYMENT-FREQ(30)','X','L','','1678','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('665','414','12','0','T-NEXT-PRINCIPAL-PYMNT-DT(30)','C','L','','1682','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('666','415','12','0','T-PAYMENT-AMOUNT(30)','F','L','','1686','8','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('667','416','12','0','T-INTEREST-PAYMENT-CODE(30)','X','L','','1694','3','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('668','417','12','0','T-INTEREST-COMPOUND-FREQ(30)','B','L','','1697','4','0','','Y','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('669','418','12','0','T-INTEREST-PAYMENT-FREQ(30)','X','L','','1699','4','0','','Y','N','N','Y','L','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('670','419','12','0','T-NEXT-INTEREST-PAYMNT-DT(30)','C','L','','1703','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('671','420','12','0','T-PAY-SCHEDULE-START-DT(30)','C','L','','1707','8','0','2','N','N','','Y','L','L','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('672','26','2','0','Sub Category Name #5','X','','','0','20','0','','','N','','','','','','B','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('673','27','2','0','Sub Category Name #6','X','','','0','20','0','','','N','','','','','','B','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('674','28','2','0','Sub Category Name #7','X','','','0','20','0','','','N','','','','','','B','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('675','29','2','0','Sub Category Name #8','X','','','0','20','0','','','N','','','','','','B','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('676','30','2','0','Sub Category Name #9','X','','','0','20','0','','','N','','','','','','B','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('677','31','2','0','Sub Category Name #10','X','','','0','20','0','','','N','','','','','','B','0','C','','12','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('678','1','13','0','UTR43','X','L','','1','181','0','','N','N','N','N','N','N','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('679','2','13','0','GL-CLASS-TYPE','X','L','','1','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('680','3','13','0','GL-ACCOUNT-TYPE','X','L','','4','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('681','4','13','0','GL-SNAPSHOT-BALANCE','F','L','','7','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('682','5','13','0','GL-AVERAGE-BALANCE','F','L','','15','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('683','6','13','0','GL-INCOME-EXPENSE','F','L','','23','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('684','7','13','0','GL-STATUS-CODE','X','L','','31','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('685','8','13','0','GL-ACCOUNT-NUMBER','X','L','','34','30','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('686','9','13','0','GL-ACCRUAL-METHOD','X','L','','64','2','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('687','10','13','0','GL-RATE','F','L','','66','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('688','11','13','0','GL-FUNDING-RATE','F','L','','74','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('689','12','13','0','GL-FUNDING-INDEX','B','L','','82','4','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('690','13','13','0','GL-CORP-NUMBER','X','L','','84','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('691','14','13','0','GL-ACCT-NUMBER','X','L','','87','10','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('692','15','13','0','GL-PRIMARY-ACCT-NUM','X','L','','97','10','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('693','16','13','0','GL-CENTER','X','L','','107','10','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('694','17','13','0','GL-BRANCH-CC','X','L','','117','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('695','18','13','0','GL-ACCOUNT-DESC','X','L','','120','30','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('696','19','13','0','GL-CURRENCY','X','L','','150','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('697','20','13','0','GL-CODE','X','L','','153','2','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('698','21','13','0','GL-PROCESSING-DATE','C','L','','155','8','0','2','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('699','22','13','0','GL-SCENARIO-CODE','X','L','','159','1','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('700','23','13','0','GL-SUBSYSID','X','L','','160','6','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('701','24','13','0','GL-AVERAGE-FUNDING-RATE','F','L','','166','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('702','25','13','0','GL-FUNDING-INCEXP','F','L','','174','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('703','1','14','0','UTR43','X','L','','1','441','0','','N','N','N','N','N','N','N','X','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('704','2','14','0','TRANSACTION-CLASS-TYPE','X','L','','1','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('705','3','14','0','CURRENT-BOOK-PRINCIPAL','F','L','','4','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('706','4','14','0','CURRENT-BOOK-YIELD','F','L','','12','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('707','5','14','0','COUPON-RATE','F','L','','20','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('708','6','14','0','REFERENCE-NUMBER','X','L','','28','20','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('709','7','14','0','ACCRUAL-METHOD','X','L','','48','2','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('710','8','14','0','CURRENT-MATURITY-DATE','C','L','','50','8','0','2','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('711','9','14','0','REPRICING-CODE','X','L','','54','2','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('712','10','14','0','REPRICING-FREQUENCY','X','L','','56','4','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('713','11','14','0','NEXT-REPRICING-DATE','C','L','','60','8','0','2','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('714','12','14','0','AMORTIZATION-CODE','X','L','','64','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('715','13','14','0','PRINCIPAL-PAYMENT-FREQUENCY','X','L','','67','4','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('716','14','14','0','NEXT-PRINCIPAL-PAYMENT-DATE','C','L','','71','8','0','2','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('717','15','14','0','PAYMENT-AMOUNT','F','L','','75','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('718','16','14','0','INTEREST-PAYMENT-CODE','X','L','','83','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('719','17','14','0','INTEREST-COMPOUND-FREQUENCY','B','L','','86','4','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('720','18','14','0','INTEREST-PAYMENT-FREQUENCY','X','L','','88','4','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('721','19','14','0','NEXT-INTEREST-PAYMENT-DATE','C','L','','92','8','0','2','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('722','20','14','0','ORIGINAL-TRANS-PURCH-DATE','C','L','','96','8','0','2','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('723','21','14','0','ORIGINAL-BOOK-VALUE','F','L','','100','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('724','22','14','0','PREM-DISC-AT-TRANS-PURCH','F','L','','108','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('725','23','14','0','PREPAY-PERCENT-PER-MONTH','F','L','','116','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('726','24','14','0','LOWEST-LIFETIME-RATE','F','L','','124','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('727','25','14','0','HIGHEST-LIFETIME-RATE','F','L','','132','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('728','26','14','0','MAXIMUM-RATE-CHANGE','F','L','','140','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('729','27','14','0','REPRICING-SPREAD-VALUE','F','L','','148','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('730','28','14','0','LAST-REPRICING-DATE','C','L','','156','8','0','2','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('731','29','14','0','AMORTIZATION-DATE','C','L','','160','8','0','2','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('732','30','14','0','FUNDING-RATE','F','L','','164','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('733','31','14','0','FUNDING-INDEX','B','L','','172','4','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('734','32','14','0','AVERAGE-BALANCE','F','L','','174','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('735','33','14','0','TRANSACTION-STATUS-CODE','X','L','','182','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('736','34','14','0','REPRICING-DRIVE-RATE','X','L','','185','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('737','35','14','0','INTEREST-INCOME','F','L','','188','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('738','36','14','0','PROCESSING-DATE','C','L','','196','8','0','2','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('739','37','14','0','ACCT-NUM','X','L','','200','20','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('740','38','14','0','BANK-NUM','X','L','','220','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('741','39','14','0','BRANCH-NUM','X','L','','223','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('742','40','14','0','CREDIT-RISK-RATING-CODE','X','L','','226','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('743','41','14','0','CURRENCY-CODE','X','L','','234','3','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('744','42','14','0','CUSTOMER-NUM','X','L','','237','12','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('745','43','14','0','GL-ACCOUNT-NUMBER','X','L','','249','10','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('746','44','14','0','GL-I-E-ACCOUNT-NUMBER','X','L','','259','10','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('747','45','14','0','GL-CODE','X','L','','269','2','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('748','46','14','0','OFFICER-NUM','X','L','','271','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('749','47','14','0','PRODUCT-CODE','X','L','','279','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('750','48','14','0','RESP-CNTR-NUM','X','L','','287','10','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('751','49','14','0','SCENARIO-CODE','X','L','','297','1','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('752','50','14','0','SIC-CODE','X','L','','298','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('753','51','14','0','SUBSYSID','X','L','','306','6','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('754','52','14','0','INCOME-EXPENSE','F','L','','312','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('755','53','14','0','AVERAGE-FUNDING-RATE','F','L','','320','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('756','54','14','0','FUNDING-INCEXP','F','L','','328','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('757','55','14','0','FEES','F','L','','336','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('758','56','14','0','VARIABLE-COST','F','L','','344','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('759','57','14','0','FIXED-COST','F','L','','352','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('760','58','14','0','OVERHEAD-COST','F','L','','360','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('761','59','14','0','ORIG-TERM','B','L','','368','5','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('762','60','14','0','REMAINING-TERM','B','L','','371','5','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('763','61','14','0','AMT-OVERDUE-30','F','L','','374','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('764','62','14','0','AMT-OVERDUE-60','F','L','','382','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('765','63','14','0','AMT-OVERDUE-90','F','L','','390','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('766','64','14','0','AMT-OVERDUE-GT-90','F','L','','398','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('767','65','14','0','PAST-DUE-IN-DAYS','B','L','','406','5','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('768','66','14','0','NON-ACCRUAL','X','L','','409','1','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('769','67','14','0','CHARGE-OFFS','F','L','','410','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('770','68','14','0','RECOVERIES','F','L','','418','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('771','69','14','0','CMT-AVAILABLE','F','L','','426','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')
INSERT SOURCE_FIELD([index],[field_number],[input_record_index],[subsystem_index],[name],[data_type],[value_type],[default_value],[address],[length],[right],[date_format],[date_slash],[repeat],[decimal],[comma],[justify],[zero],[sign],[source],[version],[pcf_use],[docmemo],[data_subtype],[valid],[folderid])       VALUES('772','70','14','0','PREPAY-PENALTY','F','L','','434','8','0','','N','N','N','N','N','N','N','E','100','P','','0','1','0')


END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SOURCE_FIELD]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[SOURCE_FIELD]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SOURCE_FIELD_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_SOURCE_FIELD_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SOURCE_FIELD_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_SOURCE_FIELD_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[SOURCE_FIELD]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[SOURCE_FIELD]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[SOURCE_FIELD] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[SOURCE_FIELD] SET temporary = [index]') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'[Index]'))
				ALTER TABLE [dbo].[SOURCE_FIELD] DROP Constraint [Index]; 
			ALTER TABLE [dbo].[SOURCE_FIELD] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[SOURCE_FIELD] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[SOURCE_FIELD].temporary', 'index', 'COLUMN';
			ALTER TABLE [dbo].[SOURCE_FIELD] ADD CONSTRAINT [Index] PRIMARY KEY([index]);  
		END 
	END
END	

GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SOURCE_FIELD_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_SOURCE_FIELD_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_SOURCE_FIELD_INSERT] 
   ON  [dbo].[SOURCE_FIELD] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''SOURCE_FIELD''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''[index]=''+convert(nvarchar(15),NEW.[index]),
                (''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''field_number=''+ISNULL(convert(nvarchar(15),NEW.field_number),'''')+''|#''+
                ''input_record_index=''+ISNULL(convert(nvarchar(15),NEW.input_record_index),'''')+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),NEW.subsystem_index),'''')+''|#''+
                ''name=''+''''''''+NEW.name+''''''''+''|#''+
                ''data_type=''+''''''''+NEW.data_type+''''''''+''|#''+
                ''value_type=''+''''''''+ISNULL(Replace(NEW.value_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''default_value=''+''''''''+ISNULL(Replace(NEW.default_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''address=''+ISNULL(convert(nvarchar(15),NEW.address),'''') +''|#''+
                ''length=''+ISNULL(convert(nvarchar(15),NEW.length),'''') +''|#''+
                ''[right]=''+ISNULL(convert(nvarchar(15),NEW.[right]),'''') +''|#''+
                ''date_format=''+''''''''+ISNULL(Replace(NEW.date_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''date_slash=''+''''''''+ISNULL(Replace(NEW.date_slash,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''repeat=''+''''''''+ISNULL(Replace(NEW.repeat,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''decimal=''+''''''''+ISNULL(Replace(NEW.decimal,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''comma=''+''''''''+ISNULL(Replace(NEW.comma,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''justify=''+''''''''+ISNULL(Replace(NEW.justify,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''zero=''+''''''''+ISNULL(Replace(NEW.zero,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[sign]=''+''''''''+ISNULL(Replace(NEW.[sign],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''source=''+''''''''+ISNULL(Replace(NEW.source,'''''''',''''''''''''),'''')+'''''''' +''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''') +''|#''+
                ''pcf_use=''+''''''''+ISNULL(Replace(NEW.pcf_use,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''docmemo=''+''''''''+ISNULL(Replace(cast(ORG.docmemo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''data_subtype=''+ISNULL(convert(nvarchar(15),NEW.data_subtype),'''') +''|#''+
                ''valid=''+convert(nvarchar(1),NEW.valid) +''|#''+
                ''folderid=''+ISNULL(convert(nvarchar(15),NEW.folderid),'''') )from INSERTED NEW,SOURCE_FIELD ORG
where ORG.[index] = NEW.[index];

END
END



set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SOURCE_FIELD_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_SOURCE_FIELD_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_SOURCE_FIELD_UPDATE] 
   ON  [dbo].[SOURCE_FIELD] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @modifiedColumns int,
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''SOURCE_FIELD''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END
--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''field_number=''+ISNULL(convert(nvarchar(15),OLD.field_number),'''')+''|#''+
                ''input_record_index=''+ISNULL(convert(nvarchar(15),OLD.input_record_index),'''')+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),OLD.subsystem_index),'''')+''|#''+
                ''name=''+''''''''+OLD.name+''''''''+''|#''+
                ''data_type=''+''''''''+OLD.data_type+''''''''+''|#''+
                ''value_type=''+''''''''+ISNULL(Replace(OLD.value_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''default_value=''+''''''''+ISNULL(Replace(OLD.default_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''address=''+ISNULL(convert(nvarchar(15),OLD.address),'''') +''|#''+
                ''length=''+ISNULL(convert(nvarchar(15),OLD.length),'''') +''|#''+
                ''[right]=''+ISNULL(convert(nvarchar(15),OLD.[right]),'''') +''|#''+
                ''date_format=''+''''''''+ISNULL(Replace(OLD.date_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''date_slash=''+''''''''+ISNULL(Replace(OLD.date_slash,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''repeat=''+''''''''+ISNULL(Replace(OLD.repeat,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''decimal=''+''''''''+ISNULL(Replace(OLD.decimal,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''comma=''+''''''''+ISNULL(Replace(OLD.comma,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''justify=''+''''''''+ISNULL(Replace(OLD.justify,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''zero=''+''''''''+ISNULL(Replace(OLD.zero,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[sign]=''+''''''''+ISNULL(Replace(OLD.[sign],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''source=''+''''''''+ISNULL(Replace(OLD.source,'''''''',''''''''''''),'''')+'''''''' +''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''') +''|#''+
                ''pcf_use=''+''''''''+ISNULL(Replace(OLD.pcf_use,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''docmemo=''+''''''''+ISNULL(Replace(cast(OLD.docmemo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''data_subtype=''+convert(nvarchar(15),OLD.data_subtype) +''|#''+
                ''valid=''+convert(nvarchar(1),OLD.valid) +''|#''+
                ''folderid=''+convert(nvarchar(15),OLD.folderid)+
                '' WHERE ''+''[index]=''+convert(nvarchar(15),OLD.[index]),
                 
                ''field_number=''+ISNULL(convert(nvarchar(15),NEW.field_number),'''')+''|#''+
                ''input_record_index=''+ISNULL(convert(nvarchar(15),NEW.input_record_index),'''')+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),NEW.subsystem_index),'''')+''|#''+
                ''name=''+''''''''+NEW.name+''''''''+''|#''+
                ''data_type=''+''''''''+NEW.data_type+''''''''+''|#''+
                ''value_type=''+''''''''+ISNULL(Replace(NEW.value_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''default_value=''+''''''''+ISNULL(Replace(NEW.default_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''address=''+ISNULL(convert(nvarchar(15),NEW.address),'''') +''|#''+
                ''length=''+ISNULL(convert(nvarchar(15),NEW.length),'''') +''|#''+
                ''[right]=''+ISNULL(convert(nvarchar(15),NEW.[right]),'''') +''|#''+
                ''date_format=''+''''''''+ISNULL(Replace(NEW.date_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''date_slash=''+''''''''+ISNULL(Replace(NEW.date_slash,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''repeat=''+''''''''+ISNULL(Replace(NEW.repeat,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''decimal=''+''''''''+ISNULL(Replace(NEW.decimal,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''comma=''+''''''''+ISNULL(Replace(NEW.comma,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''justify=''+''''''''+ISNULL(Replace(NEW.justify,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''zero=''+''''''''+ISNULL(Replace(NEW.zero,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[sign]=''+''''''''+ISNULL(Replace(NEW.[sign],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''source=''+''''''''+ISNULL(Replace(NEW.source,'''''''',''''''''''''),'''')+'''''''' +''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''') +''|#''+
                ''pcf_use=''+''''''''+ISNULL(Replace(NEW.pcf_use,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''docmemo=''+''''''''+ISNULL(Replace(cast(NEW.docmemo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''data_subtype=''+ISNULL(convert(nvarchar(15),NEW.data_subtype),'''') +''|#''+
                ''valid=''+convert(nvarchar(1),NEW.valid) +''|#''+
                ''folderid=''+ISNULL(convert(nvarchar(15),NEW.folderid),'''')+
                '' WHERE ''+''[index]=''+convert(nvarchar(15),NEW.[index]) from DELETED OLD,INSERTED NEW
where NEW.[index] = OLD.[index];
END
--update the field in SOURCE_FIELD table
UPDATE dbo.SOURCE_FIELD
SET field_number=NEW.field_number,
    input_record_index=NEW.input_record_index,
    subsystem_index=NEW.subsystem_index,
    name=NEW.name,
    data_type=NEW.data_type,
    value_type=NEW.value_type,
    default_value=NEW.default_value,
    address=NEW.address,
    length=NEW.length,
    [right]=NEW.[right],
    date_format=NEW.date_format,
    date_slash=NEW.date_slash,
    repeat=NEW.repeat,
    decimal=NEW.decimal,
    comma=NEW.comma,
    justify=NEW.justify,
    zero=NEW.zero,
    sign=NEW.sign,
    source=NEW.source,
    version=NEW.version,
    pcf_use=NEW.pcf_use,
    docmemo=NEW.docmemo,
    data_subtype=NEW.data_subtype,
    valid=NEW.valid,
    folderid=NEW.folderid
    from INSERTED NEW
    where SOURCE_FIELD.[index] in (NEW.[index]);
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''field_number=''+ISNULL(convert(nvarchar(15),OLD.field_number),'''')+''|#''+
                ''input_record_index=''+ISNULL(convert(nvarchar(15),OLD.input_record_index),'''')+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),OLD.subsystem_index),'''')+''|#''+
                ''name=''+''''''''+OLD.name+''''''''+''|#''+
                ''data_type=''+''''''''+OLD.data_type+''''''''+''|#''+
                ''value_type=''+''''''''+ISNULL(Replace(OLD.value_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''default_value=''+''''''''+ISNULL(Replace(OLD.default_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''address=''+ISNULL(convert(nvarchar(15),OLD.address),'''') +''|#''+
                ''length=''+ISNULL(convert(nvarchar(15),OLD.length),'''') +''|#''+
                ''[right]=''+ISNULL(convert(nvarchar(15),OLD.[right]),'''') +''|#''+
                ''date_format=''+''''''''+ISNULL(Replace(OLD.date_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''date_slash=''+''''''''+ISNULL(Replace(OLD.date_slash,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''repeat=''+''''''''+ISNULL(Replace(OLD.repeat,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''decimal=''+''''''''+ISNULL(Replace(OLD.decimal,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''comma=''+''''''''+ISNULL(Replace(OLD.comma,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''justify=''+''''''''+ISNULL(Replace(OLD.justify,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''zero=''+''''''''+ISNULL(Replace(OLD.zero,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[sign]=''+''''''''+ISNULL(Replace(OLD.[sign],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''source=''+''''''''+ISNULL(Replace(OLD.source,'''''''',''''''''''''),'''')+'''''''' +''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''') +''|#''+
                ''pcf_use=''+''''''''+ISNULL(Replace(OLD.pcf_use,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''docmemo=''+''''''''+ISNULL(Replace(cast(OLD.docmemo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''data_subtype=''+convert(nvarchar(15),OLD.data_subtype) +''|#''+
                ''valid=''+convert(nvarchar(1),OLD.valid) +''|#''+
                ''folderid=''+convert(nvarchar(15),OLD.folderid)+''|#''+
                ''[index]=''+convert(nvarchar(15),OLD.[index]),''[index]=''+convert(nvarchar(15),OLD.[index]) from DELETED OLD;
end
--Delete the field from SOURCE_FIELD table
DELETE FROM SOURCE_FIELD where [index] in (SELECT OLD.[index] from DELETED OLD);
END



' 
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DeleteParameters]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DeleteParameters]
    @pJobID [int]
AS
BEGIN
DELETE 
FROM PARAMETERS 
WHERE PARAMETERS.jobid = @pJobID;
END
' 
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[USERS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[USERS](
    [uid] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](350)  NOT NULL,
    [isgroup] [bit] NOT NULL CONSTRAINT [DF_USERS_isgroup]  DEFAULT ((0)),
    [isadmin] [bit] NOT NULL CONSTRAINT [DF_USERS_isadmin]  DEFAULT ((0)),
 CONSTRAINT [PK_USERS] PRIMARY KEY CLUSTERED 
(
    [uid] ASC
) ON [PRIMARY]
) ON [PRIMARY]

INSERT INTO [dbo].[USERS]
           ([name]
           ,[isgroup]
           ,[isadmin])
     VALUES
           ('Domain Users'
           ,1
           ,1)

END
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[USERS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[USERS]'),'TableHasIdentity') = 1 
	BEGIN
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[USERS]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[USERS]') AND name = N'uid') 
		BEGIN
			ALTER TABLE [dbo].[USERS] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[USERS] SET temporary = uid') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'F' AND id = OBJECT_ID(N'FK_SECURITY_USERS'))
				ALTER TABLE [dbo].[SECURITY] DROP Constraint FK_SECURITY_USERS; 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'F' AND id = OBJECT_ID(N'[FK_SECURITY_FOLDERS]'))
				ALTER TABLE [dbo].[SECURITY] DROP Constraint FK_SECURITY_FOLDERS; 
				
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'PK_USERS'))
				ALTER TABLE [dbo].[USERS] DROP Constraint PK_USERS; 
			ALTER TABLE [dbo].[USERS] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[USERS] DROP COLUMN uid; 
			EXEC sp_rename '[dbo].[USERS].temporary', 'uid', 'COLUMN';
			ALTER TABLE [dbo].[USERS] ADD CONSTRAINT PK_USERS PRIMARY KEY(uid);
			
			--Security table may not be created
		    IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SECURITY]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
				BEGIN	
					ALTER TABLE [dbo].[SECURITY]  WITH CHECK ADD  CONSTRAINT [FK_SECURITY_USERS] FOREIGN KEY([userid])
						REFERENCES [dbo].[USERS] ([uid]) ON UPDATE CASCADE ON DELETE CASCADE
					
					ALTER TABLE [dbo].[SECURITY]  WITH CHECK ADD  CONSTRAINT [FK_SECURITY_FOLDERS] FOREIGN KEY([folderid])
						REFERENCES [dbo].[FOLDERS] ([folderid])ON UPDATE CASCADE ON DELETE CASCADE
					ALTER TABLE [dbo].[SECURITY] CHECK CONSTRAINT [FK_SECURITY_FOLDERS]
				END
			
		END 
	END
END



IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[USERS]') AND name = N'UserName')
CREATE UNIQUE NONCLUSTERED INDEX [UserName] ON [dbo].[USERS] 
(
    [name] ASC
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_USERS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_USERS_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_USERS_INSERT] 
   ON  [dbo].[USERS] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''USERS''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
	IF(isnull(@actionindex, 0)<> 0)
	BEGIN
	INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
	SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''uid=''+convert(nvarchar(15),NEW.uid),
					''uid=''+convert(nvarchar(15),NEW.uid)+''|#''+
					''[name]=''+''''''''+NEW.[name]+''''''''+''|#''+
					''isgroup=''+convert(nvarchar(1),NEW.isgroup)+''|#''+
					''isadmin=''+convert(nvarchar(1),NEW.isadmin) from INSERTED NEW,USERS ORG
					where ORG.uid = NEW.uid;

	END

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
	IF(isnull(@actionindex, 0)<> 0)
	BEGIN
	INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
	SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''uid=''+convert(nvarchar(15),NEW.uid),
					''uid=''+convert(nvarchar(15),NEW.uid)+''|#''+
					''[name]=''+''''''''+NEW.[name]+''''''''+''|#''+
					''isgroup=''+convert(nvarchar(1),NEW.isgroup)+''|#''+
					''isadmin=''+convert(nvarchar(1),NEW.isadmin) from INSERTED NEW,USERS ORG
					where ORG.uid = NEW.uid;

	END
END

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_USERS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_USERS_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_USERS_UPDATE] 
   ON  [dbo].[USERS] 
   AFTER UPDATE,DELETE
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @modifiedColumns int,
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''USERS''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
				''[name]=''+''''''''+OLD.[name]+''''''''+''|#''+
                ''isgroup=''+convert(nvarchar(1),OLD.isgroup)+''|#''+
                ''isadmin=''+convert(nvarchar(1),OLD.isadmin)+
                '' WHERE ''+ ''uid=''+convert(nvarchar(15),OLD.uid),

				
                ''[name]=''+''''''''+NEW.[name]+''''''''+''|#''+
                ''isgroup=''+convert(nvarchar(1),NEW.isgroup)+''|#''+
                ''isadmin=''+convert(nvarchar(1),NEW.isadmin)+
                '' WHERE ''+''uid=''+convert(nvarchar(15),NEW.uid) from DELETED OLD,INSERTED NEW
				where NEW.uid = OLD.uid;
end
END
--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''uid=''+convert(nvarchar(15),OLD.uid)+''|#''+
                ''[name]=''+''''''''+OLD.[name]+''''''''+''|#''+
                ''isgroup=''+convert(nvarchar(1),OLD.isgroup)+''|#''+
                ''isadmin=''+convert(nvarchar(1),OLD.isadmin),
                ''uid=''+convert(nvarchar(15),OLD.uid) from DELETED OLD;
end
END
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID


--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
				''[name]=''+''''''''+OLD.[name]+''''''''+''|#''+
                ''isgroup=''+convert(nvarchar(1),OLD.isgroup)+''|#''+
                ''isadmin=''+convert(nvarchar(1),OLD.isadmin)+
                '' WHERE ''+ ''uid=''+convert(nvarchar(15),OLD.uid),

				
                ''[name]=''+''''''''+NEW.[name]+''''''''+''|#''+
                ''isgroup=''+convert(nvarchar(1),NEW.isgroup)+''|#''+
                ''isadmin=''+convert(nvarchar(1),NEW.isadmin)+
                '' WHERE ''+''uid=''+convert(nvarchar(15),NEW.uid) from DELETED OLD,INSERTED NEW
				where NEW.uid = OLD.uid;
end
END
--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''uid=''+convert(nvarchar(15),OLD.uid)+''|#''+
                ''[name]=''+''''''''+OLD.[name]+''''''''+''|#''+
                ''isgroup=''+convert(nvarchar(1),OLD.isgroup)+''|#''+
                ''isadmin=''+convert(nvarchar(1),OLD.isadmin),
                ''uid=''+convert(nvarchar(15),OLD.uid) from DELETED OLD;
end

END
'
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[OPTION_LISTS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	DROP TABLE [dbo].[OPTION_LISTS];
	
GO	

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[OPTION_LISTS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[OPTION_LISTS](
    [index] [int] NOT NULL,
    [list_id] [nvarchar](20)  NOT NULL,
    [list_entry] [nvarchar](50)  NOT NULL,
    [list_value] [nvarchar](4)  NULL,
    [extra_value] [nvarchar](4)  NULL
) ON [PRIMARY]

--INSERT Global Data for OPTION_LISTS table

INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('2','DataType','Integer (signed)','+','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('3','DataType','Letters & numbers','X','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('4','OutputFile','Main File','1','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('5','OutputFile','File 2','2','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('6','OutputFile','File 3','4','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('7','OutputFile','File 4','8','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('8','OutputFile','File 5','16','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('9','OutputFile','File 6','32','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('10','OutputFile','File 7','64','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('12','Delimiter','No Delimiter','0','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('13','Delimiter','Delimiter 1','1','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('14','Delimiter','Delimiter 2','2','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('15','Delimiter','Delimiter 3','3','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('16','Delimiter','Delimiter 4','4','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('17','Delimiter','Delimiter 5','5','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('18','Delimiter','Delimiter 6','6','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('19','Delimiter','Delimiter 7','7','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('20','DataSign','Beginning','1','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('21','Datasign','Ending','2','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('22','DataSign','Parentheses','3','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('23','DataSign','Absolute','4','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('24','DataSign','No Change','5','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('25','DataType','Decimal number (unsigned)','R','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('26','DataType','Decimal number (signed)','S','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('27','DataType','Decimal number (packed, signed)','P','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('28','DataType','Floating point number','F','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('29','DataType','Binary number','B','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('30','DataType','Date (characters)','D','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('31','DataType','Date (binary form)','C','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('32','DataType','Date (packed form)','#','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('33','DataType','Number with explicit decimal point','E','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('34','DateFormat','MMDDYY (123197)','0','MDY')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('35','DateFormat','MMDDYYYY (12311997)','7','MDCY')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('36','DateFormat','YYMMDD (971231)','1','YMD')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('37','DateFormat','YYYYMMDD (19971231)','2','CYMD')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('38','DateFormat','YYMM (9712)','5','YM')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('39','DateFormat','MMYY (1297)','6','MY')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('40','DateFormat','YYDDD (97365)','3','YD')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('41','DateFormat','YYYYDDD (1997365)','4','CYD')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('42','DateFormat','Days from 1/1/1900','8','WK1')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('43','DateFormat','DDMMYYYY (31121997)','9','DMCY')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('44','DataType','Interval (M001 or Q002)','I','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('45','SourceType','Ambit System Fields','B','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('47','SourceType','Application Record','A','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('48','SourceType','Intermediate Fields','I','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('49','SourceType','External Table Record','T','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('50','SourceType','Bypassed Record','U','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('52','SourceType','Global Fields','G','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('53','SourceType','Header Record','H','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('97','DataType','Integer (unsigned)','N','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('98','DateFormat','None','','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('54','Schedule','Convergence Predefined Time Interval','1','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('55','Schedule','ALPS Predefined Time Interval','2','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('56','Schedule','Sendero Predefined Time Interval','3','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('57','ScheOrient','Horizontal String','1','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('58','ScheOrient','Horizontal Split String','2','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('59','ScheOrient','Horizontal Block','3','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('60','ScheOrient','Horizontal Split Block','4','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('61','ScheOrient','Vertical Block','5','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('62','ScheOrient','Vertical Split Block','6','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('63','ScheOrient','Vertical String','7','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('66','Sign','Beginning','B','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('67','Sign','End','E','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('68','Sign','Parentheses','P','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('69','Sign','Absolute','A','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('70','Sign','No Change','N','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('72','IntervalType','Over Night','O','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('73','IntervalType','Remainder Of Month','R','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('74','IntervalType','Day','D','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('75','IntervalType','Week','W','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('76','IntervalType','Month','M','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('77','IntervalType','Quarter','Q','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('78','IntervalType','Year','Y','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('79','IntervalType','Print Subtotal','P','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('80','IntervalType','Subtotal n Preceeding Intervals','S','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('81','IntervalType','Grand Total','G','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('82','ExportControl','SUB_SYSTEM','C','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('83','ExportControl','INPUT_RECORD','D','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('84','ExportControl','SOURCE_FIELD','F','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('85','ExportControl','TRANSFORMS','H','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('86','ExportControl','TRANSFORM_VALUE','L','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('87','ExportControl','REPORT','I','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('88','ExportControl','CATEGORY','J','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('89','ExportControl','OUTPUT_RECORD','K','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('90','ExportControl','MM_SCHEDULE','M','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('91','ExportControl','OUTPUT_FIELD','N','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('92','ExportControl','VALUE','G','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('99','DayType','Calendar Day','C','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('100','DayType','Business Day','B','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('101','AmortType','Level Payment','P&I','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('102','AmortType','Fixed prin. Interest added','P+I','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('103','StatusType','Active Account','ACT','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('104','StatusType','Frozen Account','FZN','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('105','StatusType','Non accruing Account','NON','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('106','StatusType','Foreclosed Account','FCL','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('107','StatusType','Charged Off Account','CGO','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('108','StatusType','Alert Account','ALT','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('109','StatusType','New Account Not Yet Active','NEW','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('110','StatusType','Closed Account','CLS','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('111','StatusType','Matured Account','MAT','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('112','StatusType','Undefined','@@@','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('113','AccountType','Asset','A','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('114','AccountType','Liability','L','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('115','IntervalType1','Months','M','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('116','IntervalType1','Days','D','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('117','IntervalType1','Rounded','R','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('118','IntervalType1','Truncated','T','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('119','AccrualType','30 over 360','00','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('120','AccrualType','30 over 365','05','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('121','AccrualType','30 over Actual','0A','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('122','AccrualType','Actual over Actual','AA','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('123','AccrualType','Actual over 360','A0','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('124','AccrualType','Actual over 365','A5','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('125','AccrualType','Undefined','@@','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('128','PeriodType','Month','M','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('129','PeriodType','Year','Y','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('132','RateType','Percent','P','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('133','RateType','Rate','R','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('134','IntervalType','Actual Processing Date','A','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('135','AmortType','Principal','PRN','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('136','AmortType','Interest','INT','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('137','AmortType','Maturity','MAT','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('138','ExportControl','TEMPLATE_LINK','O','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('139','FundType','Cash Flow Funding','1','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('140','FundType','Yield Curve Point','2','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('141','FundType','Use Rate in Record','3','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('142','FundType','Maturity Date From Duration','4','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('143','FundType','Time Wtd Cash Flow','5','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('146','OrigOrCurBal','Current Balance','C','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('147','OrigOrCurBal','Original Balance','O','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('148','InterpolateType','SubSystem default method','0','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('149','InterpolateType','Nearest Date','1','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('150','InterpolateType','Linear (straight line between dates)','2','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('151','ExportControl','DATASOURCE_CONNECTION','Q','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('152','ExportControl','JOINS','R','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('153','ExportControl','DBTABLINKS','S','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('154','ExportControl','DATASOURCE_LINKS','T','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('155','IntervalType1','Business Days','B','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('156','ScheduleType','Repricing Balance Schedule','R','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('157','ScheduleType','Principal Cash Flow Schedule','P','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('158','ExportControl','FOLDERS','A','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('159','ExportControl','FOLDERLINKS','B','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('160','ExportControl','MM_FIELDFOLDER','E','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('161','FundType','Average Life','6','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('162','PRFundType','Cash Flow Funding','1','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('163','PRFundType','Yield Curve Point','2','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('164','PRFundType','Use Rate in Record','3','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('165','PRFundType','Time Weighted Cash Flow','5','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('166','LockedUnlocked','Locked','L','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('167','LockedUnlocked','UnLocked','U','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('168','LIQFundType','Cash Flow Funding','1','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])       VALUES('169','LIQFundType','Yield Curve Point','2','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])		 VALUES('170','ExportControl','BW_DBID','P','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])		 VALUES('171','ExportControl','USERS','U','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])		 VALUES('172','ExportControl','SECURITY','V','')

INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])		 VALUES('173','TrimOption','No','N','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])		 VALUES('174','TrimOption','Yes','Y','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])		 VALUES('175','TrimOption','Left Trim Only','L','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])		 VALUES('176','TrimOption','Right Trim Only','R','')

INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])		 VALUES('177','Justification','Left','L','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])		 VALUES('178','Justification','Center','C','')
INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value])		 VALUES('179','Justification','Right','R','')



END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[OPTION_LISTS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
IF NOT EXISTS(SELECT * FROM OPTION_LISTS WHERE [list_entry]='BW_DBID' AND [list_id] = 'ExportControl')
	INSERT OPTION_LISTS([index],[list_id],[list_entry],[list_value],[extra_value]) VALUES('161','ExportControl','BW_DBID','P','')

UPDATE OPTION_LISTS SET [list_value] = 'Q' WHERE [list_id] = 'ExportControl' AND [list_entry] = 'DATASOURCE_CONNECTION'
UPDATE OPTION_LISTS SET [list_value] = 'R' WHERE [list_id] = 'ExportControl' AND [list_entry] = 'JOINS'
UPDATE OPTION_LISTS SET [list_value] = 'S' WHERE [list_id] = 'ExportControl' AND [list_entry] = 'DBTABLINKS'
UPDATE OPTION_LISTS SET [list_value] = 'T' WHERE [list_id] = 'ExportControl' AND [list_entry] = 'DATASOURCE_LINKS'
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[OPTION_LISTS]') AND name = N'List_id')
CREATE NONCLUSTERED INDEX [List_id] ON [dbo].[OPTION_LISTS] 
(
    [list_id] ASC
) ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CATEGORY]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[CATEGORY](
    [report_index] [int] NOT NULL DEFAULT ((0)),
    [level] [smallint] NULL DEFAULT ((0)),
    [category_number] [smallint] NULL DEFAULT ((0)),
    [group_id] [int] NULL DEFAULT ((0)),
    [transform_id] [int] NOT NULL DEFAULT ((0)),
    [assigned] [bit] NOT NULL DEFAULT ((0)),
    [name] [nvarchar](255)  NULL,
    [name_translation] [nvarchar](255)  NULL,
    [description] [nvarchar](255)  NULL,
    [description_translation] [nvarchar](255)  NULL,
    [sort_direction] [nvarchar](1)  NULL,
    [type] [nvarchar](1)  NULL,
    [include_exclude] [nvarchar](1)  NULL,
    [detail_desired] [nvarchar](1)  NULL,
    [exception] [nvarchar](1)  NULL,
    [separate_category] [nvarchar](1)  NULL,
    [prepayment] [real] NULL DEFAULT ((0)),
    [version] [int] NULL DEFAULT ((0)),
    [PKey] [int] NOT NULL,
 CONSTRAINT [PK_CATEGORY] PRIMARY KEY CLUSTERED 
(
    [PKey] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CATEGORY]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[CATEGORY]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_CATEGORY_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_CATEGORY_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_CATEGORY_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_CATEGORY_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[CATEGORY]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[CATEGORY]') AND name = N'PKey') 
		BEGIN
			ALTER TABLE [dbo].[CATEGORY] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[CATEGORY] SET temporary = PKey')
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'PK_CATEGORY'))
				ALTER TABLE [dbo].[CATEGORY] DROP Constraint PK_CATEGORY; 
			ALTER TABLE [dbo].[CATEGORY] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[CATEGORY] DROP COLUMN PKey; 
			EXEC sp_rename '[dbo].[CATEGORY].temporary', 'PKey', 'COLUMN'; 
			ALTER TABLE [dbo].[CATEGORY] ADD CONSTRAINT PK_CATEGORY PRIMARY KEY(PKey); 
		END 
	END
END	

GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[CATEGORY]') AND name = N'Report_index')
CREATE NONCLUSTERED INDEX [Report_index] ON [dbo].[CATEGORY] 
(
    [report_index] ASC
) ON [PRIMARY]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_CATEGORY_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_CATEGORY_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_CATEGORY_INSERT] 
   ON  [dbo].[CATEGORY] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''CATEGORY''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''PKey=''+convert(nvarchar(15),NEW.PKey),

                (''PKey=''+convert(nvarchar(15),NEW.PKey)+''|#''+
                ''report_index=''+convert(nvarchar(15),NEW.report_index)+''|#''+
                ''category_number=''+ISNULL(convert(nvarchar(15),NEW.category_number),'''')+''|#''+
                ''[level]=''+ISNULL(convert(nvarchar(15),NEW.[level]),'''')+''|#''+
                ''group_id=''+ISNULL(convert(nvarchar(15),NEW.group_id),'''')+''|#''+
                ''transform_id=''+ISNULL(convert(nvarchar(15),NEW.transform_id),'''')+''|#''+
                ''assigned=''+convert(nvarchar(1),NEW.assigned)+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''name_translation=''+''''''''+ISNULL(Replace(NEW.name_translation,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(NEW.description,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description_translation=''+''''''''+ISNULL(Replace(NEW.description_translation,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''sort_direction=''+''''''''+ISNULL(Replace(NEW.sort_direction,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+''''''''+ISNULL(Replace(NEW.[type],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''include_exclude=''+''''''''+ISNULL(Replace(NEW.include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''detail_desired=''+''''''''+ISNULL(Replace(NEW.detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''separate_category=''+''''''''+ISNULL(Replace(NEW.separate_category,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(NEW.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''prepayment=''+ISNULL(convert(nvarchar(50),NEW.prepayment),'''')+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''')) from INSERTED NEW;
END
END



' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_CATEGORY_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_CATEGORY_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_CATEGORY_UPDATE] 
   ON  [dbo].[CATEGORY] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''CATEGORY''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END
--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''report_index=''+convert(nvarchar(15),OLD.report_index)+''|#''+
                ''category_number=''+ISNULL(convert(nvarchar(15),OLD.category_number),'''')+''|#''+
                ''[level]=''+ISNULL(convert(nvarchar(15),OLD.[level]),'''')+''|#''+
                ''group_id=''+ISNULL(convert(nvarchar(15),OLD.group_id),'''')+''|#''+
                ''transform_id=''+ISNULL(convert(nvarchar(15),OLD.transform_id),'''')+''|#''+
                ''assigned=''+convert(nvarchar(1),OLD.assigned)+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''name_translation=''+''''''''+ISNULL(Replace(OLD.name_translation,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(OLD.description,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description_translation=''+''''''''+ISNULL(Replace(OLD.description_translation,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''sort_direction=''+''''''''+ISNULL(Replace(OLD.sort_direction,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+''''''''+ISNULL(Replace(OLD.[type],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''include_exclude=''+''''''''+ISNULL(Replace(OLD.include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''detail_desired=''+''''''''+ISNULL(Replace(OLD.detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''separate_category=''+''''''''+ISNULL(Replace(OLD.separate_category,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(OLD.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''prepayment=''+ISNULL(convert(nvarchar(50),OLD.prepayment),'''')+''|#''+                
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''')+
                '' where ''+''PKey=''+convert(nvarchar(15),OLD.PKey),
                 
                ''report_index=''+convert(nvarchar(15),NEW.report_index)+''|#''+
                ''category_number=''+ISNULL(convert(nvarchar(15),NEW.category_number),'''')+''|#''+
                ''[level]=''+ISNULL(convert(nvarchar(15),NEW.[level]),'''')+''|#''+
                ''group_id=''+ISNULL(convert(nvarchar(15),NEW.group_id),'''')+''|#''+
                ''transform_id=''+ISNULL(convert(nvarchar(15),NEW.transform_id),'''')+''|#''+
                ''assigned=''+convert(nvarchar(1),NEW.assigned)+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''name_translation=''+''''''''+ISNULL(Replace(NEW.name_translation,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(NEW.description,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description_translation=''+''''''''+ISNULL(Replace(NEW.description_translation,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''sort_direction=''+''''''''+ISNULL(Replace(NEW.sort_direction,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+''''''''+ISNULL(Replace(NEW.[type],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''include_exclude=''+''''''''+ISNULL(Replace(NEW.include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''detail_desired=''+''''''''+ISNULL(Replace(NEW.detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''separate_category=''+''''''''+ISNULL(Replace(NEW.separate_category,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(NEW.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''prepayment=''+ISNULL(convert(nvarchar(50),NEW.prepayment),'''')+''|#''+                
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''')+
                '' where ''+''PKey=''+convert(nvarchar(15),OLD.PKey)
          from DELETED OLD,INSERTED NEW where NEW.PKey = OLD.PKey;

END
--update the field in CATEGORY table
UPDATE dbo.CATEGORY
SET report_index=NEW.report_index,
    category_number=NEW.category_number,
    [level]=NEW.[level],
    group_id=NEW.group_id,
    transform_id=NEW.transform_id,
    assigned=NEW.assigned,
    [name]=NEW.[name],
    name_translation=NEW.name_translation,
    description=NEW.description,
    description_translation=NEW.description_translation,
    sort_direction=NEW.sort_direction,
    [type]=NEW.[type],
    include_exclude=NEW.include_exclude,
    detail_desired=NEW.detail_desired,
    separate_category=NEW.separate_category,
    exception=NEW.exception,
    prepayment=NEW.prepayment,
    version=NEW.version
    from INSERTED NEW 
    where CATEGORY.PKey = NEW.PKey
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''PKey=''+convert(nvarchar(15),OLD.PKey)+''|#''+
                ''report_index=''+convert(nvarchar(15),OLD.report_index)+''|#''+
                ''category_number=''+ISNULL(convert(nvarchar(15),OLD.category_number),'''')+''|#''+
                ''[level]=''+ISNULL(convert(nvarchar(15),OLD.[level]),'''')+''|#''+
                ''group_id=''+ISNULL(convert(nvarchar(15),OLD.group_id),'''')+''|#''+
                ''transform_id=''+ISNULL(convert(nvarchar(15),OLD.transform_id),'''')+''|#''+
                ''assigned=''+convert(nvarchar(1),OLD.assigned)+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''name_translation=''+''''''''+ISNULL(Replace(OLD.name_translation,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(OLD.description,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description_translation=''+''''''''+ISNULL(Replace(OLD.description_translation,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''sort_direction=''+''''''''+ISNULL(Replace(OLD.sort_direction,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+''''''''+ISNULL(Replace(OLD.[type],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''include_exclude=''+''''''''+ISNULL(Replace(OLD.include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''detail_desired=''+''''''''+ISNULL(Replace(OLD.detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''separate_category=''+''''''''+ISNULL(Replace(OLD.separate_category,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(OLD.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''prepayment=''+ISNULL(convert(nvarchar(50),OLD.prepayment),'''')+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),''''),
                
                ''PKey=''+convert(nvarchar(15),OLD.PKey)

                from DELETED OLD;
end
--Delete the field from CATEGORY table
DELETE FROM CATEGORY 
FROM CATEGORY where PKey in(SELECT PKey from DELETED);
END



' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[JOBS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[JOBS](
    [id] [int] NOT NULL,
    [type] [nvarchar](70)  NOT NULL,
    [name] [nvarchar](350)  NOT NULL,
    [description] [ntext]  NULL,
    [statusdescription] [ntext]  NULL,
    [status] [int] NOT NULL CONSTRAINT [DF_JOBS_status]  DEFAULT ((1)),
    [completionextrainfo] [ntext]  NULL,
	[errorinfo] [ntext]  NULL,
 CONSTRAINT [PK_Jobs] PRIMARY KEY CLUSTERED 
(
    [id] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[JOBS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[JOBS]') AND name = N'errorinfo')
		ALTER TABLE [dbo].[JOBS] ADD [errorinfo] [ntext]  NULL
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DF_JOBS_statusdescription]') AND type = 'D')
ALTER TABLE [dbo].[JOBS] DROP CONSTRAINT [DF_JOBS_statusdescription];
GO

IF EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[JOBS]') AND name = N'statusdescription' AND xtype <> 99)
ALTER TABLE [dbo].[JOBS] ALTER COLUMN statusdescription [ntext]; 
GO

IF EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[JOBS]') AND name = N'completionextrainfo' AND xtype <> 99)
ALTER TABLE [dbo].[JOBS] ALTER COLUMN completionextrainfo [ntext]; 
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[JOBS]') AND name = N'name')
CREATE UNIQUE NONCLUSTERED INDEX [name] ON [dbo].[JOBS] 
(
    [name] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[JOBS]') AND name = N'Type')
CREATE NONCLUSTERED INDEX [Type] ON [dbo].[JOBS] 
(
    [type] ASC
) ON [PRIMARY]

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[JOBS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[JOBS]'),'TableHasIdentity') = 1 
	BEGIN
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[JOBS]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[JOBS]') AND name = N'id') 
		BEGIN
			ALTER TABLE [dbo].[JOBS] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[JOBS] SET temporary = id') 
		
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'F' AND id = OBJECT_ID(N'FK_JobID_ID'))
				ALTER TABLE [dbo].[JOBLINKS] DROP Constraint FK_JobID_ID; 
			
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'F' AND id = OBJECT_ID(N'FK_Parameters_Jobs'))
				ALTER TABLE [dbo].[PARAMETERS] DROP Constraint FK_Parameters_Jobs; 
				
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'F' AND id = OBJECT_ID(N'FK_Schedule_Jobs'))
				ALTER TABLE [dbo].[SCHEDULE] DROP Constraint FK_Schedule_Jobs; 
			
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'F' AND id = OBJECT_ID(N'FK_Status_Jobs'))
				ALTER TABLE [dbo].[STATUS] DROP Constraint FK_Status_Jobs; 
				
				
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'PK_Jobs'))
				ALTER TABLE [dbo].[JOBS] DROP Constraint PK_Jobs; 
				
			ALTER TABLE [dbo].[JOBS] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[JOBS] DROP COLUMN id; 
			EXEC sp_rename '[dbo].[JOBS].temporary', 'id', 'COLUMN';
			ALTER TABLE [dbo].[JOBS] ADD CONSTRAINT PK_Jobs PRIMARY KEY(id);
			
			
			ALTER TABLE [dbo].[JOBLINKS]  WITH NOCHECK ADD  CONSTRAINT [FK_JobID_ID] FOREIGN KEY([jobid])
				REFERENCES [dbo].[JOBS] ([id])
			ALTER TABLE [dbo].[JOBLINKS] CHECK CONSTRAINT [FK_JobID_ID]
			
			ALTER TABLE [dbo].[PARAMETERS]  WITH NOCHECK ADD  CONSTRAINT [FK_Parameters_Jobs] FOREIGN KEY([jobid])
				REFERENCES [dbo].[JOBS] ([id])
			ALTER TABLE [dbo].[PARAMETERS] CHECK CONSTRAINT [FK_Parameters_Jobs]
			
			ALTER TABLE [dbo].[SCHEDULE]  WITH NOCHECK ADD  CONSTRAINT [FK_Schedule_Jobs] FOREIGN KEY([jobid])
				REFERENCES [dbo].[JOBS] ([id])ON UPDATE CASCADE ON DELETE CASCADE
			ALTER TABLE [dbo].[SCHEDULE] CHECK CONSTRAINT [FK_Schedule_Jobs]
			
			ALTER TABLE [dbo].[STATUS]  WITH NOCHECK ADD  CONSTRAINT [FK_Status_Jobs] FOREIGN KEY([jobid])
				REFERENCES [dbo].[JOBS] ([id])ON UPDATE CASCADE ON DELETE CASCADE
			ALTER TABLE [dbo].[STATUS] CHECK CONSTRAINT [FK_Status_Jobs]
			
		END 
	END
END





GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_JOBS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_JOBS_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_JOBS_INSERT] 
   ON  [dbo].[JOBS] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''JOBS''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''id=''+convert(nvarchar(15),NEW.id),
                (''id=''+convert(nvarchar(15),NEW.id)+''|#''+
                ''type=''+''''''''+NEW.type+''''''''+''|#''+
                ''name=''+''''''''+NEW.name+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(ORG.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''statusdescription=''+''''''''+ISNULL(Replace(cast(ORG.statusdescription as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''status=''+convert(nvarchar(15),NEW.status)+''|#''+
                ''completionextrainfo=''+''''''''+ISNULL(Replace(cast(ORG.completionextrainfo as nvarchar(MAX)),'''''''',''''''''''''),'''')+'''''''')from INSERTED NEW,JOBS ORG
where ORG.id = NEW.id;

END
END

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_JOBS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_JOBS_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_JOBS_UPDATE] 
   ON  [dbo].[JOBS] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @modifiedColumns int,
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''JOBS''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END
	
	SET @modifiedColumns = COLUMNS_UPDATED()
--UPDATE
if(@actionval = 2)
BEGIN
if(@modifiedColumns & 15)> 0
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''type=''+''''''''+OLD.type+''''''''+''|#''+
                ''name=''+''''''''+OLD.name+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''statusdescription=''+''''''''+ISNULL(Replace(cast(OLD.statusdescription as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''status=''+convert(nvarchar(15),OLD.status)+''|#''+
                ''completionextrainfo=''+''''''''+ISNULL(Replace(cast(OLD.completionextrainfo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+
				'' WHERE ''+''id=''+convert(nvarchar(15),OLD.id),

                ''type=''+''''''''+NEW.type+''''''''+''|#''+
                ''name=''+''''''''+NEW.name+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(NEW.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''statusdescription=''+''''''''+ISNULL(Replace(cast(NEW.statusdescription as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''status=''+convert(nvarchar(15),NEW.status)+''|#''+
                ''completionextrainfo=''+''''''''+ISNULL(Replace(cast(NEW.completionextrainfo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+
                '' WHERE ''+''id=''+convert(nvarchar(15),NEW.id) from DELETED OLD,INSERTED NEW
				where NEW.id = OLD.id;
end
END
--update the field in JOBS table
UPDATE dbo.JOBS
SET type=NEW.type,
    name=NEW.name,
    description=NEW.description,
    statusdescription=NEW.statusdescription,
    status=NEW.status,
    completionextrainfo=NEW.completionextrainfo,
	errorinfo=NEW.errorinfo
    from INSERTED NEW
    where JOBS.id in (NEW.id);
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''type=''+''''''''+OLD.type+''''''''+''|#''+
                ''name=''+''''''''+OLD.name+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''statusdescription=''+''''''''+ISNULL(Replace(cast(OLD.statusdescription as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''status=''+convert(nvarchar(15),OLD.status)+''|#''+
                ''completionextrainfo=''+''''''''+ISNULL(Replace(cast(OLD.completionextrainfo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''id=''+convert(nvarchar(15),OLD.id),
				''id=''+convert(nvarchar(15),OLD.id) from DELETED OLD;
end
--Delete the field from JOBS table
DELETE FROM JOBS where id in (SELECT OLD.id from DELETED OLD);
END
'
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[OUTPUT_RECORD]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[OUTPUT_RECORD](
    [index] [int] NOT NULL,
    [report_index] [int] NULL DEFAULT ((0)),
    [name] [nvarchar](255)  NULL,
    [type] [smallint] NOT NULL DEFAULT ((0)),
    [mask] [bit] NOT NULL DEFAULT ((0)),
    [delimiter] [smallint] NULL DEFAULT ((0)),
    [output_file] [smallint] NULL DEFAULT ((0)),
    [version] [int] NULL DEFAULT ((0)),
    [delete] [bit] NOT NULL DEFAULT ((0)),
    [page_break] [bit] NOT NULL DEFAULT ((0)),
    [output_filename] [nvarchar](255)  NULL,
    [ignore_record_index] [int] NULL DEFAULT ((0)),
 CONSTRAINT [aaaaaOUTPUT_RECORD_PK] PRIMARY KEY NONCLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[OUTPUT_RECORD]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[OUTPUT_RECORD]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_OUTPUT_RECORD_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_OUTPUT_RECORD_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_OUTPUT_RECORD_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_OUTPUT_RECORD_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[OUTPUT_RECORD]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[OUTPUT_RECORD]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[OUTPUT_RECORD] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[OUTPUT_RECORD] SET temporary = [index]') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'aaaaaOUTPUT_RECORD_PK'))
				ALTER TABLE [dbo].[OUTPUT_RECORD] DROP Constraint aaaaaOUTPUT_RECORD_PK; 
			ALTER TABLE [dbo].[OUTPUT_RECORD] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[OUTPUT_RECORD] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[OUTPUT_RECORD].temporary', 'index', 'COLUMN';
			ALTER TABLE [dbo].[OUTPUT_RECORD] ADD CONSTRAINT aaaaaOUTPUT_RECORD_PK PRIMARY KEY([index]);  
		END 
	END
END	

GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_OUTPUT_RECORD_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_OUTPUT_RECORD_INSERT]
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_OUTPUT_RECORD_INSERT] 
   ON  [dbo].[OUTPUT_RECORD] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''OUTPUT_RECORD''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),NEW.[index]),

                (''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''report_index=''+ISNULL(convert(nvarchar(15),NEW.report_index),'''')+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+convert(nvarchar(15),NEW.[type])+''|#''+
                ''mask=''+convert(nvarchar(1),NEW.mask)+''|#''+
                ''delimiter=''+ISNULL(convert(nvarchar(15),NEW.delimiter),'''')+''|#''+
                ''output_file=''+ISNULL(convert(nvarchar(15),NEW.output_file),'''')+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''')+''|#''+
                ''[delete]=''+convert(nvarchar(1),NEW.[delete])+''|#''+
                ''page_break=''+convert(nvarchar(1),NEW.page_break)+''|#''+
                ''output_filename=''+''''''''+ISNULL(Replace(NEW.output_filename,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''ignore_record_index=''+ISNULL(convert(nvarchar(15),NEW.ignore_record_index),'''')) from INSERTED NEW;
END
END





' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_OUTPUT_RECORD_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_OUTPUT_RECORD_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_OUTPUT_RECORD_UPDATE] 
   ON  [dbo].[OUTPUT_RECORD] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''OUTPUT_RECORD''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END
--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),OLD.[index])+''|#''+
                ''report_index=''+ISNULL(convert(nvarchar(15),OLD.report_index),'''')+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+convert(nvarchar(15),OLD.[type])+''|#''+
                ''mask=''+convert(nvarchar(1),OLD.mask)+''|#''+
                ''delimiter=''+ISNULL(convert(nvarchar(15),OLD.delimiter),'''')+''|#''+
                ''output_file=''+ISNULL(convert(nvarchar(15),OLD.output_file),'''')+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''')+''|#''+
                ''[delete]=''+convert(nvarchar(1),OLD.[delete])+''|#''+
                ''page_break=''+convert(nvarchar(1),OLD.page_break)+''|#''+
                ''output_filename=''+''''''''+ISNULL(Replace(OLD.output_filename,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''ignore_record_index=''+ISNULL(convert(nvarchar(15),OLD.ignore_record_index),'''')+
                '' where ''+''[index]=''+convert(nvarchar(15),OLD.[index]),
                 
                ''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''report_index=''+ISNULL(convert(nvarchar(15),NEW.report_index),'''')+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+convert(nvarchar(15),NEW.[type])+''|#''+
                ''mask=''+convert(nvarchar(1),NEW.mask)+''|#''+
                ''delimiter=''+ISNULL(convert(nvarchar(15),NEW.delimiter),'''')+''|#''+
                ''output_file=''+ISNULL(convert(nvarchar(15),NEW.output_file),'''')+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''')+''|#''+
                ''[delete]=''+convert(nvarchar(1),NEW.[delete])+''|#''+
                ''page_break=''+convert(nvarchar(1),NEW.page_break)+''|#''+
                ''output_filename=''+''''''''+ISNULL(Replace(NEW.output_filename,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''ignore_record_index=''+ISNULL(convert(nvarchar(15),NEW.ignore_record_index),'''')+
                '' where ''+''[index]=''+convert(nvarchar(15),NEW.[index])
          from DELETED OLD,INSERTED NEW
where OLD.[index] = NEW.[index];
END
--update the field in CATEGORY table
UPDATE dbo.OUTPUT_RECORD
SET report_index=NEW.report_index,
    [name]=NEW.[name],
    [type]=NEW.[type],
    mask=NEW.mask,
    delimiter=NEW.delimiter,
    output_file=NEW.output_file,
    version=NEW.version,
    [delete]=NEW.[delete],
    page_break=NEW.page_break,
    output_filename=NEW.output_filename,
    ignore_record_index=NEW.ignore_record_index
    from INSERTED NEW 
    where OUTPUT_RECORD.[index] = NEW.[index];
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),OLD.[index])+''|#''+
                ''report_index=''+ISNULL(convert(nvarchar(15),OLD.report_index),'''')+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+convert(nvarchar(15),OLD.[type])+''|#''+
                ''mask=''+convert(nvarchar(1),OLD.mask)+''|#''+
                ''delimiter=''+ISNULL(convert(nvarchar(15),OLD.delimiter),'''')+''|#''+
                ''output_file=''+ISNULL(convert(nvarchar(15),OLD.output_file),'''')+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''')+''|#''+
                ''[delete]=''+convert(nvarchar(1),OLD.[delete])+''|#''+
                ''page_break=''+convert(nvarchar(1),OLD.page_break)+''|#''+
                ''output_filename=''+''''''''+ISNULL(Replace(OLD.output_filename,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''ignore_record_index=''+ISNULL(convert(nvarchar(15),OLD.ignore_record_index),''''),

                ''[index]=''+convert(nvarchar(15),OLD.[index]) 
                from DELETED OLD;
end
--Delete the field from CATEGORY table
DELETE FROM OUTPUT_RECORD 
FROM OUTPUT_RECORD where [index] in (SELECT [index] from DELETED)
END



set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[XREF]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[XREF](
    [fieldindex] [int] NULL DEFAULT ((0)),
    [fieldname] [nvarchar](255)  NULL,
    [objectid] [int] NULL DEFAULT ((0)),
    [objectname] [nvarchar](255)  NULL,
    [objecttype] [nvarchar](2)  NULL,
    [usage] [nvarchar](10)  NULL,
    [order] [int] NULL DEFAULT ((0)),
    [PKey] [int] NOT NULL,
 CONSTRAINT [PK_XREF] PRIMARY KEY CLUSTERED 
(
    [PKey] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[XREF]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[XREF]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_XREF_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_XREF_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_XREF_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_XREF_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[XREF]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[XREF]') AND name = N'PKey') 
		BEGIN
			ALTER TABLE [dbo].[XREF] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[XREF] SET temporary = PKey')
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'PK_XREF'))
				ALTER TABLE [dbo].[XREF] DROP Constraint PK_XREF; 
			ALTER TABLE [dbo].[XREF] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[XREF] DROP COLUMN PKey; 
			EXEC sp_rename '[dbo].[XREF].temporary', 'PKey', 'COLUMN'; 
			ALTER TABLE [dbo].[XREF] ADD CONSTRAINT PK_XREF PRIMARY KEY(PKey); 
		END 
	END
END	

GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_XREF_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_XREF_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_XREF_INSERT] 
   ON  [dbo].[XREF] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''XREF''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''PKey=''+convert(nvarchar(15),NEW.PKey),

                (''PKey=''+convert(nvarchar(15),NEW.PKey)+''|#''+
                ''fieldindex=''+ISNULL(convert(nvarchar(15),NEW.fieldindex),'''')+''|#''+
                ''fieldname=''+''''''''+ISNULL(Replace(NEW.fieldname,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''objectid=''+ISNULL(convert(nvarchar(15),NEW.objectid),'''')+''|#''+
                ''objectname=''+''''''''+ISNULL(Replace(NEW.objectname,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''objecttype=''+''''''''+ISNULL(Replace(NEW.objecttype,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''usage=''+''''''''+ISNULL(Replace(NEW.usage,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[order]=''+ISNULL(convert(nvarchar(15),NEW.[order]),'''')) from INSERTED NEW;
END
END






' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_XREF_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_XREF_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_XREF_UPDATE] 
   ON  [dbo].[XREF] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @modifiedColumns int,
    @user_name nvarchar(255)
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''XREF''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END
--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''fieldindex=''+ISNULL(convert(nvarchar(15),OLD.fieldindex),'''')+''|#''+
                ''fieldname=''+''''''''+ISNULL(Replace(OLD.fieldname,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''objectid=''+ISNULL(convert(nvarchar(15),OLD.objectid),'''')+''|#''+
                ''objectname=''+''''''''+ISNULL(Replace(OLD.objectname,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''objecttype=''+''''''''+ISNULL(Replace(OLD.objecttype,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''usage=''+''''''''+ISNULL(Replace(OLD.usage,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[order]=''+ISNULL(convert(nvarchar(15),OLD.[order]),'''')+
                '' where ''+''PKey=''+convert(nvarchar(15),OLD.PKey),
                 
                ''fieldindex=''+ISNULL(convert(nvarchar(15),NEW.fieldindex),'''')+''|#''+
                ''fieldname=''+''''''''+ISNULL(Replace(NEW.fieldname,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''objectid=''+ISNULL(convert(nvarchar(15),NEW.objectid),'''')+''|#''+
                ''objectname=''+''''''''+ISNULL(Replace(NEW.objectname,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''objecttype=''+''''''''+ISNULL(Replace(NEW.objecttype,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''usage=''+''''''''+ISNULL(Replace(NEW.usage,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[order]=''+ISNULL(convert(nvarchar(15),NEW.[order]),'''')+
                '' where ''+''PKey=''+convert(nvarchar(15),NEW.PKey)
          from DELETED OLD,INSERTED NEW
where OLD.PKey = NEW.PKey;
END
--update the field in CATEGORY table
UPDATE dbo.XREF
SET fieldname=NEW.fieldname,
    fieldindex=NEW.fieldindex,
    objectid=NEW.objectid,
    objectname=NEW.objectname,
    objecttype=NEW.objecttype,
    usage=NEW.usage,
    [order]=NEW.[order]
    from INSERTED NEW 
    where XREF.PKey = NEW.PKey;
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''PKey=''+convert(nvarchar(15),OLD.PKey)+''|#''+
                ''fieldindex=''+ISNULL(convert(nvarchar(15),OLD.fieldindex),'''')+''|#''+
                ''fieldname=''+''''''''+ISNULL(Replace(OLD.fieldname,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''objectid=''+ISNULL(convert(nvarchar(15),OLD.objectid),'''')+''|#''+
                ''objectname=''+''''''''+ISNULL(Replace(OLD.objectname,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''objecttype=''+''''''''+ISNULL(Replace(OLD.objecttype,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''usage=''+''''''''+ISNULL(Replace(OLD.usage,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[order]=''+ISNULL(convert(nvarchar(15),OLD.[order]),''''),

                ''PKey=''+convert(nvarchar(15),OLD.PKey)
                from DELETED OLD;
end
--Delete the field from XREF table
DELETE FROM XREF 
where PKey in (SELECT PKey from DELETED)
END






set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FUNCTION]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	DROP TABLE [dbo].[FUNCTION];

Go

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FUNCTION]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[FUNCTION](
    [function_number] [int] NOT NULL,
    [prompt] [nvarchar](255)  NULL,
    [version] [int] NULL,
    [data subtype id] [int] NULL,
    [order] [smallint] NULL,
    [name] [char](255)  NULL,
    [repeatstart] [int] NOT NULL DEFAULT ((0)),
    [repeatno] [int] NOT NULL DEFAULT ((0)),       
 CONSTRAINT [Function_Number] PRIMARY KEY CLUSTERED 
(
    [function_number] ASC
) ON [PRIMARY]
) ON [PRIMARY]

--INSERT Global Data for [FUNCTION] table

INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('1','Define result as function of values of input field combinations','1','25','1','Translation             ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('3','Date of the data to be processed','4','13','31','Processing Date         ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('4','The Day after Processing Date','4','13','32','Processing Date + 1     ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('5','The next business day after a specified relative date','4','13','48','Next Bus. Day           ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('6','Add two numbers or fields','6','20','61','Addition                ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('7','Subtract 1 number or field from another','6','20','62','Subtract                ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('8','Multiply two numbers or fields','6','20','63','Multiply                ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('9','Divide with rounded result','6','20','64','Divide (Round)         ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('10','Divide with result truncated to integer value','6','22','65','Divide (Integer)       ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('11','Result is remainder of specified division','6','22','66','Divide (Remainder)        ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('12','Integer exponentiation','6','20','67','Raise to power         ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('13','The result of adding n time intervals to the specified date','4','13','33','Date + n units         ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('14','The result of subtracting n time intervals from the specified date','4','13','34','Date - n units         ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('15','Number of Periods between two dates','4','20','35','Interval/2 dates       ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('16','The first date in dates which start at a given date occuring at specified frequency','4','13','36','Next date/unit,Date    ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('17','The last calendar or business day of the specified period','4','13','37','Last date/unit,Date    ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('18','First Calendar or Business day of calendar period following specified date','4','13','38','1st day next period    ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('19','Last Calendar or Business day of calendar period following specified date','4','13','39','last day next period   ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('20','First Calendar or Business day of  period of the specified date','4','13','40','1st day this period    ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('21','Last Calendar or Business day of  period of the specified date','4','13','41','last day this period   ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('22','First Calendar or Business day of the period prior to the specified date','4','13','42','1st day last period    ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('23','Last Calendar or Business day of the period prior to the specified date','4','13','43','last day last period   ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('24','Returns ''>'' if 1st > 2nd; ''='' if equal; or ''<''','3','12','50','Compare Numbers        ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('25','Returns ''>'' if 1st > 2nd; ''='' if equal; or ''<''','3','12','51','Compare Dates          ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('26','Returns ''>'' if 1st > 2nd; ''='' if equal; or ''<''','3','12','52','Compare Strings        ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('27','Funding rate, based on its funding index or repricing characteristics as returned from a user provided funding rate lookup table.','5','20','10','Funding Rate       ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('28','The number of days in the month of a specified date expression','4','22','44','Days in month          ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('29','The number of days in the year of a specified date expression','4','22','45','Days in year           ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('30','Annual accrual factor for period in which Starting-Date falls based on accrual method and accrual period.','5','20','11','Accrual factor         ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('31','Annual accrued amount for period in which Starting-Date falls based on accrual method and accrual period','5','20','12','Accrued Amount         ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('32','Define a constant as an intermediate field or redefine an existing field in a new format.','7','21','80','Literal/redefine       ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('33','Extract a string of characters from a longer string','7','12','81','Substring              ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('34','Put two strings together.','7','12','82','Concatenate strings    ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('35','Date on which the instrument would be paid off based on payment schedule without prepayments.','4','13','46','Amortization Date      ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('36','Amount to payoff instrument given current payment characteristics recorded in the UTF on input or output','5','20','13','Payment Amount         ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('37','The last business day before a specified relative date','4','13','47','Previous Bus.Day       ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('38','The yield to maturity based on instrument characteristics recorded in the UTF on input or output','5','20','14','Yield to maturity      ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('39','Result is found by table lookup','2','25','2','Lookup                 ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('40','Estimated original balance based on current balance and current payment characteristics','5','20','15','Original Balance       ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('41','Returns present value of the instrument based on user entered discount rate','5','20','16','Present Value          ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('42','Estimated time needed to recover outstanding principal balance on loan','5','20','17','Duration               ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('43','The Weighted Average Life term to maturity, based on the cash flow schedule.','5','20','18','Average Life           ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('44','Estimated average daily principal balance outstanding','5','20','19','Average Balance        ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('45','Calculates the fee paid by a borrower to a bank when a loan or mortgage that does not have a prepayment clause is repaid before its scheduled maturity.','5','20','21','Prepayment Penalty     ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('46','Specify a formula using number, fields, arithmetic operators (+/-*^), and parenthesis for grouping','6','20','60','Formula                ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('47','Estimated current balance outstanding','5','20','20','Current Balance        ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('48','The Weighted Average Life term to maturity, based on the cash flow schedule, including the effects of prepayments.','5','20','22','Prepay Average Life    ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('49','Define an external user function','8','25','83','User-Defined           ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('50','Remove leading & embedded blanks','7','25','84','STRLIB::deblank        ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('51','Concatenate strings, embed specified separator','7','25','85','STRLIB::concat         ','5','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('52','Concatenate sub strings and embed specified separator','7','25','86','STRLIB::concatsub      ','6','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('53','(Actual - scheduled) prin. pmt. schedule','5','28','87','AMBITBUDGET::ReprSched    ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('54','Annualized Interest * Balances Schedule','5','28','88','AMBITBUDGET::WtdRate      ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('55','Returns rightmost non-blank characters','7','25','89','STRLIB::right          ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('56','Returns schedule of compound interest accruals','5','28','90','LIQUIDITY::ComIntSch   ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('57','Future repricing balances - no rate change','5','28','91','AMBITBUDGET::FutureRepr   ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('58','Returns element having specified rank','6','25','92','MATHLIB::rank          ','4','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('59','Ordinal of items sorted by specified key fields','6','25','93','MATHLIB::sorteditemcount','3','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('60','Flexibly format number as string','7','12','94','STRLIB::number2str     ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('61','Flexibly format date as a string','7','12','95','STRLIB::date2str       ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('62','Remove specified leading & embedded  characters','7','12','96','STRLIB::deletechars    ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('63','Unlimited integer addition using numeric strings','6','12','97','BCDLIB::add            ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('64','Unlimited integer subtraction using numeric strings','6','12','98','BCDLIB::sub            ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('65','Unlimited integer multiplication using numeric strings','6','12','99','BCDLIB::mult           ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('66','Unlimited integer division using numeric strings','6','12','100','BCDLIB::div            ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('67','Unlimited integer div remainder using numeric strings','6','12','101','BCDLIB::remainder      ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('68','Result is found by database lookup','9','25','102','DBLIB::lookup          ','7','1')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('69','Insert values into table','9','25','103','DBLIB::insert          ','6','1')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('70','Ordinal of group sorted by specified key fields','6','25','104','MATHLIB::sortedgroupnumber                              ','3','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('71','Concatenate values by key field grouping','7','12','105','STRLIB::concatvert_ttl ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('72','Concat values by key field grouping. Show in Detail records.','7','12','105','STRLIB::concatvert_det ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('73','Get specified value from prior record.','7','25','105','STRLIB::getpriorvalue  ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('74','Natural log of a number','6','20','106','MATHLIB::ln            ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('75','Calculate the weighted rate array based on a group.','7','12','109','STRLIB::weightedrate_det','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('76','Compute Funding Rate from a provided Ambit Cashflow Schedule.','5','20','110','Funding Rate from Schedule                              ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('77','Funding rate, based on its funding index or repricing characteristics as returned from a user provided funding rate lookup table.','5','20','111','Periodic Repricer Funding       ','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('78','Non Maturity Deposits Funding Rate','5','20','112','Non Maturity Deposits Funding Rate','6','1')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('79','Contingent Liquidity Premium','5','20','113','Contingent Liquidity Premium','9','1')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('80','Liquidity Premium','5','20','114','Liquidity Premium','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('81','OAS Premium (ZSpread)','5','20','115','OAS Premium (ZSpread)','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('82','Calculate the weighted rate array based on a group.','7','12','116','STRLIB::weightedrate_ALM','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])		 VALUES('83','Remove specified leading & embedded strings', '7', '12', '96', 'STRLIB::deletestring','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('84','Get string length','7','22','117','STRLIB::len','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('85','Find specified string','7','12','118','STRLIB::find','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('86','Convert string to uppercase','7','12','119','STRLIB::toupper','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('87','Convert string to lowercase','7','12','120','STRLIB::tolower','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('88','Extract a string of characters from a longer string from the end','7','12','81','STRLIB::reversesubstring','0','0')
INSERT [FUNCTION]([function_number],[prompt],[version],[data subtype id],[order],[name],[repeatstart], [repeatno])       VALUES('89','Convert first letter of each word to uppercase','7','12','120','STRLIB::initcap','0','0')


END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[REPORT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[REPORT](
    [index] [int] NOT NULL,
    [subsystem_index] [int] NULL DEFAULT ((0)),
    [name] [nvarchar](255)  NULL,
    [description] [ntext]  NULL,
    [schedule_index] [int] NULL DEFAULT ((0)),
    [schedule_desired] [nvarchar](1)  NOT NULL,
    [schedule] [smallint] NULL DEFAULT ((0)),
    [schedule_orientation] [smallint] NULL DEFAULT ((0)),
    [write_input_record] [nvarchar](1)  NULL,
    [trailing_intervals] [nvarchar](1)  NULL,
    [line_before_total] [nvarchar](1)  NULL,
    [prepayment_mode] [nvarchar](1)  NULL,
    [cf_interest] [nvarchar](1)  NULL,
    [accrued_interest] [nvarchar](1)  NULL,
    [number_category] [smallint] NULL DEFAULT ((0)),
    [output_record_number] [smallint] NULL DEFAULT ((0)),
    [cvg_format] [nvarchar](1)  NULL,
    [lines_per_page] [smallint] NULL DEFAULT ((0)),
    [line_width] [smallint] NULL DEFAULT ((0)),
    [check_date] [nvarchar](1)  NULL,
    [check_date_begin] [datetime] NULL,
    [check_date_end] [datetime] NULL,
    [include_exclude] [nvarchar](1)  NULL,
    [detail_desired] [nvarchar](1)  NULL,
    [exception] [nvarchar](1)  NULL,
    [other_include_exclude] [nvarchar](1)  NULL,
    [other_detail_desired] [nvarchar](1)  NULL,
    [other_exception] [nvarchar](1)  NULL,
    [other_sub_include_exclude] [nvarchar](1)  NULL,
    [other_sub_detail_desired] [nvarchar](1)  NULL,
    [other_sub_exception] [nvarchar](1)  NULL,
    [decimal] [nvarchar](1)  NULL,
    [zero] [nvarchar](1)  NULL,
    [comma] [nvarchar](1)  NULL,
    [sign] [nvarchar](1)  NULL,
    [justify] [nvarchar](1)  NULL,
    [date_slash] [nvarchar](1)  NULL,
    [delimiter_type_1] [nvarchar](1)  NULL,
    [delimiter_length_1] [smallint] NULL DEFAULT ((0)),
    [delimiter_value_1] [nvarchar](30)  NULL,
    [delimiter_type_2] [nvarchar](1)  NULL,
    [delimiter_length_2] [smallint] NULL DEFAULT ((0)),
    [delimiter_value_2] [nvarchar](30)  NULL,
    [delimiter_type_3] [nvarchar](1)  NULL,
    [delimiter_length_3] [smallint] NULL DEFAULT ((0)),
    [delimiter_value_3] [nvarchar](30)  NULL,
    [delimiter_type_4] [nvarchar](1)  NULL,
    [delimiter_length_4] [smallint] NULL DEFAULT ((0)),
    [delimiter_value_4] [nvarchar](30)  NULL,
    [delimiter_type_5] [nvarchar](1)  NULL,
    [delimiter_length_5] [smallint] NULL DEFAULT ((0)),
    [delimiter_value_5] [nvarchar](30)  NULL,
    [delimiter_type_6] [nvarchar](1)  NULL,
    [delimiter_length_6] [smallint] NULL DEFAULT ((0)),
    [delimiter_value_6] [nvarchar](30)  NULL,
    [delimiter_type_7] [nvarchar](1)  NULL,
    [delimiter_length_7] [smallint] NULL DEFAULT ((0)),
    [delimiter_value_7] [nvarchar](30)  NULL,
    [version] [int] NULL DEFAULT ((0)),
    [pcf_name] [nvarchar](255)  NULL,
    [output_payment_trailers] [nvarchar](1)  NULL DEFAULT ('N'),
    [output_format] [nvarchar](1)  NULL DEFAULT ('F'),
    [excel_format_files] [smallint] NULL DEFAULT ((0)),
    [variable_feed] [bit] NOT NULL DEFAULT ((0)),
    [sequence_no] [smallint] NOT NULL DEFAULT ((0)),
    [transposed_output] [bit]  NOT NULL DEFAULT ((0)),
	[PrepaymentOption] [bit]  NOT NULL DEFAULT ((1)),
 CONSTRAINT [aaaaaREPORT_PK] PRIMARY KEY NONCLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[REPORT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[REPORT]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_REPORT_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_REPORT_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_REPORT_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_REPORT_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[REPORT]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[REPORT]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[REPORT] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[REPORT] SET temporary = [index]')
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'aaaaaREPORT_PK'))
				ALTER TABLE [dbo].[REPORT] DROP Constraint aaaaaREPORT_PK; 
			ALTER TABLE [dbo].[REPORT] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[REPORT] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[REPORT].temporary', 'index', 'COLUMN';
			ALTER TABLE [dbo].[REPORT] ADD CONSTRAINT aaaaaREPORT_PK PRIMARY KEY([index]);  
		END 
	END
END	

GO


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[REPORT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[REPORT]') AND name = N'transposed_Output')
		ALTER TABLE [dbo].[REPORT] ADD [transposed_output] [bit]  NOT NULL DEFAULT ((0))
	IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[REPORT]') AND name = N'PrepaymentOption')
		ALTER TABLE [dbo].[REPORT] ADD [PrepaymentOption] [bit]  NOT NULL DEFAULT ((1))
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[REPORT]') AND name = N'Number_category')
CREATE NONCLUSTERED INDEX [Number_category] ON [dbo].[REPORT] 
(
    [number_category] ASC
) ON [PRIMARY]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_REPORT_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_REPORT_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_REPORT_INSERT] 
   ON  [dbo].[REPORT] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''REPORT''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),NEW.[index]),

                (''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),NEW.subsystem_index),'''')+''|#''+	
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(ORG.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''schedule_index=''+ISNULL(convert(nvarchar(15),NEW.schedule_index),'''')+''|#''+	
                ''schedule_desired=''+''''''''+NEW.schedule_desired+''''''''+''|#''+
                ''schedule=''+ISNULL(convert(nvarchar(15),NEW.schedule),'''')+''|#''+	
                ''schedule_orientation=''+ISNULL(convert(nvarchar(15),NEW.schedule_orientation),'''')+''|#''+	
                ''write_input_record=''+''''''''+ISNULL(Replace(NEW.write_input_record,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''trailing_intervals=''+''''''''+ISNULL(Replace(NEW.trailing_intervals,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''line_before_total=''+''''''''+ISNULL(Replace(NEW.line_before_total,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''prepayment_mode=''+''''''''+ISNULL(Replace(NEW.prepayment_mode,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''cf_interest=''+''''''''+ISNULL(Replace(NEW.cf_interest,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''accrued_interest=''+''''''''+ISNULL(Replace(NEW.accrued_interest,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''number_category=''+ISNULL(convert(nvarchar(15),NEW.number_category),'''')+''|#''+	
                ''output_record_number=''+ISNULL(convert(nvarchar(15),NEW.output_record_number),'''')+''|#''+	
                ''cvg_format=''+''''''''+ISNULL(Replace(NEW.cvg_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''lines_per_page=''+ISNULL(convert(nvarchar(15),NEW.lines_per_page),'''')+''|#''+	
                ''line_width=''+ISNULL(convert(nvarchar(15),NEW.line_width),'''')+''|#''+	
                ''check_date=''+''''''''+ISNULL(Replace(NEW.check_date,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''check_date_begin=''+ CASE WHEN NEW.check_date_begin IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.check_date_begin)+'''''''' END+''|#''+	
                ''check_date_end=''+ CASE WHEN NEW.check_date_end IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.check_date_end)+'''''''' END+''|#''+	
                ''include_exclude=''+''''''''+ISNULL(Replace(NEW.include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''detail_desired=''+''''''''+ISNULL(Replace(NEW.detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(NEW.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_include_exclude=''+''''''''+ISNULL(Replace(NEW.other_include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_detail_desired=''+''''''''+ISNULL(Replace(NEW.other_detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_exception=''+''''''''+ISNULL(Replace(NEW.other_exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_sub_include_exclude=''+''''''''+ISNULL(Replace(NEW.other_sub_include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_sub_detail_desired=''+''''''''+ISNULL(Replace(NEW.other_sub_detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_sub_exception=''+''''''''+ISNULL(Replace(NEW.other_sub_exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[decimal]=''+''''''''+ISNULL(Replace(NEW.[decimal],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[zero]=''+''''''''+ISNULL(Replace(NEW.[zero],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''comma=''+''''''''+ISNULL(Replace(NEW.comma,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[sign]=''+''''''''+ISNULL(Replace(NEW.[sign],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''justify=''+''''''''+ISNULL(Replace(NEW.justify,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''date_slash=''+''''''''+ISNULL(Replace(NEW.date_slash,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_type_1=''+''''''''+ISNULL(Replace(NEW.delimiter_type_1,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_1=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_1),'''')+''|#''+	
                ''delimiter_value_1=''+''''''''+ISNULL(Replace(NEW.delimiter_value_1,'''''''',''''''''''''),'''')+''''''''+''|#''+
                
                ''delimiter_type_2=''+''''''''+ISNULL(Replace(NEW.delimiter_type_2,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_2=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_2),'''')+''|#''+	
                ''delimiter_value_2=''+''''''''+ISNULL(Replace(NEW.delimiter_value_2,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''delimiter_type_3=''+''''''''+ISNULL(Replace(NEW.delimiter_type_3,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_3=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_3),'''')+''|#''+	
                ''delimiter_value_3=''+''''''''+ISNULL(Replace(NEW.delimiter_value_3,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''delimiter_type_4=''+''''''''+ISNULL(Replace(NEW.delimiter_type_4,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_4=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_4),'''')+''|#''+	
                ''delimiter_value_4=''+''''''''+ISNULL(Replace(NEW.delimiter_value_4,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''delimiter_type_5=''+''''''''+ISNULL(Replace(NEW.delimiter_type_5,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_5=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_5),'''')+''|#''+	
                ''delimiter_value_5=''+''''''''+ISNULL(Replace(NEW.delimiter_value_5,'''''''',''''''''''''),'''')+''''''''+''|#''+	

                ''delimiter_type_6=''+''''''''+ISNULL(Replace(NEW.delimiter_type_6,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_6=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_6),'''')+''|#''+	
                ''delimiter_value_6=''+''''''''+ISNULL(Replace(NEW.delimiter_value_6,'''''''',''''''''''''),'''')+''''''''+''|#''+	

                ''delimiter_type_7=''+''''''''+ISNULL(Replace(NEW.delimiter_type_7,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_7=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_7),'''')+''|#''+	
                ''delimiter_value_7=''+''''''''+ISNULL(Replace(NEW.delimiter_value_7,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                                
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''')+''|#''+
                ''pcf_name=''+''''''''+ISNULL(Replace(NEW.pcf_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''output_payment_trailers=''+''''''''+ISNULL(Replace(NEW.output_payment_trailers,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''output_format=''+''''''''+ISNULL(Replace(NEW.output_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''excel_format_files=''+ISNULL(convert(nvarchar(15),NEW.excel_format_files),'''')+''|#''+
                ''variable_feed=''+convert(nvarchar(15),NEW.variable_feed)+''|#''+
                ''sequence_no=''+convert(nvarchar(15),NEW.sequence_no)+''|#''+
                ''transposed_output=''+convert(nvarchar(15),NEW.transposed_output)+''|#''+
				''PrepaymentOption=''+convert(nvarchar(15),NEW.PrepaymentOption))  from INSERTED NEW,REPORT ORG
where NEW.[index] = ORG.[index];
END
END



set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_REPORT_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER  [dbo].[trigger_REPORT_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_REPORT_UPDATE] 
   ON  [dbo].[REPORT] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''REPORT''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    
--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),OLD.[index])+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),OLD.subsystem_index),'''')+''|#''+	
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''schedule_index=''+ISNULL(convert(nvarchar(15),OLD.schedule_index),'''')+''|#''+	
                ''schedule_desired=''+''''''''+OLD.schedule_desired+''''''''+''|#''+
                ''schedule=''+ISNULL(convert(nvarchar(15),OLD.schedule),'''')+''|#''+	
                ''schedule_orientation=''+ISNULL(convert(nvarchar(15),OLD.schedule_orientation),'''')+''|#''+	
                ''write_input_record=''+''''''''+ISNULL(Replace(OLD.write_input_record,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''trailing_intervals=''+''''''''+ISNULL(Replace(OLD.trailing_intervals,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''line_before_total=''+''''''''+ISNULL(Replace(OLD.line_before_total,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''prepayment_mode=''+''''''''+ISNULL(Replace(OLD.prepayment_mode,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''cf_interest=''+''''''''+ISNULL(Replace(OLD.cf_interest,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''accrued_interest=''+''''''''+ISNULL(Replace(OLD.accrued_interest,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''number_category=''+ISNULL(convert(nvarchar(15),OLD.number_category),'''')+''|#''+	
                ''output_record_number=''+ISNULL(convert(nvarchar(15),OLD.output_record_number),'''')+''|#''+	
                ''cvg_format=''+''''''''+ISNULL(Replace(OLD.cvg_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''lines_per_page=''+ISNULL(convert(nvarchar(15),OLD.lines_per_page),'''')+''|#''+	
                ''line_width=''+ISNULL(convert(nvarchar(15),OLD.line_width),'''')+''|#''+	
                ''check_date=''+''''''''+ISNULL(Replace(OLD.check_date,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''check_date_begin=''+ CASE WHEN OLD.check_date_begin IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.check_date_begin)+'''''''' END+''|#''+	
                ''check_date_end=''+ CASE WHEN OLD.check_date_end IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.check_date_end)+'''''''' END+''|#''+	
                ''include_exclude=''+''''''''+ISNULL(Replace(OLD.include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''detail_desired=''+''''''''+ISNULL(Replace(OLD.detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(OLD.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_include_exclude=''+''''''''+ISNULL(Replace(OLD.other_include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_detail_desired=''+''''''''+ISNULL(Replace(OLD.other_detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_exception=''+''''''''+ISNULL(Replace(OLD.other_exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_sub_include_exclude=''+''''''''+ISNULL(Replace(OLD.other_sub_include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_sub_detail_desired=''+''''''''+ISNULL(Replace(OLD.other_sub_detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_sub_exception=''+''''''''+ISNULL(Replace(OLD.other_sub_exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[decimal]=''+''''''''+ISNULL(Replace(OLD.[decimal],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[zero]=''+''''''''+ISNULL(Replace(OLD.[zero],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''comma=''+''''''''+ISNULL(Replace(OLD.comma,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[sign]=''+''''''''+ISNULL(Replace(OLD.[sign],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''justify=''+''''''''+ISNULL(Replace(OLD.justify,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''date_slash=''+''''''''+ISNULL(Replace(OLD.date_slash,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_type_1=''+''''''''+ISNULL(Replace(OLD.delimiter_type_1,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_1=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_1),'''')+''|#''+	
                ''delimiter_value_1=''+''''''''+ISNULL(Replace(OLD.delimiter_value_1,'''''''',''''''''''''),'''')+''''''''+''|#''+
                
                ''delimiter_type_2=''+''''''''+ISNULL(Replace(OLD.delimiter_type_2,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_2=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_2),'''')+''|#''+	
                ''delimiter_value_2=''+''''''''+ISNULL(Replace(OLD.delimiter_value_2,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''delimiter_type_3=''+''''''''+ISNULL(Replace(OLD.delimiter_type_3,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_3=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_3),'''')+''|#''+	
                ''delimiter_value_3=''+''''''''+ISNULL(Replace(OLD.delimiter_value_3,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''delimiter_type_4=''+''''''''+ISNULL(Replace(OLD.delimiter_type_4,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_4=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_4),'''')+''|#''+	
                ''delimiter_value_4=''+''''''''+ISNULL(Replace(OLD.delimiter_value_4,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''delimiter_type_5=''+''''''''+ISNULL(Replace(OLD.delimiter_type_5,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_5=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_5),'''')+''|#''+	
                ''delimiter_value_5=''+''''''''+ISNULL(Replace(OLD.delimiter_value_5,'''''''',''''''''''''),'''')+''''''''+''|#''+	

                ''delimiter_type_6=''+''''''''+ISNULL(Replace(OLD.delimiter_type_6,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_6=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_6),'''')+''|#''+	
                ''delimiter_value_6=''+''''''''+ISNULL(Replace(OLD.delimiter_value_6,'''''''',''''''''''''),'''')+''''''''+''|#''+	

                ''delimiter_type_7=''+''''''''+ISNULL(Replace(OLD.delimiter_type_7,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_7=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_7),'''')+''|#''+	
                ''delimiter_value_7=''+''''''''+ISNULL(Replace(OLD.delimiter_value_7,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''')+''|#''+
                ''pcf_name=''+''''''''+ISNULL(Replace(OLD.pcf_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''output_payment_trailers=''+''''''''+ISNULL(Replace(OLD.output_payment_trailers,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''output_format=''+''''''''+ISNULL(Replace(OLD.output_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''excel_format_files=''+ISNULL(convert(nvarchar(15),OLD.excel_format_files),'''')+''|#''+
                ''variable_feed=''+convert(nvarchar(15),OLD.variable_feed)+''|#''+
                ''sequence_no=''+convert(nvarchar(15),OLD.sequence_no)+''|#''+
                ''transposed_output=''+convert(nvarchar(15),OLD.transposed_output)+''|#''+  
				''PrepaymentOption=''+convert(nvarchar(15),OLD.PrepaymentOption)+
                '' where ''+''[index]=''+convert(nvarchar(15),OLD.[index]),
                 
                ''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),NEW.subsystem_index),'''')+''|#''+	
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(NEW.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''schedule_index=''+ISNULL(convert(nvarchar(15),NEW.schedule_index),'''')+''|#''+	
                ''schedule_desired=''+''''''''+NEW.schedule_desired+''''''''+''|#''+
                ''schedule=''+ISNULL(convert(nvarchar(15),NEW.schedule),'''')+''|#''+	
                ''schedule_orientation=''+ISNULL(convert(nvarchar(15),NEW.schedule_orientation),'''')+''|#''+	
                ''write_input_record=''+''''''''+ISNULL(Replace(NEW.write_input_record,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''trailing_intervals=''+''''''''+ISNULL(Replace(NEW.trailing_intervals,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''line_before_total=''+''''''''+ISNULL(Replace(NEW.line_before_total,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''prepayment_mode=''+''''''''+ISNULL(Replace(NEW.prepayment_mode,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''cf_interest=''+''''''''+ISNULL(Replace(NEW.cf_interest,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''accrued_interest=''+''''''''+ISNULL(Replace(NEW.accrued_interest,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''number_category=''+ISNULL(convert(nvarchar(15),NEW.number_category),'''')+''|#''+	
                ''output_record_number=''+ISNULL(convert(nvarchar(15),NEW.output_record_number),'''')+''|#''+	
                ''cvg_format=''+''''''''+ISNULL(Replace(NEW.cvg_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''lines_per_page=''+ISNULL(convert(nvarchar(15),NEW.lines_per_page),'''')+''|#''+	
                ''line_width=''+ISNULL(convert(nvarchar(15),NEW.line_width),'''')+''|#''+	
                ''check_date=''+''''''''+ISNULL(Replace(NEW.check_date,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''check_date_begin=''+ CASE WHEN NEW.check_date_begin IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.check_date_begin)+'''''''' END+''|#''+	
                ''check_date_end=''+ CASE WHEN NEW.check_date_end IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.check_date_end)+'''''''' END+''|#''+	
                ''include_exclude=''+''''''''+ISNULL(Replace(NEW.include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''detail_desired=''+''''''''+ISNULL(Replace(NEW.detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(NEW.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_include_exclude=''+''''''''+ISNULL(Replace(NEW.other_include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_detail_desired=''+''''''''+ISNULL(Replace(NEW.other_detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_exception=''+''''''''+ISNULL(Replace(NEW.other_exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_sub_include_exclude=''+''''''''+ISNULL(Replace(NEW.other_sub_include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_sub_detail_desired=''+''''''''+ISNULL(Replace(NEW.other_sub_detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_sub_exception=''+''''''''+ISNULL(Replace(NEW.other_sub_exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[decimal]=''+''''''''+ISNULL(Replace(NEW.[decimal],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[zero]=''+''''''''+ISNULL(Replace(NEW.[zero],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''comma=''+''''''''+ISNULL(Replace(NEW.comma,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[sign]=''+''''''''+ISNULL(Replace(NEW.[sign],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''justify=''+''''''''+ISNULL(Replace(NEW.justify,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''date_slash=''+''''''''+ISNULL(Replace(NEW.date_slash,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_type_1=''+''''''''+ISNULL(Replace(NEW.delimiter_type_1,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_1=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_1),'''')+''|#''+	
                ''delimiter_value_1=''+''''''''+ISNULL(Replace(NEW.delimiter_value_1,'''''''',''''''''''''),'''')+''''''''+''|#''+
                
                ''delimiter_type_2=''+''''''''+ISNULL(Replace(NEW.delimiter_type_2,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_2=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_2),'''')+''|#''+	
                ''delimiter_value_2=''+''''''''+ISNULL(Replace(NEW.delimiter_value_2,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''delimiter_type_3=''+''''''''+ISNULL(Replace(NEW.delimiter_type_3,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_3=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_3),'''')+''|#''+	
                ''delimiter_value_3=''+''''''''+ISNULL(Replace(NEW.delimiter_value_3,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''delimiter_type_4=''+''''''''+ISNULL(Replace(NEW.delimiter_type_4,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_4=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_4),'''')+''|#''+	
                ''delimiter_value_4=''+''''''''+ISNULL(Replace(NEW.delimiter_value_4,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''delimiter_type_5=''+''''''''+ISNULL(Replace(NEW.delimiter_type_5,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_5=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_5),'''')+''|#''+	
                ''delimiter_value_5=''+''''''''+ISNULL(Replace(NEW.delimiter_value_5,'''''''',''''''''''''),'''')+''''''''+''|#''+	

                ''delimiter_type_6=''+''''''''+ISNULL(Replace(NEW.delimiter_type_6,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_6=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_6),'''')+''|#''+	
                ''delimiter_value_6=''+''''''''+ISNULL(Replace(NEW.delimiter_value_6,'''''''',''''''''''''),'''')+''''''''+''|#''+	

                ''delimiter_type_7=''+''''''''+ISNULL(Replace(NEW.delimiter_type_7,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_7=''+ISNULL(convert(nvarchar(15),NEW.delimiter_length_7),'''')+''|#''+	
                ''delimiter_value_7=''+''''''''+ISNULL(Replace(NEW.delimiter_value_7,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''')+''|#''+
                ''pcf_name=''+''''''''+ISNULL(Replace(NEW.pcf_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''output_payment_trailers=''+''''''''+ISNULL(Replace(NEW.output_payment_trailers,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''output_format=''+''''''''+ISNULL(Replace(NEW.output_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''excel_format_files=''+ISNULL(convert(nvarchar(15),NEW.excel_format_files),'''')+''|#''+
                ''variable_feed=''+convert(nvarchar(15),NEW.variable_feed)+''|#''+
                ''sequence_no=''+convert(nvarchar(15),NEW.sequence_no)+''|#''+
                ''transposed_output=''+convert(nvarchar(15),NEW.transposed_output)+''|#''+
				''PrepaymentOption=''+convert(nvarchar(15),NEW.PrepaymentOption)+
                '' where ''+''[index]=''+convert(nvarchar(15),NEW.[index])
          from DELETED OLD,INSERTED NEW 
where OLD.[index] = NEW.[index];
END
--update the field in REPORT table
UPDATE dbo.REPORT
SET subsystem_index=NEW.subsystem_index,
    [name]=NEW.[name],
    description=NEW.description,
    schedule_index=NEW.schedule_index,
    schedule_desired=NEW.schedule_desired,
    schedule=NEW.schedule,
    schedule_orientation=NEW.schedule_orientation,
    write_input_record=NEW.write_input_record,
    trailing_intervals=NEW.trailing_intervals,
    line_before_total=NEW.line_before_total,
    prepayment_mode=NEW.prepayment_mode,
    cf_interest=NEW.cf_interest,
    accrued_interest=NEW.accrued_interest,
    number_category=NEW.number_category,
    output_record_number=NEW.output_record_number,
    cvg_format=NEW.cvg_format,
    lines_per_page=NEW.lines_per_page,
    line_width=NEW.line_width,
    check_date=NEW.check_date,
    check_date_begin=NEW.check_date_begin,
    check_date_end=NEW.check_date_end,
    include_exclude=NEW.include_exclude,
    detail_desired=NEW.detail_desired,
    exception=NEW.exception,
    other_include_exclude=NEW.other_include_exclude,
    other_detail_desired=NEW.other_detail_desired,
    other_sub_exception=NEW.other_sub_exception,
    [decimal]=NEW.[decimal],
    zero=NEW.zero,
    comma=NEW.comma,
    [sign]=NEW.[sign],	
    justify=NEW.justify,
    date_slash=NEW.date_slash,
    delimiter_type_1=NEW.delimiter_type_1,
    delimiter_length_1=NEW.delimiter_length_1,
    delimiter_value_1=NEW.delimiter_value_1,
    
    delimiter_type_2=NEW.delimiter_type_2,
    delimiter_length_2=NEW.delimiter_length_2,
    delimiter_value_2=NEW.delimiter_value_2,	
    
    delimiter_type_3=NEW.delimiter_type_3,
    delimiter_length_3=NEW.delimiter_length_3,
    delimiter_value_3=NEW.delimiter_value_3,	

    delimiter_type_4=NEW.delimiter_type_4,
    delimiter_length_4=NEW.delimiter_length_4,
    delimiter_value_4=NEW.delimiter_value_4,
    
    delimiter_type_5=NEW.delimiter_type_5,
    delimiter_length_5=NEW.delimiter_length_5,
    delimiter_value_5=NEW.delimiter_value_5,
    
    delimiter_type_6=NEW.delimiter_type_6,
    delimiter_length_6=NEW.delimiter_length_6,
    delimiter_value_6=NEW.delimiter_value_6,
    
    delimiter_type_7=NEW.delimiter_type_7,
    delimiter_length_7=NEW.delimiter_length_7,
    delimiter_value_7=NEW.delimiter_value_7,
    version=NEW.version,
    pcf_name=NEW.pcf_name,
    output_payment_trailers=NEW.output_payment_trailers,
    output_format=NEW.output_format,
    excel_format_files=NEW.excel_format_files,
    variable_feed=NEW.variable_feed,
    sequence_no=NEW.sequence_no,
    transposed_output=NEW.transposed_output,
	PrepaymentOption=NEW.PrepaymentOption
    from INSERTED NEW 
    where REPORT.[index] = NEW.[index];
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),OLD.[index])+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),OLD.subsystem_index),'''')+''|#''+	
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''schedule_index=''+ISNULL(convert(nvarchar(15),OLD.schedule_index),'''')+''|#''+	
                ''schedule_desired=''+''''''''+OLD.schedule_desired+''''''''+''|#''+
                ''schedule=''+ISNULL(convert(nvarchar(15),OLD.schedule),'''')+''|#''+	
                ''schedule_orientation=''+ISNULL(convert(nvarchar(15),OLD.schedule_orientation),'''')+''|#''+	
                ''write_input_record=''+''''''''+ISNULL(Replace(OLD.write_input_record,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''trailing_intervals=''+''''''''+ISNULL(Replace(OLD.trailing_intervals,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''line_before_total=''+''''''''+ISNULL(Replace(OLD.line_before_total,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''prepayment_mode=''+''''''''+ISNULL(Replace(OLD.prepayment_mode,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''cf_interest=''+''''''''+ISNULL(Replace(OLD.cf_interest,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''accrued_interest=''+''''''''+ISNULL(Replace(OLD.accrued_interest,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''number_category=''+ISNULL(convert(nvarchar(15),OLD.number_category),'''')+''|#''+	
                ''output_record_number=''+ISNULL(convert(nvarchar(15),OLD.output_record_number),'''')+''|#''+	
                ''cvg_format=''+''''''''+ISNULL(Replace(OLD.cvg_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''lines_per_page=''+ISNULL(convert(nvarchar(15),OLD.lines_per_page),'''')+''|#''+	
                ''line_width=''+ISNULL(convert(nvarchar(15),OLD.line_width),'''')+''|#''+	
                ''check_date=''+''''''''+ISNULL(Replace(OLD.check_date,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''check_date_begin=''+ CASE WHEN OLD.check_date_begin IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.check_date_begin)+'''''''' END+''|#''+	
                ''check_date_end=''+ CASE WHEN OLD.check_date_end IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.check_date_end)+'''''''' END+''|#''+	
                ''include_exclude=''+''''''''+ISNULL(Replace(OLD.include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''detail_desired=''+''''''''+ISNULL(Replace(OLD.detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(OLD.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_include_exclude=''+''''''''+ISNULL(Replace(OLD.other_include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_detail_desired=''+''''''''+ISNULL(Replace(OLD.other_detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_exception=''+''''''''+ISNULL(Replace(OLD.other_exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_sub_include_exclude=''+''''''''+ISNULL(Replace(OLD.other_sub_include_exclude,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_sub_detail_desired=''+''''''''+ISNULL(Replace(OLD.other_sub_detail_desired,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''other_sub_exception=''+''''''''+ISNULL(Replace(OLD.other_sub_exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[decimal]=''+''''''''+ISNULL(Replace(OLD.[decimal],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[zero]=''+''''''''+ISNULL(Replace(OLD.[zero],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''comma=''+''''''''+ISNULL(Replace(OLD.comma,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[sign]=''+''''''''+ISNULL(Replace(OLD.[sign],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''justify=''+''''''''+ISNULL(Replace(OLD.justify,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''date_slash=''+''''''''+ISNULL(Replace(OLD.date_slash,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_type_1=''+''''''''+ISNULL(Replace(OLD.delimiter_type_1,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_1=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_1),'''')+''|#''+	
                ''delimiter_value_1=''+''''''''+ISNULL(Replace(OLD.delimiter_value_1,'''''''',''''''''''''),'''')+''''''''+''|#''+
                
                ''delimiter_type_2=''+''''''''+ISNULL(Replace(OLD.delimiter_type_2,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_2=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_2),'''')+''|#''+	
                ''delimiter_value_2=''+''''''''+ISNULL(Replace(OLD.delimiter_value_2,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''delimiter_type_3=''+''''''''+ISNULL(Replace(OLD.delimiter_type_3,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_3=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_3),'''')+''|#''+	
                ''delimiter_value_3=''+''''''''+ISNULL(Replace(OLD.delimiter_value_3,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''delimiter_type_4=''+''''''''+ISNULL(Replace(OLD.delimiter_type_4,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_4=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_4),'''')+''|#''+	
                ''delimiter_value_4=''+''''''''+ISNULL(Replace(OLD.delimiter_value_4,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''delimiter_type_5=''+''''''''+ISNULL(Replace(OLD.delimiter_type_5,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_5=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_5),'''')+''|#''+	
                ''delimiter_value_5=''+''''''''+ISNULL(Replace(OLD.delimiter_value_5,'''''''',''''''''''''),'''')+''''''''+''|#''+	

                ''delimiter_type_6=''+''''''''+ISNULL(Replace(OLD.delimiter_type_6,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_6=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_6),'''')+''|#''+	
                ''delimiter_value_6=''+''''''''+ISNULL(Replace(OLD.delimiter_value_6,'''''''',''''''''''''),'''')+''''''''+''|#''+	

                ''delimiter_type_7=''+''''''''+ISNULL(Replace(OLD.delimiter_type_7,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''delimiter_length_7=''+ISNULL(convert(nvarchar(15),OLD.delimiter_length_7),'''')+''|#''+	
                ''delimiter_value_7=''+''''''''+ISNULL(Replace(OLD.delimiter_value_7,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''')+''|#''+
                ''pcf_name=''+''''''''+ISNULL(Replace(OLD.pcf_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''output_payment_trailers=''+''''''''+ISNULL(Replace(OLD.output_payment_trailers,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''output_format=''+''''''''+ISNULL(Replace(OLD.output_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''excel_format_files=''+ISNULL(convert(nvarchar(15),OLD.excel_format_files),'''')+''|#''+
                ''variable_feed=''+convert(nvarchar(15),OLD.variable_feed)+''|#''+
                ''sequence_no=''+convert(nvarchar(15),OLD.sequence_no)+''|#''+
                ''transposed_output=''+convert(nvarchar(15),OLD.transposed_output)+ ''|#''+
				''PrepaymentOption=''+convert(nvarchar(15),OLD.PrepaymentOption),
                ''[index]=''+convert(nvarchar(15),OLD.[index]) 
                from DELETED OLD;
end
--Delete the field from CATEGORY table
DELETE FROM REPORT where [index] in (SELECT [index] from DELETED);
END
END



set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SUB_SYSTEM]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[SUB_SYSTEM](
    [index] [int] NOT NULL,
    [id] [nvarchar](6)  NULL,
    [name] [nvarchar](255)  NOT NULL,
    [description] [ntext]  NULL,
    [type] [nvarchar](1)  NOT NULL DEFAULT ('A'),
    [create_time] [datetime] NULL,
    [last_modify] [datetime] NULL,
    [version] [real] NULL DEFAULT ((0)),
    [input_type] [nvarchar](1)  NOT NULL DEFAULT ('F'),
    [delimiter] [nvarchar](3)  NULL DEFAULT ('C,'),
    [magchar] [nvarchar](1)  NULL DEFAULT (','),
    [decchar] [nvarchar](1)  NULL DEFAULT ('.'),
    [use_unassigned_values] [bit] NULL DEFAULT ((0)),
    [sequence_no] [int] NOT NULL DEFAULT ((0)),
    [folderid] [int] NOT NULL,
 CONSTRAINT [aaaaaSUB_SYSTEM_PK] PRIMARY KEY NONCLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SUB_SYSTEM]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[SUB_SYSTEM]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SUB_SYSTEM_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_SUB_SYSTEM_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SUB_SYSTEM_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_SUB_SYSTEM_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[SUB_SYSTEM]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[SUB_SYSTEM]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[SUB_SYSTEM] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[SUB_SYSTEM] SET temporary = [index]') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'aaaaaSUB_SYSTEM_PK'))
				ALTER TABLE [dbo].[SUB_SYSTEM] DROP Constraint aaaaaSUB_SYSTEM_PK; 
			ALTER TABLE [dbo].[SUB_SYSTEM] ALTER COLUMN temporary [int] NOT NULL; 
			IF EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[SUB_SYSTEM]') AND name = N'Index')



				DROP INDEX [Index] ON [dbo].[SUB_SYSTEM] WITH ( ONLINE = OFF )

			ALTER TABLE [dbo].[SUB_SYSTEM] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[SUB_SYSTEM].temporary', 'index', 'COLUMN'; 
			ALTER TABLE [dbo].[SUB_SYSTEM] ADD CONSTRAINT aaaaaSUB_SYSTEM_PK PRIMARY KEY([index]); 
		END 
	END
END	

GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[SUB_SYSTEM]') AND name = N'ID')
CREATE NONCLUSTERED INDEX [ID] ON [dbo].[SUB_SYSTEM] 
(
    [id] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[SUB_SYSTEM]') AND name = N'Index')
CREATE UNIQUE NONCLUSTERED INDEX [Index] ON [dbo].[SUB_SYSTEM] 
(
    [index] ASC
) ON [PRIMARY]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SUB_SYSTEM_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_SUB_SYSTEM_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_SUB_SYSTEM_INSERT] 
   ON  [dbo].[SUB_SYSTEM] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''SUB_SYSTEM''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),NEW.[index]),

                (''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''id=''+''''''''+ISNULL(Replace(NEW.id,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(ORG.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+''''''''+NEW.[type]+''''''''+''|#''+	
                ''create_time=''+ CASE WHEN NEW.create_time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.create_time)+'''''''' END+''|#''+
                ''last_modify=''+ CASE WHEN NEW.last_modify IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.last_modify)+'''''''' END+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''')+''|#''+
                ''input_type=''+''''''''+NEW.input_type+''''''''+''|#''+	
                ''delimiter=''+''''''''+ISNULL(Replace(NEW.delimiter,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                ''magchar=''+''''''''+ISNULL(Replace(NEW.magchar,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                ''decchar=''+''''''''+ISNULL(Replace(NEW.decchar,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                ''use_unassigned_values=''+convert(nvarchar(15),NEW.use_unassigned_values)+''|#''+
                ''sequence_no=''+convert(nvarchar(15),NEW.sequence_no)+''|#''+
                ''folderid=''+convert(nvarchar(15),NEW.folderid)) from INSERTED NEW,SUB_SYSTEM ORG
                where NEW.[index] = ORG.[index];
END
END
set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON



set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SUB_SYSTEM_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_SUB_SYSTEM_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_SUB_SYSTEM_UPDATE] 
   ON  [dbo].[SUB_SYSTEM]
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @modifiedColumns int,
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''SUB_SYSTEM''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),OLD.[index])+''|#''+
                ''id=''+''''''''+ISNULL(Replace(OLD.id,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+''''''''+OLD.[type]+''''''''+''|#''+	
                ''create_time=''+ CASE WHEN OLD.create_time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.create_time)+'''''''' END+''|#''+
                ''last_modify=''+ CASE WHEN OLD.last_modify IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.last_modify)+'''''''' END+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''')+''|#''+
                ''input_type=''+''''''''+OLD.input_type+''''''''+''|#''+	
                ''delimiter=''+''''''''+ISNULL(Replace(OLD.delimiter,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                ''magchar=''+''''''''+ISNULL(Replace(OLD.magchar,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                ''decchar=''+''''''''+ISNULL(Replace(OLD.decchar,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                ''use_unassigned_values=''+convert(nvarchar(15),OLD.use_unassigned_values)+''|#''+
                ''sequence_no=''+convert(nvarchar(15),OLD.sequence_no)+''|#''+
                ''folderid=''+convert(nvarchar(15),OLD.folderid)+
                '' where ''+''[index]=''+convert(nvarchar(15),OLD.[index]),
                 
                ''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''id=''+''''''''+ISNULL(Replace(NEW.id,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(NEW.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+''''''''+NEW.[type]+''''''''+''|#''+	
                ''create_time=''+ CASE WHEN NEW.create_time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.create_time)+'''''''' END+''|#''+
                ''last_modify=''+ CASE WHEN NEW.last_modify IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.last_modify)+'''''''' END+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''')+''|#''+
                ''input_type=''+''''''''+NEW.input_type+''''''''+''|#''+	
                ''delimiter=''+''''''''+ISNULL(Replace(NEW.delimiter,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                ''magchar=''+''''''''+ISNULL(Replace(NEW.magchar,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                ''decchar=''+''''''''+ISNULL(Replace(NEW.decchar,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                ''use_unassigned_values=''+convert(nvarchar(15),NEW.use_unassigned_values)+''|#''+
                ''sequence_no=''+convert(nvarchar(15),NEW.sequence_no)+''|#''+
                ''folderid=''+convert(nvarchar(15),NEW.folderid)+
                '' where ''+''[index]=''+convert(nvarchar(15),NEW.[index])                
          from DELETED OLD,INSERTED NEW
where OLD.[index] = NEW.[index] 
END
--update the field in CATEGORY table
UPDATE dbo.SUB_SYSTEM
SET id=NEW.id,
    [name]=NEW.[name],
    description=NEW.description,
    [type]=NEW.[type],
    create_time=NEW.create_time,
    last_modify=NEW.last_modify,
    version=NEW.version,
    input_type=NEW.input_type,
    delimiter=NEW.delimiter,
    magchar=NEW.magchar,
    decchar=NEW.decchar,
    use_unassigned_values=NEW.use_unassigned_values,
    sequence_no=NEW.sequence_no,
    folderid=NEW.folderid
    from INSERTED NEW 
    where SUB_SYSTEM.[index]=NEW.[index];
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),OLD.[index])+''|#''+
                ''id=''+''''''''+ISNULL(Replace(OLD.id,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+''''''''+OLD.[type]+''''''''+''|#''+	
                ''create_time=''+ CASE WHEN OLD.create_time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.create_time)+'''''''' END+''|#''+
                ''last_modify=''+ CASE WHEN OLD.last_modify IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.last_modify)+'''''''' END+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''')+''|#''+
                ''input_type=''+''''''''+OLD.input_type+''''''''+''|#''+	
                ''delimiter=''+''''''''+ISNULL(Replace(OLD.delimiter,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                ''magchar=''+''''''''+ISNULL(Replace(OLD.magchar,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                ''decchar=''+''''''''+ISNULL(Replace(OLD.decchar,'''''''',''''''''''''),'''')+''''''''+''|#''+	
                ''use_unassigned_values=''+convert(nvarchar(15),OLD.use_unassigned_values)+''|#''+
                ''sequence_no=''+convert(nvarchar(15),OLD.sequence_no)+''|#''+
                ''folderid=''+convert(nvarchar(15),OLD.folderid),
                ''[index]=''+convert(nvarchar(15),OLD.[index])
                from DELETED OLD;
end
--Delete the field from CATEGORY table
DELETE FROM SUB_SYSTEM WHERE [index] in (SELECT [index] from  DELETED)
END
END




' 
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[ADI_Grant_Execute_To_sp]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[ADI_Grant_Execute_To_sp]
    @user [varchar](50)
AS
BEGIN










EXEC sp_addrolemember ''db_datareader'', @user
EXEC sp_addrolemember ''db_datawriter'', @user

DECLARE @stmt as varchar(250)
DECLARE @nameSP as varchar(100)

DECLARE CursorSP CURSOR FOR
SELECT name from sysobjects where xtype=''P'' AND category=0
OPEN CursorSP 
FETCH NEXT FROM CursorSP
INTO @nameSP
WHILE @@FETCH_STATUS = 0
  BEGIN
     set @stmt = ''GRANT EXECUTE ON [dbo].['' + @nameSP + ''] TO ['' + @user + '']''
     exec (@stmt)
  FETCH NEXT FROM CursorSP
  INTO @nameSP
END
CLOSE CursorSP
DEALLOCATE CursorSP
END
' 
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[TEMPLATE_LINK]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[TEMPLATE_LINK](
    [index] [int] NOT NULL,
    [template_index] [int] NULL DEFAULT ((0)),
    [output_record_index] [int] NULL DEFAULT ((0)),
    [input_record_index] [int] NULL DEFAULT ((0)),
 CONSTRAINT [aaaaaTEMPLATE_LINK_PK] PRIMARY KEY NONCLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[TEMPLATE_LINK]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[TEMPLATE_LINK]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_TEMPLATE_LINK_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_TEMPLATE_LINK_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_TEMPLATE_LINK_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_TEMPLATE_LINK_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[TEMPLATE_LINK]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[TEMPLATE_LINK]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[TEMPLATE_LINK] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[TEMPLATE_LINK] SET temporary = [index]') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'aaaaaTEMPLATE_LINK_PK'))
				ALTER TABLE [dbo].[TEMPLATE_LINK] DROP Constraint aaaaaTEMPLATE_LINK_PK; 
			ALTER TABLE [dbo].[TEMPLATE_LINK] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[TEMPLATE_LINK] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[TEMPLATE_LINK].temporary', 'index', 'COLUMN'; 
			ALTER TABLE [dbo].[TEMPLATE_LINK] ADD CONSTRAINT aaaaaTEMPLATE_LINK_PK PRIMARY KEY([index]); 
		END 
	END
END	

GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_TEMPLATE_LINK_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_TEMPLATE_LINK_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_TEMPLATE_LINK_INSERT] 
   ON  [dbo].[TEMPLATE_LINK] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''TEMPLATE_LINK''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''[index]=''+convert(nvarchar(15),NEW.[index]),
                (''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''template_index=''+ISNULL(convert(nvarchar(15),NEW.template_index),'''')+''|#''+
                ''output_record_index=''+ISNULL(convert(nvarchar(15),NEW.output_record_index),'''')+''|#''+
                ''input_record_index=''+ISNULL(convert(nvarchar(15),NEW.input_record_index),'''') )from INSERTED NEW;
END

END





' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_TEMPLATE_LINK_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_TEMPLATE_LINK_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_TEMPLATE_LINK_UPDATE] 
   ON  [dbo].[TEMPLATE_LINK] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @modifiedColumns int,
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''TEMPLATE_LINK''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''template_index=''+ISNULL(convert(nvarchar(15),OLD.template_index),'''')+''|#''+
                ''output_record_index=''+ISNULL(convert(nvarchar(15),OLD.output_record_index),'''')+''|#''+
                ''input_record_index=''+ISNULL(convert(nvarchar(15),OLD.input_record_index),'''')+
                '' WHERE ''+''[index]=''+convert(nvarchar(15),OLD.[index]),
                 
                ''template_index=''+ISNULL(convert(nvarchar(15),NEW.template_index),'''')+''|#''+
                ''output_record_index=''+ISNULL(convert(nvarchar(15),NEW.output_record_index),'''')+''|#''+
                ''input_record_index=''+ISNULL(convert(nvarchar(15),NEW.input_record_index),'''')+
                '' WHERE ''+''[index]=''+convert(nvarchar(15),NEW.[index]) from DELETED OLD,INSERTED NEW
 where NEW.[index] = OLD.[index];
end
--update the field in TEMPLATE_LINK table
UPDATE dbo.TEMPLATE_LINK
SET template_index=NEW.template_index,
    output_record_index=NEW.output_record_index,
    input_record_index=NEW.input_record_index 
    from INSERTED NEW
    where TEMPLATE_LINK.[index] in (NEW.[index]);
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''template_index=''+ISNULL(convert(nvarchar(15),OLD.template_index),'''')+''|#''+
                ''output_record_index=''+ISNULL(convert(nvarchar(15),OLD.output_record_index),'''')+''|#''+
                ''input_record_index=''+ISNULL(convert(nvarchar(15),OLD.input_record_index),'''')+''|#''+
                ''[index]=''+convert(nvarchar(15),OLD.[index]),''[index]=''+convert(nvarchar(15),OLD.[index]) from DELETED OLD;
end
--Delete the field from TEMPLATE_LINK table
DELETE FROM TEMPLATE_LINK where [index] in (SELECT OLD.[index] from DELETED OLD);
END

END





' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[HOLIDAYS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

CREATE TABLE [dbo].[HOLIDAYS](
	[Dates] [nchar](10) NULL
) ON [PRIMARY]
END

GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[LICENSEINFO]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[LICENSEINFO](
	[LicenseInfo] [text] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DATA SUBTYPES]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[DATA SUBTYPES](
    [id] [int] NOT NULL,
    [data type id] [int] NOT NULL DEFAULT ((0)),
    [name] [nvarchar](50)  NOT NULL,
    [default value] [nvarchar](50)  NULL,
    [description] [nvarchar](255)  NULL,
    [data control id] [int] NULL DEFAULT ((0)),
    [bzero] [bit] NOT NULL DEFAULT ((1)),
    [bsigned] [bit] NOT NULL DEFAULT ((1)),
    [bdecimals] [bit] NOT NULL DEFAULT ((0)),
    [new id] [int] NULL DEFAULT ((0)),
    [default data type id] [int] NULL DEFAULT ((0)),
 CONSTRAINT [aaaaaData SubTypes_PK] PRIMARY KEY NONCLUSTERED 
(
    [id] ASC
) ON [PRIMARY]
) ON [PRIMARY]

--INSERT Global Data for [DATA SUBTYPES] table

INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('12','3','Letters & numbers','','AlphaNumeric string','0','1','0','0','3','3')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('13','30','Date (characters)','','Date (characters)','2','0','0','0','0','30')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('14','25','Decimal number (unsigned)','','Decimal number (unsigned)','0','1','0','1','0','25')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('15','26','Decimal number (signed)','','Decimal number (signed)','0','1','1','1','0','26')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('16','27','Decimal number (packed, signed)','','Decimal number (packed, signed)','0','1','1','1','0','27')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('17','29','Binary number','','Binary Number','0','0','0','0','0','29')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('18','32','Date (packed form)','','Date (packed form)','2','0','0','0','0','32')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('19','31','Date (binary form)','','Date (binary form)','2','0','0','0','0','31')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('20','28','Floating point number','','Signed Floating Point Number','0','1','1','1','0','28')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('21','2','Integer (signed)','','Integer','0','1','1','0','0','2')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('22','97','Integer (unsigned)','','Unsigned integer','0','1','0','0','0','97')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('23','44','Interval','','# Days OR # Months','0','0','0','0','0','44')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('24','33','Number with explicit decimal point','','Number with explicit decimal point','0','1','1','0','0','33')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('25','0','Any data type','','Any data type','0','1','1','0','0','0')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('26','3','External Table Index','','External Table Index','0','1','1','0','0','999')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('27','998','Amortization Method ID','','Amortization Method ID','0','1','1','0','0','998')
INSERT [DATA SUBTYPES]([id],[data type id],[name],[default value],[description],[data control id],[bzero],[bsigned],[bdecimals],[new id],[default data type id])       VALUES('28','28','Ambit System Field','','Any Schedule Type','0','0','0','0','0','50')


END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DATA SUBTYPES]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[DATA SUBTYPES]'),'TableHasIdentity') = 1 
	BEGIN
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[DATA SUBTYPES]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[DATA SUBTYPES]') AND name = N'id') 
		BEGIN
			ALTER TABLE [dbo].[DATA SUBTYPES] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[DATA SUBTYPES] SET temporary = id') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'[aaaaaData SubTypes_PK]'))
				ALTER TABLE [dbo].[DATA SUBTYPES] DROP Constraint [aaaaaData SubTypes_PK]; 
			ALTER TABLE [dbo].[DATA SUBTYPES] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[DATA SUBTYPES] DROP COLUMN id; 
			EXEC sp_rename '[dbo].[DATA SUBTYPES].temporary', 'id', 'COLUMN'; 
			ALTER TABLE [dbo].[DATA SUBTYPES] ADD CONSTRAINT [aaaaaData SubTypes_PK] PRIMARY KEY(id); 
		END 
	END
END	

GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[DATA SUBTYPES]') AND name = N'Data Control ID')
CREATE NONCLUSTERED INDEX [Data Control ID] ON [dbo].[DATA SUBTYPES] 
(
    [data control id] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[DATA SUBTYPES]') AND name = N'Data Type ID')
CREATE NONCLUSTERED INDEX [Data Type ID] ON [dbo].[DATA SUBTYPES] 
(
    [data type id] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[DATA SUBTYPES]') AND name = N'Default Data Type ID')
CREATE UNIQUE NONCLUSTERED INDEX [Default Data Type ID] ON [dbo].[DATA SUBTYPES] 
(
    [default data type id] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[DATA SUBTYPES]') AND name = N'ID')
CREATE NONCLUSTERED INDEX [ID] ON [dbo].[DATA SUBTYPES] 
(
    [id] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[DATA SUBTYPES]') AND name = N'Name')
CREATE UNIQUE NONCLUSTERED INDEX [Name] ON [dbo].[DATA SUBTYPES] 
(
    [name] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[DATA SUBTYPES]') AND name = N'New ID')
CREATE NONCLUSTERED INDEX [New ID] ON [dbo].[DATA SUBTYPES] 
(
    [new id] ASC
) ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MM_FIELDFOLDER]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[MM_FIELDFOLDER](
    [index] [int] NOT NULL,
    [name] [nvarchar](255)  NOT NULL,
    [description] [nvarchar](255)  NULL,
    [subsystem_index] [int] NULL,
    [sequence_no] [int] NULL,
 CONSTRAINT [aaaaaMM_FIELDFOLDER_PK] PRIMARY KEY CLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MM_FIELDFOLDER]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[MM_FIELDFOLDER]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MM_FIELDFOLDER_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_MM_FIELDFOLDER_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MM_FIELDFOLDER_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_MM_FIELDFOLDER_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[MM_FIELDFOLDER]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[MM_FIELDFOLDER]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[MM_FIELDFOLDER] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[MM_FIELDFOLDER] SET temporary = [index]') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'aaaaaMM_FIELDFOLDER_PK'))
				ALTER TABLE [dbo].[MM_FIELDFOLDER] DROP Constraint aaaaaMM_FIELDFOLDER_PK; 
			ALTER TABLE [dbo].[MM_FIELDFOLDER] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[MM_FIELDFOLDER] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[MM_FIELDFOLDER].temporary', 'index', 'COLUMN';
			ALTER TABLE [dbo].[MM_FIELDFOLDER] ADD CONSTRAINT aaaaaMM_FIELDFOLDER_PK PRIMARY KEY([index]);  
		END 
	END
END	

GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MM_FIELDFOLDER_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_MM_FIELDFOLDER_INSERT];

EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_MM_FIELDFOLDER_INSERT] 
   ON  [dbo].[MM_FIELDFOLDER] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''MM_FIELDFOLDER''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),NEW.[index]),

                (''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(NEW.description,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),NEW.subsystem_index),'''')+''|#''+
                ''sequence_no=''+ISNULL(convert(nvarchar(15),NEW.sequence_no),'''')) from INSERTED NEW;
END
END





' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MM_FIELDFOLDER_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_MM_FIELDFOLDER_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_MM_FIELDFOLDER_UPDATE] 
   ON  [dbo].[MM_FIELDFOLDER]
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
        
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''MM_FIELDFOLDER''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),OLD.[index])+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(OLD.description,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),OLD.subsystem_index),'''')+''|#''+
                ''sequence_no=''+ISNULL(convert(nvarchar(15),OLD.sequence_no),'''')+
                '' where ''+''[index]=''+convert(nvarchar(15),OLD.[index]),
                 
                ''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(NEW.description,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),NEW.subsystem_index),'''')+''|#''+
                ''sequence_no=''+ISNULL(convert(nvarchar(15),NEW.sequence_no),'''')+
                '' where ''+''[index]=''+convert(nvarchar(15),NEW.[index])				
          from DELETED OLD,INSERTED NEW
where OLD.[index] = NEW.[index] ;
END
--update the field in CATEGORY table
UPDATE dbo.MM_FIELDFOLDER
SET [name]=NEW.[name],
    description=NEW.description,
    subsystem_index=NEW.subsystem_index,
    sequence_no=NEW.sequence_no
    from INSERTED NEW 
    where MM_FIELDFOLDER.[index]=NEW.[index];
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),OLD.[index])+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(OLD.description,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),OLD.subsystem_index),'''')+''|#''+
                ''sequence_no=''+ISNULL(convert(nvarchar(15),OLD.sequence_no),''''),
                ''[index]=''+convert(nvarchar(15),OLD.[index])
                from DELETED OLD;
end
--Delete the field from MM_FIELDFOLDER table
DELETE FROM MM_FIELDFOLDER WHERE [index] in (SELECT [index] from  DELETED)
END
END
' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MM_AUDIT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[MM_AUDIT](
    [index] [int] IDENTITY(1,1) NOT NULL,
    [action] [smallint] NOT NULL,
    [timestamp] [datetime] NOT NULL,
    [table_name] [nvarchar](50)  NOT NULL,
    [oldvalues] [ntext]  NULL,
    [newvalues] [ntext]  NULL,
    [user_name] [nvarchar](255)  NOT NULL,
    [action_index] [int] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MM_USER_ACTIONS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	IF EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[MM_USER_ACTIONS]') AND name = N'processid')
		ALTER TABLE [dbo].[MM_USER_ACTIONS]  ALTER COLUMN [processid] [int] NULL
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MM_USER_ACTIONS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[MM_USER_ACTIONS](
    [user_name] [nvarchar](50)  NOT NULL,
    [index] [int] IDENTITY(1,1) NOT NULL,
    [description] [nvarchar](50)  NULL,
    [timestamp] [datetime] NOT NULL,
    [processid] [int] NULL,
	[machinename] [nchar](255)  NOT NULL,
    [subsystemindex] [int] NOT NULL,
    [iscurrentlyundone] [bit] NOT NULL DEFAULT ((0)),
    [isobsoleteforredoundo] [bit] NOT NULL DEFAULT ((0)),
 CONSTRAINT [PK_MM_USER_ACTIONS] PRIMARY KEY CLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CC_AUDIT]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[CC_AUDIT](
    [index] [int] IDENTITY(1,1) NOT NULL,
    [action] [smallint] NOT NULL,
    [timestamp] [datetime] NOT NULL,
    [table_name] [nvarchar](50)  NOT NULL,
    [oldvalues] [ntext]  NULL,
    [newvalues] [ntext]  NULL,
    [user_name] [nvarchar](255)  NOT NULL,
    [action_index] [int] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CC_USER_ACTIONS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	IF EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[CC_USER_ACTIONS]') AND name = N'processid')
		ALTER TABLE [dbo].[CC_USER_ACTIONS]  ALTER COLUMN [processid] [int] NULL
END
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CC_USER_ACTIONS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[CC_USER_ACTIONS](
    [user_name] [nvarchar](50)  NOT NULL,
    [index] [int] IDENTITY(1,1) NOT NULL,
    [description] [nvarchar](50)  NULL,
    [timestamp] [datetime] NOT NULL,
    [processid] [int] NULL,
	[machinename] [nchar](255)  NOT NULL,
    [iscurrentlyundone] [bit] NOT NULL DEFAULT ((0)),
    [isobsoleteforredoundo] [bit] NOT NULL DEFAULT ((0)),
 CONSTRAINT [PK_CC_USER_ACTIONS] PRIMARY KEY CLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[OUTPUT_FIELD]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[OUTPUT_FIELD](
    [index] [int] NOT NULL,
    [field_index] [int] NULL,
    [output_record_index] [int] NULL,
    [name] [nvarchar](255)  NULL,
    [mask_name] [nvarchar](255)  NULL,
    [column] [smallint] NULL,
    [data_type] [char](1)  NULL,
    [value_type] [char](1)  NULL,
    [byte_offset] [smallint] NULL,
    [length] [smallint] NULL,
    [right] [smallint] NULL,
    [date_format] [char](1)  NULL,
    [date_slash] [char](1)  NULL,
    [repeat] [char](1)  NULL,
    [decimal] [char](1)  NULL,
    [comma] [char](1)  NULL,
    [justify] [char](1)  NULL,
    [zero] [char](1)  NULL,
    [sign] [char](1)  NULL,
    [scale_factor] [smallint] NULL,
    [weight_field_index] [int] NULL,
    [version] [int] NULL,
    [pcf_use] [char](1)  NULL,
    [delete] [bit] NULL,
    [sub_field_of] [int] NULL CONSTRAINT [DF_OUTPUT_FIELD_Sub_Field_Of]  DEFAULT ((0)),
 CONSTRAINT [PK_OUTPUT_FIELD] PRIMARY KEY CLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[OUTPUT_FIELD]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[OUTPUT_FIELD]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_OUTPUT_FIELD_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_OUTPUT_FIELD_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_OUTPUT_FIELD_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_OUTPUT_FIELD_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[OUTPUT_FIELD]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[OUTPUT_FIELD]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[OUTPUT_FIELD] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[OUTPUT_FIELD] SET temporary = [index]') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'PK_OUTPUT_FIELD'))
				ALTER TABLE [dbo].[OUTPUT_FIELD] DROP Constraint PK_OUTPUT_FIELD;
			IF EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[OUTPUT_FIELD]') AND name = N'Index')



				DROP INDEX [Index] ON [dbo].[OUTPUT_FIELD] WITH ( ONLINE = OFF )

			ALTER TABLE [dbo].[OUTPUT_FIELD] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[OUTPUT_FIELD] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[OUTPUT_FIELD].temporary', 'index', 'COLUMN';
			ALTER TABLE [dbo].[OUTPUT_FIELD] ADD CONSTRAINT PK_OUTPUT_FIELD PRIMARY KEY([index]);  
		END 
	END
END	

GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[OUTPUT_FIELD]') AND name = N'Index')
CREATE NONCLUSTERED INDEX [Index] ON [dbo].[OUTPUT_FIELD] 
(
    [index] ASC
) ON [PRIMARY]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_OUTPUT_FIELD_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_OUTPUT_FIELD_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_OUTPUT_FIELD_INSERT] 
   ON  [dbo].[OUTPUT_FIELD] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''OUTPUT_FIELD''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),NEW.[index]),

                (''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''field_index=''+ISNULL(convert(nvarchar(15),NEW.field_index),'''')+''|#''+
                ''output_record_index=''+ISNULL(convert(nvarchar(15),NEW.output_record_index),'''')+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''mask_name=''+''''''''+ISNULL(Replace(NEW.mask_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[column]=''+ISNULL(convert(nvarchar(15),NEW.[column]),'''') +''|#''+
                ''data_type=''+''''''''+ISNULL(Replace(NEW.data_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''value_type=''+''''''''+ISNULL(Replace(NEW.value_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''byte_offset=''+ISNULL(convert(nvarchar(15),NEW.byte_offset),'''') +''|#''+
                ''length=''+ISNULL(convert(nvarchar(15),NEW.length),'''') +''|#''+
                ''[right]=''+ISNULL(convert(nvarchar(15),NEW.[right]),'''') +''|#''+
                ''date_format=''+''''''''+ISNULL(Replace(NEW.date_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''date_slash=''+''''''''+ISNULL(Replace(NEW.date_slash,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''repeat=''+''''''''+ISNULL(Replace(NEW.repeat,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''decimal=''+''''''''+ISNULL(Replace(NEW.decimal,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''comma=''+''''''''+ISNULL(Replace(NEW.comma,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''justify=''+''''''''+ISNULL(Replace(NEW.justify,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''zero=''+''''''''+ISNULL(Replace(NEW.zero,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[sign]=''+''''''''+ISNULL(Replace(NEW.[sign],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''scale_factor=''+ISNULL(convert(nvarchar(15),NEW.scale_factor),'''') +''|#''+
                ''weight_field_index=''+ISNULL(convert(nvarchar(15),NEW.weight_field_index),'''') +''|#''+
                ''pcf_use=''+''''''''+ISNULL(Replace(NEW.pcf_use,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[delete]=''+convert(nvarchar(15),NEW.[delete]) +''|#''+
                ''sub_field_of=''+ISNULL(convert(nvarchar(15),NEW.sub_field_of),'''')) from INSERTED NEW;
END
END




' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_OUTPUT_FIELD_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_OUTPUT_FIELD_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_OUTPUT_FIELD_UPDATE] 
   ON  [dbo].[OUTPUT_FIELD] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255),
    @value smallint

    SET @value = CHARINDEX(''2000'',@@VERSION,0)
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''OUTPUT_FIELD''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    
--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''field_index=''+ISNULL(convert(nvarchar(15),OLD.field_index),'''')+''|#''+
                ''output_record_index=''+ISNULL(convert(nvarchar(15),OLD.output_record_index),'''')+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''mask_name=''+''''''''+ISNULL(Replace(OLD.mask_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[column]=''+ISNULL(convert(nvarchar(15),OLD.[column]),'''') +''|#''+
                ''data_type=''+''''''''+ISNULL(Replace(OLD.data_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''value_type=''+''''''''+ISNULL(Replace(OLD.value_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''byte_offset=''+ISNULL(convert(nvarchar(15),OLD.byte_offset),'''') +''|#''+
                ''length=''+ISNULL(convert(nvarchar(15),OLD.length),'''') +''|#''+
                ''[right]=''+ISNULL(convert(nvarchar(15),OLD.[right]),'''') +''|#''+
                ''date_format=''+''''''''+ISNULL(Replace(OLD.date_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''date_slash=''+''''''''+ISNULL(Replace(OLD.date_slash,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''repeat=''+''''''''+ISNULL(Replace(OLD.repeat,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''decimal=''+''''''''+ISNULL(Replace(OLD.decimal,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''comma=''+''''''''+ISNULL(Replace(OLD.comma,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''justify=''+''''''''+ISNULL(Replace(OLD.justify,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''zero=''+''''''''+ISNULL(Replace(OLD.zero,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[sign]=''+''''''''+ISNULL(Replace(OLD.[sign],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''scale_factor=''+ISNULL(convert(nvarchar(15),OLD.scale_factor),'''') +''|#''+
                ''weight_field_index=''+ISNULL(convert(nvarchar(15),OLD.weight_field_index),'''') +''|#''+
                ''pcf_use=''+''''''''+ISNULL(Replace(OLD.pcf_use,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[delete]=''+convert(nvarchar(15),OLD.[delete]) +''|#''+
                ''sub_field_of=''+ISNULL(convert(nvarchar(15),OLD.sub_field_of),'''') +
                '' WHERE ''+''[index]=''+convert(nvarchar(15),OLD.[index]),
                 
                ''field_index=''+ISNULL(convert(nvarchar(15),NEW.field_index),'''')+''|#''+
                ''output_record_index=''+ISNULL(convert(nvarchar(15),NEW.output_record_index),'''')+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''mask_name=''+''''''''+ISNULL(Replace(NEW.mask_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[column]=''+ISNULL(convert(nvarchar(15),NEW.[column]),'''') +''|#''+
                ''data_type=''+''''''''+ISNULL(Replace(NEW.data_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''value_type=''+''''''''+ISNULL(Replace(NEW.value_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''byte_offset=''+ISNULL(convert(nvarchar(15),NEW.byte_offset),'''') +''|#''+
                ''length=''+ISNULL(convert(nvarchar(15),NEW.length),'''') +''|#''+
                ''[right]=''+ISNULL(convert(nvarchar(15),NEW.[right]),'''') +''|#''+
                ''date_format=''+''''''''+ISNULL(Replace(NEW.date_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''date_slash=''+''''''''+ISNULL(Replace(NEW.date_slash,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''repeat=''+''''''''+ISNULL(Replace(NEW.repeat,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''decimal=''+''''''''+ISNULL(Replace(NEW.decimal,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''comma=''+''''''''+ISNULL(Replace(NEW.comma,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''justify=''+''''''''+ISNULL(Replace(NEW.justify,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''zero=''+''''''''+ISNULL(Replace(NEW.zero,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[sign]=''+''''''''+ISNULL(Replace(NEW.[sign],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''scale_factor=''+ISNULL(convert(nvarchar(15),NEW.scale_factor),'''') +''|#''+
                ''weight_field_index=''+ISNULL(convert(nvarchar(15),NEW.weight_field_index),'''') +''|#''+
                ''pcf_use=''+''''''''+ISNULL(Replace(NEW.pcf_use,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[delete]=''+convert(nvarchar(15),NEW.[delete]) +''|#''+
                ''sub_field_of=''+ISNULL(convert(nvarchar(15),NEW.sub_field_of),'''') +
                '' WHERE ''+''[index]=''+convert(nvarchar(15),NEW.[index]) from DELETED OLD,INSERTED NEW
    where NEW.[index] = OLD.[index];
END
--update the field in OUTPUT_FIELD table
UPDATE dbo.OUTPUT_FIELD
SET field_index=NEW.field_index,
    output_record_index=NEW.output_record_index,
    [name]=NEW.[name],
    mask_name=NEW.mask_name,
    [column]=NEW.[column],
    data_type=NEW.data_type,
    value_type=NEW.value_type,
    byte_offset=NEW.byte_offset,
    length=NEW.length,
    [right]=NEW.[right],
    date_format=NEW.date_format,
    date_slash=NEW.date_slash,
    repeat=NEW.repeat,
    [decimal]=NEW.[decimal],
    comma=NEW.comma,
    justify=NEW.justify,
    zero=NEW.zero,
    [sign]=NEW.[sign],
    scale_factor=NEW.scale_factor,
    weight_field_index=NEW.weight_field_index,
    version=NEW.version,
    pcf_use=NEW.pcf_use,
    [delete]=NEW.[delete],
    sub_field_of=NEW.sub_field_of
    from INSERTED NEW
    where OUTPUT_FIELD.[index] in (NEW.[index]);
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''field_index=''+ISNULL(convert(nvarchar(15),OLD.field_index),'''')+''|#''+
                ''output_record_index=''+ISNULL(convert(nvarchar(15),OLD.output_record_index),'''')+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''mask_name=''+''''''''+ISNULL(Replace(OLD.mask_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[column]=''+ISNULL(convert(nvarchar(15),OLD.[column]),'''') +''|#''+
                ''data_type=''+''''''''+ISNULL(Replace(OLD.data_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''value_type=''+''''''''+ISNULL(Replace(OLD.value_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''byte_offset=''+ISNULL(convert(nvarchar(15),OLD.byte_offset),'''') +''|#''+
                ''length=''+ISNULL(convert(nvarchar(15),OLD.length),'''') +''|#''+
                ''[right]=''+ISNULL(convert(nvarchar(15),OLD.[right]),'''') +''|#''+
                ''date_format=''+''''''''+ISNULL(Replace(OLD.date_format,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''date_slash=''+''''''''+ISNULL(Replace(OLD.date_slash,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''repeat=''+''''''''+ISNULL(Replace(OLD.repeat,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''decimal=''+''''''''+ISNULL(Replace(OLD.decimal,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''comma=''+''''''''+ISNULL(Replace(OLD.comma,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''justify=''+''''''''+ISNULL(Replace(OLD.justify,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''zero=''+''''''''+ISNULL(Replace(OLD.zero,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[sign]=''+''''''''+ISNULL(Replace(OLD.[sign],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''scale_factor=''+ISNULL(convert(nvarchar(15),OLD.scale_factor),'''') +''|#''+
                ''weight_field_index=''+ISNULL(convert(nvarchar(15),OLD.weight_field_index),'''') +''|#''+
                ''pcf_use=''+''''''''+ISNULL(Replace(OLD.pcf_use,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[delete]=''+convert(nvarchar(15),OLD.[delete]) +''|#''+
                ''sub_field_of=''+ISNULL(convert(nvarchar(15),OLD.sub_field_of),'''') +''|#''+
                ''[index]=''+convert(nvarchar(15),OLD.[index]),''[index]=''+convert(nvarchar(15),OLD.[index]) from DELETED OLD;
end
--Delete the field from OUTPUT_FIELD table
DELETE FROM OUTPUT_FIELD where [index] in (SELECT OLD.[index] from DELETED OLD);
END
END




' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MM_SCHEDULE]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[MM_SCHEDULE](
    [report_index] [int] NULL DEFAULT ((0)),
    [schedule_number] [smallint] NULL DEFAULT ((0)),
    [repetition] [smallint] NULL DEFAULT ((0)),
    [inter_size] [smallint] NULL DEFAULT ((0)),
    [inter_type] [nvarchar](1)  NULL,
    [description] [nvarchar](255)  NULL,
    [version] [int] NULL DEFAULT ((0)),
    [PKey] [int] NOT NULL,
 CONSTRAINT [PK_MM_SCHEDULE] PRIMARY KEY CLUSTERED 
(
    [PKey] ASC
) ON [PRIMARY]
) ON [PRIMARY]

--INSERT Global Data for MM_SCHEDULE table

INSERT MM_SCHEDULE([report_index],[schedule_number],[repetition],[inter_size],[inter_type],[description],[version],[PKey])       VALUES('0','0','0','1','R','Process Date','0', '1')
INSERT MM_SCHEDULE([report_index],[schedule_number],[repetition],[inter_size],[inter_type],[description],[version],[PKey])       VALUES('0','1','1','1','O','Over Night','0', '2')
INSERT MM_SCHEDULE([report_index],[schedule_number],[repetition],[inter_size],[inter_type],[description],[version],[PKey])       VALUES('0','2','12','1','M','Year 1','0', '3')
INSERT MM_SCHEDULE([report_index],[schedule_number],[repetition],[inter_size],[inter_type],[description],[version],[PKey])       VALUES('0','3','13','1','P','Year 1 Total','0', '4')
INSERT MM_SCHEDULE([report_index],[schedule_number],[repetition],[inter_size],[inter_type],[description],[version],[PKey])       VALUES('0','4','12','1','M','Year 2','0', '5')
INSERT MM_SCHEDULE([report_index],[schedule_number],[repetition],[inter_size],[inter_type],[description],[version],[PKey])       VALUES('0','5','12','1','P','Year 2 Total','0', '6')
INSERT MM_SCHEDULE([report_index],[schedule_number],[repetition],[inter_size],[inter_type],[description],[version],[PKey])       VALUES('0','6','4','1','Q','Year 3','0', '7')
INSERT MM_SCHEDULE([report_index],[schedule_number],[repetition],[inter_size],[inter_type],[description],[version],[PKey])       VALUES('0','7','4','1','P','Year 3 Total','0', '8')
INSERT MM_SCHEDULE([report_index],[schedule_number],[repetition],[inter_size],[inter_type],[description],[version],[PKey])       VALUES('0','8','2','1','Y','Years 4~5','0', '9')
INSERT MM_SCHEDULE([report_index],[schedule_number],[repetition],[inter_size],[inter_type],[description],[version],[PKey])       VALUES('0','9','5','5','Y','Years 6~30','0', '10')


END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[MM_SCHEDULE]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[MM_SCHEDULE]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MM_SCHEDULE_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_MM_SCHEDULE_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MM_SCHEDULE_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_MM_SCHEDULE_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[MM_SCHEDULE]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[MM_SCHEDULE]') AND name = N'PKey') 
		BEGIN
			ALTER TABLE [dbo].[MM_SCHEDULE] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[MM_SCHEDULE] SET temporary = PKey') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'PK_MM_SCHEDULE'))
				ALTER TABLE [dbo].[MM_SCHEDULE] DROP Constraint PK_MM_SCHEDULE; 
			ALTER TABLE [dbo].[MM_SCHEDULE] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[MM_SCHEDULE] DROP COLUMN PKey; 
			EXEC sp_rename '[dbo].[MM_SCHEDULE].temporary', 'PKey', 'COLUMN'; 
			ALTER TABLE [dbo].[MM_SCHEDULE] ADD CONSTRAINT PK_MM_SCHEDULE PRIMARY KEY(PKey); 
		END 
	END
END	

GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[MM_SCHEDULE]') AND name = N'Report_index')
CREATE NONCLUSTERED INDEX [Report_index] ON [dbo].[MM_SCHEDULE] 
(
    [report_index] ASC
) ON [PRIMARY]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MM_SCHEDULE_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_MM_SCHEDULE_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_MM_SCHEDULE_INSERT] 
   ON  [dbo].[MM_SCHEDULE] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''MM_SCHEDULE''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''PKey=''+convert(nvarchar(15),NEW.PKey),

                (''PKey=''+convert(nvarchar(15),NEW.PKey)+''|#''+
                ''report_index=''+ISNULL(convert(nvarchar(15),NEW.report_index),'''')+''|#''+
                ''schedule_number=''+ISNULL(convert(nvarchar(15),NEW.schedule_number),'''')+''|#''+
                ''repetition=''+ISNULL(convert(nvarchar(15),NEW.repetition),'''')+''|#''+
                ''inter_size=''+ISNULL(convert(nvarchar(15),NEW.inter_size),'''') +''|#''+
                ''inter_type=''+''''''''+ISNULL(Replace(NEW.inter_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(NEW.description,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''')) from INSERTED NEW;
END
END



' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_MM_SCHEDULE_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_MM_SCHEDULE_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_MM_SCHEDULE_UPDATE] 
   ON  [dbo].[MM_SCHEDULE] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''MM_SCHEDULE''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''report_index=''+ISNULL(convert(nvarchar(15),OLD.report_index),'''')+''|#''+
                ''schedule_number=''+ISNULL(convert(nvarchar(15),OLD.schedule_number),'''')+''|#''+
                ''repetition=''+ISNULL(convert(nvarchar(15),OLD.repetition),'''')+''|#''+
                ''inter_size=''+ISNULL(convert(nvarchar(15),OLD.inter_size),'''') +''|#''+
                ''inter_type=''+''''''''+ISNULL(Replace(OLD.inter_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(OLD.description,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''')+
                '' where ''+''PKey=''+convert(nvarchar(15),OLD.PKey),
                 
                ''report_index=''+ISNULL(convert(nvarchar(15),NEW.report_index),'''')+''|#''+
                ''schedule_number=''+ISNULL(convert(nvarchar(15),NEW.schedule_number),'''')+''|#''+
                ''repetition=''+ISNULL(convert(nvarchar(15),NEW.repetition),'''')+''|#''+
                ''inter_size=''+ISNULL(convert(nvarchar(15),NEW.inter_size),'''') +''|#''+
                ''inter_type=''+''''''''+ISNULL(Replace(NEW.inter_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(NEW.description,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''')+
                '' where ''+''PKey=''+convert(nvarchar(15),NEW.PKey)
           from DELETED OLD,INSERTED NEW where NEW.PKey = OLD.PKey;
END
--update the field in CATEGORY table
UPDATE dbo.MM_SCHEDULE
SET report_index=NEW.report_index,
    schedule_number=NEW.schedule_number,
    repetition=NEW.repetition,
    inter_size=NEW.inter_size,
    inter_type=NEW.inter_type,
    description=NEW.description,
    version=NEW.version
    from INSERTED NEW 
    where MM_SCHEDULE.PKey = NEW.PKey;
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''PKey=''+convert(nvarchar(15),OLD.PKey)+''|#''+
                ''report_index=''+ISNULL(convert(nvarchar(15),OLD.report_index),'''')+''|#''+
                ''schedule_number=''+ISNULL(convert(nvarchar(15),OLD.schedule_number),'''')+''|#''+
                ''repetition=''+ISNULL(convert(nvarchar(15),OLD.repetition),'''')+''|#''+
                ''inter_size=''+ISNULL(convert(nvarchar(15),OLD.inter_size),'''') +''|#''+
                ''inter_type=''+''''''''+ISNULL(Replace(OLD.inter_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(OLD.description,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),''''),

                ''PKey=''+convert(nvarchar(15),OLD.PKey)
                from DELETED OLD;
end
--Delete the field from CATEGORY table
DELETE FROM MM_SCHEDULE WHERE PKey in(SELECT  PKey from DELETED);

END
END



' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[TRANSFORM_PARAM_TYPES]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	DROP TABLE [dbo].[TRANSFORM_PARAM_TYPES]
	
GO	

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[TRANSFORM_PARAM_TYPES]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[TRANSFORM_PARAM_TYPES](
    [id] [int] NOT NULL,
    [function_number] [int] NULL,
    [name] [nvarchar](50)  NULL,
    [description] [nvarchar](255)  NULL,
    [input order] [int] NULL,
    [data subtype id] [int] NULL,
    [srcfield] [bit] NOT NULL DEFAULT ((0)),
    [srcliteral] [bit] NOT NULL DEFAULT ((0)),
    [required] [bit] NOT NULL DEFAULT ((1)),
    [transform type idx] [int] NULL,
    [list_id] [nvarchar](50)  NULL,
    [default] [nvarchar](50)  NULL,
    [isrepeatvalue] [bit] NOT NULL DEFAULT ((0))   
) ON [PRIMARY]

--INSERT Global Data for TRANSFORM_PARAM_TYPES table

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('1','2','Date of run.','No arguments for this function','1','13','0','0','1','252','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('2','3','A Date','Date in Header record; Constant; or [Run date] field','1','13','1','1','1','253','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('3','4','A Date','Header or Application Date; Constant;  [Processing Date] ;[Run Date]','1','13','1','1','1','254','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('4','5','A Date','Date field or constant in CY/M/D format','1','13','1','1','1','255','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('5','6','First Number','a number or numeric field','1','20','1','1','1','256','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('6','6','Second Number','a number or numeric field','2','20','1','1','1','256','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('7','7','First Number','a number or numeric field','1','20','1','1','1','258','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('8','7','less 2nd Number','a number or numeric field','2','20','1','1','1','258','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('9','8','First Number','a number or numeric field','1','20','1','1','1','259','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('10','8','X 2nd Number','a number or numeric field','2','20','1','1','1','259','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('11','9','Numerator','a number or numeric field','1','20','1','1','1','260','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('12','9','Denominator','a number or numeric field','2','20','1','1','1','260','','1','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('13','10','Numerator','a number or numeric field','1','20','1','1','1','261','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('14','10','Denominator','a number or numeric field','2','20','1','1','1','260','','1','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('15','11','Numerator','a number or numeric field','1','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('16','11','Denominator','a number or numeric field','2','20','1','1','1','0','','1','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('17','12','Base Number','a number or numeric field','1','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('18','12','Exponent','a number or numeric field','2','20','1','1','1','0','','1','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('19','13','Starting Date','Date field or constant','1','13','1','1','1','264','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('20','13','Number of Periods','Numeric constant or number field','2','22','1','1','1','264','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('21','13','Interval','e.g. 1 M for 1 month;30 D for 30 days','3','23','1','1','1','264','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('22','14','Starting Date','Date field or constant','1','13','1','1','1','267','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('23','14','Number of Periods','Numeric constant or number field','2','22','1','1','1','267','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('24','14','Interval','e.g. 1 M for 1 month;30 D for 30 days','3','23','1','1','1','267','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('25','15','Interval Start Date','Date field or constant','1','13','1','1','1','270','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('26','15','Interval End Date','Date field or constant in CY/M/D format','2','13','1','1','1','270','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('27','15','Interval unit','Interval field or constant. E.g. 3 M,15 D','3','23','1','1','1','270','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('28','15','M,R,T,D,B','See help for details.','4','12','1','1','1','270','IntervalType1','M','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('29','16','Start Date','Date field or constant in CY/M/D format','1','13','1','1','1','274','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('30','16','End Date','Date field or constant in CY/M/D format','2','13','1','1','1','274','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('31','16','Interval','Interval field or constant;E.g. 3 M,15 D','3','23','1','1','1','274','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('32','17','Start Date','Date field or constant in m/d/y format','1','13','1','1','1','277','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('33','17','End Date','Date field or constant in CY/M/D format','2','13','1','1','1','277','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('34','17','Interval','Interval field or constant;E.g. 3 M,15 D','3','23','1','1','1','277','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('35','18','Interval','Interval field or constant;E.g. 3 M,15 D','1','23','1','1','1','280','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('36','18','Start Date','Date field or constant in CY/M/D format','2','13','1','1','1','280','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('37','18','''C'' or ''B''','C=Calendar day; B=Business day','3','12','0','1','1','280','DayType','C','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('38','19','Interval','Interval field or constant;E.g. 3 M,15 D','1','23','1','1','1','283','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('39','19','Start Date','Date field or constant in CY/M/D format','2','13','1','1','1','283','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('40','19','''C'' or ''B''','C=Calendar day; B=Business day','3','12','0','1','1','283','DayType','C','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('41','20','Interval','Interval field or constant;E.g. 3 M,15 D','1','23','1','1','1','286','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('42','20','Start Date','Date field or constant in CY/M/D format','2','13','1','1','1','286','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('43','20','''C'' or ''B''','C=Calendar day; B=Business day','3','12','0','1','1','286','DayType','C','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('44','21','Interval','Interval field or constant;E.g. 3 M,15 D','1','23','1','1','1','289','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('45','21','Start Date','Date field or constant in CY/M/D format','2','13','1','1','1','289','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('46','21','''C'' or ''B''','C=Calendar day; B=Business day','3','12','0','1','1','289','DayType','C','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('47','22','Interval','Interval field or constant;E.g. 3 M,15 D','1','23','1','1','1','292','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('48','22','Start Date','Date field or constant in CY/M/D format','2','13','1','1','1','292','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('49','22','''C'' or ''B''','C=Calendar day; B=Business day','3','12','0','1','1','292','DayType','C','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('50','23','Interval','Interval field or constant;E.g. 3 M,15 D','1','23','1','1','1','295','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('51','23','Start Date','Date field or constant in CY/M/D format','2','13','1','1','1','295','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('52','23','''C'' or ''B''','C=Calendar day; B=Business day','3','12','0','1','1','295','DayType','C','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('53','24','First Number','Numeric constant or number field','1','20','1','1','1','298','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('54','24','Second Number','Numeric constant or number field','2','20','1','1','1','298','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('55','25','First Date','Date field or constant in CY/M/D format','1','13','1','1','1','300','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('56','25','Second Date','Date field or constant in CY/M/D format','2','13','1','1','1','300','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('57','26','First String','Letters and Numbers field or string','1','12','1','1','1','302','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('58','26','Second String','Letters and Numbers field or string','2','12','1','1','1','302','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('66','28','Date in desired month','Date field or constant in CY/M/D format','1','13','1','1','1','311','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('67','29','Date in desired year','Date field or constant in CY/M/D format','1','13','1','1','1','312','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('68','30','Starting Date','Date field or constant in CY/M/D format','1','13','1','1','1','313','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('69','30','Accrual Method','Accrual method code or field. See Help for details.','2','12','1','1','1','313','AccrualType','AA','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('70','31','Starting Date','Date field or constant in CY/M/D format','1','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('71','31','Accrual Method','If Literal then only AA,A0,A5,00 and 05 accepted.','2','12','1','1','1','0','AccrualType','AA','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('72','31','Current Principal','Numeric constant or number field','3','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('73','31','Accrual Rate','Numeric constant or number field','4','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('74','31','"P"(%) "R"(RATE)','Only "P" or "R" accepted in this field.','5','12','0','1','1','0','RateType','P','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('75','31','Interval','Interval field or constant;E.g. 3 M,15 D','6','23','1','1','1','0','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('178','27','Funding Rate Table','One of Listed External Tables or a field','1','26','1','0','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('179','27','Funding Method','One of Listed transfer Funding methods or an appropriate field or an index','2','22','1','1','1','0','FundType','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('180','27','TP CF Method','One of Listed TP CF methods or the default UTR','3','27','1','0','0','0','','Use Current UTR','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('181','27','Balance Funded','Original or current balance?','4','12','0','1','0','0','OrigOrCurBal','{O}-Original Balance','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('182','27','Discount Rate','Rate field or constant','5','20','1','1','0','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('183','40','Amortization Code','"P&I" or "P+I" or equivalent field','7','12','1','1','1','0','AmortType','P&I','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('76','32','Field or constant','field or constant to be reformatted','1','25','1','1','1','321','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('77','33','String source','any source field or literal','1','25','1','1','1','322','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('78','33','Start position','Numeric constant or number field','2','22','1','1','1','322','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('79','33','Length of SubString','Numeric constant or number field','3','22','1','1','1','322','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('80','34','First string','any source field or literal','1','25','1','1','1','325','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('81','34','Second string','any source field or literal','2','25','1','1','1','325','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('82','35','Current Principal','Numeric constant or number field','1','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('83','35','Coupon Rate','Numeric constant or number field','2','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('84','35','Payment Amount','Numeric constant or number field','3','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('85','35','Interval','Interval field or constant;E.g. 3 M,15 D','4','23','1','1','1','0','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('86','35','Next Payment Date','Date field or constant in CY/M/D format','5','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('87','35','Amortization Code','"P&I" or "P+I" or equivalent field','6','12','1','1','1','0','AmortType','P&I','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('88','36','Current Principal','Numeric constant or number field','1','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('89','36','Coupon Rate','Numeric constant or number field','2','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('90','36','Payment Frequency','Interval field or constant;E.g. 3 M,15 D','3','23','1','1','1','0','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('91','36','Next Payment Date','Date field or constant in CY/M/D format','4','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('92','36','Amortization Date','Date field or constant in CY/M/D format','5','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('93','36','Amortization Code','"P&I" or "P+I" or equivalent field','6','12','1','1','1','0','AmortType','P&I','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('94','37','A Date','Date field or constant in CY/M/D format','1','13','1','1','1','339','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('95','38','Premium','Numeric constant or number field','1','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('96','38','Balance','Numeric constant or number field','2','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('97','38','Payment Amount','Numeric constant or number field','3','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('98','38','Interval','Interval field or constant;E.g. 3 M,15 D','4','23','1','1','1','0','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('99','38','Next Payment Date','Date field or constant in CY/M/D format','5','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('100','38','Amortization Date','Date field or constant in CY/M/D format','6','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('101','40','Current Principal','Numeric constant or number field','1','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('102','40','Coupon Rate','Numeric constant or number field','2','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('103','40','Payment Amount','Numeric constant or number field','3','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('104','40','Origination Date','Date field or constant in CY/M/D format','4','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('105','40','Next Payment Date','Date field or constant in CY/M/D format','5','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('106','40','Amortization Date','Date field or constant in CY/M/D format','6','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('107','41','Discount Rate','Numeric constant or number field','1','20','1','1','0','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('108','42','Discount Rate','Numeric constant or number field','1','20','1','1','0','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('109','42','"M"(MONTH) "Y"(YEAR)','Only M or Y accepted','2','12','0','1','0','0','PeriodType','M','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('110','43','"M"(MONTH) "Y"(YEAR)','Only M or Y accepted','1','12','0','1','0','0','PeriodType','M','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('111','44','Current Principal','Numeric constant or number field','1','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('112','44','Coupon Rate','Numeric constant or number field','2','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('113','44','Amortization Code','"P&I" or "P+I"','3','12','1','1','1','0','AmortType','P&I','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('114','44','Payment Amount','Numeric constant or number field','4','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('115','44','Interval','Interval field or constant;E.g. 3 M,15 D','5','23','1','1','1','0','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('116','44','Last Payment Date','Date field or constant in CY/M/D format','6','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('117','44','Status Code','''ACT'','' NEW'' or ''CLS''','7','12','1','1','1','0','StatusType','ACT','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('118','45','"A"(Asset) "L"(Liability)','L or A','1','12','1','1','1','0','AccountType','A','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('120','46','Number','Numeric constant or number field','1','22','1','1','1','367','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('121','47','Payment Amount','Numeric constant or number field','1','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('122','47','Coupon Rate','Numeric constant or number field','2','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('123','47','Interval','Interval field or constant;E.g. 3 M,15 D','3','23','1','1','1','0','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('124','47','Next Payment Date','Date field or constant in CY/M/D format','4','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('125','47','Amortization Date','Date field or constant in CY/M/D format','5','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('126','47','Amortization Code','"P&I" or "P+I"','6','12','1','1','1','0','AmortType','P&I','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('127','48','"M" (MONTH) "Y"(YEAR)','Field or Literal = ''M'' or ''Y''','1','12','1','1','0','0','PeriodType','M','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('128','999','Binary','This is a Yes/No input','1','17','0','1','1','375','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('129','999','Binary Combo','This is a Yes/No input','2','17','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('130','999','Binary Date','This is simply a Date','3','19','0','1','1','375','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('131','999','Binary Date Combo','This is simply a Date','4','19','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('132','999','Date','This is also a Date','5','13','0','1','1','375','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('133','999','Date Combo','This is also a Date','6','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('134','999','Packed Date','Yet another date','7','18','0','1','1','375','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('135','999','Packed Date Combo','Yet another date','8','18','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('136','999','Packed BCD','Floating Point Number','9','16','0','1','1','375','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('137','999','Packed BCD Combo','Floating Point Number','10','16','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('138','999','Decimal Signed','Decimal (signed)','11','15','0','1','1','375','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('139','999','Decimal Signed Combo','Decimal (signed)','12','15','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('140','999','Decimal Unsigned','Decimal (unsigned)','13','14','0','1','1','375','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('141','999','Decimal Unsigned Combo','Decimal (unsigned)','14','14','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('142','999','Floating Point','Floating Point Number','15','20','0','1','1','375','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('143','999','Floating Point Combo','Floating Point Number','16','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('144','999','Frequency','### Days  OR ### Months','17','23','0','1','1','375','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('145','999','Frequency Combo','### Days  OR ### Months','18','23','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('146','999','Hexidecimal','Hexidecimal Number','19','24','0','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('147','999','Hexidecimal Combo','Hexidecimal Number','20','24','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('148','999','Integer','Integer','21','21','0','1','1','375','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('149','999','Integer Combo','Integer','22','21','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('150','999','Unsigned','Unsigned integer','23','22','0','1','1','375','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('151','999','Unsigned Combo','Unsigned integer','24','22','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('152','999','Letters and Numbers','Any AlphaNumeric input','25','12','0','1','1','375','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('153','999','Letters and Numbers Combo','Any AlphaNumeric input','26','12','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('154','1000','Date Param','Date (characters)','27','13','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('184','40','Payment Frequency','Interval field or constant;E.g. 3 M, 15 D','8','23','1','1','1','0','','1 Month','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('185','41','TP CF Method','One of Listed TP CF Methods or the default UTR','2','27','1','0','0','0','','Use Current UTR','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('186','42','TP CF Method','One of Listed TP CF Methods or the default UTR','3','27','1','0','0','0','','Use Current UTR','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('187','43','TP CF Method','One of Listed TP CF Methods or the default UTR','2','27','1','0','0','0','','Use Current UTR','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('188','48','TP CF Method','One of Listed TP CF Methods or the default UTR','2','27','1','0','0','0','','Use Current UTR','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('212','53','Library Name','AMBITBUDGET','1','12','1','0','1','14965312','','AMBITBUDGET','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('213','53','Function Name','Prepaid Prin. Sched.','2','12','1','0','1','14965312','','ReprSched','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('214','53','Cash Flow Schedule','Ambit Amortizing Balance Schedule','3','28','1','0','1','14965312','','[Amortizing Balance]','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('215','53','Repricing Balance','Ambit Repricing Balance Schedule','4','28','1','1','1','14965312','','[Repricing Balance]','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('216','53','Buffer Name','A name unique to this field','5','12','1','1','1','14965312','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('217','54','Library Name','AMBITBUDGET','1','12','1','0','1','14965312','','AMBITBUDGET','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('218','54','Function Name','Returns Rate * Balance Schedule','2','12','1','0','1','14965312','','WtdRate','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('219','54','Cash Flow Schedule','Ambit Schedule','3','28','1','0','1','14965312','','[Amortizing Balance]','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('220','54','Annual Interest Rate','Any Numeric input','4','20','1','1','1','14965312','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('221','54','Buffer Name','A name unique to this field','5','12','1','1','1','14965312','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('222','55','Library Name','STRLIB','1','12','0','1','1','14965312','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('223','55','Function Name','right','2','12','0','1','1','14965312','','right','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('224','55','String','Any AlphaNumeric input','3','12','1','1','1','14965312','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('225','55','Number of chars to return','Any Numeric input','4','20','1','1','1','14965312','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('226','56','Library Name','LIQUIDITY','1','12','1','0','1','-858993460','','LIQUIDITY','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('227','56','Function Name','Returns Compound Interest Accrual Schedule','2','12','1','0','1','-858993460','','ComIntSch','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('228','56','Prin. Cash Flow Schedule','Amortizing,Repricing,or Cash Flow Sched.','3','28','1','0','1','-858993460','','[Amortizing Balance]','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('229','56','Most recent int.pay date','Most recent date on which interest was paid','4','13','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('230','56','Compound Interest Rate','Annual rate, e.g. 5.125 for 5.125%','5','20','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('231','56','Compounding Frequency','e.g. 1 M for 1 month;30 D for 30 days','6','23','1','1','1','-858993460','','1 M','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('232','56','Accrual method','e.g. 00,AA, or 0A','7','12','1','1','1','-858993460','AccrualType','AA','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('233','56','Interest Payment Frequency','e.g. 1 M for 1 month;30 D for 30 days','8','23','1','1','1','-858993460','','12 M','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('234','56','Next Interest Pay Date','Next date on which interest is paid','9','13','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('235','56','Accrual Display Frequency','Default is interest payment frequency','10','23','1','1','0','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('236','57','Library Name','AMBITBUDGET','1','12','1','0','1','-858993460','','AMBITBUDGET','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('237','57','Function Name','Future Repricing Balance Schedule','2','12','1','0','1','-858993460','','FutureRepr','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('238','57','Cash Flow Schedule','Ambit Amortizing Balance Schedule','3','28','1','0','1','-858993460','','[Amortizing Balance]','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('239','57','Repricing Balance','Ambit Repricing Balance Schedule','4','28','1','1','1','-858993460','','[Repricing Balance]','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('240','57','Repricing Frequency','e.g. M012 or M001 or D007','5','23','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('241','58','Library Name','MATHLIB','1','12','1','0','1','0','','MATHLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('242','58','Function Name','Return element having specified rank','2','12','1','0','1','0','','rank','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('243','58','Desired rank: 1 = largest, -1 = smallest','Any Numeric input','3','21','1','1','1','0','','1','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('244','58','Ranked field','Any field','4','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('245','59','Library Name','MATHLIB','1','12','1','0','1','0','','MATHLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('246','59','Function Name','Ordinal of items sorted by specified key fields','2','12','1','0','1','0','','sorteditemcount','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('247','59','Key field','Any field by which sorting to be done.','3','25','1','0','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('248','60','Library Name','STRLIB','1','12','1','0','1','0','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('249','60','Function Name','Format number as a string.','2','12','1','0','1','0','','number2str','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('250','60','Number or numeric string','Any numeric field or string.','3','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('251','60','Format Control String','e.g. M,/D./JR/R4/L$/SL','4','12','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('252','61','Library Name','STRLIB','1','12','1','0','1','0','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('253','61','Function Name','Format Date as a string.','2','12','1','0','1','0','','date2str','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('254','61','Date','Date in YYYYMMDD format.','3','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('255','61','Format Control String','See documentation.','4','12','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('256','62','Library Name','STRLIB','1','12','0','0','1','0','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('257','62','Function Name','deletechars','2','12','0','0','1','0','','deletechars','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('258','62','String','Any AlphaNumeric source string','3','12','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('259','62','String','The characters to delete from source string','4','12','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('260','63','Library Name','BCDLIB','1','12','0','1','1','0','','BCDLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('261','63','Function Name','add','2','12','0','1','1','0','','add','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('262','63','Addend 1','Letters&Numbers source string containing only digits','3','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('263','63','Addend 2','Letters&Numbers source string containing only digits','4','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('189','45','TP CF Method','One of Listed TP CF Methods or the default UTR','2','27','1','0','0','0','','Use Current UTR','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('190','38','Amortization Code','"P&I" or "P+I" or equivalent field','7','12','1','1','1','0','AmortType','P&I','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('191','38','Default Value','Numeric constant or number field','8','20','1','1','1','0','','0','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('192','42','Balance Funded','Original or current balance?','4','12','0','1','0','0','OrigOrCurBal','{C}-Current Balance','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('193','43','Balance Funded','Original or current balance?','3','12','0','1','0','0','OrigOrCurBal','{C}-Current Balance','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('194','41','Balance Funded','Original or current balance?','3','12','0','1','0','0','OrigOrCurBal','{C}-Current Balance','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('195','48','Balance Funded','Original or current balance?','3','12','0','1','0','0','OrigOrCurBal','{C}-Current Balance','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('196','45','Balance Funded','Original or current balance?','3','12','0','1','0','0','OrigOrCurBal','{C}-Current Balance','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('197','27','Rate Interpolation Method','Nearest date = 1;Linear = 2','6','22','1','1','0','0','InterpolateType','{1}-Nearest Date','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('198','50','Library Name','STRLIB','1','12','0','1','1','14965312','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('199','50','Function Name','deblank','2','12','0','1','1','14965312','','deblank','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('200','50','String','Any AlphaNumeric input','3','12','1','1','1','14965312','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('201','51','Library Name','STRLIB','1','12','0','1','1','14965312','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('202','51','Function Name','concat','2','12','0','1','1','14965312','','concat','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('203','51','Result Justification','(L)eft,(C)enter, or (R)ight','3','12','0','1','1','0','Justification','{L}-Left','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('204','51','Separator string','Any AlphaNumeric input','4','12','1','1','0','14965312','','_','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('205','51','Source string','Any AlphaNumeric input','5','12','1','1','1','14965312','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('206','52','Library Name','STRLIB','1','12','0','1','1','14965312','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('207','52','Function Name','concatsub','2','12','0','1','1','14965312','','concatsub','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('208','52','Result Justification','(L)eft,(C)enter, or (R)ight','3','12','0','1','1','0','Justification','{L}-Left','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('209','52','Separator string','Any AlphaNumeric input','4','12','1','1','0','14965312','','_','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('210','52','Number of chars to skip','0 to Length of string','5','20','1','1','1','14965312','','0','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('211','52','Source string','Any AlphaNumeric input','6','12','1','1','1','14965312','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('264','64','Library Name','BCDLIB','1','12','0','0','1','0','','BCDLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('265','64','Function Name','sub','2','12','0','0','1','0','','sub','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('266','64','Minuend','Letters&Numbers source string containing only digits','3','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('267','64','Subtrahend','Letters&Numbers source string containing only digits','4','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('268','65','Library Name','BCDLIB','1','12','0','0','1','0','','BCDLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('269','65','Function Name','Integer multiplication','2','12','0','0','1','0','','mult','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('270','65','Multiplicand','Letters&Numbers source string containing only digits','3','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('271','65','Multiplier','Letters&Numbers source string containing only digits','4','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('272','66','Library Name','BCDLIB','1','12','0','0','1','0','','BCDLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('273','66','Function Name','Integer division','2','12','0','0','1','0','','div','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('274','66','Dividend','Letters&Numbers source string containing only digits','3','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('275','66','Divisor','Letters&Numbers source string containing only digits','4','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('276','67','Library Name','BCDLIB','1','12','0','0','1','0','','BCDLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('277','67','Function Name','Integer div remainder','2','12','0','0','1','0','','remainder','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('278','67','Dividend','Letters&Numbers source string containing only digits','3','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('279','67','Divisor','Letters&Numbers source string containing only digits','4','25','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('280','68','Library Name','DBLIB','1','12','0','1','1','1','','DBLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('281','68','Function Name','Database lookup','2','12','0','1','1','1','','lookup','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('282','68','Database ID','Any AlphaNumeric input','3','12','1','1','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('283','68','Exception code','(R)eturn value, (E)xception report, (F)atal error','4','12','1','1','1','1','','E','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('284','68','Table name','Any AlphaNumeric input','5','12','1','1','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('285','68','Result field name','Any AlphaNumeric input','6','12','1','1','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('286','68','Key field name','Any AlphaNumeric input','7','12','1','1','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('287','68','Key value','Field or value appropriate to target field type','8','25','1','1','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('288','69','Library Name','DBLIB','1','12','0','1','1','1','','DBLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('289','69','Function Name','Insert values into table','2','12','0','1','1','1','','insert','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('290','69','Database ID','Any AlphaNumeric input','3','12','1','1','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('291','69','Exception code','(R)eturn value, (E)xception report, (F)atal error','4','12','1','1','1','1','','E','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('292','69','Table name','Any AlphaNumeric input','5','12','1','1','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('293','69','Field name','Any AlphaNumeric input','6','12','1','1','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('294','69','Field value','Field or value appropriate to target field type','7','25','1','1','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('295','70','Library Name','MATHLIB','1','12','1','0','1','1','','MATHLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('296','70','Function Name','Ordinal of group sorted by specified key fields','2','12','1','0','1','1','','sortedgroupnumber','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('297','70','Key field','Any field by which group ordering is done.','3','25','1','0','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('298','71','Library Name','STRLIB','1','12','1','0','1','1','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('299','71','Function Name','Concat value string for use in totaling records','2','12','1','0','1','1','','concatvert_ttl','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('300','71','Key field','Field by which records are ordered.','3','25','1','0','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('301','71','Value field or literal','Field/value for each input record in group.','4','25','1','1','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('302','71','Value field or literal','delimiter field/value','5','12','1','1','1','1','',',','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('303','72','Library Name','STRLIB','1','12','1','0','1','1','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('304','72','Function Name','Concat value string for use in detail records','2','12','1','0','1','1','','concatvert_det','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('305','72','Key field','Field by which records are ordered.','3','25','1','0','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('306','72','Value field or literal','Field/value for each input record in group.','4','25','1','1','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('307','72','Value field or literal','delimiter field/value','5','12','1','1','1','1','',',','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('308','73','Library Name','STRLIB','1','12','1','0','1','1','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('309','73','Function Name','Get value of field in prior record.','2','12','1','0','1','1','','getpriorvalue','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('310','73','Value source field','Field for which prior record value desired.','3','25','1','0','1','1','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('311','74','Library Name','MATHLIB','1','12','1','0','1','-858993460','','MATHLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('312','74','Function Name','Natural log of a number','2','12','1','0','1','-858993460','','ln','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('313','74','Number','Number for which the log is required','3','20','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('314','43','Base Schedule','Repricing or Principal Cash Flow Schedule?','4','12','0','1','0','0','ScheduleType','{P}-Principal Cash Flow Schedule','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('315','75','Library Name','STRLIB','1','12','1','1','1','-858993460','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('316','75','Function Name','Calculate the weighted rate array based on a group','2','12','1','1','1','-858993460','','weightedrate_det','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('317','75','Group Field','Field by which records are ordered.','3','25','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('318','75','Balance','The balance to be used.','4','20','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('319','75','Rate','The rate','5','20','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('320','75','Delimiter','The delimiter to be used.','6','12','1','1','1','-858993460','',',','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('321','76','Funding Table ID','One of Listed External Tables or a field','1','26','1','0','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('322','76','Pricing Method','One of Listed transfer pricing methods or an appropriate field or an index','2','22','1','1','1','-858993460','FundType','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('323','76','Cash Flow Schedule','Ambit Cashflow Schedule.','3','28','1','0','1','-858993460','','[Amortizing Balance]','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('324','76','Origination Date','Date field or constant in CY/M/D format','4','13','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('325','76','Accrual Method','If Literal then only AA,A0,A5,00 and 05 accepted.','5','12','1','1','1','-858993460','AccrualType','AA','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('326','76','Rate Interpolation Method','Nearest date = 1;Linear = 2','6','22','1','1','0','-858993460','InterpolateType','{1}-Nearest Date','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('327','77','Pricing Rate Table','One of Listed External Tables or a field','1','26','1','0','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('328','77','Pricing Drive Rate (0 = YC)','One of Listed transfer Pricing methods or an appropriate field or an index','2','22','1','1','1','0','','0','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('329','77','Pricing Spread','One of Listed transfer Pricing methods or an appropriate field or an index','3','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('330','77','Funding Rate Table','One of Listed External Tables or a field','4','26','1','0','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('331','77','Funding Method','One of Listed transfer Funding methods or an appropriate field or an index','5','22','1','1','1','0','PRFundType','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('332','77','TP CF Method','One of Listed TP CF methods or the default UTR','6','27','1','0','0','0','','Use Current UTR','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('333','77','Balance Funded','Original or current balance?','7','12','0','1','0','0','OrigOrCurBal','{O}-Original Balance','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('334','77','Rate Interpolation Method','Nearest date = 1;Linear = 2','8','22','1','1','0','0','InterpolateType','{1}-Nearest Date','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('335','77','Locked/Unlocked','Locked or Unlocked?','9','12','0','1','0','0','LockedUnlocked','{L}-Locked','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('336','78','Last Repricing Date','Date field or constant in CY/M/D format','1','13','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('337','78','Maturity Date','For Monthly Repricing','2','13','1','1','0','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('338','78','Funding Table ID','One of Listed External Tables or a field','3','26','1','0','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('339','78','Core Funding Rate','Rate field or constant','4','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('340','78','Number of Non Core Rates','Number of Non Core Rates','5','22','1','1','1','-858993460','','1','1')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('341','78','Non Core Funding Rate','Rate field or constant','6','22','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('342','78','Non Core Percent','Percent field or constant','7','22','1','1','1','0','','','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('343','79','Total Limit','Total Limit','1','20','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('344','79','Face(Current Drawdown)','Face(Current Drawdown)','2','20','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('345','79','Origin Date','Date field or constant in CY/M/D format','3','13','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('346','79','Current Maturity Date','Date field or constant in CY/M/D format','4','13','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('347','79','Spread','Rate field or constant','5','20','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('348','79','Liquidity Table ID','One of Listed External Tables or a field','6','26','1','0','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('349','79','Volatility Term Prem Spread','Rate field or constant','7','14','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('350','79','Number of Scenarios','Number of Scenarios','8','22','1','1','1','-858993460','','1','1')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('351','79','Forecasted Avg drawdown %','Percent field or constant','9','14','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('352','79','Probability Scenario','Percent field or constant','10','14','1','1','1','0','','100','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('353','80','Funding Rate Table','One of Listed External Tables or a field','1','26','1','0','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('354','80','Funding Method','One of Listed transfer Funding methods or an appropriate field or an index','2','22','1','1','1','0','LIQFundType','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('355','80','TP CF Method','One of Listed TP CF methods or the default UTR','3','27','1','0','0','0','','Use Current UTR','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('356','80','Balance Funded','Original or current balance?','4','12','0','1','0','0','OrigOrCurBal','{O}-Original Balance','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('357','80','Rate Interpolation Method','Nearest date = 1;Linear = 2','5','22','1','1','0','0','InterpolateType','{1}-Nearest Date','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('358','81','Funding Rate Table','One of Listed External Tables or a field','1','26','1','0','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('359','81','TP CF Method','One of Listed TP CF methods or the default UTR','2','27','1','0','0','0','','Use Current UTR','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('360','81','Balance Funded','Original or current balance?','3','12','0','1','0','0','OrigOrCurBal','{O}-Original Balance','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('361','82','Library Name','STRLIB','1','12','1','1','1','-858993460','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('362','82','Function Name','Calculate the weighted rate array based on a group','2','12','1','1','1','-858993460','','weightedrate_ALM','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('363','82','Group Field','Field by which records are ordered.','3','25','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('364','82','Balance','The balance to be used.','4','20','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('365','82','Rate','The rate','5','20','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('366','82','Maturity Date','Date field or constant in CY/M/D format','6','13','1','1','1','-858993460','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('367','82','Delimiter','The delimiter to be used.','7','12','1','1','1','-858993460','','endl','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],srcliteral, [required], [transform type idx], list_id, [default], [isrepeatvalue])		 VALUES('368','83','Library Name', 'STRLIB', '1', '12', '0', '0', '1', '0', '', 'STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],srcliteral, [required], [transform type idx], list_id, [default], [isrepeatvalue])		 VALUES('369','83','Function Name', 'deletestring', '2', '12', '0','0', '1', '0', '', 'deletestring','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],srcliteral, [required], [transform type idx], list_id, [default], [isrepeatvalue])		 VALUES('370','83','String', 'Any AlphaNumeric source string', '3', '12', '1', '1', '1', '0', '', '','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],srcliteral, [required], [transform type idx], list_id, [default], [isrepeatvalue])		 VALUES('371','83','String', 'The string to delete from source string', '4', '12', '1', '1', '1', '0', '', '','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('372','84','Library Name','STRLIB','1','12','0','1','1','0','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('373','84','Function Name','len','2','12','0','1','1','0','','len','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('374','84','String','Any string input','3','12','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('375','84','Trim','Trimmed output?','4','12','0','1','1','0','TrimOption','{N}-No','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('376','85','Library Name','STRLIB','1','12','0','1','1','0','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('377','85','Function Name','find','2','12','0','1','1','0','','find','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('378','85','Source String','Any alphanumeric source string','3','12','1','1','1','0','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('379','85','String to find','The string to find from source string','4','12','1','1','1','0','','','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('380','86','Library Name','STRLIB','1','12','0','1','1','0','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('381','86','Function Name','toupper','2','12','0','1','1','0','','toupper','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('382','86','String','Any alphanumeric string','3','12','1','1','1','0','','','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('383','87','Library Name','STRLIB','1','12','0','1','1','0','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('384','87','Function Name','tolower','2','12','0','1','1','0','','tolower','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('385','87','String','Any alphanumeric string','3','12','1','1','1','0','','','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('386','88','Library Name','STRLIB','1','12','0','1','1','0','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('387','88','Function Name','reversesubstring','2','12','0','1','1','0','','reversesubstring','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('388','88','String source','Any source field or literal','3','25','1','1','1','322','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('389','88','Start position','Numeric constant or number field','4','22','1','1','1','322','','','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('390','88','Length of SubString','Numeric constant or number field','5','22','1','1','1','322','','','0')

INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('391','89','Library Name','STRLIB','1','12','0','1','1','0','','STRLIB','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('392','89','Function Name','initcap','2','12','0','1','1','0','','initcap','0')
INSERT TRANSFORM_PARAM_TYPES([id],[function_number],[name],[description],[input order],[data subtype id],[srcfield],[srcliteral],[required],[transform type idx],[list_id],[default], [isrepeatvalue])       VALUES('393','89','String','Any alphanumeric string','3','12','1','1','1','0','','','0')


END

GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[TRANSFORM_PARAM_TYPES]') AND name = N'ID')
CREATE UNIQUE NONCLUSTERED INDEX [ID] ON [dbo].[TRANSFORM_PARAM_TYPES] 
(
    [id] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[TRANSFORM_PARAM_TYPES]') AND name = N'List_ID')
CREATE NONCLUSTERED INDEX [List_ID] ON [dbo].[TRANSFORM_PARAM_TYPES] 
(
    [list_id] ASC
) ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DATASOURCE_CONNECTION]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[DATASOURCE_CONNECTION](
    [index] [int] NOT NULL,
    [name] [nvarchar](255)  NULL,
    [connect_string] [nvarchar](1500)  NULL,
    [database_type] [nvarchar](255)  NULL,
 CONSTRAINT [aaaaaDatasource_connection_PK] PRIMARY KEY NONCLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
ELSE
BEGIN
IF EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[DATASOURCE_CONNECTION]') AND name = N'connect_string' AND prec<>1500)
	ALTER TABLE [dbo].[DATASOURCE_CONNECTION] ALTER COLUMN connect_string nvarchar(1500)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DATASOURCE_CONNECTION]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[DATASOURCE_CONNECTION]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_DATASOURCE_CONNECTION_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_DATASOURCE_CONNECTION_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_DATASOURCE_CONNECTION_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_DATASOURCE_CONNECTION_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[DATASOURCE_CONNECTION]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[DATASOURCE_CONNECTION]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[DATASOURCE_CONNECTION] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[DATASOURCE_CONNECTION] SET temporary = [index]') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'aaaaaDatasource_connection_PK'))
				ALTER TABLE [dbo].[DATASOURCE_CONNECTION] DROP Constraint aaaaaDatasource_connection_PK; 
			ALTER TABLE [dbo].[DATASOURCE_CONNECTION] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[DATASOURCE_CONNECTION] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[DATASOURCE_CONNECTION].temporary', 'index', 'COLUMN'; 
			ALTER TABLE [dbo].[DATASOURCE_CONNECTION] ADD CONSTRAINT aaaaaDatasource_connection_PK PRIMARY KEY([index]); 
		END 
	END
END	

GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_DATASOURCE_CONNECTION_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_DATASOURCE_CONNECTION_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_DATASOURCE_CONNECTION_INSERT] 
   ON  [dbo].[DATASOURCE_CONNECTION] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''DATASOURCE_CONNECTION''
    SET @actionval=1	
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''[index]=''+convert(nvarchar(15),NEW.[index]),
                (''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''name=''+''''''''+ISNULL(Replace(NEW.name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''connect_string=''+''''''''+ISNULL(Replace(NEW.connect_string,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''database_type=''+''''''''+ISNULL(Replace(NEW.database_type,'''''''',''''''''''''),'''')+'''''''' )from INSERTED NEW;
END

END


' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_DATASOURCE_CONNECTION_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_DATASOURCE_CONNECTION_UPDATE]
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_DATASOURCE_CONNECTION_UPDATE] 
   ON  [dbo].[DATASOURCE_CONNECTION] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''DATASOURCE_CONNECTION''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''connect_string=''+''''''''+ISNULL(Replace(OLD.connect_string,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''database_type=''+''''''''+ISNULL(Replace(OLD.database_type,'''''''',''''''''''''),'''')+''''''''+
                '' WHERE ''+''[index]=''+convert(nvarchar(15),OLD.[index]),
                 
                ''name=''+''''''''+ISNULL(Replace(NEW.name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''connect_string=''+''''''''+ISNULL(Replace(NEW.connect_string,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''database_type=''+''''''''+ISNULL(Replace(NEW.database_type,'''''''',''''''''''''),'''')+''''''''+
                '' WHERE ''+''[index]=''+convert(nvarchar(15),NEW.[index]) from DELETED OLD,INSERTED NEW
where NEW.[index] = OLD.[index];
end
--update the field in DATASOURCE_CONNECTION table
UPDATE dbo.DATASOURCE_CONNECTION
SET name=NEW.name,
    connect_string=NEW.connect_string,
    database_type=NEW.database_type
    from INSERTED NEW
    where DATASOURCE_CONNECTION.[index] in (NEW.[index]);
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''connect_string=''+''''''''+ISNULL(Replace(OLD.connect_string,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''database_type=''+''''''''+ISNULL(Replace(OLD.database_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[index]=''+convert(nvarchar(15),OLD.[index]),''[index]=''+convert(nvarchar(15),OLD.[index]) from DELETED OLD;
end
--Delete the field from DATASOURCE_CONNECTION table
DELETE FROM DATASOURCE_CONNECTION where [index] in (SELECT OLD.[index] from DELETED OLD) 
END
END


' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DATASOURCE_LINKS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[DATASOURCE_LINKS]') AND name = N'externaltable_index')
		ALTER TABLE [dbo].[DATASOURCE_LINKS] ADD [externaltable_index] [int] NULL DEFAULT ((0))
	IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[DATASOURCE_LINKS]') AND name = N'BufferSize')
		ALTER TABLE [dbo].[DATASOURCE_LINKS] ADD [BufferSize] [int] NULL DEFAULT ((0))
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DATASOURCE_LINKS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[DATASOURCE_LINKS](
    [index] [int] NOT NULL,
    [subsystem_index] [int] NULL DEFAULT ((0)),
    [report_index] [int] NULL DEFAULT ((0)),
    [datasource_connection_index] [int] NULL DEFAULT ((0)),
    [join_index] [int] NULL DEFAULT ((0)),
    [table_name] [nvarchar](255)  NULL,
    [datatype_style] [int] NOT NULL DEFAULT ((0)),
    [dbf_name] [nvarchar](255)  NULL,
    [output_id_field] [bit] NULL DEFAULT ((0)),
    [externaltable_index] [int] NULL DEFAULT ((0)),
	[BufferSize] [int] NULL  DEFAULT ((0)),
 CONSTRAINT [aaaaaDatasource_links_PK] PRIMARY KEY NONCLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DATASOURCE_LINKS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[DATASOURCE_LINKS]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_DATASOURCE_LINKS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_DATASOURCE_LINKS_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_DATASOURCE_LINKS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_DATASOURCE_LINKS_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[DATASOURCE_LINKS]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[DATASOURCE_LINKS]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[DATASOURCE_LINKS] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[DATASOURCE_LINKS] SET temporary = [index]') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'aaaaaDatasource_links_PK'))
				ALTER TABLE [dbo].[DATASOURCE_LINKS] DROP Constraint aaaaaDatasource_links_PK; 
			ALTER TABLE [dbo].[DATASOURCE_LINKS] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[DATASOURCE_LINKS] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[DATASOURCE_LINKS].temporary', 'index', 'COLUMN'; 
			ALTER TABLE [dbo].[DATASOURCE_LINKS] ADD CONSTRAINT aaaaaDatasource_links_PK PRIMARY KEY([index]); 
		END 
	END
END	

GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_DATASOURCE_LINKS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_DATASOURCE_LINKS_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_DATASOURCE_LINKS_INSERT] 
   ON  [dbo].[DATASOURCE_LINKS] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''DATASOURCE_LINKS''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''[index]=''+convert(nvarchar(15),NEW.[index]),
                (''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),NEW.subsystem_index),'''')+''|#''+
				''BufferSize=''+ISNULL(convert(nvarchar(15),NEW.BufferSize),'''')+''|#''+
                ''report_index=''+ISNULL(convert(nvarchar(15),NEW.report_index),'''')+''|#''+
                ''externaltable_index=''+ISNULL(convert(nvarchar(15),NEW.externaltable_index),'''')+''|#''+
                ''datasource_connection_index=''+ISNULL(convert(nvarchar(15),NEW.datasource_connection_index),'''')+''|#''+
                ''join_index=''+ISNULL(convert(nvarchar(15),NEW.join_index),'''')+''|#''+
                ''table_name=''+''''''''+ISNULL(Replace(NEW.table_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''datatype_style=''+ISNULL(convert(nvarchar(15),NEW.datatype_style),'''') +''|#''+
                ''dbf_name=''+''''''''+ISNULL(Replace(NEW.dbf_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''output_id_field=''+convert(nvarchar(1),NEW.output_id_field))from INSERTED NEW;

END

END



' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_DATASOURCE_LINKS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_DATASOURCE_LINKS_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_DATASOURCE_LINKS_UPDATE] 
   ON  [dbo].[DATASOURCE_LINKS] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''DATASOURCE_LINKS''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),OLD.subsystem_index),'''')+''|#''+
				''BufferSize=''+ISNULL(convert(nvarchar(15),OLD.BufferSize),'''')+''|#''+
                ''report_index=''+ISNULL(convert(nvarchar(15),OLD.report_index),'''')+''|#''+
                ''externaltable_index=''+ISNULL(convert(nvarchar(15),OLD.externaltable_index),'''')+''|#''+
                ''datasource_connection_index=''+ISNULL(convert(nvarchar(15),OLD.datasource_connection_index),'''')+''|#''+
                ''join_index=''+ISNULL(convert(nvarchar(15),OLD.join_index),'''')+''|#''+
                ''table_name=''+''''''''+ISNULL(Replace(OLD.table_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''datatype_style=''+ISNULL(convert(nvarchar(15),OLD.datatype_style),'''') +''|#''+
                ''dbf_name=''+''''''''+ISNULL(Replace(OLD.dbf_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''output_id_field=''+convert(nvarchar(1),OLD.output_id_field) +
                '' WHERE ''+''[index]=''+convert(nvarchar(15),OLD.[index]),
                 
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),NEW.subsystem_index),'''')+''|#''+
				''BufferSize=''+ISNULL(convert(nvarchar(15),NEW.BufferSize),'''')+''|#''+
                ''report_index=''+ISNULL(convert(nvarchar(15),NEW.report_index),'''')+''|#''+
                ''externaltable_index=''+ISNULL(convert(nvarchar(15),NEW.externaltable_index),'''')+''|#''+
                ''datasource_connection_index=''+ISNULL(convert(nvarchar(15),NEW.datasource_connection_index),'''')+''|#''+
                ''join_index=''+ISNULL(convert(nvarchar(15),NEW.join_index),'''')+''|#''+
                ''table_name=''+''''''''+ISNULL(Replace(NEW.table_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''datatype_style=''+ISNULL(convert(nvarchar(15),NEW.datatype_style),'''') +''|#''+
                ''dbf_name=''+''''''''+ISNULL(Replace(NEW.dbf_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''output_id_field=''+convert(nvarchar(1),NEW.output_id_field) +
                '' WHERE ''+''[index]=''+convert(nvarchar(15),NEW.[index]) from DELETED OLD,INSERTED NEW
 where NEW.[index] = OLD.[index];
end
--update the field in DATASOURCE_LINKS table
UPDATE dbo.DATASOURCE_LINKS
SET subsystem_index=NEW.subsystem_index,
    report_index=NEW.report_index,
    externaltable_index=NEW.externaltable_index,
    datasource_connection_index=NEW.datasource_connection_index,
    join_index=NEW.join_index,
    table_name=NEW.table_name,
    datatype_style=NEW.datatype_style,
    dbf_name=NEW.dbf_name,
    output_id_field=NEW.output_id_field,
	BufferSize=NEW.BufferSize
    from INSERTED NEW
    where DATASOURCE_LINKS.[index] in (NEW.[index]);
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),OLD.subsystem_index),'''')+''|#''+
				''BufferSize=''+ISNULL(convert(nvarchar(15),OLD.BufferSize),'''')+''|#''+
                ''report_index=''+ISNULL(convert(nvarchar(15),OLD.report_index),'''')+''|#''+
                ''externaltable_index=''+ISNULL(convert(nvarchar(15),OLD.externaltable_index),'''')+''|#''+
                ''datasource_connection_index=''+ISNULL(convert(nvarchar(15),OLD.datasource_connection_index),'''')+''|#''+
                ''join_index=''+ISNULL(convert(nvarchar(15),OLD.join_index),'''')+''|#''+
                ''table_name=''+''''''''+ISNULL(Replace(OLD.table_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''datatype_style=''+ISNULL(convert(nvarchar(15),OLD.datatype_style),'''') +''|#''+
                ''dbf_name=''+''''''''+ISNULL(Replace(OLD.dbf_name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[index]=''+convert(nvarchar(15),OLD.[index]),''[index]=''+convert(nvarchar(15),OLD.[index]) from DELETED OLD;
end
--Delete the field from DATASOURCE_LINKS table
DELETE FROM DATASOURCE_LINKS where [index] in (SELECT OLD.[index] from DELETED OLD);
END
END



' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[TRANSFORM_VALUE]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[TRANSFORM_VALUE](
    [index] [int] NOT NULL DEFAULT ((0)),
    [transform_id] [int] NULL DEFAULT ((0)),
    [param_type_id] [int] NULL DEFAULT ((0)),
    [translation_value_type] [nvarchar](1)  NULL,
    [translation_value] [nvarchar](255)  NULL,
    [arg_type] [nvarchar](1)  NOT NULL,
    [arg_param] [nvarchar](255)  NULL,
    [arg_modifier] [nvarchar](255)  NULL,
    [valid] [bit] NOT NULL DEFAULT ((0)),
    [PKey] [int] NOT NULL,
 CONSTRAINT [PK_TRANSFORM_VALUE] PRIMARY KEY CLUSTERED 
(
    [PKey] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[TRANSFORM_VALUE]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[TRANSFORM_VALUE]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_TRANSFORM_VALUE_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_TRANSFORM_VALUE_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_TRANSFORM_VALUE_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_TRANSFORM_VALUE_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[TRANSFORM_VALUE]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[TRANSFORM_VALUE]') AND name = N'PKey') 
		BEGIN
			ALTER TABLE [dbo].[TRANSFORM_VALUE] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[TRANSFORM_VALUE] SET temporary = PKey') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'PK_TRANSFORM_VALUE'))
				ALTER TABLE [dbo].[TRANSFORM_VALUE] DROP Constraint PK_TRANSFORM_VALUE; 
			ALTER TABLE [dbo].[TRANSFORM_VALUE] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[TRANSFORM_VALUE] DROP COLUMN PKey; 
			EXEC sp_rename '[dbo].[TRANSFORM_VALUE].temporary', 'PKey', 'COLUMN'; 
			ALTER TABLE [dbo].[TRANSFORM_VALUE] ADD CONSTRAINT PK_TRANSFORM_VALUE PRIMARY KEY(PKey); 
		END 
	END
END	

GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[TRANSFORM_VALUE]') AND name = N'Field_index')
CREATE NONCLUSTERED INDEX [Field_index] ON [dbo].[TRANSFORM_VALUE] 
(
    [transform_id] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[TRANSFORM_VALUE]') AND name = N'Index')
CREATE NONCLUSTERED INDEX [Index] ON [dbo].[TRANSFORM_VALUE] 
(
    [index] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[TRANSFORM_VALUE]') AND name = N'Param_Type_ID')
CREATE NONCLUSTERED INDEX [Param_Type_ID] ON [dbo].[TRANSFORM_VALUE] 
(
    [param_type_id] ASC
) ON [PRIMARY]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_TRANSFORM_VALUE_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_TRANSFORM_VALUE_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_TRANSFORM_VALUE_INSERT] 
   ON  [dbo].[TRANSFORM_VALUE] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''TRANSFORM_VALUE''
    SET @actionval=1	

    SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                (''PKey=''+convert(nvarchar(15),NEW.PKey)),
                (''PKey=''+convert(nvarchar(15),NEW.PKey)+''|#''+
                ''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''transform_id=''+ISNULL(convert(nvarchar(15),NEW.transform_id),'''')+''|#''+
                ''param_type_id=''+ISNULL(convert(nvarchar(15),NEW.param_type_id),'''')+''|#''+
                ''translation_value_type=''+''''''''+ISNULL(Replace(NEW.translation_value_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''translation_value=''+''''''''+ISNULL(Replace(NEW.translation_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''arg_type=''+''''''''+NEW.arg_type+''''''''+''|#''+
                ''arg_param=''+''''''''+ISNULL(Replace(NEW.arg_param,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''arg_modifier=''+''''''''+ISNULL(Replace(NEW.arg_modifier,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''valid=''+convert(nvarchar(1),NEW.valid))from INSERTED NEW;

END

END



' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_TRANSFORM_VALUE_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_TRANSFORM_VALUE_UPDATE];	
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_TRANSFORM_VALUE_UPDATE] 
   ON  [dbo].[TRANSFORM_VALUE] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''TRANSFORM_VALUE''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
    SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''param_type_id=''+ISNULL(convert(nvarchar(15),OLD.param_type_id),'''')+''|#''+
                ''translation_value_type=''+''''''''+ISNULL(Replace(OLD.translation_value_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''translation_value=''+''''''''+ISNULL(Replace(OLD.translation_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''arg_type=''+''''''''+OLD.arg_type+''''''''+''|#''+
                ''arg_param=''+''''''''+ISNULL(Replace(OLD.arg_param,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''arg_modifier=''+''''''''+ISNULL(Replace(OLD.arg_modifier,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''valid=''+convert(nvarchar(1),OLD.valid) +
                '' WHERE ''+''PKey=''+convert(nvarchar(15),OLD.PKey),
                 
                ''param_type_id=''+ISNULL(convert(nvarchar(15),NEW.param_type_id),'''')+''|#''+
                ''translation_value_type=''+''''''''+ISNULL(Replace(NEW.translation_value_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''translation_value=''+''''''''+ISNULL(Replace(NEW.translation_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''arg_type=''+''''''''+NEW.arg_type+''''''''+''|#''+
                ''arg_param=''+''''''''+ISNULL(Replace(NEW.arg_param,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''arg_modifier=''+''''''''+ISNULL(Replace(NEW.arg_modifier,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''valid=''+convert(nvarchar(1),NEW.valid) +
                '' WHERE ''+''PKey=''+convert(nvarchar(15),NEW.PKey) from DELETED OLD,INSERTED NEW
WHERE NEW.PKey = OLD.PKey;
end
--update the field in TRANSFORM_VALUE table
UPDATE dbo.TRANSFORM_VALUE
SET param_type_id = NEW.param_type_id,
    translation_value_type = NEW.translation_value_type, 
    translation_value = NEW.translation_value,
    arg_type = NEW.arg_type,
    arg_param = NEW.arg_param,
    arg_modifier = NEW.arg_modifier,
    valid = NEW.valid
    from INSERTED NEW
    where TRANSFORM_VALUE.PKey IN(NEW.PKey);
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''PKey=''+convert(nvarchar(15),OLD.PKey)+''|#''+
                ''param_type_id=''+ISNULL(convert(nvarchar(15),OLD.param_type_id),'''')+''|#''+
                ''translation_value_type=''+''''''''+ISNULL(Replace(OLD.translation_value_type,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''translation_value=''+''''''''+ISNULL(Replace(OLD.translation_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''arg_type=''+''''''''+OLD.arg_type+''''''''+''|#''+
                ''arg_param=''+''''''''+ISNULL(Replace(OLD.arg_param,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''arg_modifier=''+''''''''+ISNULL(Replace(OLD.arg_modifier,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''valid=''+convert(nvarchar(1),OLD.valid) +''|#''+
                ''transform_id=''+ISNULL(convert(nvarchar(15),OLD.transform_id),'''')+''|#''+
                ''[index]=''+convert(nvarchar(15),OLD.[index]),''PKey=''+convert(nvarchar(15),OLD.PKey) from DELETED OLD;
end
--Delete the field from TRANSFORM_VALUE table
DELETE FROM TRANSFORM_VALUE where PKey in (SELECT OLD.PKey from DELETED OLD);
END
END



' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[TRANSFORMS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[TRANSFORMS](
    [id] [int] NOT NULL,
    [field_index] [int] NOT NULL DEFAULT ((0)),
    [name] [nvarchar](3000)  NULL,
    [transform_function] [int] NOT NULL DEFAULT ((0)),
 CONSTRAINT [aaaaaTransforms_PK] PRIMARY KEY NONCLUSTERED 
(
    [id] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
ELSE
BEGIN
IF EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[TRANSFORMS]') AND name = N'name' AND prec<>3000)
	ALTER TABLE [dbo].[TRANSFORMS] ALTER COLUMN name nvarchar(3000)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[TRANSFORMS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[TRANSFORMS]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_TRANSFORMS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_TRANSFORMS_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_TRANSFORMS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_TRANSFORMS_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[TRANSFORMS]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[TRANSFORMS]') AND name = N'id') 
		BEGIN
			ALTER TABLE [dbo].[TRANSFORMS] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[TRANSFORMS] SET temporary = id')
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'aaaaaTransforms_PK'))
				ALTER TABLE [dbo].[TRANSFORMS] DROP Constraint aaaaaTransforms_PK; 
			ALTER TABLE [dbo].[TRANSFORMS] ALTER COLUMN temporary [int] NOT NULL;
			IF EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[TRANSFORMS]') AND name = N'ID')



				DROP INDEX [ID] ON [dbo].[TRANSFORMS] WITH ( ONLINE = OFF )

			ALTER TABLE [dbo].[TRANSFORMS] DROP COLUMN id; 
			EXEC sp_rename '[dbo].[TRANSFORMS].temporary', 'id', 'COLUMN'; 
			ALTER TABLE [dbo].[TRANSFORMS] ADD CONSTRAINT aaaaaTransforms_PK PRIMARY KEY(id); 
		END 
	END
END	

GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[TRANSFORMS]') AND name = N'ID')
CREATE NONCLUSTERED INDEX [ID] ON [dbo].[TRANSFORMS] 
(
    [id] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[TRANSFORMS]') AND name = N'Transform_function')
CREATE NONCLUSTERED INDEX [Transform_function] ON [dbo].[TRANSFORMS] 
(
    [transform_function] ASC
) ON [PRIMARY]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_TRANSFORMS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_TRANSFORMS_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_TRANSFORMS_INSERT] 
   ON  [dbo].[TRANSFORMS] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''TRANSFORMS''
    SET @actionval=1	
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''id=''+convert(nvarchar(15),NEW.id),
                (''id=''+convert(nvarchar(15),NEW.id)+''|#''+
                ''field_index=''+convert(nvarchar(15),NEW.field_index)+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''transform_function=''+convert(nvarchar(15),NEW.transform_function) )from INSERTED NEW;

END

END



' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_TRANSFORMS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_TRANSFORMS_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_TRANSFORMS_UPDATE] 
   ON  [dbo].[TRANSFORMS] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''TRANSFORMS''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
    SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''field_index=''+convert(nvarchar(15),OLD.field_index)+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''transform_function=''+convert(nvarchar(15),OLD.transform_function)+
                '' WHERE ''+''id=''+convert(nvarchar(15),OLD.id),
                 
                ''field_index=''+convert(nvarchar(15),NEW.field_index)+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''transform_function=''+convert(nvarchar(15),NEW.transform_function)+
                '' WHERE ''+''id=''+convert(nvarchar(15),NEW.id)from DELETED OLD,INSERTED NEW
where NEW.id = OLD.id;
end
--update the field in TRANSFORMS table
UPDATE dbo.TRANSFORMS
SET field_index=NEW.field_index,
    name=NEW.name,
    transform_function=NEW.transform_function
    from INSERTED NEW
    where TRANSFORMS.id in (NEW.id);
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''field_index=''+convert(nvarchar(15),OLD.field_index)+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''transform_function=''+convert(nvarchar(15),OLD.transform_function)+''|#''+
                ''id=''+convert(nvarchar(15),OLD.id),''id=''+convert(nvarchar(15),OLD.id) from DELETED OLD;
end
--Delete the field from TRANSFORMS table
DELETE FROM TRANSFORMS where id in (SELECT OLD.id from DELETED OLD);

END

END




' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DBTABLINKS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[DBTABLINKS](
    [join_index] [int] NOT NULL DEFAULT ((0)),
    [table1] [nvarchar](255)  NOT NULL,
    [field1] [nvarchar](255)  NOT NULL,
    [table2] [nvarchar](255)  NOT NULL,
    [field2] [nvarchar](255)  NOT NULL,
    [join_type] [nvarchar](255)  NOT NULL,
    [PKey] [int] NOT NULL,
 CONSTRAINT [PK_DBTABLINKS] PRIMARY KEY CLUSTERED 
(
    [PKey] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DBTABLINKS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[DBTABLINKS]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_DBTABLINKS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_DBTABLINKS_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_DBTABLINKS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_DBTABLINKS_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[DBTABLINKS]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[DBTABLINKS]') AND name = N'PKey') 
		BEGIN
			ALTER TABLE [dbo].[DBTABLINKS] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[DBTABLINKS] SET temporary = PKey') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'PK_DBTABLINKS'))
				ALTER TABLE [dbo].[DBTABLINKS] DROP Constraint PK_DBTABLINKS; 
			ALTER TABLE [dbo].[DBTABLINKS] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[DBTABLINKS] DROP COLUMN PKey; 
			EXEC sp_rename '[dbo].[DBTABLINKS].temporary', 'PKey', 'COLUMN'; 
			ALTER TABLE [dbo].[DBTABLINKS] ADD CONSTRAINT PK_DBTABLINKS PRIMARY KEY(PKey); 
		END 
	END
END	

GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[DBTABLINKS]') AND name = N'Join_Index')
CREATE NONCLUSTERED INDEX [Join_Index] ON [dbo].[DBTABLINKS] 
(
    [join_index] ASC
) ON [PRIMARY]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_DBTABLINKS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_DBTABLINKS_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_DBTABLINKS_INSERT] 
   ON  [dbo].[DBTABLINKS] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''DBTABLINKS''
    SET @actionval=1

    SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''PKey=''+convert(nvarchar(15),NEW.PKey),

                (''PKey=''+convert(nvarchar(15),NEW.PKey)+''|#''+
                ''join_index=''+convert(nvarchar(15),NEW.join_index)+''|#''+
                ''table1=''+''''''''+NEW.table1+''''''''+''|#''+
                ''field1=''+''''''''+NEW.field1+''''''''+''|#''+
                ''table2=''+''''''''+NEW.table2+''''''''+''|#''+
                ''field2=''+''''''''+NEW.field2+''''''''+''|#''+
                ''join_type=''+''''''''+NEW.join_type+'''''''') from INSERTED NEW;
END
END


set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_DBTABLINKS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_DBTABLINKS_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_DBTABLINKS_UPDATE] 
   ON  [dbo].[DBTABLINKS] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''DBTABLINKS''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
    SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END
--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''join_index=''+convert(nvarchar(15),OLD.join_index)+''|#''+
                ''table1=''+''''''''+OLD.table1+''''''''+''|#''+
                ''field1=''+''''''''+OLD.field1+''''''''+''|#''+
                ''table2=''+''''''''+OLD.table2+''''''''+''|#''+
                ''field2=''+''''''''+OLD.field2+''''''''+''|#''+
                ''join_type=''+''''''''+OLD.join_type+''''''''+
                '' where ''+''PKey=''+convert(nvarchar(15),OLD.PKey),
                 
                ''join_index=''+convert(nvarchar(15),NEW.join_index)+''|#''+
                ''table1=''+''''''''+NEW.table1+''''''''+''|#''+
                ''field1=''+''''''''+NEW.field1+''''''''+''|#''+
                ''table2=''+''''''''+NEW.table2+''''''''+''|#''+
                ''field2=''+''''''''+NEW.field2+''''''''+''|#''+
                ''join_type=''+''''''''+NEW.join_type+''''''''+
                '' where ''+''PKey=''+convert(nvarchar(15),NEW.PKey)
          from DELETED OLD,INSERTED NEW
where NEW.join_index = OLD.join_index;
END
--update the field in CATEGORY table
UPDATE dbo.DBTABLINKS
SET join_index=NEW.join_index,
    table1=NEW.table1,
    table2=NEW.table2,
    field2=NEW.field2,
    field1=NEW.field1,
    join_type=NEW.join_type
    from INSERTED NEW,DBTABLINKS 
    where DBTABLINKS.PKey = NEW.PKey;
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                
                ''PKey=''+convert(nvarchar(15),OLD.PKey)+''|#''+
                ''join_index=''+convert(nvarchar(15),OLD.join_index)+''|#''+
                ''table1=''+''''''''+OLD.table1+''''''''+''|#''+
                ''field1=''+''''''''+OLD.field1+''''''''+''|#''+
                ''table2=''+''''''''+OLD.table2+''''''''+''|#''+
                ''field2=''+''''''''+OLD.field2+''''''''+''|#''+
                ''join_type=''+''''''''+OLD.join_type+'''''''',

                ''PKey=''+convert(nvarchar(15),OLD.PKey)
                from DELETED OLD;
end
--Delete the field from CATEGORY table
DELETE FROM DBTABLINKS 
where PKey IN(SELECT PKey from DELETED);
END

' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[INPUT_RECORD]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[INPUT_RECORD]') AND name = N'has_header_row')
    ALTER TABLE [dbo].[INPUT_RECORD] Add [has_header_row] [nvarchar](1) DEFAULT ('N') NOT NULL
    
    IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[INPUT_RECORD]') AND name = N'database_defined')
    ALTER TABLE [dbo].[INPUT_RECORD] Add [database_defined] [bit] NOT NULL DEFAULT ((0))    
END
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[INPUT_RECORD]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[INPUT_RECORD](
    [index] [int] NOT NULL,
    [subsystem_index] [int] NULL DEFAULT ((0)),
    [id_value] [nvarchar](8)  NULL,
    [name] [nvarchar](255)  NULL,
    [type] [nvarchar](1)  NOT NULL,
    [byte_offset] [smallint] NULL DEFAULT ((0)),
    [delimiter] [nvarchar](1)  NULL,
    [exception] [nvarchar](1)  NULL,
    [version] [int] NULL DEFAULT ((0)),
    [input_rec_num] [int] NULL DEFAULT ((0)),
    [bancware_provided] [bit] NOT NULL DEFAULT ((0)),
    [input_filename] [nvarchar](255)  NULL,
    [tablelist_filename] [nvarchar](255)  NULL,
    [has_header_row] [nvarchar](1) NOT NULL DEFAULT ('N'),
    [database_defined] [bit] NOT NULL DEFAULT ((0)),
) ON [PRIMARY]

--INSERT Global Data for INPUT_RECORD table

INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('1','0','','Global Fields','G','0','','','1','0','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('2','0','','Ambit System Fields','B','0','','','1','0','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('3','0','','System Templates','S','0','','','0','1','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('4','0','','User-Defined Templates','M','0','','','0','4','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('5','0','','GL Header','E','0','U','N','0','16','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('6','0','','GL UTF','E','0','U','N','0','16','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('7','0','','GL EOF','E','0','U','N','0','16','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('8','0','','FDBR','E','0','U','N','0','16','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('9','0','','UTF Header','E','0','U','N','0','16','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('10','0','','UTF','E','0','U','N','0','16','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('11','0','','UTF EOF','E','0','U','N','0','16','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('12','0','','Trailer','E','0','U','N','0','16','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('13','0','','GL UTF V2','E','0','U','N','0','16','1','','')
INSERT INPUT_RECORD([index],[subsystem_index],[id_value],[name],[type],[byte_offset],[delimiter],[exception],[version],[input_rec_num],[bancware_provided],[input_filename],[tablelist_filename])       VALUES('14','0','','PROFITABILITY UTF','E','0','U','N','0','16','1','','')


END
ELSE
BEGIN
UPDATE [dbo].[INPUT_RECORD] SET name='PROFITABILITY UTF' where [index]=14 and name='PERSPECTIVE UTF'
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[INPUT_RECORD]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[INPUT_RECORD]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_INPUT_RECORD_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_INPUT_RECORD_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_INPUT_RECORD_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_INPUT_RECORD_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[INPUT_RECORD]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[INPUT_RECORD]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[INPUT_RECORD] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[INPUT_RECORD] SET temporary = [index]') 
			IF EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[INPUT_RECORD]') AND name = N'Index')



				DROP INDEX [Index] ON [dbo].[INPUT_RECORD] WITH ( ONLINE = OFF )

			ALTER TABLE [dbo].[INPUT_RECORD] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[INPUT_RECORD] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[INPUT_RECORD].temporary', 'index', 'COLUMN'; 
		END 
	END
END	

GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[INPUT_RECORD]') AND name = N'Index')
CREATE UNIQUE NONCLUSTERED INDEX [Index] ON [dbo].[INPUT_RECORD] 
(
    [index] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[INPUT_RECORD]') AND name = N'input_rec_num')
CREATE NONCLUSTERED INDEX [input_rec_num] ON [dbo].[INPUT_RECORD] 
(
    [input_rec_num] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[INPUT_RECORD]') AND name = N'Number')
CREATE NONCLUSTERED INDEX [Number] ON [dbo].[INPUT_RECORD] 
(
    [version] ASC
) ON [PRIMARY]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_INPUT_RECORD_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_INPUT_RECORD_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_INPUT_RECORD_INSERT] 
   ON  [dbo].[INPUT_RECORD] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''INPUT_RECORD''
    SET @actionval=1	

    SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''[index]=''+convert(nvarchar(15),NEW.[index]),
                (''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),NEW.subsystem_index),'''')+''|#''+
                ''id_value=''+''''''''+ISNULL(Replace(NEW.id_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''name=''+''''''''+ISNULL(Replace(NEW.name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''type=''+''''''''+NEW.type+''''''''+''|#''+
                ''byte_offset=''+ISNULL(convert(nvarchar(15),NEW.byte_offset),'''') +''|#''+
                ''delimiter=''+''''''''+ISNULL(Replace(NEW.delimiter,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(NEW.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''has_header_row=''+''''''''+ISNULL(Replace(NEW.has_header_row,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''') +''|#''+
                ''input_rec_num=''+convert(nvarchar(15),NEW.input_rec_num) +''|#''+
                ''bancware_provided=''+convert(nvarchar(1),NEW.bancware_provided) +''|#''+
                ''input_filename=''+''''''''+ISNULL(Replace(NEW.input_filename,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''tablelist_filename=''+''''''''+ISNULL(Replace(NEW.tablelist_filename,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''database_defined=''+convert(nvarchar(1),NEW.database_defined))from INSERTED NEW;

END

END



' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_INPUT_RECORD_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_INPUT_RECORD_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_INPUT_RECORD_UPDATE] 
   ON  [dbo].[INPUT_RECORD] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255),
    @value smallint

    SET @value = CHARINDEX(''2000'',@@VERSION,0)
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''INPUT_RECORD''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
    SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END
--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),OLD.subsystem_index),'''')+''|#''+
                ''id_value=''+''''''''+ISNULL(Replace(OLD.id_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''type=''+''''''''+OLD.type+''''''''+''|#''+
                ''byte_offset=''+ISNULL(convert(nvarchar(15),OLD.byte_offset),'''') +''|#''+
                ''delimiter=''+''''''''+ISNULL(Replace(OLD.delimiter,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(OLD.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''has_header_row=''+''''''''+ISNULL(Replace(OLD.has_header_row,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''') +''|#''+
                ''input_rec_num=''+convert(nvarchar(15),OLD.input_rec_num) +''|#''+
                ''bancware_provided=''+convert(nvarchar(1),OLD.bancware_provided) +''|#''+
                ''input_filename=''+''''''''+ISNULL(Replace(OLD.input_filename,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''tablelist_filename=''+''''''''+ISNULL(Replace(OLD.tablelist_filename,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''database_defined=''+convert(nvarchar(1),OLD.database_defined)+
                '' WHERE ''+''[index]=''+convert(nvarchar(15),OLD.[index]),
                 
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),NEW.subsystem_index),'''')+''|#''+
                ''id_value=''+''''''''+ISNULL(Replace(NEW.id_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''name=''+''''''''+ISNULL(Replace(NEW.name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''type=''+''''''''+NEW.type+''''''''+''|#''+
                ''byte_offset=''+ISNULL(convert(nvarchar(15),NEW.byte_offset),'''') +''|#''+
                ''delimiter=''+''''''''+ISNULL(Replace(NEW.delimiter,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(NEW.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''has_header_row=''+''''''''+ISNULL(Replace(NEW.has_header_row,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''') +''|#''+
                ''input_rec_num=''+convert(nvarchar(15),NEW.input_rec_num) +''|#''+
                ''bancware_provided=''+convert(nvarchar(1),NEW.bancware_provided) +''|#''+
                ''input_filename=''+''''''''+ISNULL(Replace(NEW.input_filename,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''tablelist_filename=''+''''''''+ISNULL(Replace(NEW.tablelist_filename,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''database_defined=''+convert(nvarchar(1),NEW.database_defined)+
                '' WHERE ''+''[index]=''+convert(nvarchar(15),NEW.[index]) from DELETED OLD,INSERTED NEW
 where NEW.[index] = OLD.[index];
end
--update the field in INPUT_RECORD table
UPDATE dbo.INPUT_RECORD
SET subsystem_index=NEW.subsystem_index,
    id_value=NEW.id_value,
    [name]=NEW.[name],
    [type]=NEW.[type],
    byte_offset=NEW.byte_offset,
    delimiter=NEW.delimiter,
    exception=NEW.exception,
    has_header_row=NEW.has_header_row,
    version=NEW.version,
    input_rec_num=NEW.input_rec_num,
    bancware_provided=NEW.bancware_provided,
    input_filename=NEW.input_filename,
    tablelist_filename=NEW.tablelist_filename,
    database_defined=NEW.database_defined
    from INSERTED NEW
    where INPUT_RECORD.[index] in (NEW.[index]);
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''subsystem_index=''+ISNULL(convert(nvarchar(15),OLD.subsystem_index),'''')+''|#''+
                ''id_value=''+''''''''+ISNULL(Replace(OLD.id_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''type=''+''''''''+OLD.type+''''''''+''|#''+
                ''byte_offset=''+ISNULL(convert(nvarchar(15),OLD.byte_offset),'''') +''|#''+
                ''delimiter=''+''''''''+ISNULL(Replace(OLD.delimiter,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(OLD.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''has_header_row=''+''''''''+ISNULL(Replace(OLD.has_header_row,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''') +''|#''+
                ''input_rec_num=''+convert(nvarchar(15),OLD.input_rec_num) +''|#''+
                ''bancware_provided=''+convert(nvarchar(1),OLD.bancware_provided) +''|#''+
                ''input_filename=''+''''''''+ISNULL(Replace(OLD.input_filename,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''tablelist_filename=''+''''''''+ISNULL(Replace(OLD.tablelist_filename,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''database_defined=''+convert(nvarchar(1),OLD.database_defined)+''|#''+
                ''[index]=''+convert(nvarchar(15),OLD.[index]),''[index]=''+convert(nvarchar(15),OLD.[index]) from DELETED OLD;
end
--Delete the field from INPUT_RECORD table
DELETE FROM INPUT_RECORD where [index] in (SELECT OLD.[index] from DELETED OLD);
END


set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[VALUE]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[VALUE](
    [index] [int] NOT NULL,
    [field_index] [int] NOT NULL DEFAULT ((0)),
    [value_number] [smallint] NULL DEFAULT ((0)),
    [from] [nvarchar](255)  NULL,
    [to] [nvarchar](255)  NULL,
    [name] [nvarchar](255)  NULL,
    [translation_value] [nvarchar](255)  NULL,
    [exception] [nvarchar](1)  NULL,
    [assigned] [bit] NOT NULL DEFAULT ((0)),
    [docmemo] [ntext]  NULL,
    [version] [int] NULL DEFAULT ((0)),
    [version_index] [int] NULL DEFAULT ((0))
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[VALUE]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[VALUE]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_VALUE_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_VALUE_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_VALUE_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_VALUE_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[VALUE]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[VALUE]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[VALUE] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[VALUE] SET temporary = [index]') 
			ALTER TABLE [dbo].[VALUE] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[VALUE] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[VALUE].temporary', 'index', 'COLUMN'; 
		END 
	END
END	

GO

IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[VALUE]') AND name = N'Field_index')
CREATE NONCLUSTERED INDEX [Field_index] ON [dbo].[VALUE] 
(
    [field_index] ASC
) ON [PRIMARY]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_VALUE_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_VALUE_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_VALUE_INSERT] 
   ON  [dbo].[VALUE] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''VALUE''
    SET @actionval=1	
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''[index]=''+convert(nvarchar(15),NEW.[index]),
                (''[index]=''+convert(nvarchar(15),NEW.[index])+''|#''+
                ''field_index=''+convert(nvarchar(15),NEW.field_index)+''|#''+
                ''value_number=''+ISNULL(convert(nvarchar(15),NEW.value_number),'''')+''|#''+
                ''[from]=''+''''''''+ISNULL(Replace(NEW.[from],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[to]=''+''''''''+ISNULL(Replace(NEW.[to],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''translation_value=''+''''''''+ISNULL(Replace(NEW.translation_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(NEW.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''assigned=''+convert(nvarchar(1),NEW.assigned) +''|#''+
                ''docmemo=''+''''''''+ISNULL(Replace(cast(ORG.docmemo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''') +''|#''+
                ''version_index=''+ISNULL(convert(nvarchar(15),NEW.version_index),'''') )from INSERTED NEW,VALUE ORG
                where ORG.[index] = NEW.[index];

END

END



set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_VALUE_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_VALUE_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_VALUE_UPDATE] 
   ON  [dbo].[VALUE] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''VALUE''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
    SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''field_index=''+convert(nvarchar(15),OLD.field_index)+''|#''+
                ''value_number=''+ISNULL(convert(nvarchar(15),OLD.value_number),'''')+''|#''+
                ''[from]=''+''''''''+ISNULL(Replace(OLD.[from],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[to]=''+''''''''+ISNULL(Replace(OLD.[to],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''translation_value=''+''''''''+ISNULL(Replace(OLD.translation_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(OLD.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''assigned=''+convert(nvarchar(1),OLD.assigned) +''|#''+
                ''docmemo=''+''''''''+ISNULL(Replace(cast(OLD.docmemo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''') +''|#''+
                ''version_index=''+ISNULL(convert(nvarchar(15),OLD.version_index),'''') +
                '' WHERE ''+''[index]=''+convert(nvarchar(15),OLD.[index]),
                 
                ''field_index=''+convert(nvarchar(15),NEW.field_index)+''|#''+
                ''value_number=''+ISNULL(convert(nvarchar(15),NEW.value_number),'''')+''|#''+
                ''[from]=''+''''''''+ISNULL(Replace(NEW.[from],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[to]=''+''''''''+ISNULL(Replace(NEW.[to],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(NEW.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''translation_value=''+''''''''+ISNULL(Replace(NEW.translation_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(NEW.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''assigned=''+convert(nvarchar(1),NEW.assigned) +''|#''+
                ''docmemo=''+''''''''+ISNULL(Replace(cast(NEW.docmemo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),NEW.version),'''') +''|#''+
                ''version_index=''+ISNULL(convert(nvarchar(15),NEW.version_index),'''') +
                '' WHERE ''+''[index]=''+convert(nvarchar(15),NEW.[index]) from DELETED OLD,INSERTED NEW;
end
--update the field in VALUE table
UPDATE dbo.VALUE
SET field_index=NEW.field_index,
    value_number=NEW.value_number,
    [from]=NEW.[from],
    [to]=NEW.[to],
    [name]=NEW.[name],
    translation_value=NEW.translation_value,
    exception=NEW.exception,
    assigned=NEW.assigned,
    docmemo=NEW.docmemo,
    version=NEW.version,
    version_index=NEW.version_index
    from INSERTED NEW
    where VALUE.[index] in (NEW.[index]);
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''field_index=''+convert(nvarchar(15),OLD.field_index)+''|#''+
                ''value_number=''+ISNULL(convert(nvarchar(15),OLD.value_number),'''')+''|#''+
                ''[from]=''+''''''''+ISNULL(Replace(OLD.[from],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[to]=''+''''''''+ISNULL(Replace(OLD.[to],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''translation_value=''+''''''''+ISNULL(Replace(OLD.translation_value,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''exception=''+''''''''+ISNULL(Replace(OLD.exception,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''assigned=''+convert(nvarchar(1),OLD.assigned) +''|#''+
                ''docmemo=''+''''''''+ISNULL(Replace(cast(OLD.docmemo as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''version=''+ISNULL(convert(nvarchar(15),OLD.version),'''') +''|#''+
                ''version_index=''+ISNULL(convert(nvarchar(15),OLD.version_index),'''') +''|#''+
                ''[index]=''+convert(nvarchar(15),OLD.[index]),''[index]=''+convert(nvarchar(15),OLD.[index]) from DELETED OLD;
end
--Delete the field from VALUE table
DELETE FROM VALUE where [index] in (SELECT OLD.[index] from DELETED OLD);
END

END


set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CreateADIUSERSRole]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CreateADIUSERSRole]
AS
BEGIN
            EXEC sp_addrole ''ADI_USERS'' --create a role

            DECLARE @stmt as varchar(250)
            DECLARE @nameSP as varchar(100)

            --fetch all the stored procs and give execute rights
            DECLARE CursorSP CURSOR FOR
                SELECT name from sysobjects where xtype=''P'' AND category=0
            OPEN CursorSP 
            FETCH NEXT FROM CursorSP
            INTO @nameSP
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    set @stmt = ''GRANT EXECUTE ON [dbo].['' + @nameSP + ''] TO [ADI_USERS]''
                    exec (@stmt)
                    FETCH NEXT FROM CursorSP
                    INTO @nameSP
                END
            CLOSE CursorSP
            DEALLOCATE CursorSP

            --fetch all the tables and give rights similar to db_datareader and db_datawriter
            DECLARE CursorTbl CURSOR FOR
                SELECT name from sysobjects where xtype=''U''
                                                                
            OPEN CursorTbl 
            FETCH NEXT FROM CursorTbl
            INTO @nameSP
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    set @stmt = ''GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE ON [dbo].['' + @nameSP + ''] TO [ADI_USERS]''
                    exec (@stmt)
                    FETCH NEXT FROM CursorTbl
                    INTO @nameSP
                END
            CLOSE CursorTbl
            DEALLOCATE CursorTbl
        END
    ' 
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_FOLDERS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
	DROP TRIGGER [dbo].[trigger_FOLDERS_INSERT]; 
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_FOLDERS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
	DROP TRIGGER [dbo].[trigger_FOLDERS_UPDATE]; 
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FOLDERS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[FOLDERS]') AND name = N'sequence_no')
    ALTER TABLE [dbo].[FOLDERS] Add sequence_no [int] DEFAULT (0) NOT NULL

    IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[FOLDERS]') AND name = N'type')
    ALTER TABLE [dbo].[FOLDERS] Add [type] [smallint] DEFAULT(1) NOT NULL
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FOLDERS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    IF EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[FOLDERS]') AND name = N'sequence_no')
    UPDATE [dbo].[FOLDERS] SET [sequence_no] = [folderid] where sequence_no = 0
END

GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FOLDERS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[FOLDERS](
    [folderid] [int] NOT NULL,
    [name] [nvarchar](350)  NOT NULL,
    [description] [ntext]  NULL,
    [sequence_no] [int] NOT NULL DEFAULT ((0)),
    [type] [smallint] NOT NULL DEFAULT ((1)),
 CONSTRAINT [FolderID] PRIMARY KEY CLUSTERED 
(
    [folderid] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

INSERT INTO [dbo].[FOLDERS]
           ([folderid]
		   ,[name]
           ,[description]
           ,[sequence_no]
           ,[type])
     VALUES
           (1
		   ,'Root'
           ,Null
           ,0
           ,1)

INSERT INTO [dbo].[FOLDERS]
           ([folderid]
		   ,[name]
           ,[description]
           ,[sequence_no]
           ,[type])
     VALUES
           (0
		   ,'Global'
           ,Null
           ,0
           ,2)

INSERT INTO [dbo].[FOLDERS]
           ([folderid]
		   ,[name]
           ,[description]
           ,[sequence_no]
           ,[type])
     VALUES
           (-1
		   ,'ADI_JobManager'
           ,Null
           ,0
           ,2)
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FOLDERS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[FOLDERS]'),'TableHasIdentity') = 1 
	BEGIN
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[FOLDERS]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[FOLDERS]') AND name = N'folderid') 
		BEGIN
			ALTER TABLE [dbo].[FOLDERS] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[FOLDERS] SET temporary = folderid') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'F' AND id = OBJECT_ID(N'FK_SECURITY_FOLDERS'))
				ALTER TABLE [dbo].[SECURITY] DROP Constraint FK_SECURITY_FOLDERS; 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'F' AND id = OBJECT_ID(N'FK_FolderID_Parent'))
				ALTER TABLE [dbo].[FOLDERLINKS] DROP Constraint FK_FolderID_Parent
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'F' AND id = OBJECT_ID(N'FK_FolderID_Child'))
				ALTER TABLE [dbo].[FOLDERLINKS] DROP Constraint FK_FolderID_Child
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'F' AND id = OBJECT_ID(N'FK_Parent_FolderID'))
				ALTER TABLE [dbo].[JOBLINKS] DROP Constraint FK_Parent_FolderID
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'FolderID'))
				ALTER TABLE [dbo].[FOLDERS] DROP Constraint FolderID; 
			ALTER TABLE [dbo].[FOLDERS] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[FOLDERS] DROP COLUMN folderid; 
			EXEC sp_rename '[dbo].[FOLDERS].temporary', 'folderid', 'COLUMN';
			ALTER TABLE [dbo].[FOLDERS] ADD CONSTRAINT FolderID PRIMARY KEY(folderid);
			ALTER TABLE [dbo].[FOLDERLINKS]  WITH CHECK ADD  CONSTRAINT [FK_FolderID_Child] FOREIGN KEY([child])
				REFERENCES [dbo].[FOLDERS] ([folderid])
			ALTER TABLE [dbo].[FOLDERLINKS] CHECK CONSTRAINT [FK_FolderID_Child]
			ALTER TABLE [dbo].[FOLDERLINKS]  WITH CHECK ADD  CONSTRAINT [FK_FolderID_Parent] FOREIGN KEY([parent])
				REFERENCES [dbo].[FOLDERS] ([folderid])
			ALTER TABLE [dbo].[SECURITY]  WITH CHECK ADD  CONSTRAINT [FK_SECURITY_FOLDERS] FOREIGN KEY([folderid])
				REFERENCES [dbo].[FOLDERS] ([folderid]) ON UPDATE CASCADE ON DELETE CASCADE
			ALTER TABLE [dbo].[SECURITY] CHECK CONSTRAINT [FK_SECURITY_FOLDERS]
			ALTER TABLE [dbo].[JOBLINKS]  WITH CHECK ADD  CONSTRAINT [FK_Parent_FolderID] FOREIGN KEY([parent])
				REFERENCES [dbo].[FOLDERS] ([folderid])
		END 
	END
END	

GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_FOLDERS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_FOLDERS_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_FOLDERS_INSERT] 
   ON  [dbo].[FOLDERS]
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255),
	@foldertype int

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''FOLDERS''
    SET @actionval=1
	SELECT @foldertype = type FROM INSERTED;

IF(@foldertype = 1)
	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
ELSE
    SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
IF(@foldertype = 1)
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''folderid=''+convert(nvarchar(15),NEW.folderid),

                (''name=''+''''''''+ISNULL(Replace(NEW.name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(ORG.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+convert(nvarchar(15),NEW.[type]) +''|#''+
                ''sequence_no=''+convert(nvarchar(15),NEW.sequence_no) +''|#''+
                ''folderid=''+convert(nvarchar(15),NEW.folderid)) from INSERTED NEW, FOLDERS ORG
where NEW.folderid = ORG.folderid;
ELSE
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''folderid=''+convert(nvarchar(15),NEW.folderid),

                (''name=''+''''''''+ISNULL(Replace(NEW.name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(ORG.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+convert(nvarchar(15),NEW.[type]) +''|#''+
                ''sequence_no=''+convert(nvarchar(15),NEW.sequence_no) +''|#''+
                ''folderid=''+convert(nvarchar(15),NEW.folderid)) from INSERTED NEW, FOLDERS ORG
where NEW.folderid = ORG.folderid;
END
END



SET ANSI_NULLS ON
' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_FOLDERS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER  [dbo].[trigger_FOLDERS_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_FOLDERS_UPDATE] 
   ON  [dbo].[FOLDERS] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255),
	@foldertype int
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''FOLDERS''
    SET @actionval=0	
	SELECT @foldertype = type FROM DELETED
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
IF(@foldertype = 1)
	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
ELSE
    SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END
--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
IF(@foldertype = 1)
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+convert(nvarchar(15),OLD.[type]) +''|#''+
                ''sequence_no=''+convert(nvarchar(15),OLD.sequence_no) +
                '' WHERE ''+''folderid=''+convert(nvarchar(15),OLD.folderid),
                 
                ''name=''+''''''''+ISNULL(Replace(NEW.name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(NEW.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+convert(nvarchar(15),NEW.[type]) +''|#''+
                ''sequence_no=''+convert(nvarchar(15),NEW.sequence_no) +
                '' WHERE ''+''folderid=''+convert(nvarchar(15),NEW.folderid) from DELETED OLD,INSERTED NEW
where NEW.folderid = OLD.folderid;
ELSE
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+convert(nvarchar(15),OLD.[type]) +''|#''+
                ''sequence_no=''+convert(nvarchar(15),OLD.sequence_no) +
                '' WHERE ''+''folderid=''+convert(nvarchar(15),OLD.folderid),
                 
                ''name=''+''''''''+ISNULL(Replace(NEW.name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(NEW.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+convert(nvarchar(15),NEW.[type]) +''|#''+
                ''sequence_no=''+convert(nvarchar(15),NEW.sequence_no) +
                '' WHERE ''+''folderid=''+convert(nvarchar(15),NEW.folderid) from DELETED OLD,INSERTED NEW
where NEW.folderid = OLD.folderid;
END
--update the field in SOURCE_FIELD table
UPDATE dbo.FOLDERS
SET 
    [name]=NEW.[name],
    description=NEW.description,
    [type]=NEW.[type],
    sequence_no=NEW.sequence_no
    from INSERTED NEW
    where FOLDERS.folderid in (NEW.folderid );
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
IF(@foldertype = 1)
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+convert(nvarchar(15),OLD.[type]) +''|#''+
                ''sequence_no=''+convert(nvarchar(15),OLD.sequence_no) +''|#''+
                ''folderid=''+convert(nvarchar(15),OLD.folderid),''folderid=''+convert(nvarchar(15),OLD.folderid) from DELETED OLD;
ELSE
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''[type]=''+convert(nvarchar(15),OLD.[type]) +''|#''+
                ''sequence_no=''+convert(nvarchar(15),OLD.sequence_no) +''|#''+
                ''folderid=''+convert(nvarchar(15),OLD.folderid),''folderid=''+convert(nvarchar(15),OLD.folderid) from DELETED OLD;
end
--Delete the field from FOLDERS table
DELETE FROM FOLDERS where folderid in (SELECT OLD.folderid from DELETED OLD);
END










' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[JOINS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[JOINS](
    [index] [int] NOT NULL,
    [name] [nvarchar](255)  NOT NULL,
    [extrasql] [ntext]  NULL,
    [description] [ntext]  NULL,
    [userspecifiedquerysource] [ntext]  NULL,
    [datasource_connection] [int] NULL DEFAULT ((0)),
 CONSTRAINT [aaaaaJoins_PK] PRIMARY KEY NONCLUSTERED 
(
    [index] ASC
) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[JOINS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[JOINS]'),'TableHasIdentity') = 1 
	BEGIN
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_JOINS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_JOINS_INSERT]; 
		IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_JOINS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1) 
			DROP TRIGGER [dbo].[trigger_JOINS_UPDATE]; 
		
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[JOINS]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[JOINS]') AND name = N'index') 
		BEGIN
			ALTER TABLE [dbo].[JOINS] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[JOINS] SET temporary = [index]') 
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'aaaaaJoins_PK'))
				ALTER TABLE [dbo].[JOINS] DROP Constraint aaaaaJoins_PK; 
			ALTER TABLE [dbo].[JOINS] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[JOINS] DROP COLUMN [index]; 
			EXEC sp_rename '[dbo].[JOINS].temporary', 'index', 'COLUMN';
			ALTER TABLE [dbo].[JOINS] ADD CONSTRAINT aaaaaJoins_PK PRIMARY KEY([index]);  
		END 
	END
END	

GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_JOINS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_JOINS_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_JOINS_INSERT] 
   ON  [dbo].[JOINS]
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''JOINS''
    SET @actionval=1	

    SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[index]=''+convert(nvarchar(15),NEW.[index]),
                (''name=''+''''''''+ISNULL(Replace(NEW.name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''extrasql=''+''''''''+ISNULL(Replace(cast(ORG.extrasql as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(ORG.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''userspecifiedquerysource=''+''''''''+ISNULL(Replace(cast(ORG.userspecifiedquerysource as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''datasource_connection=''+ISNULL(convert(nvarchar(15),NEW.datasource_connection),'''')+''|#''+
                ''[index]=''+convert(nvarchar(15),NEW.[index])) from INSERTED NEW, JOINS ORG
where NEW.[index] = ORG.[index];
END
END



set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_JOINS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_JOINS_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_JOINS_UPDATE] 
   ON  [dbo].[JOINS] 
   INSTEAD OF UPDATE,DELETE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''JOINS''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
    SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''extrasql=''+''''''''+ISNULL(Replace(cast(OLD.extrasql as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''userspecifiedquerysource=''+''''''''+ISNULL(Replace(cast(OLD.userspecifiedquerysource as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''datasource_connection=''+ISNULL(convert(nvarchar(15),OLD.datasource_connection),'''')+
                '' WHERE ''+''[index]=''+convert(nvarchar(15),OLD.[index]) ,

                ''name=''+''''''''+ISNULL(Replace(NEW.name,'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''extrasql=''+''''''''+ISNULL(Replace(cast(NEW.extrasql as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(NEW.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''userspecifiedquerysource=''+''''''''+ISNULL(Replace(cast(NEW.userspecifiedquerysource as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''datasource_connection=''+ISNULL(convert(nvarchar(15),NEW.datasource_connection),'''')+
                '' WHERE ''+''[index]=''+convert(nvarchar(15),NEW.[index]) from DELETED OLD,INSERTED NEW
where OLD.[index] = NEW.[index];
end
--update the field in JOINS table
UPDATE dbo.JOINS
SET [name]=NEW.[name],
    extrasql=NEW.extrasql,
    description=NEW.description,
    userspecifiedquerysource=NEW.userspecifiedquerysource,
    datasource_connection=NEW.datasource_connection
    from INSERTED NEW
    where JOINS.[index] in (SELECT NEW.[index] from INSERTED NEW);
END

--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[name]=''+''''''''+ISNULL(Replace(OLD.[name],'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''extrasql=''+''''''''+ISNULL(Replace(cast(OLD.extrasql as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''description=''+''''''''+ISNULL(Replace(cast(OLD.description as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''userspecifiedquerysource=''+''''''''+ISNULL(Replace(cast(OLD.userspecifiedquerysource as nvarchar(MAX)),'''''''',''''''''''''),'''')+''''''''+''|#''+
                ''datasource_connection=''+ISNULL(convert(nvarchar(15),OLD.datasource_connection),'''')+''|#''+
                 ''[index]=''+convert(nvarchar(15),OLD.[index]) ,''[index]=''+convert(nvarchar(15),OLD.[index]) from DELETED OLD;
end
--Delete the field from VALUE table
DELETE FROM JOINS where [index] in (SELECT OLD.[index] from DELETED OLD);
END
END




set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SECURITY]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[SECURITY](
    [userid] [int] NOT NULL,
    [folderid] [int] NOT NULL,
    [canview] [bit] NOT NULL CONSTRAINT [DF_SECURITY_rights]  DEFAULT ((0)),
    [canexecute] [bit] NOT NULL CONSTRAINT [DF_SECURITY_canexecute]  DEFAULT ((0)),
    [canadd] [bit] NOT NULL CONSTRAINT [DF_SECURITY_canadd]  DEFAULT ((0)),
    [canupdate] [bit] NOT NULL CONSTRAINT [DF_SECURITY_canupdate]  DEFAULT ((0)),
    [candelete] [bit] NOT NULL CONSTRAINT [DF_SECURITY_candelete]  DEFAULT ((0)),
 CONSTRAINT [PK_SECURITY] PRIMARY KEY CLUSTERED 
(
    [userid] ASC,
    [folderid] ASC
) ON [PRIMARY]
) ON [PRIMARY]

INSERT INTO [dbo].[SECURITY]
           ([userid]
           ,[folderid]
           ,[canview]
           ,[canexecute]
           ,[canadd]
           ,[canupdate]
           ,[candelete])
     VALUES
           (1
           ,1
           ,1
           ,1
           ,1
           ,1
           ,1)

INSERT INTO [dbo].[SECURITY]
			([userid]
			,[folderid]
			,[canview]
			,[canexecute]
			,[canadd]
			,[canupdate]
			,[candelete])
			VALUES
			(1
			,-1
			,1
			,1
			,1
			,1
			,1)

INSERT INTO [dbo].[SECURITY]
			([userid]
			,[folderid]
			,[canview]
			,[canexecute]
			,[canadd]
			,[canupdate]
			,[candelete])
			VALUES
			(1
			,0
			,1
			,1
			,1
			,1
			,1)

END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SECURITY_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_SECURITY_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_SECURITY_INSERT] 
   ON  [dbo].[SECURITY] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255),
    @foldertype int

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''SECURITY''
    SET @actionval=1	

    SELECT @foldertype = type FROM FOLDERS where FOLDERS.folderid IN(select folderid from inserted)
    
IF(@foldertype = 1)
    SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
else
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
	
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
IF(@foldertype = 1)
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
				''userid=''+convert(nvarchar(15),NEW.userid)+''|#''+
				''folderid=''+convert(nvarchar(15),NEW.folderid),
                ''userid=''+convert(nvarchar(15),NEW.userid)+''|#''+
				''folderid=''+convert(nvarchar(15),NEW.folderid)+''|#''+
                ''canview=''+convert(nvarchar(1),NEW.canview)+''|#''+
                ''canexecute=''+convert(nvarchar(1),NEW.canexecute)+''|#''+
                ''canadd=''+convert(nvarchar(1),NEW.canadd)+''|#''+
                ''canupdate=''+convert(nvarchar(1),NEW.canupdate)+''|#''+
                ''candelete=''+convert(nvarchar(1),NEW.candelete) from INSERTED NEW,SECURITY ORG
			    where ORG.userid = NEW.userid and ORG.folderid = NEW.folderid;
ELSE
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
				''userid=''+convert(nvarchar(15),NEW.userid)+''|#''+
				''folderid=''+convert(nvarchar(15),NEW.folderid),
                ''userid=''+convert(nvarchar(15),NEW.userid)+''|#''+
				''folderid=''+convert(nvarchar(15),NEW.folderid)+''|#''+
                ''canview=''+convert(nvarchar(1),NEW.canview)+''|#''+
                ''canexecute=''+convert(nvarchar(1),NEW.canexecute)+''|#''+
                ''canadd=''+convert(nvarchar(1),NEW.canadd)+''|#''+
                ''canupdate=''+convert(nvarchar(1),NEW.canupdate)+''|#''+
                ''candelete=''+convert(nvarchar(1),NEW.candelete) from INSERTED NEW,SECURITY ORG
			    where ORG.userid = NEW.userid and ORG.folderid = NEW.folderid;
END
END

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SECURITY_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_SECURITY_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_SECURITY_UPDATE] 
   ON  [dbo].[SECURITY] 
   AFTER UPDATE,DELETE
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @modifiedColumns int,
    @user_name nvarchar(255),
    @foldertype int
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''SECURITY''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
    SELECT @foldertype = type FROM FOLDERS where FOLDERS.folderid IN(select folderid from DELETED)
    
IF(@foldertype = 1)
    SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
else
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
IF(@foldertype = 1)
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
				''canview=''+convert(nvarchar(1),OLD.canview)+''|#''+
                ''canexecute=''+convert(nvarchar(1),OLD.canexecute)+''|#''+
                ''canadd=''+convert(nvarchar(1),OLD.canadd)+''|#''+
                ''canupdate=''+convert(nvarchar(1),OLD.canupdate)+''|#''+
                ''candelete=''+convert(nvarchar(1),OLD.candelete)+
                '' WHERE ''+''userid=''+convert(nvarchar(15),OLD.userid)+'' AND ''+
				''folderid=''+convert(nvarchar(15),OLD.folderid),

				''canview=''+convert(nvarchar(1),NEW.canview)+''|#''+
                ''canexecute=''+convert(nvarchar(1),NEW.canexecute)+''|#''+
                ''canadd=''+convert(nvarchar(1),NEW.canadd)+''|#''+
                ''canupdate=''+convert(nvarchar(1),NEW.canupdate)+''|#''+
                ''candelete=''+convert(nvarchar(1),NEW.candelete)+ 
                '' WHERE ''+''userid=''+convert(nvarchar(15),NEW.userid)+'' AND ''+
				''folderid=''+convert(nvarchar(15),NEW.folderid) from DELETED OLD,INSERTED NEW
				where NEW.userid = OLD.userid and NEW.folderid = OLD.folderid;
else
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
				''canview=''+convert(nvarchar(1),OLD.canview)+''|#''+
                ''canexecute=''+convert(nvarchar(1),OLD.canexecute)+''|#''+
                ''canadd=''+convert(nvarchar(1),OLD.canadd)+''|#''+
                ''canupdate=''+convert(nvarchar(1),OLD.canupdate)+''|#''+
                ''candelete=''+convert(nvarchar(1),OLD.candelete)+
                '' WHERE ''+''userid=''+convert(nvarchar(15),OLD.userid)+'' AND ''+
				''folderid=''+convert(nvarchar(15),OLD.folderid),

				''canview=''+convert(nvarchar(1),NEW.canview)+''|#''+
                ''canexecute=''+convert(nvarchar(1),NEW.canexecute)+''|#''+
                ''canadd=''+convert(nvarchar(1),NEW.canadd)+''|#''+
                ''canupdate=''+convert(nvarchar(1),NEW.canupdate)+''|#''+
                ''candelete=''+convert(nvarchar(1),NEW.candelete)+ 
                '' WHERE ''+''userid=''+convert(nvarchar(15),NEW.userid)+'' AND ''+
				''folderid=''+convert(nvarchar(15),NEW.folderid) from DELETED OLD,INSERTED NEW
				where NEW.userid = OLD.userid and NEW.folderid = OLD.folderid;
end
END
--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
IF(@foldertype = 1)
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''userid=''+convert(nvarchar(15),OLD.userid)+''|#''+
				''folderid=''+convert(nvarchar(15),OLD.folderid)+''|#''+
                ''canview=''+convert(nvarchar(1),OLD.canview)+''|#''+
                ''canexecute=''+convert(nvarchar(1),OLD.canexecute)+''|#''+
                ''canadd=''+convert(nvarchar(1),OLD.canadd)+''|#''+
                ''canupdate=''+convert(nvarchar(1),OLD.canupdate)+''|#''+
                ''candelete=''+convert(nvarchar(1),OLD.candelete),
                ''userid=''+convert(nvarchar(15),OLD.userid)+''|#''+
                ''folderid=''+convert(nvarchar(15),OLD.folderid) from DELETED OLD;
else
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''userid=''+convert(nvarchar(15),OLD.userid)+''|#''+
				''folderid=''+convert(nvarchar(15),OLD.folderid)+''|#''+
                ''canview=''+convert(nvarchar(1),OLD.canview)+''|#''+
                ''canexecute=''+convert(nvarchar(1),OLD.canexecute)+''|#''+
                ''canadd=''+convert(nvarchar(1),OLD.canadd)+''|#''+
                ''canupdate=''+convert(nvarchar(1),OLD.canupdate)+''|#''+
                ''candelete=''+convert(nvarchar(1),OLD.candelete),
                ''userid=''+convert(nvarchar(15),OLD.userid)+''|#''+
                ''folderid=''+convert(nvarchar(15),OLD.folderid) from DELETED OLD;                
end
END
'
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[JOBLINKS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[JOBLINKS](
    [parent] [int] NOT NULL CONSTRAINT [DF_JobLinks_Parent]  DEFAULT ((0)),
    [jobid] [int] NOT NULL CONSTRAINT [DF_JobLinks_JobID]  DEFAULT ((0)),
    [joborder] [int] NOT NULL CONSTRAINT [DF_JOBLINKS_joborder]  DEFAULT ((0)),
 CONSTRAINT [PK_JobLinks] PRIMARY KEY CLUSTERED 
(
    [parent] ASC,
    [jobid] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_JOBLINKS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_JOBLINKS_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_JOBLINKS_INSERT] 
   ON  [dbo].[JOBLINKS] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''JOBLINKS''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''[parent]=''+convert(nvarchar(15),NEW.[parent])+''|#''+
				''jobid=''+convert(nvarchar(15),NEW.jobid),
                ''[parent]=''+convert(nvarchar(15),NEW.[parent])+''|#''+
                ''jobid=''+convert(nvarchar(15),NEW.jobid)+''|#''+
                ''joborder=''+convert(nvarchar(15),NEW.joborder) from INSERTED NEW,JOBLINKS ORG
where ORG.jobid = NEW.jobid and ORG.[parent] = NEW.[parent];

END
END

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_JOBLINKS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_JOBLINKS_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_JOBLINKS_UPDATE] 
   ON  [dbo].[JOBLINKS] 
   AFTER UPDATE,DELETE
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @modifiedColumns int,
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''JOBLINKS''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[parent]=''+convert(nvarchar(15),OLD.[parent])+''|#''+
                ''jobid=''+convert(nvarchar(15),OLD.jobid)+''|#''+
                ''joborder=''+convert(nvarchar(15),OLD.joborder)+
                '' where ''+ ''[parent]=''+convert(nvarchar(15),OLD.[parent])+ '' AND ''+
                ''jobid=''+convert(nvarchar(15),OLD.jobid),

                ''[parent]=''+convert(nvarchar(15),NEW.[parent])+''|#''+
                ''jobid=''+convert(nvarchar(15),NEW.jobid)+''|#''+
                ''joborder=''+convert(nvarchar(15),NEW.joborder)+ 
                '' where ''+ ''[parent]=''+convert(nvarchar(15),NEW.[parent])+ '' AND ''+
                ''jobid=''+convert(nvarchar(15),NEW.jobid) from DELETED OLD,INSERTED NEW
				where NEW.jobid = OLD.jobid and  NEW.[parent] = OLD.[parent];
end
END
--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''[parent]=''+convert(nvarchar(15),OLD.[parent])+''|#''+
                ''jobid=''+convert(nvarchar(15),OLD.jobid)+''|#''+
                ''joborder=''+convert(nvarchar(15),OLD.joborder),
                ''[parent]=''+convert(nvarchar(15),OLD.[parent])+''|#''+
                ''jobid=''+convert(nvarchar(15),OLD.jobid) from DELETED OLD;
end
END
'
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[STATUS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[STATUS](
    [jobid] [int] NOT NULL,
    [statusline] [int] NOT NULL,
    [status] [nvarchar](1000)  NOT NULL,
 CONSTRAINT [PK_Status] PRIMARY KEY CLUSTERED 
(
    [jobid] ASC,
    [statusline] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[STATUS]') AND name = N'JobID')
CREATE NONCLUSTERED INDEX [JobID] ON [dbo].[STATUS] 
(
    [jobid] ASC
) ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SCHEDULE]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[SCHEDULE](
    [id] [int] NOT NULL,
    [jobid] [int] NULL CONSTRAINT [DF_Schedule_JobID]  DEFAULT ((0)),
    [starttime] [datetime] NOT NULL,
    [scheduletype] [tinyint] NOT NULL CONSTRAINT [DF_Schedule_ScheduleType]  DEFAULT ((0)),
    [scheduletime] [datetime] NOT NULL,
    [usebdays] [bit] NULL,
 CONSTRAINT [PK_Schedule] PRIMARY KEY CLUSTERED 
(
    [id] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[SCHEDULE]') AND name = N'usebdays')
ALTER TABLE [dbo].[SCHEDULE] Add [usebdays] [bit] DEFAULT (0);
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[SCHEDULE]') AND name = N'JobID')
CREATE NONCLUSTERED INDEX [JobID] ON [dbo].[SCHEDULE] 
(
    [jobid] ASC
) ON [PRIMARY]
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[SCHEDULE]') AND name = N'StartTime')
CREATE NONCLUSTERED INDEX [StartTime] ON [dbo].[SCHEDULE] 
(
    [starttime] ASC
) ON [PRIMARY]
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SCHEDULE]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1) 
BEGIN 
	IF OBJECTPROPERTY(object_id('[dbo].[SCHEDULE]'),'TableHasIdentity') = 1 
	BEGIN
		IF NOT EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[SCHEDULE]') AND name = N'temporary') AND
		EXISTS (SELECT * from syscolumns where [id] = OBJECT_ID(N'[dbo].[SCHEDULE]') AND name = N'id') 
		BEGIN
			ALTER TABLE [dbo].[SCHEDULE] ADD temporary [int] NULL; 
			EXEC('UPDATE [dbo].[SCHEDULE] SET temporary = id') 
		
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'F' AND id = OBJECT_ID(N'FK_RUNONSCHEDULE_SCHEDULE'))
				ALTER TABLE [dbo].[RUNONSCHEDULE] DROP Constraint FK_RUNONSCHEDULE_SCHEDULE; 
				
			IF EXISTS(SELECT * FROM dbo.sysobjects WHERE xtype = N'PK' AND id = OBJECT_ID(N'PK_Schedule'))
				ALTER TABLE [dbo].[SCHEDULE] DROP Constraint PK_Schedule; 
				
			ALTER TABLE [dbo].[SCHEDULE] ALTER COLUMN temporary [int] NOT NULL; 
			ALTER TABLE [dbo].[SCHEDULE] DROP COLUMN id; 
			EXEC sp_rename '[dbo].[SCHEDULE].temporary', 'id', 'COLUMN';
			ALTER TABLE [dbo].[SCHEDULE] ADD CONSTRAINT PK_Schedule PRIMARY KEY(id);
			
			IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RUNONSCHEDULE]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
			BEGIN
				ALTER TABLE [dbo].[RUNONSCHEDULE]  WITH CHECK ADD  CONSTRAINT [FK_RUNONSCHEDULE_SCHEDULE] FOREIGN KEY([scheduleid])
					REFERENCES [dbo].[SCHEDULE] ([id])ON UPDATE CASCADE ON DELETE CASCADE
				ALTER TABLE [dbo].[RUNONSCHEDULE] CHECK CONSTRAINT [FK_RUNONSCHEDULE_SCHEDULE]
			END
			
		END 
	END
END



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SCHEDULE_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_SCHEDULE_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_SCHEDULE_INSERT] 
   ON  [dbo].[SCHEDULE] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''SCHEDULE''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''id=''+convert(nvarchar(15),NEW.id),
                ''id=''+convert(nvarchar(15),NEW.id)+''|#''+
                ''jobid=''+convert(nvarchar(15),NEW.jobid)+''|#''+
                ''starttime=''+ CASE WHEN NEW.starttime IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.starttime)+'''''''' END+''|#''+
                ''scheduletype=''+convert(nvarchar(15),NEW.scheduletype)+''|#''+
                ''scheduletime=''+ CASE WHEN NEW.scheduletime IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.scheduletime)+'''''''' END+''|#''+
                ''usebdays=''+convert(nvarchar(1),NEW.usebdays) from INSERTED NEW,SCHEDULE ORG
where ORG.id = NEW.id;

END
END

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_SCHEDULE_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_SCHEDULE_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_SCHEDULE_UPDATE] 
   ON  [dbo].[SCHEDULE] 
   AFTER UPDATE,DELETE
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @modifiedColumns int,
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''SCHEDULE''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''id=''+convert(nvarchar(15),OLD.id)+''|#''+
                ''jobid=''+convert(nvarchar(15),OLD.jobid)+''|#''+
                ''starttime=''+ CASE WHEN OLD.starttime IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.starttime)+'''''''' END+''|#''+
                ''scheduletype=''+convert(nvarchar(15),OLD.scheduletype)+''|#''+
                ''scheduletime=''+ CASE WHEN OLD.scheduletime IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.scheduletime)+'''''''' END+''|#''+
                ''usebdays=''+convert(nvarchar(1),OLD.usebdays),

                ''id=''+convert(nvarchar(15),NEW.id)+''|#''+
                ''jobid=''+convert(nvarchar(15),NEW.jobid)+''|#''+
                ''starttime=''+ CASE WHEN NEW.starttime IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.starttime)+'''''''' END+''|#''+
                ''scheduletype=''+convert(nvarchar(15),NEW.scheduletype)+''|#''+
                ''scheduletime=''+ CASE WHEN NEW.scheduletime IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.scheduletime)+'''''''' END+''|#''+
                ''usebdays=''+convert(nvarchar(1),NEW.usebdays) from DELETED OLD,INSERTED NEW
				where NEW.id = OLD.id;
end
END
--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''id=''+convert(nvarchar(15),OLD.id)+''|#''+
                ''jobid=''+convert(nvarchar(15),OLD.jobid)+''|#''+
                ''starttime=''+ CASE WHEN OLD.starttime IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.starttime)+'''''''' END+''|#''+
                ''scheduletype=''+convert(nvarchar(15),OLD.scheduletype)+''|#''+
                ''scheduletime=''+ CASE WHEN OLD.scheduletime IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.scheduletime)+'''''''' END+''|#''+
                ''usebdays=''+convert(nvarchar(1),OLD.usebdays),''id=''+convert(nvarchar(15),OLD.id) from DELETED OLD;
end
END
'
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[PARAMETERS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[PARAMETERS](
    [jobid] [int] NOT NULL CONSTRAINT [DF_Parameters_JobID]  DEFAULT ((0)),
    [paramnumber] [int] NOT NULL CONSTRAINT [DF_Parameters_paramNumber]  DEFAULT ((0)),
    [paramstring] [nvarchar](1000)  NULL,
 CONSTRAINT [PK_Parameters] PRIMARY KEY CLUSTERED 
(
    [jobid] ASC,
    [paramnumber] ASC
) ON [PRIMARY]
) ON [PRIMARY]
END
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[PARAMETERS]') AND name = N'JobID')
CREATE NONCLUSTERED INDEX [JobID] ON [dbo].[PARAMETERS] 
(
    [jobid] ASC
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_PARAMETERS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_PARAMETERS_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_PARAMETERS_INSERT] 
   ON  [dbo].[PARAMETERS] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''PARAMETERS''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''jobid=''+convert(nvarchar(15),NEW.jobid),
                ''jobid=''+convert(nvarchar(15),NEW.jobid)+''|#''+
                ''paramnumber=''+convert(nvarchar(15),NEW.paramnumber)+''|#''+
                ''paramstring=''+''''''''+ISNULL(Replace(NEW.paramstring,'''''''',''''''''''''),'''')+'''''''' from INSERTED NEW,PARAMETERS ORG
where ORG.jobid = NEW.jobid and ORG.paramnumber = NEW.paramnumber;

END
END

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_PARAMETERS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_PARAMETERS_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_PARAMETERS_UPDATE] 
   ON  [dbo].[PARAMETERS] 
   AFTER UPDATE,DELETE
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @modifiedColumns int,
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''PARAMETERS''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''jobid=''+convert(nvarchar(15),OLD.jobid)+''|#''+
                ''paramnumber=''+convert(nvarchar(15),OLD.paramnumber)+''|#''+
                ''paramstring=''+''''''''+ISNULL(Replace(OLD.paramstring,'''''''',''''''''''''),'''')+''''''''+
                '' WHERE ''+''jobid=''+convert(nvarchar(15),OLD.jobid)+ ''AND ''+
                ''paramnumber=''+convert(nvarchar(15),OLD.paramnumber),

                ''jobid=''+convert(nvarchar(15),NEW.jobid)+''|#''+
                ''paramnumber=''+convert(nvarchar(15),NEW.paramnumber)+''|#''+
                ''paramstring=''+''''''''+ISNULL(Replace(NEW.paramstring,'''''''',''''''''''''),'''')+''''''''+
                '' WHERE ''+''jobid=''+convert(nvarchar(15),OLD.jobid)+ ''AND ''+
                ''paramnumber=''+convert(nvarchar(15),OLD.paramnumber)
                  from DELETED OLD,INSERTED NEW
				where NEW.jobid = OLD.jobid and
				NEW.paramnumber = OLD.paramnumber;
end
END
--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''jobid=''+convert(nvarchar(15),OLD.jobid)+''|#''+
                ''paramnumber=''+convert(nvarchar(15),OLD.paramnumber)+''|#''+
                ''paramstring=''+''''''''+ISNULL(Replace(OLD.paramstring,'''''''',''''''''''''),'''')+'''''''',''jobid=''+convert(nvarchar(15),OLD.jobid) from DELETED OLD;
end
END
'
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RUNONSCHEDULE]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[RUNONSCHEDULE](
    [scheduleid] [int] NOT NULL,
    [time] [datetime] NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_RUNONSCHEDULE_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_RUNONSCHEDULE_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_RUNONSCHEDULE_INSERT] 
   ON  [dbo].[RUNONSCHEDULE] 
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)

    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''RUNONSCHEDULE''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,''scheduleid=''+convert(nvarchar(15),NEW.scheduleid),
                ''scheduleid=''+convert(nvarchar(15),NEW.scheduleid)+''|#''+
                ''time=''+ CASE WHEN NEW.time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.time)+'''''''' END from INSERTED NEW,RUNONSCHEDULE ORG
where ORG.scheduleid = NEW.scheduleid;

END
END

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
' 
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_RUNONSCHEDULE_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_RUNONSCHEDULE_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_RUNONSCHEDULE_UPDATE] 
   ON  [dbo].[RUNONSCHEDULE] 
   AFTER UPDATE,DELETE
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @modifiedColumns int,
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''RUNONSCHEDULE''
    SET @actionval=0	
    
    SELECT @ins = count(*) from INSERTED
    SELECT @del = count(*) from DELETED
    
	SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
    END

--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''scheduleid=''+convert(nvarchar(15),OLD.scheduleid)+''|#''+
                ''time=''+ CASE WHEN OLD.time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.time)+'''''''' END+
                '' WHERE ''+''scheduleid=''+convert(nvarchar(15),OLD.scheduleid),

                ''scheduleid=''+convert(nvarchar(15),NEW.scheduleid)+''|#''+
                ''time=''+ CASE WHEN NEW.time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),NEW.time)+'''''''' END+
                '' WHERE ''+''scheduleid=''+convert(nvarchar(15),NEW.scheduleid)
                  from DELETED OLD,INSERTED NEW
				where NEW.scheduleid = OLD.scheduleid;
end
END
--DELETE
else if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''scheduleid=''+convert(nvarchar(15),OLD.scheduleid)+''|#''+
                ''time=''+ CASE WHEN OLD.time IS NULL then ''NULL'' ELSE ''''''''+convert(nvarchar(30),OLD.time)+'''''''' END,
                ''scheduleid=''+convert(nvarchar(15),OLD.scheduleid) from DELETED OLD;
end
END
'
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FOLDERLINKS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[FOLDERLINKS](
    [parent] [int] NOT NULL CONSTRAINT [DF_FolderLinks_Parent]  DEFAULT ((0)),
    [child] [int] NOT NULL
) ON [PRIMARY]
END
GO


IF NOT EXISTS (SELECT * FROM dbo.sysindexes WHERE id = OBJECT_ID(N'[dbo].[FOLDERLINKS]') AND name = N'Child')
CREATE NONCLUSTERED INDEX [Child] ON [dbo].[FOLDERLINKS] 
(
    [child] ASC
) ON [PRIMARY]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_FOLDERLINKS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_FOLDERLINKS_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_FOLDERLINKS_INSERT] 
   ON  [dbo].[FOLDERLINKS]
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @foldertype smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''FOLDERLINKS''
    SET @actionval=1	
    
    SELECT @foldertype = type FROM FOLDERS where folderid IN(select child from inserted)
    
IF(@foldertype = 1)
    SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
else
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
IF(@foldertype = 1)
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''child=''+convert(nvarchar(15),NEW.child) +''|#''+
                ''parent=''+convert(nvarchar(15),NEW.parent),

                (''child=''+convert(nvarchar(15),NEW.child) +''|#''+
                ''parent=''+convert(nvarchar(15),NEW.parent)) from INSERTED NEW;

ELSE
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''child=''+convert(nvarchar(15),NEW.child) +''|#''+
                ''parent=''+convert(nvarchar(15),NEW.parent),

                (''child=''+convert(nvarchar(15),NEW.child) +''|#''+
                ''parent=''+convert(nvarchar(15),NEW.parent)) from INSERTED NEW;
END
END



' 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_FOLDERLINKS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_FOLDERLINKS_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_FOLDERLINKS_UPDATE] 
   ON  [dbo].[FOLDERLINKS]
   AFTER DELETE,UPDATE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @foldertype smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''FOLDERLINKS''
    SET @actionval=3	
    
    SELECT @del = count(*) from DELETED
    SELECT @ins = count(*) from INSERTED
    
    SELECT @foldertype = type FROM FOLDERS where folderid IN(select child from DELETED)
    
IF(@foldertype = 1)
    SELECT @actionindex = max([index]) from CC_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
else
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
    

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
IF(@foldertype = 1)
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''parent=''+convert(nvarchar(15),OLD.parent) +''|#''+
                ''child=''+convert(nvarchar(15),OLD.child)+
                '' where ''+''child=''+convert(nvarchar(15),OLD.child),

                ''parent=''+convert(nvarchar(15),NEW.parent) +''|#''+
                ''child=''+convert(nvarchar(15),NEW.child)+
                '' where ''+''child=''+convert(nvarchar(15),NEW.child) from DELETED OLD,INSERTED NEW
where NEW.child  = OLD.child ;
ELSE
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''parent=''+convert(nvarchar(15),OLD.parent) +''|#''+
                ''child=''+convert(nvarchar(15),OLD.child)+
                '' where ''+''child=''+convert(nvarchar(15),OLD.child),

                ''parent=''+convert(nvarchar(15),NEW.parent) +''|#''+
                ''child=''+convert(nvarchar(15),NEW.child)+
                '' where ''+''child=''+convert(nvarchar(15),NEW.child) from DELETED OLD,INSERTED NEW
where NEW.child  = OLD.child ;
end
end
-- DELETE
if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
IF(@foldertype = 1)
INSERT INTO dbo.CC_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''parent=''+convert(nvarchar(15),OLD.parent) +''|#''+
                ''child=''+convert(nvarchar(15),OLD.child),
                ''child=''+convert(nvarchar(15),OLD.child) from DELETED OLD;

ELSE
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''parent=''+convert(nvarchar(15),OLD.parent) +''|#''+
                ''child=''+convert(nvarchar(15),OLD.child),
                ''child=''+convert(nvarchar(15),OLD.child) from DELETED OLD;
end
END
END


SET ANSI_NULLS ON
' 
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[JOBTRACKER]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[JOBTRACKER](
	[RequestID] [nvarchar](50) NULL,
	[JobID] [int] NULL,
	[JobType] [nvarchar](50) NULL,
	[RunOnMachine] [nvarchar](50) NULL,
	[Status] [nchar](10) NULL,
	[TimeStamp] [datetime] NULL,
	[ProcessID] [int] NULL,
	[ErrorMessage] [varchar](50) NULL
) ON [PRIMARY]
END

GO

SET ANSI_PADDING OFF
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[BW_DBID]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE [dbo].[BW_DBID](
		[name] [nvarchar](255)  NOT NULL,
		[connect_string] [ntext]  NOT NULL,
		[encryptedpasswd] [nvarchar](255)  NULL,
	CONSTRAINT [PK_BW_DBID] PRIMARY KEY CLUSTERED 
	(
		[name] ASC
	) ON [PRIMARY]
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GLOBAL_OPTIONS]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[GLOBAL_OPTIONS](
    [option_name] [nvarchar](255)  NOT NULL,
    [option_value] [nvarchar](255)  NULL,
) ON [PRIMARY]

--INSERT Global Data for GLOBAL_OPTIONS table

INSERT GLOBAL_OPTIONS([option_name],[option_value])       VALUES('GProcessingDate','00000000')


END
GO
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_GLOBAL_OPTIONS_INSERT]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_GLOBAL_OPTIONS_INSERT];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_GLOBAL_OPTIONS_INSERT] 
   ON  [dbo].[GLOBAL_OPTIONS]
   AFTER INSERT
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''GLOBAL_OPTIONS''
    SET @actionval=1	

	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID
    
IF(isnull(@actionindex, 0)<> 0)
BEGIN
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''option_name=''+''''''''+ISNULL(Replace(NEW.option_name,'''''''',''''''''''''),'''')+'''''''' +''|#''+
                ''option_value=''+''''''''+ISNULL(Replace(NEW.option_value,'''''''',''''''''''''),'''')+'''''''',

                (''option_name=''+''''''''+ISNULL(Replace(NEW.option_name,'''''''',''''''''''''),'''')+'''''''' +''|#''+
                ''option_value=''+''''''''+ISNULL(Replace(NEW.option_value,'''''''',''''''''''''),'''')+'''''''') from INSERTED NEW;
END
END



' 
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_GLOBAL_OPTIONS_UPDATE]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_GLOBAL_OPTIONS_UPDATE];
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[trigger_GLOBAL_OPTIONS_UPDATE] 
   ON  [dbo].[GLOBAL_OPTIONS]
   AFTER DELETE,UPDATE 
AS 
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

  declare
    @changedate datetime,
    @actionval smallint,
    @actionindex int,
    @ins int,
    @del int,
    @tableName nvarchar(50),
    @user_name nvarchar(255)
    
    
    SET @user_name=SYSTEM_USER
    SET @changedate = getdate()
    SET @tableName = ''GLOBAL_OPTIONS''
    SET @actionval=3	
    
    SELECT @del = count(*) from DELETED
    SELECT @ins = count(*) from INSERTED
    
	SELECT @actionindex = max([index]) from MM_USER_ACTIONS INNER JOIN sys.sysprocesses ON processid = hostprocess WHERE [user_name]= SYSTEM_USER AND machinename = hostname AND spid = @@SPID

    if @ins > 0 and @del > 0
       SET @actionval=2	
    ELSE if isnull(@ins, 0) =0 and @del > 0
        SET @actionval=3	
--UPDATE
if(@actionval = 2)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''option_name=''+''''''''+ISNULL(Replace(OLD.option_name,'''''''',''''''''''''),'''')+'''''''' +''|#''+
                ''option_value=''+''''''''+ISNULL(Replace(OLD.option_value,'''''''',''''''''''''),'''')+''''''''+
                '' where ''+''option_name=''+''''''''+ISNULL(Replace(OLD.option_name,'''''''',''''''''''''),'''')+'''''''',

                ''option_name=''+''''''''+ISNULL(Replace(NEW.option_name,'''''''',''''''''''''),'''')+'''''''' +''|#''+
                ''option_value=''+''''''''+ISNULL(Replace(NEW.option_value,'''''''',''''''''''''),'''')+''''''''+
                '' where ''+''option_name=''+''''''''+ISNULL(Replace(NEW.option_name,'''''''',''''''''''''),'''')+'''''''' from DELETED OLD,INSERTED NEW
where NEW.option_name  = OLD.option_name ;
end
end
-- DELETE
if(@actionval = 3)
BEGIN
IF(isnull(@actionindex, 0)<> 0)
begin
INSERT INTO dbo.MM_AUDIT( action_index, action, timestamp, table_name, [user_name],oldvalues,newvalues)	
SELECT @actionindex,@actionval,@changedate,@tableName,@user_name,
                ''option_name=''+''''''''+ISNULL(Replace(OLD.option_name,'''''''',''''''''''''),'''')+'''''''' +''|#''+
                ''option_value=''+''''''''+ISNULL(Replace(OLD.option_value,'''''''',''''''''''''),'''')+'''''''',
                ''option_name=''+''''''''+ISNULL(Replace(OLD.option_name,'''''''',''''''''''''),'''')+'''''''' from DELETED OLD;
end
END
END


' 
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[trigger_INSERTRUNJOB]') AND OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER [dbo].[trigger_INSERTRUNJOB]
EXEC dbo.sp_executesql @statement = N'-- =============================================
-- Create date: 29-May-14
-- Description:	TRIGGER TO PREVENT MULTIPLE INSERTION OF NEW JOB RUN REQUEST
-- =============================================
CREATE TRIGGER [dbo].[trigger_INSERTRUNJOB] 
   ON  [dbo].[JOBTRACKER] 
   INSTEAD OF Insert
AS 
BEGIN
	IF ((select count(*) from JOBTRACKER, inserted where JOBTRACKER.JobID = inserted.JobID and JOBTRACKER.Status = inserted.Status) <= 0)
	BEGIN
		INSERT INTO JOBTRACKER  SELECT * FROM inserted
	END
END 
'

GO


SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[junkPaste]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[junkPaste]
AS
BEGIN

INSERT INTO PARAMETERS (jobid, paramnumber, paramstring) 
SELECT jobid, [PASTE ERRORS].paramnumber, [PASTE ERRORS].paramstring
FROM [PASTE ERRORS], PARAMETERS;

END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetVersion]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetVersion]
AS
BEGIN

SELECT MISC.versionmajor, MISC.versionminor, MISC.versionbuild
FROM MISC;

END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetServers]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	BEGIN
	EXEC dbo.sp_executesql @statement = N'DROP PROCEDURE [dbo].[GetServers];'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetServers]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetServers]
    @DBName [nvarchar](70)
AS
BEGIN

SELECT  distinct RTRIM(LTRIM(hostname)) as name FROM sys.sysprocesses where dbid =DB_ID(@DBName) and program_name = "ADI Job Runner 2015.1.0"

END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DeleteServer]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DeleteServer]
    @pName [nvarchar](350),
    @pType [nvarchar](70)
AS
BEGIN
DELETE FROM SERVERS
WHERE (((SERVERS.name)=@pName) AND ((SERVERS.type)=@pType));
END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DeleteMMFolder]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DeleteMMFolder]
    @nodeID [int]
AS
BEGIN


Delete From OUTPUT_FIELD where output_record_index in 
(SELECT [index] from OUTPUT_RECORD WHERE [type]<>30 and report_index in
(SELECT [index] from REPORT WHERE subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID)));

Delete FRom TEMPLATE_LINK where output_record_index in 
(SELECT [index] from OUTPUT_RECORD WHERE [type]<>30 and report_index in
(SELECT [index] from REPORT WHERE subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID)));

Delete From CATEGORY where report_index in
(SELECT [index] from REPORT WHERE subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID));

Delete From OUTPUT_RECORD where type<>30 and report_index in
(SELECT [index] from REPORT WHERE subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID));

Delete From MM_SCHEDULE where report_index in
(SELECT [index] from REPORT WHERE subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID));

Delete From [DATASOURCE_LINKS] where report_index in
(SELECT [index] from REPORT WHERE subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID));


Delete From TRANSFORM_VALUE where transform_id in
(SELECT transform_id from CATEGORY WHERE report_index in
(SELECT [index] from REPORT WHERE subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID)));

Delete From TRANSFORMS where id in
(SELECT transform_id from CATEGORY WHERE report_index in
(SELECT [index] from REPORT WHERE subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID)));

DELETE from OUTPUT_RECORD where type = 30 and report_index in
(SELECT [index] from REPORT WHERE subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID));

DELETE from REPORT where [index] in
(SELECT [index] from REPORT WHERE subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID));

DELETE from [VALUE] where field_index in
(SELECT [index] from SOURCE_FIELD where input_record_index in
(select [index] From INPUT_RECORD where subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID)));

DELETE from TRANSFORM_VALUE where transform_id in
(Select id from TRANSFORMS where field_index in 
(SELECT [index] from SOURCE_FIELD where source = ''I'' and input_record_index in
(select [index] From INPUT_RECORD where subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID))));

DELETE from TRANSFORMS where field_index in
(SELECT [index] from SOURCE_FIELD where source = ''I'' and input_record_index in
(select [index] From INPUT_RECORD where subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID)));


Delete From SOURCE_FIELD  where input_record_index in
(select [index] From INPUT_RECORD where subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID));

Delete From TEMPLATE_LINK  where input_record_index in
(select [index] From INPUT_RECORD where subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID));

DELETE FROM INPUT_RECORD WHERE subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID);

Delete From DATASOURCE_LINKS where subsystem_index in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID);

Delete From MM_FIELDFOLDER where subsystem_index  in
(SELECT [index] from SUB_SYSTEM WHERE folderid = @nodeID);

Delete From SUB_SYSTEM where folderid = @nodeID;

DELETE FROM FOLDERLINKS
WHERE FOLDERLINKS.child = @nodeID;

DELETE  FROM FOLDERS
WHERE FOLDERS.folderid = @nodeID  AND type = 2;

END




' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetJobsByTypeAndNode]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetJobsByTypeAndNode]
    @TypeName [nvarchar](70),
    @parentID [int]
AS
BEGIN

SELECT JOBS.id, JOBS.name
FROM JOBS INNER JOIN JOBLINKS ON JOBS.id = JOBLINKS.jobid
WHERE (((JOBS.type)=@TypeName) AND ((JOBLINKS.parent)=@parentID));


END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetJobsByNode]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetJobsByNode]
    @parentID [int]
AS
BEGIN

SELECT JOBS.name, JOBS.id
FROM JOBS INNER JOIN JOBLINKS ON JOBS.id = JOBLINKS.jobid
WHERE (((JOBLINKS.parent)=@parentID))
ORDER BY JOBLINKS.joborder;

END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetJobs]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetJobs]
AS
BEGIN

SELECT JOBS.id, JOBS.name
FROM JOBS,JOBLINKS

WHERE JOBS.id = JOBLINKS.jobid

ORDER BY JOBLINKS.joborder;

END
' 
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetScheduleProperties]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetScheduleProperties]
    @schedID [int]
AS
BEGIN
    SELECT JOBS.name AS JobName, JOBS.description AS JobDesc, 
    SCHEDULE.jobid, SCHEDULE.starttime, SCHEDULE.scheduletype, 
    SCHEDULE.scheduletime FROM JOBS INNER JOIN SCHEDULE ON 
    JOBS.id = SCHEDULE.jobid WHERE (((SCHEDULE.id)=@schedID));
END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetJobType]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetJobType]
    @jobID [int]
AS
BEGIN

SELECT JOBS.type
FROM JOBS
WHERE (((JOBS.id)=@jobID));

END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetSchedulePropertiesEx]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetSchedulePropertiesEx]
    @schedID [int]
AS
BEGIN
    SELECT JOBS.name AS JobName, JOBS.description AS JobDesc, 
    SCHEDULE.jobid, SCHEDULE.starttime, SCHEDULE.scheduletype, 
    SCHEDULE.scheduletime, SCHEDULE.usebdays FROM JOBS INNER JOIN SCHEDULE ON 
    JOBS.id = SCHEDULE.jobid WHERE (((SCHEDULE.id)=@schedID))
END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RenameJob]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[RenameJob]
    @jobID [int],
    @newDesc [ntext],
    @newName [nvarchar](350)
AS
BEGIN

UPDATE JOBS SET JOBS.name = @newName, JOBS.description = @newDesc
WHERE (((JOBS.id)=@jobID));

END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetJobsByType]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetJobsByType]
    @TypeName [nvarchar](70)
AS
BEGIN

SELECT JOBS.id, JOBS.name
FROM JOBS
WHERE (((JOBS.type)=@TypeName))
ORDER BY JOBS.id;

END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DeleteJob]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	BEGIN
	EXEC dbo.sp_executesql @statement = N'DROP PROCEDURE [dbo].[DeleteJob];'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DeleteJob]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DeleteJob]
    @jobID [int]
AS
BEGIN

DELETE
FROM JOBLINKS
WHERE JOBLINKS.jobid= @jobID;

DELETE
FROM PARAMETERS
WHERE PARAMETERS.jobid = @jobID

DELETE
FROM JOBTRACKER
WHERE JOBTRACKER.JobID= @jobID;

DELETE
FROM JOBS
WHERE JOBS.id= @jobID;

END
' 
END

ELSE
EXEC dbo.sp_executesql @statement = N'ALTER PROCEDURE [dbo].[DeleteJob]
    @jobID [int]
AS
BEGIN

DELETE
FROM JOBLINKS
WHERE JOBLINKS.jobid= @jobID;

DELETE
FROM PARAMETERS
WHERE PARAMETERS.jobid = @jobID

DELETE
FROM JOBS
WHERE JOBS.id= @jobID;

END'

GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FindExistingSibling]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[FindExistingSibling]
    @nodeID [int],
    @nodeName [nvarchar](350)
AS
BEGIN

SELECT FL2.child
FROM FOLDERLINKS, FOLDERS, FOLDERLINKS AS FL2
WHERE (((FL2.child)<>@nodeID) AND ((FOLDERLINKS.child)=@nodeID) AND ((FOLDERLINKS.parent)=[FL2].[parent]) 
AND ((FOLDERS.folderid)=[FL2].[child]) AND ((FOLDERS.name)=@nodeName));

END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetChildNodes]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetChildNodes]
    @parentNode [int]
AS
BEGIN

SELECT FOLDERLINKS.child AS ID, FOLDERS.name
FROM FOLDERLINKS, FOLDERS
WHERE (((FOLDERS.folderid)=[FOLDERLINKS].[child]) AND ((FOLDERLINKS.parent)=@parentNode))
ORDER BY FOLDERS.sequence_no;


END
' 
END

GO
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetChildNodes]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'ALTER PROCEDURE [dbo].[GetChildNodes]
    @parentNode int
    AS
    BEGIN
        SELECT FOLDERLINKS.child AS ID, FOLDERS.name
        FROM FOLDERLINKS, FOLDERS
        WHERE (((FOLDERS.folderid)=[FOLDERLINKS].[child]) AND ((FOLDERLINKS.parent)=@parentNode))
        ORDER BY FOLDERS.sequence_no;
    END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FindExistingNode]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[FindExistingNode]
    @nodeID [int],
    @folderName [nvarchar](350)
AS
BEGIN

SELECT FOLDERS.folderid
FROM FOLDERLINKS, FOLDERS
WHERE (((FOLDERLINKS.parent)=@nodeID) AND( FOLDERLINKS.child = FOLDERS.folderid ) AND  ((FOLDERS.name)=@folderName));

END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DeleteNode]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DeleteNode]
    @nodeID [int]
AS
BEGIN

DELETE FROM [JOBLINKS]
WHERE [JOBLINKS].parent = @nodeID;

DELETE FROM FOLDERLINKS
WHERE (FOLDERLINKS.child = @nodeID);

DELETE FROM SECURITY
WHERE (SECURITY.folderid = @nodeID);

DELETE  FROM FOLDERS
WHERE (FOLDERS.folderid = @nodeID)  AND (@nodeID <> 1 );

END
' 
END
ELSE
EXEC dbo.sp_executesql @statement = N'ALTER PROCEDURE [dbo].[DeleteNode]
    @nodeID [int]
AS
BEGIN

DELETE FROM [JOBLINKS]
WHERE [JOBLINKS].parent = @nodeID;

DELETE FROM FOLDERLINKS
WHERE (FOLDERLINKS.child = @nodeID);

DELETE FROM SECURITY
WHERE (SECURITY.folderid = @nodeID);

DELETE  FROM FOLDERS
WHERE (FOLDERS.folderid = @nodeID)  AND (@nodeID <> 1 );

END
' 
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FindJobNodePair]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[FindJobNodePair]
    @mjobID [int],
    @nodeID [int]
AS
BEGIN

SELECT JOBLINKS.jobid
FROM JOBLINKS
WHERE (((JOBLINKS.jobid)=@mjobID) AND ((JOBLINKS.parent)=@nodeID));


END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FindJobOwners]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[FindJobOwners]
    @mjobID [int]
AS
BEGIN

SELECT JOBLINKS.parent
FROM JOBLINKS
WHERE (((JOBLINKS.jobid)= @mjobID));



END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RemoveJob]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[RemoveJob]
    @mjobID [int],
    @nodeID [int]
AS
BEGIN

DELETE 
FROM JOBLINKS
WHERE (((JOBLINKS.jobid)=@mjobID) AND ((JOBLINKS.parent)=@nodeID));

END
' 
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetScheduleList]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetScheduleList]
AS
BEGIN
    SELECT SCHEDULE.id FROM SCHEDULE;
END
' 
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetScheduleListByJobID]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetScheduleListByJobID]
    @ParamJobID [int]
AS
BEGIN
    SELECT SCHEDULE.id FROM SCHEDULE WHERE SCHEDULE.jobid=@ParamJobID;
END
' 
END
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DeleteSchedule]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DeleteSchedule]
    @schedID [int]
AS
BEGIN
    DELETE FROM SCHEDULE WHERE SCHEDULE.id=@schedID;
END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetStatus]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[GetStatus]
    @pJobID [int]
AS
BEGIN

SELECT STATUS.status
FROM STATUS
WHERE (((STATUS.jobid)=@pJobID))
ORDER BY STATUS.statusline;

END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DeleteStatus]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[DeleteStatus]
    @paramID [int]
AS
BEGIN

DELETE 
FROM STATUS
WHERE STATUS.jobid = @paramID;
END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[RenameNode]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[RenameNode]
    @jobID [int],
    @newName [nvarchar](350),
    @newDesc [ntext]
AS
BEGIN

UPDATE FOLDERS SET FOLDERS.name = @newName, FOLDERS.description = @newDesc
WHERE (((FOLDERS.folderid)=@jobID));

END
' 
END
GO

SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SP_InsertRunJob]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	BEGIN
	EXEC dbo.sp_executesql @statement = N'DROP PROCEDURE [dbo].[SP_InsertRunJob];'
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[SP_InsertRunJob]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[SP_InsertRunJob]
    @JOBID [int], @RUNONMACHINE [varchar](16), @HOSTMACHINE[varchar](16)
AS
BEGIN

	DECLARE @_JOBTYPE NVARCHAR(70)
	DECLARE @_RUNONMACHINE NVARCHAR(70)
	DECLARE @_STATUS INT	
	SET @_STATUS = (SELECT [status] FROM JOBS WHERE id=@JOBID)
	IF @_STATUS = 0
	BEGIN
		RETURN
	END
	SET  @_JOBTYPE = (SELECT TYPE FROM JOBS WHERE id=@JOBID)
	IF (@_JOBTYPE != "BatchTask")
	BEGIN
		SET @_RUNONMACHINE = (SELECT UPPER(LTRIM(RTRIM(PARAMETERS.paramstring))) FROM PARAMETERS WHERE PARAMETERS.paramnumber = 0 AND PARAMETERS.jobid=@JOBID)
	END
	IF(@_RUNONMACHINE = "" or @_RUNONMACHINE="127.0.0.1" or @_RUNONMACHINE IS NULL)
	BEGIN
		SET @_RUNONMACHINE = @RUNONMACHINE
	END
		
	DECLARE @_REQUESTID NVARCHAR(50)
	SET @_REQUESTID = @HOSTMACHINE + "#" + CAST (SYSDATETIME() AS nvarchar(MAX))
		
	DELETE FROM JOBTRACKER WHERE [JobID]=@JOBID AND [Status]!="NEW" 
	INSERT INTO JOBTRACKER VALUES (@_REQUESTID, @JOBID, @_JOBTYPE, @_RUNONMACHINE, "NEW", CURRENT_TIMESTAMP, 0, "") 
END
' 
END
GO

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FK_SECURITY_FOLDERS]') AND type = 'F')
ALTER TABLE [dbo].[SECURITY]  WITH CHECK ADD  CONSTRAINT [FK_SECURITY_FOLDERS] FOREIGN KEY([folderid])
REFERENCES [dbo].[FOLDERS] ([folderid])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[SECURITY] CHECK CONSTRAINT [FK_SECURITY_FOLDERS]
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FK_SECURITY_USERS]') AND type = 'F')
ALTER TABLE [dbo].[SECURITY]  WITH CHECK ADD  CONSTRAINT [FK_SECURITY_USERS] FOREIGN KEY([userid])
REFERENCES [dbo].[USERS] ([uid])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[SECURITY] CHECK CONSTRAINT [FK_SECURITY_USERS]
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FK_JobID_ID]') AND type = 'F')
ALTER TABLE [dbo].[JOBLINKS]  WITH NOCHECK ADD  CONSTRAINT [FK_JobID_ID] FOREIGN KEY([jobid])
REFERENCES [dbo].[JOBS] ([id])
ELSE
BEGIN
	ALTER TABLE [dbo].[JOBLINKS] DROP Constraint FK_JobID_ID; 
	ALTER TABLE [dbo].[JOBLINKS]  WITH NOCHECK ADD  CONSTRAINT [FK_JobID_ID] FOREIGN KEY([jobid])
	REFERENCES [dbo].[JOBS] ([id])
END
GO
ALTER TABLE [dbo].[JOBLINKS] CHECK CONSTRAINT [FK_JobID_ID]
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FK_Parent_FolderID]') AND type = 'F')
ALTER TABLE [dbo].[JOBLINKS]  WITH CHECK ADD  CONSTRAINT [FK_Parent_FolderID] FOREIGN KEY([parent])
REFERENCES [dbo].[FOLDERS] ([folderid])
ELSE
BEGIN
	ALTER TABLE [dbo].[JOBLINKS] DROP Constraint [FK_Parent_FolderID]; 
	ALTER TABLE [dbo].[JOBLINKS]  WITH CHECK ADD  CONSTRAINT [FK_Parent_FolderID] FOREIGN KEY([parent])
	REFERENCES [dbo].[FOLDERS] ([folderid])
END
GO
ALTER TABLE [dbo].[JOBLINKS] CHECK CONSTRAINT [FK_Parent_FolderID]
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FK_Status_Jobs]') AND type = 'F')
ALTER TABLE [dbo].[STATUS]  WITH NOCHECK ADD  CONSTRAINT [FK_Status_Jobs] FOREIGN KEY([jobid])
REFERENCES [dbo].[JOBS] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[STATUS] CHECK CONSTRAINT [FK_Status_Jobs]
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FK_Schedule_Jobs]') AND type = 'F')
ALTER TABLE [dbo].[SCHEDULE]  WITH NOCHECK ADD  CONSTRAINT [FK_Schedule_Jobs] FOREIGN KEY([jobid])
REFERENCES [dbo].[JOBS] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[SCHEDULE] CHECK CONSTRAINT [FK_Schedule_Jobs]
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FK_Parameters_Jobs]') AND type = 'F')
ALTER TABLE [dbo].[PARAMETERS]  WITH NOCHECK ADD  CONSTRAINT [FK_Parameters_Jobs] FOREIGN KEY([jobid])
REFERENCES [dbo].[JOBS] ([id])
ELSE
BEGIN
	ALTER TABLE [dbo].[PARAMETERS] DROP Constraint FK_Parameters_Jobs; 
	ALTER TABLE [dbo].[PARAMETERS]  WITH NOCHECK ADD  CONSTRAINT [FK_Parameters_Jobs] FOREIGN KEY([jobid])
	REFERENCES [dbo].[JOBS] ([id])
END
GO
ALTER TABLE [dbo].[PARAMETERS] CHECK CONSTRAINT [FK_Parameters_Jobs]
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FK_RUNONSCHEDULE_SCHEDULE]') AND type = 'F')
ALTER TABLE [dbo].[RUNONSCHEDULE]  WITH CHECK ADD  CONSTRAINT [FK_RUNONSCHEDULE_SCHEDULE] FOREIGN KEY([scheduleid])
REFERENCES [dbo].[SCHEDULE] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[RUNONSCHEDULE] CHECK CONSTRAINT [FK_RUNONSCHEDULE_SCHEDULE]
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FK_FolderID_Child]') AND type = 'F')
ALTER TABLE [dbo].[FOLDERLINKS]  WITH CHECK ADD  CONSTRAINT [FK_FolderID_Child] FOREIGN KEY([child])
REFERENCES [dbo].[FOLDERS] ([folderid])
GO
ALTER TABLE [dbo].[FOLDERLINKS] CHECK CONSTRAINT [FK_FolderID_Child]
GO
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[FK_FolderID_Parent]') AND type = 'F')
ALTER TABLE [dbo].[FOLDERLINKS]  WITH CHECK ADD  CONSTRAINT [FK_FolderID_Parent] FOREIGN KEY([parent])
REFERENCES [dbo].[FOLDERS] ([folderid])
ELSE
BEGIN
	ALTER TABLE [dbo].[FOLDERLINKS] DROP Constraint FK_FolderID_Parent; 
	ALTER TABLE [dbo].[FOLDERLINKS]  WITH CHECK ADD  CONSTRAINT [FK_FolderID_Parent] FOREIGN KEY([parent])
	REFERENCES [dbo].[FOLDERS] ([folderid])
END
GO
ALTER TABLE [dbo].[FOLDERLINKS] CHECK CONSTRAINT [FK_FolderID_Parent]
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[CreateADIUSERSRole]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	IF  NOT EXISTS (SELECT * FROM dbo.sysusers WHERE name = N'ADI_USERS' AND issqlrole = 1)
	BEGIN
		EXEC CreateADIUSERSRole
	END
ELSE
	-- if database is updated then grant permission to all droped and recreated store procedures and table
	-- grant permission to tables
	GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE ON [dbo].[MISC] TO [ADI_USERS]
	GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE ON [dbo].[OPTION_LISTS] TO [ADI_USERS]
	GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE ON [dbo].[FUNCTION] TO [ADI_USERS]
	GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE ON [dbo].[TRANSFORM_PARAM_TYPES] TO [ADI_USERS]
	GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE ON [dbo].[BW_DBID] TO [ADI_USERS]
	GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE ON [dbo].[HOLIDAYS] TO [ADI_USERS]
	GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE ON [dbo].[JOBTRACKER] TO [ADI_USERS]
	GRANT DELETE, INSERT, REFERENCES, SELECT, UPDATE ON [dbo].[LICENSEINFO] TO [ADI_USERS]
	-- grant permission to store procedures
	GRANT EXECUTE ON [dbo].[DeleteJob] TO [ADI_USERS]
	GRANT EXECUTE ON [dbo].[GetServers] TO [ADI_USERS]
	GRANT EXECUTE ON [dbo].[SP_InsertRunJob] TO [ADI_USERS]
END
GO

IF  EXISTS (SELECT * FROM dbo.sysusers WHERE name = N'ADI_USERS' AND issqlrole = 1)
	GRANT ALTER ANY SCHEMA TO ADI_USERS;
GO


UPDATE OUTPUT_RECORD set name = 'Ambit UTR'
WHERE name = 'BW UTR'

GO

UPDATE OUTPUT_RECORD set name = 'Ambit GL UTR'
WHERE name = 'BW GL UTR'

GO

UPDATE TRANSFORM_VALUE set arg_param = 'AMBITBUDGET'
FROM TRANSFORM_VALUE 
INNER JOIN TRANSFORMS ON TRANSFORM_VALUE.transform_id = TRANSFORMS.id
where TRANSFORM_VALUE.[index] = 0 AND TRANSFORM_VALUE.arg_param='BWBUDGET' 
AND (TRANSFORMS.transform_function  = 53
OR TRANSFORMS.transform_function  = 54 OR TRANSFORMS.transform_function = 57)

GO

UPDATE [dbo].[JOBS]  SET      [type] = 'CLTask' WHERE [type] ='{3542AF72-3DF2-11D3-B862-00105A1D485A}'
GO
UPDATE [dbo].[JOBS]  SET      [type] = 'BatchTask' WHERE [type] ='{AB6E8A72-D657-11D2-8124-00104B733360}'
GO
UPDATE [dbo].[JOBS]  SET      [type] = 'FDBRLoaderTask' WHERE [type] ='{0B5D69D4-D0C1-11d2-B87F-00A0CC306473}'
GO
UPDATE [dbo].[JOBS]  SET      [type] = 'AFTask' WHERE [type] ='{B3A64E22-5957-11D2-B856-00A0CC306473}'
GO
UPDATE [dbo].[JOBS]  SET      [type] = 'GLRITask' WHERE [type] ='{BB33E2D3-2FFA-4C75-A8E6-9BE47417AED9}'
GO
UPDATE [dbo].[JOBS]  SET      [type] = 'SQLCmdTask' WHERE [type] ='{B2E4C371-F68D-41a9-BEF4-8FF75970DBBD}'
GO
