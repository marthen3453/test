USE [SF_SQL_Admin]
GO

/****** Object:  StoredProcedure [dbo].[DatabaseStandardSecuritySetup2]    Script Date: 3/30/2017 1:33:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE Procedure [dbo].[DatabaseStandardSecuritySetup3]
	-- Datababase Name you wish to grant permissions to
	@DBName sysname = ''

	-- The base portions of the security group names.  Ex. "ADVWRKS" for the Adventureworks database. SQL_ADVWRKS_APPADMIN_DLG, SQL_ADVWRKS_APPACCT_DLG
	,@Security_Group_Base_Name sysname = ''

	-- 1 if this is for a shared instance of SQL Server.  0 if the instance is dedicated to the application
	,@IsSharedServer BIT = 0

	-- 0 if you want permissions granted down to the database level.  1 if you only want the server logins created and server level permissions granted.
	,@OnlyServerLevelPermissions BIT = 0

AS

DECLARE
	@cmd nvarchar(max)
	,@Site_code varchar(5)
	,@Domain varchar(10)
	,@DomainPrefix varchar(20)
	,@AppAdmin sysname
	,@AppAdminExists bit
	,@AppAcct sysname
	,@AppAcctExists bit
	,@DataAdmin sysname
	,@DataAdminExists bit
	,@ReportUser sysname
	,@ReportUserExists bit
	,@TempAdmin sysname
	,@TempAdminExists bit
	,@i INT
	,@ErrMsg VARCHAR(MAX)  

SELECT @Domain = DEFAULT_DOMAIN()
SELECT
	@DomainPrefix = @Domain + '\'

PRINT '--------------------------------------------------------------------------------'
PRINT '--DOMAIN:  ' + @Domain
PRINT '--DATABASE:  ' + @DBName	
PRINT '--SECURITY GROUP BASE NAME:  ' + @Security_Group_Base_Name
PRINT '--IS SERVER SHARED:  ' + CASE @IsSharedServer WHEN 1 THEN 'TRUE' ELSE 'FALSE' END
PRINT '--GRANT ONLY SERVER PERMISSIONS:  ' + CASE @OnlyServerLevelPermissions WHEN 1 THEN 'TRUE' ELSE 'FALSE' END
PRINT '--------------------------------------------------------------------------------'
PRINT ''

BEGIN TRY 

	SELECT
		 @AppAdmin = @DomainPrefix + 'SQL_'+@Security_Group_Base_Name+'_APPADMIN_DLG'
		,@AppAcct = @DomainPrefix + 'SQL_'+@Security_Group_Base_Name+'_APPACCT_DLG'
		,@DataAdmin = @DomainPrefix + 'SQL_'+@Security_Group_Base_Name+'_DATAADMIN_ALL_DLG'
		,@ReportUser = @DomainPrefix + 'SQL_'+@Security_Group_Base_Name+'_RPT_ALL_DLG'
		,@TempAdmin = @DomainPrefix + 'SQL_'+@Security_Group_Base_Name+'_TEMPADMIN_DLG'

	PRINT '------------------------'
	PRINT '--CREATE SERVER LOGINS--'
	PRINT '------------------------'


	CREATE_LOGINS:
	/******************
	** Create Logins **
	******************/
	--AppAdmin
	BEGIN TRY  
		Select @cmd = 'IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = ''' + @AppAdmin + ''')' + CHAR(13) + CHAR(10) +
					CHAR(9) + 'CREATE LOGIN [' + @AppAdmin + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
		EXEC sp_executesql @cmd
		Print @cmd
		SET @AppAdminExists = 1
	END TRY 
	BEGIN CATCH  
		PRINT @AppAdmin + ' not found in Active Directory'
		SET @AppAdminExists = 0	
	END CATCH


	--AppAcct
	BEGIN TRY 
		Select @cmd = 'IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = ''' + @AppAcct + ''')' + CHAR(13) + CHAR(10) +
					CHAR(9) + 'CREATE LOGIN [' + @AppAcct + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
		EXEC sp_executesql @cmd
		Print @cmd
		SET @AppAcctExists = 1
	END TRY
	BEGIN CATCH
		PRINT @AppAcct + ' not found in Active Directory'
		SET @AppAcctExists = 0
	END CATCH

	--DataAdmin_All
	BEGIN TRY
		Select @cmd = 'IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = ''' + @DataAdmin + ''')' + CHAR(13) + CHAR(10) +
					CHAR(9) + 'CREATE LOGIN [' + @DataAdmin + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
		EXEC sp_executesql @cmd
		Print @cmd
		SET @DataAdminExists = 1
	END TRY
	BEGIN CATCH
		PRINT @DataAdmin + ' not found in Active Directory'
		SET @DataAdminExists = 0
	END CATCH 

	--RPT
	BEGIN TRY
		Select @cmd = 'IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = ''' + @ReportUser + ''')' + CHAR(13) + CHAR(10) +
					CHAR(9) + 'CREATE LOGIN [' + @ReportUser + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
		EXEC sp_executesql @cmd
		Print @cmd
		SET @ReportUserExists = 1
	END TRY
	BEGIN CATCH
		PRINT @ReportUser + ' not found in Active Directory'
		SET @ReportUserExists = 0
	END CATCH

	--TEMPADMIN
	BEGIN TRY
		Select @cmd = 'IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = ''' + @TempAdmin + ''')' + CHAR(13) + CHAR(10) +
					CHAR(9) + 'CREATE LOGIN [' + @TempAdmin + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
		EXEC sp_executesql @cmd
		Print @cmd
		SET @TempAdminExists = 1
	END TRY
	BEGIN CATCH
		PRINT @TempAdmin + ' not found in Active Directory'
		SET @TempAdminExists = 0
	END CATCH

	PRINT ''

	--Exit it if only need to 
	IF @OnlyServerLevelPermissions = 1
	BEGIN
		GOTO GRANT_SERVER_PERMISSIONS
	END
	ELSE


	CREATE_DB_USERS:
	/**************************
	** Create Database Users **
	**************************/
	-- Create users inside all DBs
	IF @DBName = 'ALL'
	BEGIN

	PRINT '-------------------------'
	PRINT '--CREATE DATABASE USERS--'
	PRINT '-------------------------'

	PRINT ''

	DECLARE CREATEUSERS CURSOR STATIC

		FOR SELECT name
		FROM sys.databases
		WHERE name NOT IN ('master', 'model', 'msdb', 'tempdb', 'SF_SQL_Admin');

		OPEN CREATEUSERS

		FETCH FIRST FROM CREATEUSERS INTO @dbname

		WHILE @@FETCH_STATUS = 0 
		BEGIN

			--App Admin
			IF @AppAdminExists = 1
			BEGIN
				select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
							'IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = ''' + @AppAdmin + ''')' + CHAR(13) + CHAR(10) +
							CHAR(9) + 'CREATE USER [' + @AppAdmin + '] FOR LOGIN  [' + @AppAdmin + ']'
				EXEC sp_executesql @cmd
				Print @cmd
			END

			--App Acct
			IF @AppAcctExists = 1
			BEGIN
				select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
							'IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = ''' + @AppAcct + ''')' + CHAR(13) + CHAR(10) +
							CHAR(9) + 'CREATE USER [' + @AppAcct + '] FOR LOGIN  [' + @AppAcct + ']'
				EXEC sp_executesql @cmd
				Print @cmd
			END

			--Data Admin
			IF @DataAdminExists = 1
			BEGIN
				select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
							'IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = ''' + @DataAdmin + ''')' + CHAR(13) + CHAR(10) +
							CHAR(9) + 'CREATE USER [' + @DataAdmin + '] FOR LOGIN  [' + @DataAdmin + ']'
				EXEC sp_executesql @cmd
				Print @cmd
			END

			--RPT
			IF @ReportUserExists = 1
			BEGIN
				select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
							'IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = ''' + @ReportUser + ''')' + CHAR(13) + CHAR(10) +
							CHAR(9) + 'CREATE USER [' + @ReportUser + '] FOR LOGIN  [' + @ReportUser + ']'
				EXEC sp_executesql @cmd
				Print @cmd
			END

			--Temp Admin
			IF @IsSharedServer = 1
			BEGIN
				IF @TempAdminExists = 1
				BEGIN
					select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
								'IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = ''' + @TempAdmin + ''')' + CHAR(13) + CHAR(10) +
								CHAR(9) + 'CREATE USER [' + @TempAdmin + '] FOR LOGIN  [' + @TempAdmin + ']'
					EXEC sp_executesql @cmd
					Print @cmd
				END
			END

		FETCH NEXT FROM CREATEUSERS INTO @dbname
		END

		CLOSE CREATEUSERS

		DEALLOCATE CREATEUSERS;

	END

	-- Create users for only one DB
	IF @DBName <> 'ALL'
	BEGIN
		-- Validate if database exists if attempting to create
		IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = @DBName)
		BEGIN
			RAISERROR ('DATABASE %s does not exist!!', 15, 1, @DBName)
		END
		PRINT '-------------------------'
		PRINT '--CREATE DATABASE USERS--'
		PRINT '-------------------------'
	
		--App Admin
		IF @AppAdminExists = 1
		BEGIN
			select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
						'IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = ''' + @AppAdmin + ''')' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'CREATE USER [' + @AppAdmin + '] FOR LOGIN  [' + @AppAdmin + ']'
			EXEC sp_executesql @cmd
			Print @cmd
		END

		--App Acct
		IF @AppAcctExists = 1
		BEGIN
			select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
						'IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = ''' + @AppAcct + ''')' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'CREATE USER [' + @AppAcct + '] FOR LOGIN  [' + @AppAcct + ']'
			EXEC sp_executesql @cmd
			Print @cmd
		END

		--Data Admin
		IF @DataAdminExists = 1
		BEGIN
			select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
						'IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = ''' + @DataAdmin + ''')' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'CREATE USER [' + @DataAdmin + '] FOR LOGIN  [' + @DataAdmin + ']'
			EXEC sp_executesql @cmd
			Print @cmd
		END

		--RPT
		IF @ReportUserExists = 1
		BEGIN
			select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
						'IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = ''' + @ReportUser + ''')' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'CREATE USER [' + @ReportUser + '] FOR LOGIN  [' + @ReportUser + ']'
			EXEC sp_executesql @cmd
			Print @cmd
		END

		--Temp Admin
		IF @IsSharedServer = 1
		BEGIN
			IF @TempAdminExists = 1
			BEGIN
				select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
							'IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = ''' + @TempAdmin + ''')' + CHAR(13) + CHAR(10) +
							CHAR(9) + 'CREATE USER [' + @TempAdmin + '] FOR LOGIN  [' + @TempAdmin + ']'
				EXEC sp_executesql @cmd
				Print @cmd
			END
		END

		PRINT ''

		-- Validate if database exists if attempting to create
		IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = @DBName)
		BEGIN
			RAISERROR ('DATABASE %s does not exist!!', 15, 1, @DBName)
		END
	END

	GRANT_SERVER_PERMISSIONS:
	/***********************
	** Grant Permissions  **
	***********************/
	PRINT '-------------------------------'		
	PRINT '--GRANTING SERVER PERMISSIONS--'
	PRINT '-------------------------------'

	-- Bulk Admin to App Admin 
	IF @AppAdminExists = 1
	BEGIN
		select @cmd = 'EXEC master..sp_addsrvrolemember @rolename = N''bulkadmin'', @loginame = ''' + @AppAdmin + ''''
		EXEC sp_executesql @cmd
		Print @cmd
	END
	
	-- Bulk Admin to App Acct 
	IF @AppAcctExists =1
	BEGIN
		select @cmd = 'EXEC master..sp_addsrvrolemember @rolename = N''bulkadmin'', @loginame = ''' + @AppAcct + ''''
		EXEC sp_executesql @cmd
		Print @cmd
	END

	-- Bulk Admin to Data Admin 
	IF @DataAdminExists = 1
	BEGIN
		select @cmd = 'EXEC master..sp_addsrvrolemember @rolename = N''bulkadmin'', @loginame = ''' + @DataAdmin + ''''
		EXEC sp_executesql @cmd
		Print @cmd
	END

	--If dedicated server, grant server level permissions to App Admin and Temp Admin logins
	IF @IsSharedServer = 0
	BEGIN

		-- TempAdmin
		IF @TempAdminExists = 1
		BEGIN
			select @cmd = 'EXEC master..sp_addsrvrolemember @rolename = N''sysadmin'', @loginame = ''' + @TempAdmin + ''''
			EXEC sp_executesql @cmd
			Print @cmd
		END
		
		IF @AppAdminExists = 1
		BEGIN
			select @cmd = 'USE master' + CHAR(13) + CHAR(10) +
					CHAR(9) + 'GRANT VIEW SERVER STATE TO [' + @AppAdmin + ']'
			EXEC sp_executesql @cmd
			Print @cmd
		END

	END
	PRINT ''



	GRANT_DB_PERMISSIONS:
	IF @OnlyServerLevelPermissions = 1
	BEGIN
		GOTO PROC_EXIT
	END
	
	IF @DBName <> 'ALL'
	BEGIN 
		PRINT '---------------------------------'		
		PRINT '--GRANTING DATABASE PERMISSIONS--'
		PRINT '---------------------------------'		
		-- App Admin
		If @Domain = 'UNTOPR'
		BEGIN
			IF @AppAdminExists = 1
			BEGIN
				select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
							' exec sp_addrolemember ''db_owner'', ''' + @AppAdmin + ''''
				EXEC sp_executesql @cmd
				Print @cmd
			END
		END
		ELSE
		BEGIN
			IF (@AppAdminExists = 1)
			BEGIN
				select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datareader'', ''' + @AppAdmin + '''' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datawriter'', ''' + @AppAdmin + '''' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT EXECUTE TO [' + @AppAdmin + ']'  + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT VIEW DEFINITION TO [' + @AppAdmin + ']'  + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT SHOWPLAN TO [' + @AppAdmin + ']'  + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT VIEW DATABASE STATE TO [' + @AppAdmin + ']'
				EXEC sp_executesql @cmd
				Print @cmd
			END 
		END

		-- App Acct
		IF (@AppAcctExists = 1)
		BEGIN
			select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datareader'', ''' + @AppAcct + '''' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datawriter'', ''' + @AppAcct + '''' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT EXECUTE TO [' + @AppAcct + ']'
			EXEC sp_executesql @cmd
			Print @cmd
		END
		
		-- Data Admin
		IF @DataAdminExists = 1
		BEGIN
			select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datareader'', ''' + @DataAdmin + '''' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datawriter'', ''' + @DataAdmin + ''''  + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT VIEW Definition TO [' + @DataAdmin + ']'
			EXEC sp_executesql @cmd
			Print @cmd
		END

		--RPT
		IF @ReportUserExists = 1
		BEGIN
			select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datareader'', ''' + @ReportUser + ''''  + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT VIEW Definition TO [' + @ReportUser + ']'
			EXEC sp_executesql @cmd
			Print @cmd
		END 

		--Temp Admin
		IF @IsSharedServer = 1
		BEGIN
			IF @TempAdminExists = 1
			BEGIN
				select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
							CHAR(9) + 'exec sp_addrolemember ''db_owner'', ''' + @TempAdmin + '''' + CHAR(13) + CHAR(10)
				EXEC sp_executesql @cmd
				Print @cmd
			END
		END
		ELSE
		BEGIN
			IF @TempAdminExists = 1
			BEGIN
				select @cmd = 'USE master' + CHAR(13) + CHAR(10) +
							CHAR(9) + 'EXEC master..sp_addsrvrolemember @rolename = N''sysadmin'', @loginame = ''' + @TempAdmin + ''''
				EXEC sp_executesql @cmd
				Print @cmd
			END
		END
	END

	IF @DBName = 'ALL'
	BEGIN
		
		DECLARE GRANTPERMISSIONS CURSOR STATIC

		FOR SELECT name
		FROM sys.databases
		WHERE name NOT IN ('master', 'model', 'msdb', 'tempdb', 'SF_SQL_Admin');

		OPEN GRANTPERMISSIONS

		FETCH FIRST FROM GRANTPERMISSIONS INTO @DBName

		PRINT '---------------------------------'		
		PRINT '--GRANTING DATABASE PERMISSIONS--'
		PRINT '---------------------------------'	

		WHILE @@FETCH_STATUS = 0
		BEGIN
			
		-- App Admin
		If @Domain = 'UNTOPR'
		BEGIN
			IF @AppAdminExists = 1
			BEGIN
				select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
							' exec sp_addrolemember ''db_owner'', ''' + @AppAdmin + ''''
				EXEC sp_executesql @cmd
				Print @cmd
			END
		END
		ELSE
		BEGIN
			IF (@AppAdminExists = 1)
			BEGIN
				select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datareader'', ''' + @AppAdmin + '''' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datawriter'', ''' + @AppAdmin + '''' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT EXECUTE TO [' + @AppAdmin + ']'  + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT VIEW DEFINITION TO [' + @AppAdmin + ']'  + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT SHOWPLAN TO [' + @AppAdmin + ']'  + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT VIEW DATABASE STATE TO [' + @AppAdmin + ']'
				EXEC sp_executesql @cmd
				Print @cmd
			END 
		END

		-- App Acct
		IF (@AppAcctExists = 1)
		BEGIN
			select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datareader'', ''' + @AppAcct + '''' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datawriter'', ''' + @AppAcct + '''' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT EXECUTE TO [' + @AppAcct + ']'
			EXEC sp_executesql @cmd
			Print @cmd
		END
		
		-- Data Admin
		IF @DataAdminExists = 1
		BEGIN
			select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datareader'', ''' + @DataAdmin + '''' + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datawriter'', ''' + @DataAdmin + ''''  + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT VIEW Definition TO [' + @DataAdmin + ']'
			EXEC sp_executesql @cmd
			Print @cmd
		END

		--RPT
		IF @ReportUserExists = 1
		BEGIN
			select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
						CHAR(9) + 'exec sp_addrolemember ''db_datareader'', ''' + @ReportUser + ''''  + CHAR(13) + CHAR(10) +
						CHAR(9) + 'GRANT VIEW Definition TO [' + @ReportUser + ']'
			EXEC sp_executesql @cmd
			Print @cmd
		END 

		--Temp Admin
		IF @IsSharedServer = 1
		BEGIN
			IF @TempAdminExists = 1
			BEGIN
				select @cmd = 'USE ' + @DBName + CHAR(13) + CHAR(10) +
							CHAR(9) + 'exec sp_addrolemember ''db_owner'', ''' + @TempAdmin + '''' + CHAR(13) + CHAR(10)
				EXEC sp_executesql @cmd
				Print @cmd
			END
		END
		ELSE
		BEGIN
			IF @TempAdminExists = 1
			BEGIN
				select @cmd = 'USE master' + CHAR(13) + CHAR(10) +
							CHAR(9) + 'EXEC master..sp_addsrvrolemember @rolename = N''sysadmin'', @loginame = ''' + @TempAdmin + ''''
				EXEC sp_executesql @cmd
				Print @cmd
			END
		END

		FETCH NEXT FROM GRANTPERMISSIONS INTO @DBName
		END

		CLOSE GRANTPERMISSIONS
		DEALLOCATE GRANTPERMISSIONS

	END

	PRINT ''


END TRY
BEGIN CATCH
	Set @ErrMsg = '!!!ERROR:  ' + ISNULL(ERROR_MESSAGE(), 'UNKNOWN') + '!!!'
	--PRINT @ErrMsg
	RAISERROR (@ErrMsg, 15, 1)
END CATCH

PROC_EXIT:
	PRINT ''


GO


