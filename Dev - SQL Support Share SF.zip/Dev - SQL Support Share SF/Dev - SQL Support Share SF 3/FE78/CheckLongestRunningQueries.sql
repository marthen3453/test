SELECT TOP 10 (total_elapsed_time/execution_count) AS average, max_elapsed_time, execution_count, t.text, p.query_plan
FROM sys.dm_exec_query_stats AS s
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS t
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS p
ORDER BY (total_elapsed_time / execution_count ) DESC

SELECT TOP 10 (total_elapsed_time/execution_count) AS average, max_elapsed_time, execution_count, t.text, p.query_plan
FROM sys.dm_exec_query_stats AS s
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS t
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS p
ORDER BY execution_count DESC