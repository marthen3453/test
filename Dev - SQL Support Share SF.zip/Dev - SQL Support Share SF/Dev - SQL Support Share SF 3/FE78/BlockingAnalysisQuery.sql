-- Returns information about each request that is excuting within SQL Server
SELECT * FROM SYS.dm_exec_requests WHERE session_id = '375'

--Returns 1 row per autheticated session on SQL Server, is a server-scope view that shows information about all acitve user connects and internal tasks
SELECT * fROM sys.dm_exec_sessions WHERE session_id = '375'

--Last request start time for DMV Sessions
SELECT * FROM sys.dm_exec_sessions WHERE session_id IN (SELECT dISTINCT REQUEST_session_id  fROM sys.dm_tran_locks) ORDER BY last_request_start_time asc

--contains information about processes that are running on an instance of SQL Server
SELECT * FROM master.sys.sysprocesses

--Returns information about currently active lock manager resources in SQL Server
--represnts a currently active reqeust to the lock amanger for a lck that has been grated or is waiting to be granted
SELECT * fROM sys.dm_tran_locks WHERE REQUEST_session_id = '375'

--Contains a row for each user-defined, schema-scoped object that is created within a database
SELECT * fROM sys.objects WHERE object_id ='133575514' --take from sys.dm_trans_lock table and under field resource_associated_entity_id

--returns infromation about the connections established to this instance of SQL Server and the details of each connection
SELECT * FROM sys.dm_exec_connections WHERE session_id='375'

--Returns the text of the SQL batch that is identified by the specified sql_handle 
--(Number) comes from sys.dm_exec_connections under field most_recent_SQL_Handle
SELECT * FROM sys.dm_exec_sql_text (0x01000B008D7AA900809B854E010000000000000000000000)
SELECT * FROM sys.dm_exec_sql_text (0x01000B00A494021B10C578F4000000000000000000000000)



--Running sessions and shows blocking
select SUBSTRING(dest.text, (der.statement_start_offset/2)+1, 
        ((CASE der.statement_end_offset 
          WHEN -1 THEN DATALENGTH(dest.text) 
         ELSE der.statement_end_offset 
         END - der.statement_start_offset)/2) + 1) AS statement_text, * from sys.dm_exec_requests as der 
inner join sys.dm_exec_sessions as des on der.session_id = des.session_id 
cross apply sys.dm_exec_sql_text(der.sql_handle) as dest where der.session_id <> @@SPID