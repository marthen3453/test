
select SUBSTRING(dest.text, (der.statement_start_offset/2)+1, 
        ((CASE der.statement_end_offset 
          WHEN -1 THEN DATALENGTH(dest.text) 
         ELSE der.statement_end_offset 
         END - der.statement_start_offset)/2) + 1) AS statement_text, * from sys.dm_exec_requests as der 
inner join sys.dm_exec_sessions as des on der.session_id = des.session_id 
cross apply sys.dm_exec_sql_text(der.sql_handle) as dest where der.session_id <> @@SPID 
