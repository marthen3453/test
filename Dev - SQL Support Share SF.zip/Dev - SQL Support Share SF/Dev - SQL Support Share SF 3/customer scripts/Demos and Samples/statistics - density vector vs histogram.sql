﻿/*create a table with only two distinct values in the 'value' column.  
1 value has 1000 rows.  the other has 10 rows.   
the txt column was just to make the rows spread over enough data pages to make it worth considering an index seek 
instead of a defaulting to a table scan because of the small number of pages involved.*/
use tempdb
create --drop
table uneven_distrib (id int identity(1, 1), value int, txt char(500))
go

insert into uneven_distrib select 1000, '' 
go 1000

insert into uneven_distrib select 10, ''
go 10

insert into uneven_distrib select 1, ''
go 100

insert into uneven_distrib select 2, ''
go 100

/*create an index*/
create index ix1 on uneven_distrib (value)
alter index ix1 on uneven_distrib rebuild

-----------------------------------------------------------------------------------
/* ad hoc queries with literal values */
-------------------------------------------------------------------------------------

/*SQL knows the value of the literal when compiling, and so can use the histogram 
to determine that a seek is appropriate because that specific literal has a 
small enough number of estimated rows to make a seek worthwhile.

the one with 10 rows uses a seek, and the one with 1000 rows uses a scan.  
in both cases, the estimated row count is spot on, because it used the histogram.
use ctrl-L to see the estimated plans. 
*/

select * from uneven_distrib where value = 10
select * from uneven_distrib where value = 1000
select * from uneven_distrib where value = 0

-----------------------------------------------------------------------------------
/* ad hoc queries with parameterized values*/
-------------------------------------------------------------------------------------

/*when declaring a variable first, sql does not use the histogram because it doesn't know the value 
at compile time.  rather, it uses the density vector to generate estimated rows returned. 

 note in the query plan is the estimated row count, which is 505.  this shows that it's using the density vector 
instead of the histogram.  2 distinct values for 1010 rows = estimated 505 rows on average*/
select * from uneven_distrib where value = 10

declare @value int = 10
select * from uneven_distrib where value = @value
go


-----------------------------------------------------------------------------------
/* stored procs can have parameter sniffing */
-------------------------------------------------------------------------------------
if exists (select * from sys.objects where name = 'usp_uneven_distrib' ) drop procedure usp_uneven_distrib
go
create proc usp_uneven_distrib (@value int)
as
select * from uneven_distrib where value = @value
go

/* you get parameter sniffing with a proc*/
declare @proc_value int = 10
exec usp_uneven_distrib @value = @proc_value

declare @proc_value2 int = 1000
exec usp_uneven_distrib @value = @proc_value2
go

-----------------------------------------------------------------------------------
/* Options to address parameter sniffing */
-------------------------------------------------------------------------------------


/* SP_RECOMPILE
   may be a quick fix, but the problem may come back later */
sp_recompile usp_uneven_distrib
go 
declare @proc_value int = 1000
exec usp_uneven_distrib @value = @proc_value
set @proc_value = 10
exec usp_uneven_distrib @value = @proc_value

go

/* WITH RECOMPILE
   avoids parameter sniffing, but increases cpu because of the recompiles.
   may be a good choice for a simple query that compiles quickly, or a proc that is called infrequently */
create proc v4(@value int)
with recompile
as
select * from uneven_distrib where value = @value

/* option (recompile)
   statement-level recompilation.  
   This may be a good choice when 1 statement in a large stored procedure is problematic.  
   much less impactful on CPU in that case. */


create proc v5 (@value int)
as
select * from uneven_distrib where value = @value
option (recompile)
go

/* PUBLIC/PRIVATE VARIABLES
   NOT RECOMMENDED. 
   App developers like creating public and private variables.  but, this is treated 
   the same way as the example above where the variable was declared in the same scope
   as the query.  SQL Server uses the density vector.  
   That may be what you want, but more likely you're getting that result without realizing it.*/

create proc usp_uneven_distrib2 (@value int)
as
declare @inner_value int = @value
select * from uneven_distrib where value = @inner_value
go

/* OPTIMIZE FOR UNKNOWN
   If you want to force the density vector, which is valid in some cases, then 
   be explicit about it.*/

create proc usp_uneven_distrib3 (@value int)
as
select * from uneven_distrib where value = @value
option (optimize for unknown)
go
---------------------------------------------------------------
/* USE IF BLOCKS
   If the data have just a few outliers causing problems (e.g., 1 customer has 40% of the orders in the system), 
   then create an if block and optimize for the outlier value.
   when this approach is used, the estimated plan includes all the different possibilities, 
   and the actual plan varies based on the value of the parameter, without recompiling.
*/
go
create -- drop
proc usp_uneven_distrib5 (@value int)
as
if @value in (10, 20, 30)
begin
select * from uneven_distrib where value = @value
option (optimize for (@value = 10))
end
else if @value = 1000
begin
select * from uneven_distrib where value = @value
option (optimize for (@value = 1000))
end
else 
begin
select * from uneven_distrib where value = @value
option (optimize for unknown)

end


go
/* review the estimated and actual plans */

declare @proc_value int = 10
exec usp_uneven_distrib5 @value = @proc_value
declare @proc_value2 int = 1000
exec usp_uneven_distrib5 @value = @proc_value2
go
　
