create table customers 
(customer_id int
, first_name varchar(100)
, last_name varchar(100)
, creation_datetime datetime
, revision_datetime datetime
, PRIMARY KEY CLUSTERED (CUSTOMER_ID)
)


create table order_type 
(order_type_id int
, order_type_description varchar(50)
, creation_datetime datetime
, revision_datetime datetime
, PRIMARY KEY CLUSTERED (order_type_id)
)

create table order_status_type 
(order_status_type_id int
, order_status_type_description varchar(50)
, creation_datetime datetime
, revision_datetime datetime
, PRIMARY KEY CLUSTERED (order_status_type_id)
)

create table location_type 
(location_type_id int
, location_type_description varchar(50)
, creation_datetime datetime
, revision_datetime datetime
, PRIMARY KEY CLUSTERED (order_status_type_id)
)

create table location
(location_id int
, location_type_id int
, street_nbr varchar(20)
, street_name nvarchar(50)
, city_state_zip_id int
, creation_datetime datetime
, revision_datetime datetime
, PRIMARY KEY CLUSTERED ()
)

create table payment_terms_type
(payment_terms_type_id int
, payment_terms_type_description varchar(50)
, creation_datetime datetime
, revision_datetime datetime
, PRIMARY KEY CLUSTERED (payment_terms_type_id)
)

create table payment_type
( payment_type_id int
, payment_type_description varchar(50)
, creation_datetime datetime
, revision_datetime datetime
, PRIMARY KEY CLUSTERED ()
)

create table payment_status_type
( payment_status_type_id int
, payment_status_type_description varchar(50)
, creation_datetime datetime
, revision_datetime datetime
, PRIMARY KEY CLUSTERED (payment_status_type_id)
)

create table shipment_type
( shipment_type_id int
, shipment_type_description varchar(50)
, creation_datetime datetime
, revision_datetime datetime
, PRIMARY KEY CLUSTERED (shipment_type_id)
)

create table shipment_status_type
( shipment_status_type_id int
,shipment_status_type_description varchar(50)
, creation_datetime datetime
, revision_datetime datetime
, PRIMARY KEY CLUSTERED (shipment_status_type_id)
)

use tempdb
create table orders  --- approx 40 bytes per row
( order_id                int identity(1, 1)
, customer_id             int                                                                                                                   int
, order_datetime          datetime
, order_type_id           int
, order_status_type_id    int
, shipfrom_location_id    int
, shipto_location_id      int
, order_total_pieces      int
, order_total_price       money
, payment_terms_type_id   int
, payment_type_id         int
, payment_status_type_id  int
, shipment_type_id        int
, shipping_company_id     int
, shipoment_datetime      datetime
, shipment_status_type_id int
, delivery_datetime       datetime
)

select o.*
,  ot.order_type_desc
, ost.order_status_type_desc   
, ptt.payment_terms_type_desc  
,  pt.payment_type_desc        
, pst.payment_status_type_desc 
,  st.shipment_type_desc       
, sst.shipment_status_type_desc
from orders                    o
join order_type               ot  on o.order_type            =  ot.order_type                         
join order_status_type       ost  on o.order_status_type     = ost.order_status_type   
join payment_terms_type      ptt  on o.payment_terms_type    = ptt.payment_terms_type  
join payment_type             pt  on o.payment_type          =  pt.payment_type         
join payment_status_type     pst  on o.payment_status_type   = pst.payment_status_type 
join shipment_type            st  on o.shipment_type         =  st.shipment_type       
join shipment_status_type    sst  on o.shipment_status_type  = sst.shipment_status_type
where (payment_status_type_id = @payment_status_type_id    or @payment_status_type_id is null)
and (order_type_id            = @order_type_id             or @order_type_id             is null)
and (order_status_type_id     = @order_status_type_id      or @order_status_type_id      is null)
and (payment_terms_type_id    = @payment_terms_type_id     or @payment_terms_type_id     is null)
and (payment_type_id          = @payment_type_id           or @payment_type_id           is null)
and (shipment_type_id         = @shipment_type_id          or @shipment_type_id          is null)
and (shipment_status_type_id  = @shipment_status_type_id   or @shipment_status_type_id   is null)



/* NEW APPROACH */

/* build type set table for each object.  
   goal is to have a set of data significantly smaller than the original table, 
   so you have to test to see how many combinations you come up with.  add or remove
   new fields as appropriate.

   when app inserts/updates, it calculates a hashed value of the relevant type ids, and checks to 
   see if that combination is in the type_set table.  
         if so, it gets the type_set_id to use during the main table's insert/update. 
         if no, insert type new combination into the type_set table and get the new type_set_id.
   typically, very few inserts after initial implementation.
   typically, if type set entries are relatively small, entries can be cached in the app. 
*/
new order has the following type ids:
order_type_id           = 1        
order_status_type_id    = 1
payment_terms_type_id   = 1
payment_type_id         = 1
payment_status_type_id  = 1
shipment_type_id        = 1
shipment_status_type_id = 1

calculate hash (order_type_id,order_status_type_id....) 

select from order_type_set
where order_type_set_hash = hashed_value

create table order_type_set  -- distinct set of values in use. could do full cross join, but would
                             -- have to maintain it if new values added to underlying type tables
( order_type_set_id         int
, order_type_id             int
, order_status_type_id      int
, payment_terms_type_id     int
, payment_type_id           int
, payment_status_type_id    int
, shipment_type_id          int
, shipment_status_type_id   int
, order_status_type_desc    nvarchar(100)
, payment_terms_type_desc   nvarchar(100)  
, payment_type_desc         nvarchar(100)       
, payment_status_type_desc  nvarchar(100) 
, shipment_type_desc        nvarchar(100)       
, shipment_status_type_desc nvarchar(100)
, order_type_set_hash       binary(8000)-- use hashbytes(cast(order_status_type_id as varchar(10)) + ' | ' + ...
)
/* HASH COLUMN USED BY APP TO FIND VALUE TO USE DURING INSERTS*/ 


create table orders_v2 -- approximately 30 bytes per row.
( order_id             int identity(1, 1)
, customer_id          int  
, order_type_set_id    int
, order_datetime       datetime
, shipfrom_location_id int
, shipto_location_id   int
, order_total_pieces   int
, order_total_price    money
, shipping_company_id  int
, shipment_datetime    datetime
, delivery_datetime    datetime
)

/* benefits - 
smaller row size = more rows per page = reduced IO = more pages in memory
simple indexing strategy.  
   one index on orders table combines 8 different type table values.
   type set can be indexed intensely because of small number of rows.
   or
   type set may not need any indexing at all if small enough.  index scan may be good.
reduced number of joins to support type table descriptions. 
consistent query plan implementation - less likely to get table scans from complex
   where clauses.  put the complex where clause on the type set table with small number of rows.
*/

/* example select */
declare @payment_status_type_id  int
declare @order_type_id           int
declare @order_status_type_id    int
declare @payment_terms_type_id   int
declare @payment_type_id         int
declare @shipment_type_id        int
declare @shipment_status_type_id int

select *
into #order_type_set_ids
from order_type_set
where (payment_status_type_id = @payment_status_type_id    or @payment_status_type_id is null)
and (order_type_id            = @order_type_id             or @order_type_id             is null)
and (order_status_type_id     = @order_status_type_id      or @order_status_type_id      is null)
and (payment_terms_type_id    = @payment_terms_type_id     or @payment_terms_type_id     is null)
and (payment_type_id          = @payment_type_id           or @payment_type_id           is null)
and (shipment_type_id         = @shipment_type_id          or @shipment_type_id          is null)
and (shipment_status_type_id  = @shipment_status_type_id   or @shipment_status_type_id   is null)


select o.*
, order_status_type_desc   
, payment_terms_type_desc  
, payment_type_desc        
, payment_status_type_desc 
, shipment_type_desc       
, shipment_status_type_desc
from orders_v2 o
join #order_type_set_ids ots on ots.order_type_set_id = o.order_type_set_id





