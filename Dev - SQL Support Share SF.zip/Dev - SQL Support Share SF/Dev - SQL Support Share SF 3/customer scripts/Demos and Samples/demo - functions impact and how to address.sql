set statistics io, time off

if exists (select * from sys.objects where name = 'pto_fn_get_product_count')
drop function dbo.pto_fn_get_product_count

go

create function dbo.pto_fn_get_product_count (@productid int)
returns int
as
begin
declare @productcount int
select @productcount =  count(*) 
from bigTransactionHistory 
where productid = @productid

return @productcount
end

go

IF OBJECT_ID(N'TEMPDB..#transactions') IS NOT NULL DROP TABLE #transactions

select top 5000 *
into #transactions
from bigtransactionhistory
where transactiondate between '12/1/08' and '12/1/12'


set statistics io, time on

/* call function 5000 times */

--select top 5000 *
--, dbo.pto_fn_get_product_count(productid)
--from #transactions


--/* call functions only as often as necessary*/

IF OBJECT_ID(N'TEMPDB..#trans') IS NOT NULL DROP TABLE #trans
IF OBJECT_ID(N'TEMPDB..#productcount') IS NOT NULL DROP TABLE #productcount


select productid, count(*) as productCount
into #productcount
from bigTransactionHistory
where productid in (select distinct productid from #transactions)
group by productid


select t.*, pc.productCount
from #transactions t
join #productcount pc on pc.productid = t.ProductID