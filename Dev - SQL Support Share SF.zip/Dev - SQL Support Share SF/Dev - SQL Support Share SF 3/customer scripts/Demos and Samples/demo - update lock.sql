USE tempdb

IF (SELECT OBJECT_ID('dbo.t1')
 ) IS NOT NULL
DROP TABLE dbo.t1
GO
CREATE TABLE dbo.t1
 (c1 INT
 ,c2 INT
 ,c3 DATETIME)

-- Inserting Dummy Records in the table create above

INSERT INTO dbo.t1
VALUES (11, 12, GETDATE())
INSERT INTO dbo.t1
VALUES (21, 22, GETDATE())

-- Now close all other connection and open a new connection

BEGIN TRAN T1
UPDATE t1
SET c3=GETDATE()

-- Open second connection in SSMS and paste the below query

BEGIN TRAN T2
UPDATE t1
SET c3=GETDATE()

-- Go to the first connection and paste the below query and execute it:
--Note the U lock with the status of WAIT for a KEY, with the same resource description 
--as a KEY lock that the first connection has  been GRANTED. Now COMMIT or ROLLBACK the first connection,  and you should see the second connection will get the X lock on the KEY it is waiting for, plus the X lock on the other KEY.

SELECT request_session_id AS session_id, DB_NAME(resource_database_id) AS [database],
 request_mode , resource_type ,
 resource_associated_entity_id,
 resource_description, request_status
FROM sys.dm_tran_locks;







