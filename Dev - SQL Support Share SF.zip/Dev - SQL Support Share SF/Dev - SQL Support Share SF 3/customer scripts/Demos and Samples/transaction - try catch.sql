CREATE PROCEDURE [dbo].[orthogonal]
AS
BEGIN
    SET NOCOUNT ON
    declare @procname sysname = QUOTENAME(OBJECT_NAME(@@PROCID)), @msg nvarchar(1024)
    
    set @msg = @procname + ' started...'
    print @msg

    BEGIN TRY

        declare @begincount int = @@TRANCOUNT
        if (@begincount = 0)
            BEGIN TRAN

        /* Do your work */

        if (@begincount = 0)
            COMMIT TRAN
    END TRY
    BEGIN CATCH
    SELECT 
        ERROR_NUMBER() AS ErrorNumber,
        ERROR_SEVERITY() AS ErrorSeverity,
        ERROR_STATE() as ErrorState,
        ERROR_PROCEDURE() as ErrorProcedure,
        ERROR_LINE() as ErrorLine,
        ERROR_MESSAGE() as ErrorMessage;

        if (XACT_STATE() <> 0 and @begincount = 0)
            ROLLBACK TRAN;
--   -1 = uncommittable - must roll back. 
--    0 = no active user transaction
--    1 = there's an active transaction
        THROW;

    END CATCH

    set @msg = @procname + ' ended.'
    print @msg

END

/* from books online:

�A TRY block must be immediately followed by a CATCH block.


�TRY�CATCH constructs can be nested. This means that TRY�CATCH constructs can be placed inside other TRY and CATCH blocks. 
When an error occurs within a nested TRY block, program control is transferred to the CATCH block that is associated with the nested TRY block.


�To handle an error that occurs within a given CATCH block, write a TRY�...CATCH block within the specified CATCH block.


�Errors that have a severity of 20 or higher that cause the Database Engine to close the connection will not be handled by the 
TRY�CATCH block. However, TRY�CATCH will handle errors with a severity of 20 or higher as long as the connection is not closed.


�Errors that have a severity of 10 or lower are considered warnings or informational messages, and are not handled by TRY�CATCH blocks. 


�Attentions will terminate a batch even if the batch is within the scope of a TRY�CATCH construct. This includes an attention sent 
by the Microsoft Distributed Transaction Coordinator (MS DTC) when a distributed transaction fails. MS DTC manages distributed transactions.

If a distributed transaction executes within the scope of a TRY block and an error occurs, execution is transferred to the associated CATCH 
block. The distributed transaction enters an uncommittable state. Execution within the CATCH block may be interrupted by the Microsoft 
Distributed Transaction Coordinator which manages distributed transactions. When the error occurs, MS DTC asynchronously notifies all servers 
participating in the distributed transaction, and terminates all tasks involved in the distributed transaction. This notification is sent in 
the form of an attention, which is not handled by a TRY�CATCH construct, and the batch is ended. When a batch finishes running, the Database 
Engine rolls back any active uncommittable transactions. If no error message was sent when the transaction entered an uncommittable state, 
when the batch finishes, an error message will be sent to the client application that indicates an uncommittable transaction was detected 
and rolled back For more information about distributed transactions, see Distributed Transactions (Database Engine).


Compile and Statement-level Recompile Errors


There are two types of errors that will not be handled by TRY�CATCH if the error occurs in the same execution level as the TRY�CATCH construct:

�Compile errors, such as syntax errors that prevent a batch from executing.


�Errors that occur during statement-level recompilation, such as object name resolution errors that happen after compilation due to deferred name resolution.


When the batch, stored procedure, or trigger that contains the TRY�CATCH construct generates one of these errors, the TRY�CATCH construct does
 not handle these errors. These errors will return to the application or batch that called the error-generating routine. For example, the following 
code example shows a SELECT statement that causes a syntax error. If this code is executed in the SQL Server Management Studio Query Editor, execution 
will not start because the batch fails to compile. The error will be returned to the Query Editor and will not get caught by TRY�CATCH.

USE Adventureworks2014;
GO

BEGIN TRY
    -- This PRINT statement will not run because the batch
    -- does not begin execution.
    PRINT N'Starting execution';

    -- This SELECT statement contains a syntax error that
    -- stops the batch from compiling successfully.
    SELECT ** FROM HumanResources.Employee;
END TRY
BEGIN CATCH
    SELECT 
        ERROR_NUMBER() AS ErrorNumber,
        ERROR_MESSAGE() AS ErrorMessage;
END CATCH;
GO
Unlike the syntax error in the previous example, an error that occurs during statement-level recompilation will not prevent the batch from 
compiling, but it will terminate the batch as soon as recompilation for the statement fails. For example, if a batch has two statements and
 the second statement references a table that does not exist, deferred name resolution causes the batch to compile successfully and start
 execution without binding the missing table to the query plan until that statement is recompiled. The batch stops running when it gets to
 the statement that references the missing table and returns an error. This type of error will not be handled by a TRY�CATCH construct at
 the same level of execution at which the error occurred. The following example demonstrates this behavior.




USE Adventureworks2014;
GO

BEGIN TRY
    -- This PRINT statement will run because the error
    -- occurs at the SELECT statement.
    PRINT N'Starting execution';

    -- This SELECT statement will generate an object name
    -- resolution error because the table does not exist.
    SELECT * FROM NonExistentTable;
END TRY
BEGIN CATCH
    SELECT 
        ERROR_NUMBER() AS ErrorNumber,
        ERROR_MESSAGE() AS ErrorMessage;
END CATCH;
GO

You can use TRY�CATCH to handle errors that occur during compilation or statement-level recompilation by executing the error-generating code 
in a separate batch within the TRY block. For example, you do this by placing the code in a stored procedure or by executing a dynamic
 Transact-SQL statement using sp_executesql. This allows TRY�CATCH to catch the error at a higher level of execution than the error occurrence.
 For example, the following code shows a stored procedure that generates an object name resolution error. The batch that contains the 
TRY�CATCH construct is executing at a higher level than the stored procedure; and the error, which occurs at a lower level, is caught.







Copy


USE Adventureworks2014;
GO

-- Verify that the stored procedure does not already exist.
IF OBJECT_ID ('usp_MyError', 'P') IS NOT NULL
    DROP PROCEDURE usp_MyError;
GO

CREATE PROCEDURE usp_MyError
AS
    -- This SELECT statement will generate
    -- an object name resolution error.
    SELECT * FROM NonExistentTable;
GO

BEGIN TRY
    -- Run the stored procedure.
    EXECUTE usp_MyError;
END TRY
BEGIN CATCH
    SELECT 
        ERROR_NUMBER() AS ErrorNumber,
        ERROR_MESSAGE() AS ErrorMessage;
END CATCH;
GO


Uncommittable Transactions


Inside a TRY�CATCH construct, transactions can enter a state in which the transaction remains open but cannot be committed. 
The transaction cannot perform any action that would generate a write to the transaction log, such as modifying data or trying to 
roll back to a savepoint. However, in this state, the locks acquired by the transaction are maintained, and the connection is also
 kept open. The effects of the transaction are not reversed until a ROLLBACK statement is issued, or until the batch ends and the 
transaction is automatically rolled back by the Database Engine. If no error message was sent when the transaction entered an uncommittable 
state, when the batch finishes, an error message will be sent to the client application that indicates an uncommittable transaction
 was detected and rolled back.

A transaction enters an uncommittable state inside a TRY block when an error occurs that would otherwise have ended the transaction.
 For example, most errors from a data definition language (DDL) statement (such as CREATE TABLE), or most errors that occur when SET
 XACT_ABORT is set to ON, terminate the transaction outside a TRY block but make a transaction uncommittable inside a TRY block.

The code in a CATCH block should test for the state of a transaction by using the XACT_STATE function. XACT_STATE returns a -1 if the 
session has an uncommittable transaction. The CATCH block must not perform any actions that would generate writes to the log if XACT_STATE 
returns a -1. The following code example generates an error from a DDL statement and uses XACT_STATE to test the state of a transaction in 
order to take the most appropriate action.

-- Verify that the table does not exist.
IF OBJECT_ID (N'my_books', N'U') IS NOT NULL
    DROP TABLE my_books;
GO

-- Create table my_books.
CREATE TABLE my_books
    (
    Isbn        int PRIMARY KEY,
    Title       NVARCHAR(100)
    );
GO

BEGIN TRY
    BEGIN TRANSACTION;
        -- This statement will generate an error because the 
        -- column author does not exist in the table.
        ALTER TABLE my_books
            DROP COLUMN author;
    -- If the DDL statement succeeds, commit the transaction.
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    SELECT
        ERROR_NUMBER() as ErrorNumber,
        ERROR_MESSAGE() as ErrorMessage;

    -- Test XACT_STATE for 1 or -1.
    -- XACT_STATE = 0 means there is no transaction and
    -- a commit or rollback operation would generate an error.

    -- Test whether the transaction is uncommittable.
    IF (XACT_STATE()) = -1
    BEGIN
        PRINT
            N'The transaction is in an uncommittable state. ' +
            'Rolling back transaction.'
        ROLLBACK TRANSACTION;
    END;

    -- Test whether the transaction is active and valid.
    IF (XACT_STATE()) = 1
    BEGIN
        PRINT
            N'The transaction is committable. ' +
            'Committing transaction.'
        COMMIT TRANSACTION;   
    END;
END CATCH;
GO

USE Adventureworks2014;
GO

-- Verify that the table does not exist.
IF OBJECT_ID (N'my_sales',N'U') IS NOT NULL
    DROP TABLE my_sales;
GO

-- Create and populate the table for deadlock simulation.
CREATE TABLE my_sales 
    (
    Itemid       INT PRIMARY KEY,
    Sales        INT not null
    );
GO

INSERT my_sales (itemid, sales) VALUES (1, 1);
INSERT my_sales (itemid, sales) VALUES (2, 1);
GO
  
-- Verify that the stored procedure for error printing
-- does not exist.
IF OBJECT_ID (N'usp_MyErrorLog',N'P') IS NOT NULL
    DROP PROCEDURE usp_MyErrorLog;
GO

-- Create a stored procedure for printing error information.
CREATE PROCEDURE usp_MyErrorLog
AS
    PRINT 
        'Error ' + CONVERT(VARCHAR(50), ERROR_NUMBER()) +
        ', Severity ' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) +
        ', State ' + CONVERT(VARCHAR(5), ERROR_STATE()) + 
        ', Line ' + CONVERT(VARCHAR(5), ERROR_LINE());
    PRINT 
        ERROR_MESSAGE();
GO


The following code scripts for session 1 and session 2 run simultaneously in two separate SQL Server Management Studio connections. 
Both sessions try to update the same rows in the table. One of the sessions will succeed with the update operation during the first 
attempt, and the other session will be selected as the deadlock victim. The deadlock victim error will cause execution to jump to the 
CATCH block and the transaction will enter an uncommittable state. Inside the CATCH block, the deadlock victim can roll back the 
transaction and retry updating the table until the update succeeds or the retry limit is reached, whichever happens first.

USE Adventureworks2014;
GO

-- Declare and set variable
-- to track number of retries
-- to try before exiting.
DECLARE @retry INT;
SET @retry = 5;

-- Keep trying to update 
-- table if this task is 
-- selected as the deadlock 
-- victim.
WHILE (@retry > 0)
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;
    
        UPDATE my_sales
        SET sales = sales + 1
        WHERE itemid = 1;

        WAITFOR DELAY '00:00:13';
    
        UPDATE my_sales
        SET sales = sales + 1
        WHERE itemid = 2;

        SET @retry = 0;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH 
        -- Check error number.
        -- If deadlock victim error,
        -- then reduce retry count
        -- for next update retry. 
        -- If some other error
        -- occurred, then exit
        -- retry WHILE loop.
        IF (ERROR_NUMBER() = 1205)
            SET @retry = @retry - 1;
        ELSE
            SET @retry = -1;

        -- Print error information.
        EXECUTE usp_MyErrorLog;
  
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;
    END CATCH;
END; -- End WHILE loop.
GO
USE Adventureworks2014;
GO

-- Declare and set variable
-- to track number of retries
-- to try before exiting.
DECLARE @retry INT;
SET @retry = 5;

--Keep trying to update 
-- table if this task is 
-- selected as the deadlock 
-- victim.
WHILE (@retry > 0)
BEGIN
    BEGIN TRY
       BEGIN TRANSACTION;
    
        UPDATE my_sales
        SET sales = sales + 1
        WHERE itemid = 2;

        WAITFOR DELAY '00:00:07';
    
        UPDATE my_sales
        SET sales = sales + 1
        WHERE itemid = 1;

        SET @retry = 0;

        COMMIT TRANSACTION;
    END TRY

    BEGIN CATCH 
        -- Check error number.
        -- If deadlock victim error,
        -- then reduce retry count
        -- for next update retry. 
        -- If some other error
        -- occurred, then exit
        -- retry WHILE loop.
        IF (ERROR_NUMBER() = 1205)
            SET @retry = @retry - 1;
        ELSE
            SET @retry = -1;

        -- Print error information.
        EXECUTE usp_MyErrorLog;
  
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;
    END CATCH;
END; -- End WHILE loop.
GO


The Adventureworks2014 sample database includes an error-handling solution designed to log information about errors that are caught
by the CATCH block of a TRY�CATCH construct that can later be queried or analyzed.

dbo.ErrorLog Table


The ErrorLog table records information about an error number, error severity, error state, name of the stored procedure or trigger 
where the error occurred, line number at which the error occurred, and the complete text of the error message. It also records the date
 and time at which the error occurred, and the user name which executed the error-generating routine. This table is populated when the 
stored procedure uspLogError is executed in the scope of the CATCH block of a TRY�CATCH construct.

dbo.uspLogError


The stored procedure uspLogError logs error information in the ErrorLog table about the error that caused execution to transfer to the 
CATCH block of a TRY�CATCH construct. For uspLogError to insert error information into the ErrorLog table, the following conditions must exist:

�uspLogError is executed within the scope of a CATCH block.


�If the current transaction is in an uncommittable state, the transaction is rolled back before executing uspLogError.


The output parameter @ErrorLogID of uspLogError returns the ErrorLogID of the row inserted by uspLogError into the ErrorLog table. 
The default value of @ErrorLogID is 0. The following example shows the code for uspLogError. 

CREATE PROCEDURE [dbo].[uspLogError] 
    @ErrorLogID [int] = 0 OUTPUT  -- Contains the ErrorLogID of the row inserted
                                  -- by uspLogError in the ErrorLog table.

AS
BEGIN
    SET NOCOUNT ON;

    -- Output parameter value of 0 indicates that error 
    -- information was not logged.
    SET @ErrorLogID = 0;

    BEGIN TRY
        -- Return if there is no error information to log.
        IF ERROR_NUMBER() IS NULL
            RETURN;

        -- Return if inside an uncommittable transaction.
        -- Data insertion/modification is not allowed when 
        -- a transaction is in an uncommittable state.
        IF XACT_STATE() = -1
        BEGIN
            PRINT 'Cannot log error since the current transaction is in an uncommittable state. ' 
                + 'Rollback the transaction before executing uspLogError in order to successfully log error information.';
            RETURN;
        END;

        INSERT [dbo].[ErrorLog] 
            (
            [UserName], 
            [ErrorNumber], 
            [ErrorSeverity], 
            [ErrorState], 
            [ErrorProcedure], 
            [ErrorLine], 
            [ErrorMessage]
            ) 
        VALUES 
            (
            CONVERT(sysname, CURRENT_USER), 
            ERROR_NUMBER(),
            ERROR_SEVERITY(),
            ERROR_STATE(),
            ERROR_PROCEDURE(),
            ERROR_LINE(),
            ERROR_MESSAGE()
            );

        -- Pass back the ErrorLogID of the row inserted
        SELECT @ErrorLogID = @@IDENTITY;
    END TRY
    BEGIN CATCH
        PRINT 'An error occurred in stored procedure uspLogError: ';
        EXECUTE [dbo].[uspPrintError];
        RETURN -1;
    END CATCH
END; 










