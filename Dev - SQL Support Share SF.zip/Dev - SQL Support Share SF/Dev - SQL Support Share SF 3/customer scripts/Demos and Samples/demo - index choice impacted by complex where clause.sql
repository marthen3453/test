declare @Productnumber varchar(100) = 'HT-2981-42000'
declare @productid int = null
declare @dt datetime = null
declare @transid int = null

select *
from bigTransactionHistory
where (@Productnumber is null or productnumber = @Productnumber)
and (@productid is null or productid = @Productid)
and (@dt is null or transactiondate = @dt)
and (@transid is null or transactionid = @transid)


declare @Productnumber nvarchar(100) = 'HT-2981-42000'
select *
from bigTransactionHistory
where productnumber = @productnumber





























create table #ids (int)
if "any high cardinality filters are applied"
begin
      if @productnumber is not null
         begin
            select transactionid
            into #ids
            from bigTransactionHistory
            where productnumber= @Productnumber
         end
      if @productid is not null
          begin
            select transactionid
            into #ids
            from bigTransactionHistory
            where productid= @Productid
         end  

      select t.*
      from bigTransactionHistory t
      join #ids i on i.transactionid = t.transactionid
      where (@Productnumber is null or productnumber = @Productnumber)
      and (@productid is null or productid = @Productid)
      and (@dt is null or transactiondate = @dt)
      and (@transid is null or transactionid = @transid)
end -- if "any high cardinality filters are applied"

else -- no high cardinality filters
   begin
      select *
      from bigTransactionHistory
      where 
      and (@dt is null or transactiondate = @dt)
      and (@transid is null or transactionid = @transid)
   end

