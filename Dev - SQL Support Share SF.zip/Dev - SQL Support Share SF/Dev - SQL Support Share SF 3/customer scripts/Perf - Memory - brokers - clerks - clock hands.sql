-- View the current state of the memory brokers
-- Note the current memory, the predicted future memory, the target memory and whether the memory is growing, shrinking or stable

SELECT p.name AS resource_governor_pool_name, b.memory_broker_type
	, b.allocations_kb AS current_memory_allocated_kb
	, b.allocations_kb_per_sec AS allocation_rate_in_kb_per_sec
	, b.future_allocations_kb AS near_future_allocations_kb
	, b.target_allocations_kb
	, b.last_notification AS last_memory_notification
FROM sys.dm_os_memory_brokers b
INNER JOIN sys.resource_governor_resource_pools p ON p.pool_id = b.pool_id


/* memory clerks to get finer grain breakdown of memory use*/

SELECT type, name, memory_node_id
	, sum(pages_kb 
		+ virtual_memory_reserved_kb 
		+ virtual_memory_committed_kb 
		+ awe_allocated_kb 
		+ shared_memory_reserved_kb 
		+ shared_memory_committed_kb) AS TotalKB
FROM sys.dm_os_memory_clerks
GROUP BY type, name, memory_node_id
ORDER BY TotalKB DESC

/* clock hands show whether pages are flushed because of internal or external (OS) pressure */
select * 
from sys.dm_os_memory_cache_clock_hands
order by removed_all_rounds_count desc




