select t.transaction_begin_time
, datediff(minute, t.transaction_begin_time, getdate()) as transaction_minutes
, st.session_id
, s.status
, s.database_id
,  db_name(s.database_id) as database_name
   ,case when r.session_id is null then 'N/A - no active request' 
         else
       (SELECT TOP 1 SUBSTRING(s2.text,statement_start_offset / 2+1 , 
         ( (CASE WHEN statement_end_offset = -1 
            THEN (LEN(CONVERT(nvarchar(max),s2.text)) * 2) 
            ELSE statement_end_offset END)  - statement_start_offset) / 2+1)) end AS sql_statement
from sys.dm_tran_active_transactions           t
join sys.dm_tran_session_transactions         st on st.transaction_id = t.transaction_id
join sys.dm_exec_sessions                      s on s.session_id = st.session_id
left join sys.dm_exec_requests                 r on r.session_id = s.session_id
outer APPLY SYS.DM_EXEC_SQL_TEXT (SQL_HANDLE) S2
order by db_name(s.database_id)
, t.transaction_begin_time desc


DBCC OPENTRAN