--use @db_name

--EXEC sys.sp_addextendedproperty 
--@name = N'ApplicationOwner', 
--@value = N'Faisal Mohammed';
--GO

--EXEC sys.sp_addextendedproperty 
--@name = N'ApplicationSupported', 
--@value = N'Sharepoint';
--GO


create table #db (id int, name sysname, row_num int)
insert into #db 
select database_id, name, row_number() over(order by name)
from sys.databases
where state_desc = 'online'

create table ##properties (db_name sysname, property_name sysname, property_value sql_variant)


declare @counter int = 1
declare @Max_counter int
select @max_counter = max(row_num) from #db
declare @db_name sysname
declare @sql_text nvarchar(1000)

while @counter <= @max_counter
begin

   select @db_name = quotename(name) from #db where row_num = @counter

   set @sql_text = '
   use @db_name

   insert into ##properties
      select db_name() as db_name, p.name property_name, p.value
      from sys.extended_properties p
      where class_desc = ''database''
   '

   set @sql_text = replace(@sql_text, '@db_name', @db_name)
print @sql_text
   exec (@sql_text)

   set @counter = @counter + 1
end

--select * from ##properties

select serverproperty('ServerName') as server_name, name
, coalesce((select property_value from ##properties p where p.property_name = 'applicationowner' and p.db_name = db.name), '') as Application_Owner
, coalesce((select property_value from ##properties p where p.property_name = 'applicationsupported' and p.db_name = db.name), '')  as Application_Supported
from #db db

drop table #db
drop table ##properties
