USE [msdb]
GO

SELECT 
	CONVERT(VARCHAR(10), Report_Time, 101) AS ReportDate
,	1440 - COUNT(*) AS MinutesNotMonitored
--,	COUNT(*) AS AvailabilityCount
  FROM [dbo].[SQLPIG_Processor_Usage_SF]
WHERE
	CONVERT(VARCHAR(10), Report_Time, 101) != CONVERT(VARCHAR(10), GETDATE(), 101)
	AND
	CONVERT(VARCHAR(10), Report_Time, 101) != (SELECT CONVERT(VARCHAR(10), MIN(CONVERT(DATETIME, CONVERT(VARCHAR(10), Report_Time, 101))), 101) FROM [dbo].[SQLPIG_Processor_Usage_SF])
GROUP BY
	CONVERT(VARCHAR(10), Report_Time, 101)
HAVING
	COUNT(*) < 1440
ORDER BY
	CONVERT(DATETIME, CONVERT(VARCHAR(10), Report_Time, 101))

SELECT 
	CONVERT(DATETIME, CONVERT(VARCHAR(10), Report_Time, 101)) AS ReportDate
--,	1440 - COUNT(*) AS MinutesNotMonitored
,	COUNT(*) AS AvailabilityCount
INTO #AvailCalc
FROM [dbo].[SQLPIG_Processor_Usage_SF]
WHERE
	CONVERT(VARCHAR(10), Report_Time, 101) != CONVERT(VARCHAR(10), GETDATE(), 101)
	AND
	CONVERT(VARCHAR(10), Report_Time, 101) != (SELECT CONVERT(VARCHAR(10), MIN(CONVERT(DATETIME, CONVERT(VARCHAR(10), Report_Time, 101))), 101) FROM [dbo].[SQLPIG_Processor_Usage_SF])
GROUP BY
	CONVERT(VARCHAR(10), Report_Time, 101)
ORDER BY
	CONVERT(DATETIME, CONVERT(VARCHAR(10), Report_Time, 101))

SELECT
	CONVERT(VARCHAR(10), MIN(ReportDate), 101) AS DateFrom
,	CONVERT(VARCHAR(10), MAX(ReportDate), 101) AS DateTo
,	SUM(AvailabilityCount) AS SumAvailCount
,	COUNT(*) AS NumDays
,	CONVERT(decimal(10,4), (CONVERT(decimal(10,4), SUM(AvailabilityCount))/CONVERT(decimal(10,4), COUNT(*))/CONVERT(decimal(10,4), 1440))*100.00) AS PercentageAvailability
FROM 
	#AvailCalc


DROP TABLE #AvailCalc