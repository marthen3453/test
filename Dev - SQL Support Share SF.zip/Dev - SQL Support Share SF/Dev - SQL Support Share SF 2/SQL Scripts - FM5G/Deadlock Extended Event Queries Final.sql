WITH SessionData AS (
 SELECT 
  XEventData.XEvent.value('(data/value)[1]', 'varchar(max)') VarcharResults
  , CAST(REPLACE(REPLACE(XEventData.XEvent.value('(data/value)[1]', 'varchar(max)'), '', ''), '','') AS XML) AS DeadlockGraph
 FROM (
   select CAST(target_data as xml) as TargetData
   from sys.dm_xe_session_targets st
   join sys.dm_xe_sessions s on s.address = st.event_session_address
   where name = 'system_health'
 ) AS Data
 CROSS APPLY TargetData.nodes ('RingBufferTarget/event[@name="xml_deadlock_report"]') AS XEventData (XEvent) 
)
SELECT
	CASE 
		WHEN (CHARINDEX('lasttranstarted', VarcharResults, 1) > 0) THEN SUBSTRING(VarcharResults, CHARINDEX('lasttranstarted="', VarcharResults) + len('lasttranstarted="'),19)
		ELSE SUBSTRING(VarcharResults, CHARINDEX('lastbatchstarted="', VarcharResults) + len('lastbatchstarted="'),19)
	END AS DeadlockDate
	, DeadlockGraph
FROM
	SessionData
WHERE
	CHARINDEX('victimProcess id', VarcharResults, 1) > 0
AND
	(CHARINDEX('lasttranstarted', VarcharResults, 1) > 0 OR CHARINDEX('lastbatchstarted', VarcharResults, 1) > 0)
ORDER BY 1 DESC;



--select * from fn_get_sql(0x0300050094d12f5049a24001d5a100000100000000000000)