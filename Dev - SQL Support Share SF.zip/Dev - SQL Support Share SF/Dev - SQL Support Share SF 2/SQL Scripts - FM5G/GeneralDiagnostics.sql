-- read error log first argument determines the log (0 = current log)
xp_readerrorlog 0, 1

--  Get logins that are connected and how many sessions they have (Query 28) (Connection Counts)
SELECT login_name, [program_name], COUNT(session_id) AS [session_count] 
FROM sys.dm_exec_sessions WITH (NOLOCK)
GROUP BY login_name, [program_name]
ORDER BY COUNT(session_id) DESC OPTION (RECOMPILE);


-- Get Average Task Counts (run multiple times)  (Query 29) (Avg Task Counts)
SELECT AVG(current_tasks_count) AS [Avg Task Count], 
AVG(runnable_tasks_count) AS [Avg Runnable Task Count],
AVG(pending_disk_io_count) AS [Avg Pending DiskIO Count]
FROM sys.dm_os_schedulers WITH (NOLOCK)
WHERE scheduler_id < 255 OPTION (RECOMPILE);

-- Sustained values above 10 suggest further investigation in that area
-- High Avg Task Counts are often caused by blocking or other resource contention
-- High Avg Runnable Task Counts are a good sign of CPU pressure
-- High Avg Pending DiskIO Counts are a sign of disk pressure


-- Get Table names, row counts, and compression status for clustered index or heap  (Query 53) (Table Sizes)
SELECT OBJECT_NAME(object_id) AS [ObjectName], 
SUM(Rows) AS [RowCount], data_compression_desc AS [CompressionType]
FROM sys.partitions WITH (NOLOCK)
WHERE index_id < 2 --ignore the partitions from the non-clustered index if any
AND OBJECT_NAME(object_id) NOT LIKE N'sys%'
AND OBJECT_NAME(object_id) NOT LIKE N'queue_%' 
AND OBJECT_NAME(object_id) NOT LIKE N'filestream_tombstone%' 
AND OBJECT_NAME(object_id) NOT LIKE N'fulltext%'
AND OBJECT_NAME(object_id) NOT LIKE N'ifts_comp_fragment%'
AND OBJECT_NAME(object_id) NOT LIKE N'filetable_updates%'
AND OBJECT_NAME(object_id) NOT LIKE N'xml_index_nodes%'
GROUP BY object_id, data_compression_desc
ORDER BY SUM(Rows) DESC OPTION (RECOMPILE);

-- Gives you an idea of table sizes, and possible data compression opportunities


-- Get some key table properties (Query 54) (Table Properties)
SELECT t.[name], 
		t.create_date, 
		t.lock_on_bulk_load, 
		t.is_replicated, 
		t.has_replication_filter, 
       t.is_tracked_by_cdc, 
	   t.lock_escalation_desc--, 
	   --t.durability_desc, 
	  -- t.is_memory_optimized
FROM sys.tables AS t WITH (NOLOCK) 
ORDER BY t.name OPTION (RECOMPILE);

-- Get estimate duration from sys.dm_exec_requests
SELECT command,
s.text ,
start_time,
percent_complete,
CAST(((DATEDIFF (s, start_time,GetDate ()))/3600) as varchar) + ' hour(s), '
+ CAST ((DATEDIFF( s,start_time ,GetDate())% 3600)/60 as varchar ) + 'min, '
+ CAST ((DATEDIFF( s,start_time ,GetDate())% 60) as varchar ) + ' sec' as running_time,
CAST((estimated_completion_time /3600000) as varchar) + ' hour(s), '
+ CAST ((estimated_completion_time % 3600000)/60000 as varchar ) + 'min, '
+ CAST ((estimated_completion_time % 60000)/1000 as varchar ) + ' sec' as est_time_to_go,
dateadd(second ,estimated_completion_time/ 1000, getdate()) as est_completion_time
FROM sys.dm_exec_requests r
CROSS APPLY sys.dm_exec_sql_text(r .sql_handle) s
WHERE r. command = 'BACKUP DATABASE'
--in ('RESTORE DATABASE', 'BACKUP DATABASE', 'RESTORE LOG', 'BACKUP LOG')



