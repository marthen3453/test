EXECUTE AS LOGIN = 'SFSA'
--Will Create Table
USE [SF_SQL_Admin]
GO

/****** Object:  Table [dbo].[Perf_CounterData_AG_State_Monitor]    Script Date: 7/25/2017 1:31:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Perf_CounterData_AG_State_Monitor](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[CollectionTime] [datetime] NOT NULL,
	[AGGroupName] [sysname] NOT NULL,
	[InstanceName] [nvarchar](256) NOT NULL,
	[role_desc] [nvarchar](60) NOT NULL,
	[synchronization_state] [tinyint] NOT NULL,
	[SyncState] [nvarchar](60) NOT NULL,
	[availability_mode] [tinyint] NOT NULL,
	[SyncMode] [nvarchar](60) NOT NULL,
	[RedoRate] [bigint] NULL,
	[Redo Queue Size] [bigint] NULL,
	[Database Name] [nvarchar](255) NOT NULL
 CONSTRAINT [PK_Perf_CounterData_AG_State_Monitor] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


----------------------------------------------------------------------------------
--Will Create PROC

USE [SF_SQL_Admin]
GO

/****** Object:  StoredProcedure [dbo].[Perf_CounterData_AG_State_Monitor_SP]    Script Date: 7/25/2017 1:30:29 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



 Create Procedure [dbo].[Perf_CounterData_AG_State_Monitor_SP]

 (@maxLatency INT = 60)
 AS 
  
IF EXISTS (
		SELECT *
		FROM sys.dm_hadr_availability_replica_states ars
		WHERE ars.ROLE = 1
		)
BEGIN
	IF (
			SELECT COUNT(*)
			FROM sys.dm_hadr_database_replica_states drs
			LEFT JOIN sys.availability_replicas ar ON drs.replica_id = ar.replica_id
			LEFT JOIN sys.availability_groups ags ON ar.group_id = ags.group_id
			LEFT JOIN sys.dm_hadr_availability_replica_states hars ON ar.group_id = hars.group_id
				AND ar.replica_id = hars.replica_id
			WHERE (
					(
						ar.availability_mode_desc = 'SYNCHRONOUS_COMMIT'
						AND drs.synchronization_state_desc <> 'SYNCHRONIZED'
						) OR  (ar.availability_mode_desc = 'ASYNCHRONOUS_COMMIT'
						AND drs.synchronization_state_desc <> 'SYNCHRONIZING')
					)
			) > 0
	BEGIN
		INSERT INTO Perf_CounterData_AG_State_Monitor
		SELECT DISTINCT getdate() AS CollectionTime
			,ags.NAME AS AGGroupName
			,ar.replica_server_name AS InstanceName
			,hars.role_desc
			,drs.synchronization_state
			,drs.synchronization_state_desc AS SyncState
			,ar.availability_mode
			,ar.availability_mode_desc AS SyncMode
			,drs.redo_rate AS RedoRate
			,drs.redo_queue_size AS [Redo Queue Size]
			,db_name(drs.database_id) as [Database Name]
		--INTO Perf_CounterData_AG_State_Monitor (Use to create table in SF_SQL_ADMIN. Comment above insert, uncomment this to create table.)
		FROM sys.dm_hadr_database_replica_states drs
		LEFT JOIN sys.availability_replicas ar ON drs.replica_id = ar.replica_id
		LEFT JOIN sys.availability_groups ags ON ar.group_id = ags.group_id
		LEFT JOIN sys.dm_hadr_availability_replica_states hars ON ar.group_id = hars.group_id
			AND ar.replica_id = hars.replica_id
		WHERE (
				(
					ar.availability_mode_desc = 'SYNCHRONOUS_COMMIT'
					AND drs.synchronization_state_desc <> 'SYNCHRONIZED'
					) OR  (ar.availability_mode_desc = 'ASYNCHRONOUS_COMMIT'
					AND drs.synchronization_state_desc <> 'SYNCHRONIZING')
				)

		IF (
				SELECT COUNT(*)
				FROM sys.dm_hadr_database_replica_states drs
				LEFT JOIN sys.availability_replicas ar ON drs.replica_id = ar.replica_id
				LEFT JOIN sys.availability_groups ags ON ar.group_id = ags.group_id
				LEFT JOIN sys.dm_hadr_availability_replica_states hars ON ar.group_id = hars.group_id
					AND ar.replica_id = hars.replica_id
				WHERE (
						(
							ar.availability_mode_desc = 'SYNCHRONOUS_COMMIT'
							AND drs.synchronization_state_desc <> 'SYNCHRONIZED'
							) OR  (ar.availability_mode_desc = 'ASYNCHRONOUS_COMMIT'
							AND drs.synchronization_state_desc <> 'SYNCHRONIZING')
						)
					AND ((drs.log_send_queue_size / NULLIF(drs.log_send_rate, 0)) / 60) >= @maxLatency
				) > 0
		BEGIN
			EXEC xp_logevent 98766
				,"SQL AG HEALTH CHECK FAIELD. PLEASE SEE SF_SQL_Admin.Perf_CounterData_AG_State_Monitor"
				,ERROR;
		END
	END
END


GO

----------------------------------------------------------------------------------
--Will Create Job

USE [msdb]
GO

/****** Object:  Job [SF_SQL_Admin Perf CounterData AG State Monitor Job]    Script Date: 7/25/2017 1:32:14 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 7/25/2017 1:32:14 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SF_SQL_Admin Perf CounterData AG State Monitor Job', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sfsa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Step 1]    Script Date: 7/25/2017 1:32:14 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Step 1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec Perf_CounterData_AG_State_Monitor_SP', 
		@database_name=N'SF_SQL_Admin', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every min', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20170725, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'5c63bcf7-5ddd-40f3-b1e7-5365cd0204ee'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
